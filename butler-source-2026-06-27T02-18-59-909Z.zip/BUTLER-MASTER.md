# Butler AI — Master Source Bundle

> Generated 2026-06-27T02:18:59.718Z
> 148 files · 0 active runtime override(s)

## How to edit

1. Edit any code block below directly (keep the fenced \`\`\`<lang> path=<file> markers intact).
2. Convert your edited file(s) into JSON of the shape:

    ```json
    { "files": { "src/routes/home.tsx": "<new source>", "...": "..." } }
    ```

3. Upload that JSON via the **IMPORT SOURCE JSON** button. The new code becomes the active runtime override (the original bundle stays untouched).

---

### `/.gitignore`

``` path=/.gitignore
# Logs
logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*
lerna-debug.log*

node_modules
dist
dist-ssr
.output
.vinxi
.tanstack/**
.nitro
*.local

# Wrangler / Cloudflare
.wrangler/
.dev.vars

# Editor directories and files
.vscode/*
!.vscode/extensions.json
.idea
.DS_Store
*.suo
*.ntvs*
*.njsproj
*.sln
*.sw?

```


### `/.prettierignore`

``` path=/.prettierignore
node_modules
dist
.output
.vinxi
pnpm-lock.yaml
package-lock.json
bun.lock
routeTree.gen.ts

```


### `/.prettierrc`

``` path=/.prettierrc
{
  "printWidth": 100,
  "semi": true,
  "singleQuote": false,
  "trailingComma": "all"
}

```


### `/AGENTS.md`

```md path=/AGENTS.md
<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

```


### `/PLAYSTORE.md`

```md path=/PLAYSTORE.md
# Butler AI — Play Store Submission Guide

This project is now Play-Store-ready as a **Trusted Web Activity (TWA)**. The Play Store binary is built by GitHub Actions from your published Lovable URL.

## What's already done

- `public/manifest.webmanifest` — PWA manifest (required for TWA).
- `public/icon-512.png` — 512×512 app icon.
- `public/robots.txt` + `public/sitemap.xml` — SEO basics.
- `public/.well-known/assetlinks.json` — Digital Asset Links (needs your package + SHA256).
- `twa-manifest.json` — Bubblewrap config.
- `.github/workflows/build-aab.yml` — CI that produces a **signed `.aab`** you upload to Play Console.
- Real legal pages live at `/legal/privacy`, `/legal/terms`, `/legal/safety`, `/legal/delete`.
- Root metadata, OG tags, theme colors set to real Butler AI values (no "Lovable App" defaults).

## One-time setup (15 minutes)

### 1. Publish the web app
Click **Publish** in Lovable. Note your URL (e.g. `butler-ai.lovable.app`) or connect a custom domain. The TWA opens this URL inside a Chrome shell — it MUST be HTTPS and publicly reachable.

### 2. Pick a Play Store package ID
Reverse-DNS, lowercase, unchangeable after first upload. Example: `com.shawnjan.butlerai`.

### 3. Generate a signing keystore (local machine, once)
```bash
keytool -genkeypair -v -keystore android.keystore -alias android \
  -keyalg RSA -keysize 2048 -validity 10000
# remember the passwords you choose
base64 -w0 android.keystore > keystore.b64.txt
```

### 4. Add three GitHub Actions secrets
In your repo → Settings → Secrets and variables → Actions:
- `ANDROID_KEYSTORE_BASE64` — contents of `keystore.b64.txt`
- `ANDROID_KEYSTORE_PASSWORD` — store password from step 3
- `ANDROID_KEY_PASSWORD` — key password from step 3

### 5. Fill in the three `REPLACE_WITH_…` placeholders
- `twa-manifest.json` → `packageId`, `host`, and all `REPLACE_WITH_YOUR_PUBLISHED_DOMAIN` strings.
- `public/.well-known/assetlinks.json` → `package_name` (the SHA256 comes from step 7).

### 6. Build the AAB
Push a tag, or run the workflow manually:
```bash
git tag v1.0.0 && git push --tags
```
GitHub Actions produces `app-release-bundle.aab`. Download it from the Actions artifacts.

### 7. Upload to Play Console
- Create app → upload the `.aab` to Internal Testing first.
- After upload, Play Console → Setup → App Integrity gives you the **SHA-256 cert fingerprint**.
- Paste it into `public/.well-known/assetlinks.json` and republish the web app. Without this, the TWA will show a Chrome address bar (which Play Store rejects for production).

### 8. Fill out the Play Console listing
- **Privacy Policy URL**: `https://YOUR-DOMAIN/legal/privacy`
- **Data Safety form**: Butler AI collects no data → check "No data collected". Reference `/legal/safety`.
- **Account deletion URL**: `https://YOUR-DOMAIN/legal/delete`
- **Content rating**: complete the IARC questionnaire (this app is utility, no UGC).
- **Target audience**: 18+ (matches existing legal copy).
- **App category**: Productivity.

## Anything region-locked? No.

- No hardcoded IPs in shipping code (LAN discovery probes the user's *own* network at runtime).
- No owner-specific emails baked into UI — contact addresses come from the JSON override system, so each deployer can set their own.
- The PC server companion (`butler_server_*.py`) is optional and runs on the user's own machine; the mobile app works standalone.

## Updating the app

Web changes go live the instant you click Publish — no Play Store re-submission needed. Only re-upload an AAB when you bump the version code in `twa-manifest.json` (e.g. native permissions change).

```


### `/bunfig.toml`

```toml path=/bunfig.toml
[install]
# 24h supply-chain guard: skip package versions published less than a day ago.
minimumReleaseAge = 86400
# Each entry bypasses the 24h guard for one package — confirm with the user
# before adding any.
minimumReleaseAgeExcludes = ["@lovable.dev/vite-tanstack-config", "@lovable.dev/mcp-js", "@lovable.dev/vite-plugin-dev-server-bridge", "@lovable.dev/vite-plugin-hmr-gate"]

```


### `/components.json`

```json path=/components.json
{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "new-york",
  "rsc": false,
  "tsx": true,
  "tailwind": {
    "css": "src/styles.css",
    "baseColor": "slate",
    "cssVariables": true,
    "prefix": ""
  },
  "iconLibrary": "lucide",
  "rtl": false,
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components/ui",
    "lib": "@/lib",
    "hooks": "@/hooks"
  },
  "registries": {}
}

```


### `/eslint.config.js`

```js path=/eslint.config.js
import js from "@eslint/js";
import eslintPluginPrettier from "eslint-plugin-prettier/recommended";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import tseslint from "typescript-eslint";

export default tseslint.config(
  { ignores: ["dist", ".output", ".vinxi"] },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    plugins: {
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      "no-restricted-imports": [
        "error",
        {
          paths: [
            {
              name: "server-only",
              message:
                "TanStack Start does not use the Next.js `server-only` package. Rename the module to `*.server.ts` or mark it with `@tanstack/react-start/server-only`.",
            },
          ],
        },
      ],
      "react-refresh/only-export-components": ["warn", { allowConstantExport: true }],
      "@typescript-eslint/no-unused-vars": "off",
    },
  },
  eslintPluginPrettier,
);

```


### `/package.json`

```json path=/package.json
{
  "name": "tanstack_start_ts",
  "private": true,
  "sideEffects": false,
  "type": "module",
  "scripts": {
    "dev": "vite dev",
    "build": "vite build",
    "build:dev": "vite build --mode development",
    "preview": "vite preview",
    "lint": "eslint .",
    "format": "prettier --write ."
  },
  "dependencies": {
    "@ai-sdk/openai-compatible": "^2.0.51",
    "@ai-sdk/react": "^3.0.211",
    "@hookform/resolvers": "^5.2.2",
    "@radix-ui/react-accordion": "^1.2.12",
    "@radix-ui/react-alert-dialog": "^1.1.15",
    "@radix-ui/react-aspect-ratio": "^1.1.8",
    "@radix-ui/react-avatar": "^1.1.11",
    "@radix-ui/react-checkbox": "^1.3.3",
    "@radix-ui/react-collapsible": "^1.1.12",
    "@radix-ui/react-context-menu": "^2.2.16",
    "@radix-ui/react-dialog": "^1.1.15",
    "@radix-ui/react-dropdown-menu": "^2.1.16",
    "@radix-ui/react-hover-card": "^1.1.15",
    "@radix-ui/react-label": "^2.1.8",
    "@radix-ui/react-menubar": "^1.1.16",
    "@radix-ui/react-navigation-menu": "^1.2.14",
    "@radix-ui/react-popover": "^1.1.15",
    "@radix-ui/react-progress": "^1.1.8",
    "@radix-ui/react-radio-group": "^1.3.8",
    "@radix-ui/react-scroll-area": "^1.2.10",
    "@radix-ui/react-select": "^2.2.6",
    "@radix-ui/react-separator": "^1.1.8",
    "@radix-ui/react-slider": "^1.3.6",
    "@radix-ui/react-slot": "^1.2.4",
    "@radix-ui/react-switch": "^1.2.6",
    "@radix-ui/react-tabs": "^1.1.13",
    "@radix-ui/react-toggle": "^1.1.10",
    "@radix-ui/react-toggle-group": "^1.1.11",
    "@radix-ui/react-tooltip": "^1.2.8",
    "@tailwindcss/vite": "^4.2.1",
    "@tanstack/react-query": "^5.83.0",
    "@tanstack/react-router": "^1.168.25",
    "@tanstack/react-start": "^1.167.50",
    "@tanstack/router-plugin": "^1.167.28",
    "ai": "^6.0.209",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "cmdk": "^1.1.1",
    "date-fns": "^4.1.0",
    "embla-carousel-react": "^8.6.0",
    "input-otp": "^1.4.2",
    "jszip": "^3.10.1",
    "lucide-react": "^0.575.0",
    "react": "^19.2.0",
    "react-day-picker": "^9.14.0",
    "react-dom": "^19.2.0",
    "react-hook-form": "^7.71.2",
    "react-resizable-panels": "^4.6.5",
    "recharts": "^2.15.4",
    "sonner": "^2.0.7",
    "tailwind-merge": "^3.5.0",
    "tailwindcss": "^4.2.1",
    "tw-animate-css": "^1.3.4",
    "vaul": "^1.1.2",
    "vite-tsconfig-paths": "^6.0.2",
    "zod": "^3.24.2"
  },
  "devDependencies": {
    "@eslint/js": "^9.32.0",
    "@lovable.dev/vite-tanstack-config": "2.6.2",
    "@types/node": "^22.16.5",
    "@types/react": "^19.2.0",
    "@types/react-dom": "^19.2.0",
    "@vitejs/plugin-react": "^5.2.0",
    "eslint": "^9.32.0",
    "eslint-config-prettier": "^10.1.1",
    "eslint-plugin-prettier": "^5.2.6",
    "eslint-plugin-react-hooks": "^5.2.0",
    "eslint-plugin-react-refresh": "^0.4.20",
    "globals": "^15.15.0",
    "nitro": "3.0.260603-beta",
    "prettier": "^3.7.3",
    "typescript": "^5.8.3",
    "typescript-eslint": "^8.56.1",
    "vite": "^8.0.16"
  }
}

```


### `/public/manifest.webmanifest`

```json path=/public/manifest.webmanifest
{
  "name": "Butler AI",
  "short_name": "Butler AI",
  "description": "Butler AI — cyberpunk command deck for personal PC automation. Runs locally on your devices, no data leaves you.",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "orientation": "portrait",
  "background_color": "#05080d",
  "theme_color": "#22c55e",
  "categories": ["productivity", "utilities"],
  "icons": [
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "maskable"
    }
  ]
}

```


### `/public/robots.txt`

``` path=/public/robots.txt
User-agent: *
Allow: /
Disallow: /api/

Sitemap: /sitemap.xml

```


### `/src/components/ActivityFeed.tsx`

```ts path=/src/components/ActivityFeed.tsx
import { useEffect, useState } from "react";
import { Activity, AlertTriangle, CheckCircle2, Info, XCircle } from "lucide-react";
import { loadLog, type ExecRecord } from "@/lib/execlog";

function relTime(ts: number) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  return `${Math.floor(s / 86400)}d`;
}

const ICON = {
  success: CheckCircle2,
  info: Info,
  warn: AlertTriangle,
  error: XCircle,
} as const;

const TONE = {
  success: "var(--success)",
  info: "var(--cyan)",
  warn: "var(--warning)",
  error: "var(--danger)",
} as const;

export function ActivityFeed({ limit = 6 }: { limit?: number }) {
  const [items, setItems] = useState<ExecRecord[]>([]);
  useEffect(() => {
    const refresh = () => setItems(loadLog().slice(0, limit));
    refresh();
    const id = setInterval(refresh, 4000);
    window.addEventListener("butler:log", refresh as any);
    return () => { clearInterval(id); window.removeEventListener("butler:log", refresh as any); };
  }, [limit]);

  if (!items.length) {
    return (
      <div className="flex items-center gap-2 text-[11px] text-muted-foreground font-mono py-1">
        <Activity className="size-3.5" /> No activity yet.
      </div>
    );
  }

  return (
    <ul className="space-y-1.5">
      {items.map((r) => {
        const Icon = ICON[r.level];
        const color = TONE[r.level];
        return (
          <li key={r.id} className="flex items-start gap-2 panel p-2">
            <Icon className="size-3.5 mt-0.5 shrink-0" style={{ color }} />
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-display text-[11px] font-bold truncate">{r.title}</span>
                <span className="font-mono text-[9px] text-muted-foreground shrink-0">{relTime(r.ts)}</span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-muted-foreground font-mono">
                <span className="uppercase tracking-[0.14em]">{r.source}</span>
                {r.detail ? <span className="truncate">· {r.detail}</span> : null}
              </div>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

```


### `/src/components/AppShell.tsx`

```ts path=/src/components/AppShell.tsx
import { Link } from "@tanstack/react-router";
import {
  Home, Code2, User, Network, FolderClosed, ScrollText,
  Wrench, Headphones, Settings as SettingsIcon, Circle,
} from "lucide-react";
import type { ReactNode } from "react";
import { AskBar } from "@/components/AskBar";
import { TopBar } from "@/components/TopBar";


type ActiveKey =
  | "home" | "scripts" | "butler" | "knowledge" | "files"
  | "logs" | "builder" | "support" | "settings"
  | "run" | "ai" | "cfg" | "term";

const ALIAS: Record<string, ActiveKey> = {
  run: "scripts", ai: "butler", term: "logs", cfg: "settings",
};


export function AppShell({ children, active }: { children: ReactNode; active?: ActiveKey }) {
  const a: ActiveKey | undefined = active ? ((ALIAS[active as string] ?? active) as ActiveKey) : undefined;
  return (
    <main
      className="relative min-h-screen overflow-x-clip text-foreground"
      style={{
        background:
          "radial-gradient(ellipse 88% 44% at 50% -10%, color-mix(in oklab, var(--cyan) 18%, transparent), transparent 62%)," +
          "radial-gradient(ellipse 70% 44% at 100% 100%, color-mix(in oklab, var(--magenta) 12%, transparent), transparent 64%)," +
          "linear-gradient(180deg, var(--ink) 0%, var(--background) 52%, var(--ink-deep) 100%)",
      }}
    >
      {/* === themed cyberpunk backdrop === */}
      {/* deep radial bloom */}
      {/* circuit grid */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.10]"
           style={{
             backgroundImage:
                "linear-gradient(color-mix(in oklab, var(--cyan) 55%, transparent) 1px, transparent 1px)," +
                "linear-gradient(90deg, color-mix(in oklab, var(--cyan) 55%, transparent) 1px, transparent 1px)",
              backgroundSize: "46px 46px, 46px 46px",
           }} />
      {/* faint hex/diagonal traces */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.08]"
           style={{
             backgroundImage:
               "repeating-linear-gradient(60deg, color-mix(in oklab, var(--magenta) 50%, transparent) 0 1px, transparent 1px 28px)," +
               "repeating-linear-gradient(-60deg, color-mix(in oklab, var(--cyan) 40%, transparent) 0 1px, transparent 1px 36px)",
           }} />

      {/* static scanline veil (cheap, no repaint) */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.12]"
           style={{
             backgroundImage: "repeating-linear-gradient(180deg, transparent 0 2px, color-mix(in oklab, var(--cyan) 6%, transparent) 2px 3px)",
           }} />
      {/* static neon edge accents */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[2px]"
           style={{ background: "linear-gradient(90deg, transparent, var(--cyan) 30%, var(--magenta) 70%, transparent)", opacity: 0.55 }} />
      <div className="pointer-events-none absolute inset-x-0 bottom-[58px] h-[1px]"
           style={{ background: "linear-gradient(90deg, transparent, var(--magenta), transparent)", opacity: 0.5 }} />
      <div className="relative mx-auto flex max-w-md flex-col gap-3 px-3 pb-[140px] pt-2">
        <TopBar />
        {children}

        <AskBar />
        <nav className="fixed inset-x-0 bottom-0 z-40" style={{ touchAction: "pan-y" }}>
          <div className="mx-auto flex max-w-md items-stretch justify-between gap-[2px] border-t border-[color:var(--border)] bg-[var(--ink-2)] px-1 py-1.5">
            <Tab to="/home"      icon={<Home className="h-[16px] w-[16px]" />}        label="CORE"    color="cyan"    active={a === "home"} />
            <Tab to="/run"       icon={<Code2 className="h-[16px] w-[16px]" />}       label="OPS"     color="violet"  active={a === "scripts"} />
            <Tab to="/ai"        icon={<User className="h-[16px] w-[16px]" />}        label="BUTLR"   color="cyan"    active={a === "butler"} />
            <Tab to="/knowledge" icon={<Network className="h-[16px] w-[16px]" />}     label="KB"      color="green"   active={a === "knowledge"} />
            <Tab to="/intel"     icon={<ScrollText className="h-[16px] w-[16px]" />}  label="INTEL"   color="amber"   active={a === "logs"} />
            <Tab to="/files"     icon={<FolderClosed className="h-[16px] w-[16px]"/>} label="VAULT"   color="cyan"    active={a === "files"} />
            <Tab to="/builder"   icon={<Wrench className="h-[16px] w-[16px]" />}      label="FORGE"   color="violet"  active={a === "builder"} />
            <Tab to="/support"   icon={<Headphones className="h-[16px] w-[16px]" />}  label="LINK"    color="cyan"    active={a === "support"} />
            <Tab to="/settings"  icon={<SettingsIcon className="h-[16px] w-[16px]"/>} label="CONF"    color="cyan"    active={a === "settings"} />
          </div>
        </nav>


      </div>
    </main>
  );
}

const COLOR_VAR: Record<string, string> = {
  cyan: "var(--cyan)", violet: "var(--magenta)", green: "var(--green)", amber: "var(--orange)", red: "var(--red)",
};
function Tab({ to, icon, label, color, active }: { to: string; icon: ReactNode; label: string; color: string; active?: boolean }) {
  return (
    <Link
      to={to as any}
      data-active={active ? "true" : "false"}
      className="hex-tab flex-1 basis-0"
      style={{ ["--c" as any]: COLOR_VAR[color] ?? "var(--cyan)" }}
    >
      {icon}
      <span className="font-display text-[7.5px] font-extrabold tracking-[0.12em]">{label}</span>
    </Link>
  );
}


export function SectionTitle({ icon, color, label }: { icon: ReactNode; color: string; label: string }) {
  return (
    <div className="flex items-center gap-2" style={{ color: `var(--${color})` }}>
      {icon}
      <span className="font-display text-[11px] font-extrabold tracking-[0.25em]">{label}</span>
    </div>
  );
}

/** Cyberpunk page header — centered title + butler badge (no side menu) */
export function PageHeader({ title, sub, color = "cyan" }: { title: string; sub?: string; color?: string }) {
  const c = `var(--${color})`;
  return (
    <header className="panel-cyber flex items-center gap-3 px-3 py-3" style={{ ["--c" as any]: c }}>
      <div className="flex-1 text-center">
        <div className="font-display text-[18px] font-extrabold tracking-[0.32em]" style={{ color: c, textShadow: `0 0 14px ${c}` }}>
          {title}
        </div>
        {sub && <div className="font-mono text-[9px] tracking-[0.4em] text-foreground/60">{sub}</div>}
      </div>
      <div className="flex items-center gap-2 rounded-sm border border-[color:var(--border)] bg-[var(--ink-3)] px-2 py-1">
        <div className="grid h-7 w-7 place-items-center rounded-sm bg-gradient-to-br from-[#1a2230] to-[#06080d] text-cyan">
          <User className="h-4 w-4" />
        </div>
        <div className="flex flex-col leading-tight">
          <span className="font-display text-[9px] font-bold tracking-widest text-foreground/80">BUTLER</span>
          <span className="flex items-center gap-1 font-mono text-[8px] tracking-widest text-[color:var(--green)]">
            <Circle className="h-1.5 w-1.5 fill-current" /> ONLINE
          </span>
        </div>
      </div>
    </header>
  );
}

```


### `/src/components/AskBar.tsx`

```ts path=/src/components/AskBar.tsx
import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Send, Sparkles, Circle } from "lucide-react";

const HINTS = [
  "clean my temp files",
  "list top 10 RAM processes",
  "sort Downloads by file type",
  "why is my CPU spiking?",
  "scan my LAN",
  "format Python files in this folder",
];

/**
 * Slim AI chat dock pinned above the bottom toolbar.
 * Rotates suggestion via CSS only (no JS interval = zero re-render cost).
 */
export function AskBar() {
  const navigate = useNavigate();
  const [v, setV] = useState("");
  // SSR-safe: deterministic on first render, randomised after mount so hydration matches.
  const [idx, setIdx] = useState(0);
  useEffect(() => { setIdx(Math.floor(Math.random() * HINTS.length)); }, []);
  const placeholder = `ASK BUTLER — "${HINTS[idx]}"`;

  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const q = v.trim();
    void navigate({ to: "/ai", search: q ? { q } : undefined } as any);
    setV("");
  };

  return (
    <div className="fixed inset-x-0 bottom-[58px] z-30 pointer-events-none" style={{ touchAction: "pan-y" }}>
      <div className="mx-auto max-w-md px-2 pointer-events-auto" style={{ touchAction: "pan-y" }}>
        <form onSubmit={submit}
              className="panel-cyber flex items-center gap-2 px-2 py-1.5"
              style={{ ["--c" as any]: "var(--magenta)" }}>
          <span className="relative grid h-7 w-7 shrink-0 place-items-center rounded-sm border border-[color:var(--border)] bg-[var(--ink)] text-[color:var(--magenta)]">
            <Sparkles className="h-3.5 w-3.5" />
            <Circle className="pulse-dot absolute -right-0.5 -top-0.5 h-1.5 w-1.5 fill-[color:var(--green)] text-[color:var(--green)]" />
          </span>
          <input
            value={v}
            onChange={(e) => setV(e.target.value)}
            placeholder={placeholder}
            className="min-w-0 flex-1 bg-transparent font-mono text-[11px] tracking-[0.04em] text-foreground placeholder:text-foreground/35 focus:outline-none"
          />
          <span className="hidden xs:inline font-mono text-[8.5px] tracking-widest text-foreground/35">⏎</span>
          <button type="submit"
                  className="grid h-7 w-7 shrink-0 place-items-center rounded-sm border text-[color:var(--magenta)]"
                  style={{ borderColor: "color-mix(in oklab, var(--magenta) 60%, transparent)",
                           boxShadow: "0 0 10px -2px var(--magenta)" }}
                  aria-label="Send to Butler">
            <Send className="h-3.5 w-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
}

```


### `/src/components/BarMeter.tsx`

```ts path=/src/components/BarMeter.tsx
export function BarMeter({
  label, value, max = 100, unit = "%", color = "var(--cyan)", detail,
}: {
  label: string;
  value: number | null;
  max?: number;
  unit?: string;
  color?: string;
  detail?: string;
}) {
  const pct = typeof value === "number" ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  return (
    <div>
      <div className="flex items-baseline justify-between text-[11px] mb-1">
        <span className="font-display font-bold tracking-[0.14em] uppercase text-muted-foreground">{label}</span>
        <span className="font-mono tabular-nums font-bold" style={{ color }}>
          {typeof value === "number" ? `${Math.round(value)}${unit}` : "—"}
          {detail ? <span className="text-muted-foreground font-normal ml-1.5">· {detail}</span> : null}
        </span>
      </div>
      <div className="relative h-2.5 rounded-sm overflow-hidden border border-[color:var(--border)] bg-[rgba(77,217,255,0.04)]">
        <div
          className="absolute inset-y-0 left-0 transition-[width] duration-700"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(180deg, ${color} 0%, color-mix(in oklab, ${color} 60%, transparent) 100%)`,
            boxShadow: `0 0 12px ${color}, inset 0 1px 0 rgba(255,255,255,0.25)`,
          }}
        />
        <div className="absolute inset-y-0 left-0 w-full pointer-events-none"
          style={{
            backgroundImage: "repeating-linear-gradient(90deg, rgba(255,255,255,0.05) 0 1px, transparent 1px 8px)",
          }}
        />
      </div>
    </div>
  );
}

```


### `/src/components/BridgeStatus.tsx`

```ts path=/src/components/BridgeStatus.tsx
import { Link } from "@tanstack/react-router";
import { Cpu, Loader2, ShieldOff, Wifi, WifiOff } from "lucide-react";
import { fmtUptime, type Telemetry } from "@/lib/useTelemetry";

export function BridgeStatus({ t }: { t: Telemetry }) {
  if (!t.paired) {
    return (
      <Link to={"/home" as any} className="chip chip-warning">
        <ShieldOff className="size-3" /> Pair PC
      </Link>
    );
  }
  if (!t.online) {
    return (
      <span className="chip chip-danger">
        <WifiOff className="size-3" /> Offline
      </span>
    );
  }
  return (
    <span className="chip chip-success">
      <Wifi className="size-3" /> {t.hostname || "Bridge"}{t.uptime ? ` · ${fmtUptime(t.uptime)}` : ""}
    </span>
  );
}

export function ModelChip({ t }: { t: Telemetry }) {
  if (!t.paired) return null;
  return (
    <span className="chip chip-cyan">
      {t.online ? <Cpu className="size-3" /> : <Loader2 className="size-3 animate-spin" />}
      {t.model || "model"}
    </span>
  );
}

```


### `/src/components/ButlerLive.tsx`

```ts path=/src/components/ButlerLive.tsx
import { useEffect, useMemo, useRef, useState } from "react";
import { Activity, Cpu, HardDrive, Database, Zap, Radio, Brain, Network } from "lucide-react";

function freezeLiveFx() {
  if (typeof window === "undefined") return false;
  const nav = navigator as Navigator & { connection?: { saveData?: boolean } };
  return Boolean(
    nav.connection?.saveData ||
    window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ||
    window.matchMedia?.("(pointer: coarse)").matches ||
    window.matchMedia?.("(max-width: 640px)").matches,
  );
}

/* ============================================================
   Live data sourced/derived from the uploaded Butler AI exports:
   - butler_ai_config_1.json   → scripts roster + security/connection
   - butler_ai_MASTER_v15_0... → palette + tab persona names
   - butler_master_*           → server/HMAC facts
   ============================================================ */

export const BUTLER_SCRIPTS = [
  { id: 1, name: "System Monitor", status: "active",  interval: "1s",            icon: Activity, color: "green"   as const },
  { id: 2, name: "Web Crawler",    status: "idle",    interval: "—",             icon: Radio,    color: "cyan"    as const },
  { id: 3, name: "File Sync",      status: "waiting", interval: "bidirectional", icon: Database, color: "yellow"  as const },
  { id: 4, name: "Brain Trainer",  status: "ready",   interval: "epoch 0",       icon: Brain,    color: "magenta" as const },
];

/* ---------- Live sparkline (CPU / RAM / NET) ---------- */
export function LiveSparkline({
  label, color, base = 32, jitter = 18, unit = "%", icon: Icon,
}: { label: string; color: "cyan"|"green"|"magenta"|"orange"|"yellow"; base?: number; jitter?: number; unit?: string; icon: typeof Cpu }) {
  // SSR-safe: start with deterministic sine wave, then animate client-side
  const [pts, setPts] = useState<number[]>(() =>
    Array.from({ length: 40 }, (_, i) => base + Math.sin(i * 0.35) * (jitter / 2))
  );
  useEffect(() => {
    if (freezeLiveFx()) return;
    setPts(Array.from({ length: 40 }, () => base + (Math.random() - 0.5) * jitter));
    const t = window.setInterval(() => {
      setPts((p) => {
        const next = Math.max(2, Math.min(98, p[p.length - 1] + (Math.random() - 0.5) * 14));
        return [...p.slice(1), next];
      });
    }, 1200);
    return () => window.clearInterval(t);
  }, [base, jitter]);
  const max = 100;
  const w = 100, h = 32;
  const d = pts
    .map((y, i) => `${i === 0 ? "M" : "L"} ${(i / (pts.length - 1)) * w} ${h - (y / max) * h}`)
    .join(" ");
  const last = pts[pts.length - 1].toFixed(0);
  return (
    <div className={`panel relative overflow-hidden p-3 glow-${color}`}>
      <div className="flex items-center justify-between">
        <div className={`flex items-center gap-1.5 text-[10px] tracking-widest text-${color}`}>
          <Icon className="h-3 w-3" /> {label}
        </div>
        <div className={`font-mono text-sm font-bold text-${color}`}>{last}{unit}</div>
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="mt-1.5 h-10 w-full">
        <defs>
          <linearGradient id={`grad-${label}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={`var(--${color})`} stopOpacity=".6" />
            <stop offset="100%" stopColor={`var(--${color})`} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={`${d} L ${w} ${h} L 0 ${h} Z`} fill={`url(#grad-${label})`} />
        <path d={d} fill="none" stroke={`var(--${color})`} strokeWidth="1.2" />
      </svg>
    </div>
  );
}

/* ---------- Telemetry grid for HOME tour ---------- */
export function TelemetryGrid() {
  return (
    <div className="grid grid-cols-3 gap-2">
      <LiveSparkline label="CPU"  color="cyan"    icon={Cpu}      base={28} />
      <LiveSparkline label="RAM"  color="magenta" icon={HardDrive} base={54} />
      <LiveSparkline label="NET"  color="green"   icon={Network}   base={12} unit="MB" />
    </div>
  );
}

/* ---------- Scripts roster sourced from butler_ai_config_1 ---------- */
export function ScriptsRoster() {
  const [pulse, setPulse] = useState(0);
  useEffect(() => {
    if (freezeLiveFx()) return;
    const t = setInterval(() => setPulse((p) => p + 1), 1400);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="panel-cyber overflow-hidden p-2">
      <div className="flex items-center justify-between px-1 pb-1">
        <span className="text-[10px] tracking-widest text-muted-foreground">SCRIPTS · v6.0 ROSTER</span>
        <span className="text-[10px] tracking-widest text-green">{BUTLER_SCRIPTS.length} LOADED</span>
      </div>
      <ul className="divide-y divide-border/40">
        {BUTLER_SCRIPTS.map((s, i) => {
          const Icon = s.icon;
          const live = s.status === "active" && pulse % 2 === 0;
          return (
            <li key={s.id} className="flex items-center gap-3 px-1 py-2">
              <div className={`grid h-8 w-8 place-items-center rounded-md border border-${s.color}/40 bg-${s.color}/5 text-${s.color}`}>
                <Icon className="h-3.5 w-3.5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className={`text-xs font-bold tracking-wider text-${s.color}`}>{s.name}</div>
                <div className="text-[10px] tracking-widest text-muted-foreground">id:{s.id} · {s.interval}</div>
              </div>
              <span className={`flex items-center gap-1 rounded border border-${s.color}/40 bg-${s.color}/10 px-1.5 py-0.5 font-mono text-[9px] tracking-widest text-${s.color}`}>
                <span className={`h-1.5 w-1.5 rounded-full bg-${s.color} ${live ? "pulse-dot" : ""}`} />
                {s.status.toUpperCase()}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/* ---------- SIGMA-NET knowledge graph (animated nodes) ---------- */
export function SigmaNetGraph() {
  // SSR-safe deterministic seed (golden-angle scatter), randomised on mount
  const [nodes, setNodes] = useState(() =>
    Array.from({ length: 14 }, (_, i) => {
      const a = i * 2.399; const r = 6 + (i % 5) * 3;
      return { id: i, x: 50 + Math.cos(a) * r * 3, y: 50 + Math.sin(a) * r * 3, r: 1.8 + (i % 3) * 0.6 };
    })
  );
  useEffect(() => {
    if (freezeLiveFx()) return;
    setNodes(Array.from({ length: 14 }, (_, i) => ({
      id: i, x: 10 + Math.random() * 80, y: 10 + Math.random() * 80, r: 1.6 + Math.random() * 2.2,
    })));
  }, []);
  const edges = useMemo(() => {
    const out: [number, number][] = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y;
        if (Math.hypot(dx, dy) < 28) out.push([i, j]);
      }
    }
    return out;
  }, [nodes]);
  return (
    <div className="panel-cyber relative overflow-hidden p-3 glow-cyan">
      <div className="flex items-center justify-between">
        <span className="text-[10px] tracking-widest text-cyan">SIGMA-NET · LOCAL KB</span>
        <span className="text-[10px] tracking-widest text-muted-foreground">{nodes.length} nodes · {edges.length} edges</span>
      </div>
      <svg viewBox="0 0 100 100" className="mt-2 h-32 w-full">
        {edges.map(([a, b], i) => (
          <line key={i} x1={nodes[a].x} y1={nodes[a].y} x2={nodes[b].x} y2={nodes[b].y}
            stroke="var(--cyan)" strokeOpacity="0.22" strokeWidth="0.35" />
        ))}
        {nodes.map((n, i) => (
          <g key={n.id}>
            <circle cx={n.x} cy={n.y} r={n.r + 1.6} fill="var(--cyan)" opacity="0.15">
              <animate attributeName="r" values={`${n.r + 1.2};${n.r + 2.6};${n.r + 1.2}`} dur={`${2 + (i % 5) * 0.4}s`} repeatCount="indefinite" />
            </circle>
            <circle cx={n.x} cy={n.y} r={n.r} fill="var(--cyan)" />
          </g>
        ))}
      </svg>
    </div>
  );
}

/* ---------- Animated QR pairing tile ---------- */
export function PairingQR() {
  // SSR-safe deterministic pattern, scrambled on mount
  const [cells, setCells] = useState<boolean[]>(() =>
    Array.from({ length: 13 * 13 }, (_, i) => ((i * 73) ^ (i >> 2)) % 3 !== 0)
  );
  useEffect(() => {
    setCells(Array.from({ length: 13 * 13 }, () => Math.random() > 0.5));
  }, []);
  return (
    <div className="panel-cyber grid place-items-center gap-2 p-4 glow-green">
      <div className="grid gap-[1px] rounded-md border border-green/40 bg-background/60 p-2"
        style={{ gridTemplateColumns: "repeat(13, minmax(0, 1fr))" }}>
        {cells.map((on, i) => (
          <span key={i} className={`h-2 w-2 ${on ? "bg-green shadow-[0_0_4px_var(--green)]" : "bg-background/60"}`} />
        ))}
      </div>
      <div className="text-[10px] tracking-widest text-green">SCAN ON YOUR PC · butler_server.py</div>
      <div className="font-mono text-[10px] text-muted-foreground">192.168.1.42:8765 · HMAC-SHA256</div>
    </div>
  );
}

/* ---------- HMAC live signer (cosmetic, marquee) ---------- */
export function HmacMarquee() {
  const [hash, setHash] = useState("");
  useEffect(() => {
    if (freezeLiveFx()) {
      setHash("9f2c7a88d13b44c0a91e00ff88b7aa10");
      return;
    }
    const hex = "0123456789abcdef";
    const t = window.setInterval(() => {
      setHash(Array.from({ length: 32 }, () => hex[Math.floor(Math.random() * 16)]).join(""));
    }, 900);
    return () => window.clearInterval(t);
  }, []);
  return (
    <div className="panel-cyber flex items-center gap-2 overflow-hidden px-3 py-2">
      <Zap className="h-3.5 w-3.5 shrink-0 text-yellow" />
      <span className="text-[10px] tracking-widest text-muted-foreground">HMAC</span>
      <span className="truncate font-mono text-[10px] text-yellow">{hash}</span>
    </div>
  );
}

/* ---------- Boot/health ring (radial gauge) ---------- */
export function HealthRing({ value = 92, label = "HEALTH", color = "green" as "green" | "cyan" | "magenta" }) {
  const ref = useRef<SVGCircleElement>(null);
  const C = 2 * Math.PI * 28;
  useEffect(() => {
    if (!ref.current) return;
    ref.current.style.strokeDashoffset = `${C - (value / 100) * C}`;
  }, [value, C]);
  return (
    <div className={`panel flex items-center gap-3 p-3 glow-${color}`}>
      <svg viewBox="0 0 64 64" className="h-14 w-14 -rotate-90">
        <circle cx="32" cy="32" r="28" fill="none" stroke="currentColor" strokeOpacity="0.15" strokeWidth="5" />
        <circle ref={ref} cx="32" cy="32" r="28" fill="none" stroke={`var(--${color})`} strokeWidth="5"
          strokeDasharray={C} strokeDashoffset={C} strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 1.2s ease-out", filter: `drop-shadow(0 0 6px var(--${color}))` }} />
      </svg>
      <div>
        <div className={`text-lg font-extrabold text-${color}`}>{value}<span className="text-xs">/100</span></div>
        <div className="text-[10px] tracking-widest text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}

```


### `/src/components/Charts.tsx`

```ts path=/src/components/Charts.tsx
/**
 * Charts — zero-dep SVG/CSS charts ported from the CommandCube RN sources.
 *
 * Web ports of:
 *   AreaSparkline · MiniBarChart · ActivityBarChart · CircRing
 *   StorageDonut · DiskProgressBar · MetricLineChart · DomainBreakdownChart
 *   ThreatHeatmap · DataStatCard
 *
 * All animation-free (no JS loops / requestAnimationFrame) — pure CSS gradients
 * and static SVG so the cyberpunk shell stays lag-free on low-end phones.
 */
import { useMemo } from "react";

/* ────────────────────────────── AREA SPARKLINE BARS ─ */
export function AreaSparkline({ points, color, height = 60 }: { points: number[]; color: string; height?: number }) {
  const max = Math.max(1, ...points);
  return (
    <div className="flex items-end gap-[1px] overflow-hidden" style={{ height }}>
      {points.map((p, i) => {
        const h = Math.max(3, (p / max) * (height - 4));
        const last = i === points.length - 1;
        const op = last ? 1 : 0.35 + (i / points.length) * 0.6;
        return (
          <div key={i} className="flex-1 rounded-[2px]"
            style={{
              height: h, background: color, opacity: op,
              boxShadow: last ? `0 0 8px ${color}` : undefined,
            }} />
        );
      })}
    </div>
  );
}

/* ────────────────────────────── MINI WEEKDAY BAR CHART ─ */
export function MiniBarChart({ data, color, label }: { data: { day: string; value: number }[]; color: string; label: string }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="space-y-1.5">
      <div className="font-mono text-[9px] tracking-widest text-foreground/55">{label}</div>
      <div className="flex h-14 items-end gap-1">
        {data.map((d, i) => {
          const h = Math.max(4, (d.value / max) * 48);
          return (
            <div key={i} className="flex flex-1 flex-col items-center gap-0.5">
              <div className="flex w-full flex-1 items-end justify-center">
                <div className="w-[80%] rounded-sm"
                  style={{ height: h, background: color, opacity: 0.55 + (i / data.length) * 0.45 }} />
              </div>
              <div className="font-mono text-[8px] text-foreground/55">{d.day}</div>
            </div>
          );
        })}
      </div>
      <div className="flex justify-between font-mono text-[8px]">
        <span className="text-foreground/55">0</span>
        <span style={{ color }}>{max}</span>
      </div>
    </div>
  );
}

/* ────────────────────────────── ACTIVITY BAR CHART (multi-color) ─ */
export function ActivityBarChart({ heights, palette }: { heights?: number[]; palette?: string[] }) {
  const H = heights ?? [45, 70, 30, 85, 55, 40, 75, 60, 50, 65, 42, 78];
  const P = palette ?? ["var(--cyan)", "var(--green)", "var(--magenta)", "var(--orange)", "var(--red)"];
  return (
    <div className="flex h-24 items-end justify-between gap-[3px]">
      {H.map((h, i) => {
        const c = P[i % P.length];
        return (
          <div key={i} className="w-3.5 rounded-sm"
            style={{ height: `${h}%`, background: c, opacity: 0.75 + (i % 3) * 0.08, boxShadow: `0 0 4px ${c}` }} />
        );
      })}
    </div>
  );
}

/* ────────────────────────────── CIRCULAR RING ─ */
export function CircRing({ label, pct, color, size = 84 }: { label: string; pct: number; color: string; size?: number }) {
  const r = (size - 14) / 2;
  const C = 2 * Math.PI * r;
  const dash = (pct / 100) * C;
  return (
    <div className="flex flex-col items-center gap-1.5">
      <div className="relative grid place-items-center" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth="7"
            stroke={`color-mix(in oklab, ${color} 18%, transparent)`} />
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth="7"
            stroke={color} strokeLinecap="round"
            strokeDasharray={`${dash} ${C}`}
            style={{ filter: `drop-shadow(0 0 6px ${color})` }} />
        </svg>
        <div className="absolute font-display font-black tabular-nums" style={{ color, fontSize: size * 0.22 }}>
          {Math.round(pct)}%
        </div>
      </div>
      <div className="font-mono text-[9px] tracking-widest text-foreground/55">{label}</div>
    </div>
  );
}

/* ────────────────────────────── STORAGE DONUT ─ */
export function StorageDonut({ slices, label, sub }: { slices: { color: string; pct: number; label: string }[]; label: string; sub: string }) {
  const segs: string[] = [];
  let acc = 0;
  for (const s of slices) {
    const start = (acc / 100) * 360;
    const end = ((acc + s.pct) / 100) * 360;
    segs.push(`${s.color} ${start}deg ${end}deg`);
    acc += s.pct;
  }
  if (acc < 100) segs.push(`color-mix(in oklab, var(--cyan) 8%, transparent) ${(acc / 100) * 360}deg 360deg`);
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="grid place-items-center rounded-full" style={{
        width: 110, height: 110,
        background: `conic-gradient(${segs.join(", ")})`,
        boxShadow: "0 0 14px color-mix(in oklab, var(--cyan) 30%, transparent)",
      }}>
        <div className="grid h-[78px] w-[78px] place-items-center rounded-full bg-[var(--ink)] border border-[color:var(--border)]">
          <div className="text-center leading-tight">
            <div className="font-display text-[16px] font-black text-foreground">{label}</div>
            <div className="font-mono text-[8px] tracking-widest text-foreground/55">{sub}</div>
          </div>
        </div>
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2">
        {slices.map((s) => (
          <div key={s.label} className="flex items-center gap-1">
            <div className="h-2 w-2 rounded-[2px]" style={{ background: s.color }} />
            <span className="font-mono text-[8.5px] tracking-widest text-foreground/65">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ────────────────────────────── DISK PROGRESS BAR ─ */
export function DiskProgressBar({ label, pct, color }: { label: string; pct: number; color: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="w-10 font-mono text-[10px] font-bold tracking-widest text-foreground/65">{label}</span>
      <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-[#15171c]">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color, boxShadow: `0 0 6px ${color}` }} />
      </div>
      <span className="w-10 text-right font-mono text-[11px] font-black tabular-nums" style={{ color }}>{pct}%</span>
    </div>
  );
}

/* ────────────────────────────── METRIC LINE CHART (SVG area + line) ─ */
export function MetricLineChart({ history, color, height = 64, width = 280, label }: {
  history: number[]; color: string; height?: number; width?: number; label: string;
}) {
  const pts = history.slice(-24);
  if (pts.length < 2) {
    return (
      <div className="grid place-items-center font-mono text-[9px] tracking-widest text-foreground/40" style={{ height }}>NO DATA</div>
    );
  }
  const max = Math.max(...pts, 1);
  const min = Math.min(...pts, 0);
  const range = Math.max(1, max - min);
  const step = width / (pts.length - 1);
  const y = (v: number) => height - ((v - min) / range) * (height - 8) - 4;
  const path = pts.map((v, i) => `${i === 0 ? "M" : "L"}${i * step},${y(v)}`).join(" ");
  const fill = `${path} L${(pts.length - 1) * step},${height} L0,${height} Z`;
  const id = `g_${label.replace(/\W/g, "")}`;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="block h-auto w-full">
      <defs>
        <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.45" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={fill} fill={`url(#${id})`} />
      <path d={path} fill="none" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"
        style={{ filter: `drop-shadow(0 0 4px ${color})` }} />
      <circle cx={(pts.length - 1) * step} cy={y(pts[pts.length - 1])} r="2.6" fill={color}
        style={{ filter: `drop-shadow(0 0 6px ${color})` }} />
    </svg>
  );
}

/* ────────────────────────────── DOMAIN BREAKDOWN BARS ─ */
export function DomainBreakdownChart({ data }: { data: { domain: string; count: number; color: string }[] }) {
  const max = Math.max(1, ...data.map((d) => d.count));
  const CH = 88;
  return (
    <div className="flex items-end gap-2" style={{ height: CH }}>
      {data.slice(0, 8).map((d, i) => {
        const h = Math.max(3, (d.count / max) * (CH - 28));
        return (
          <div key={d.domain} className="flex flex-1 flex-col items-center justify-end gap-1" style={{ height: CH }}>
            <span className="font-mono text-[9px] font-bold tabular-nums" style={{ color: d.color }}>{d.count}</span>
            <div className="w-full rounded-sm"
              style={{ height: h, background: d.color, opacity: i === 0 ? 1 : 0.75, boxShadow: i === 0 ? `0 0 8px ${d.color}` : undefined }} />
            <span className="truncate font-mono text-[8px] font-bold tracking-wider" style={{ color: d.color }}>
              {d.domain.toUpperCase().slice(0, 6)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

/* ────────────────────────────── THREAT HEATMAP (cols × rows) ─ */
export function ThreatHeatmap({ cols = 14, rows = 3, color = "var(--red)", title = "THREAT HEATMAP" }: {
  cols?: number; rows?: number; color?: string; title?: string;
}) {
  const data = useMemo(
    () => Array.from({ length: cols * rows }, (_, i) => (Math.sin(i * 1.7) + 1) / 2),
    [cols, rows],
  );
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 font-mono text-[10px] tracking-widest" style={{ color }}>
        <span className="h-2 w-2 rounded-full" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
        <span className="font-display font-bold">{title}</span>
        <span className="text-foreground/40">· 7D</span>
      </div>
      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
        {data.map((v, i) => {
          const op = v > 0.75 ? 0.9 : v > 0.5 ? 0.55 : v > 0.3 ? 0.3 : 0.12;
          return <div key={i} className="aspect-square rounded-[3px]" style={{ background: color, opacity: op }} />;
        })}
      </div>
      <div className="flex items-center gap-1.5 border-t border-[color:var(--border)] pt-1.5 font-mono text-[8.5px] tracking-widest text-foreground/55">
        <span>LOW</span>
        {[0.12, 0.3, 0.55, 0.9].map((o, i) => (
          <span key={i} className="h-2.5 w-3 rounded-[2px]" style={{ background: color, opacity: o }} />
        ))}
        <span>HIGH</span>
      </div>
    </div>
  );
}

/* ────────────────────────────── DATA STAT CARD ─ */
export function DataStatCard({ title, subtitle, value, statusLabel, statusColor, color, sparkPoints, statRow }: {
  title: string; subtitle: string; value: string; statusLabel: string; statusColor: string; color: string;
  sparkPoints: number[]; statRow: { label: string; value: string }[];
}) {
  return (
    <div className="relative overflow-hidden rounded-md border border-[color:var(--border)] bg-[var(--ink-2)]"
      style={{ boxShadow: `0 6px 20px -10px ${color}` }}>
      <div className="h-[3px]" style={{ background: color }} />
      <div className="flex items-center gap-2.5 px-3 pb-1 pt-3">
        <div className="grid h-9 w-9 place-items-center rounded-md border"
          style={{ borderColor: `color-mix(in oklab, ${color} 40%, transparent)`, background: `color-mix(in oklab, ${color} 12%, transparent)`, color }}>
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 12a9 9 0 1 0 9-9" /><path d="M12 3v9l6 6" />
          </svg>
        </div>
        <div className="flex-1">
          <div className="font-display text-[13px] font-black tracking-wide text-foreground">{title}</div>
          <div className="font-mono text-[9px] tracking-widest text-foreground/55">{subtitle}</div>
        </div>
        <div className="flex items-center gap-1 rounded-md border px-1.5 py-0.5"
          style={{ borderColor: `color-mix(in oklab, ${statusColor} 55%, transparent)`, background: `color-mix(in oklab, ${statusColor} 12%, transparent)` }}>
          <span className="h-1.5 w-1.5 rounded-full pulse-dot" style={{ background: statusColor, boxShadow: `0 0 6px ${statusColor}` }} />
          <span className="font-mono text-[8.5px] font-bold tracking-widest" style={{ color: statusColor }}>{statusLabel}</span>
        </div>
      </div>
      <div className="px-3 font-display text-[40px] font-black leading-none tabular-nums" style={{ color, textShadow: `0 0 14px ${color}` }}>
        {value}
      </div>
      <div className="px-3 pb-2 pt-2">
        <AreaSparkline points={sparkPoints} color={color} height={48} />
      </div>
      <div className="flex border-t border-[color:var(--border)]">
        {statRow.map((s, i) => (
          <div key={i} className={`flex-1 px-3 py-2 ${i < statRow.length - 1 ? "border-r border-[color:var(--border)]" : ""}`}>
            <div className="font-mono text-[8px] font-bold tracking-widest text-foreground/55">{s.label}</div>
            <div className="font-display text-[13px] font-black text-foreground">{s.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

```


### `/src/components/DebugOverlay.tsx`

```ts path=/src/components/DebugOverlay.tsx
import { useEffect, useRef, useState } from "react";

/**
 * Touch + scroll + click diagnostic overlay.
 * Enable with `?debug=1` in URL or `localStorage.setItem('butler.debug','1')`.
 * Toggle visibility via the tiny [D] FAB. Tap [×] to clear log; long-press to disable.
 */
type Row = { t: number; kind: string; info: string };

function describe(el: Element | null): string {
  if (!el) return "<none>";
  const tag = el.tagName.toLowerCase();
  const id = (el as HTMLElement).id ? `#${(el as HTMLElement).id}` : "";
  const cls = typeof (el as HTMLElement).className === "string"
    ? "." + ((el as HTMLElement).className as string).trim().split(/\s+/).slice(0, 2).join(".")
    : "";
  const role = el.getAttribute("role");
  const aria = el.getAttribute("aria-label");
  const txt = (el.textContent || "").trim().slice(0, 24);
  return `${tag}${id}${cls}${role ? `[${role}]` : ""}${aria ? `"${aria}"` : ""}${txt ? ` ⟨${txt}⟩` : ""}`;
}

export function DebugOverlay() {
  const [enabled, setEnabled] = useState(false);
  const [open, setOpen] = useState(true);
  const [rows, setRows] = useState<Row[]>([]);
  const [sy, setSy] = useState(0);
  const buf = useRef<Row[]>([]);
  const raf = useRef<number | null>(null);
  const lastTouchMove = useRef(0);

  // Activate detection (client-only — never runs during SSR)
  useEffect(() => {
    try {
      const url = new URL(window.location.href);
      const flag = url.searchParams.get("debug") === "1"
        || window.localStorage.getItem("butler.debug") === "1";
      if (url.searchParams.get("debug") === "1") {
        window.localStorage.setItem("butler.debug", "1");
      }
      setEnabled(flag);
    } catch { /* noop */ }
  }, []);

  // Instrument
  useEffect(() => {
    if (!enabled) return;
    const push = (kind: string, info: string) => {
      const row: Row = { t: performance.now(), kind, info };
      buf.current = [...buf.current.slice(-49), row];
      if (raf.current == null) {
        raf.current = window.requestAnimationFrame(() => {
          raf.current = null;
          setRows(buf.current);
          setSy(window.scrollY);
        });
      }
    };
    const onTouch = (e: TouchEvent) => {
      if (e.type === "touchmove") {
        const now = performance.now();
        if (now - lastTouchMove.current < 140) return;
        lastTouchMove.current = now;
      }
      const t = e.touches[0] || e.changedTouches[0];
      const target = t ? document.elementFromPoint(t.clientX, t.clientY) : null;
      push(e.type, `(${t?.clientX|0},${t?.clientY|0}) → ${describe(target)}`);
    };
    const onClick = (e: MouseEvent) => {
      push("click", `(${e.clientX},${e.clientY}) → ${describe(e.target as Element)}`);
    };
    const onScroll = () => {
      push("scroll", `y=${window.scrollY|0} h=${document.documentElement.scrollHeight}`);
    };
    const onErr = (e: ErrorEvent) => push("error", String(e.message).slice(0, 80));

    window.addEventListener("touchstart", onTouch, { capture: true, passive: true });
    window.addEventListener("touchmove",  onTouch, { capture: true, passive: true });
    window.addEventListener("touchend",   onTouch, { capture: true, passive: true });
    window.addEventListener("click",      onClick, { capture: true });
    window.addEventListener("scroll",     onScroll, { capture: true, passive: true });
    window.addEventListener("error",      onErr);
    return () => {
      window.removeEventListener("touchstart", onTouch, true);
      window.removeEventListener("touchmove",  onTouch, true);
      window.removeEventListener("touchend",   onTouch, true);
      window.removeEventListener("click",      onClick, true);
      window.removeEventListener("scroll",     onScroll, true);
      window.removeEventListener("error",      onErr);
      if (raf.current != null) cancelAnimationFrame(raf.current);
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-[9999] pointer-events-none font-mono text-[10px] leading-tight">
      {/* FAB toggles */}
      <div className="pointer-events-auto absolute right-2 bottom-[148px] flex flex-col gap-1">
        <button
          onClick={() => setOpen(o => !o)}
          className="grid h-7 w-7 place-items-center rounded-sm border border-emerald-400/60 bg-black/80 text-emerald-300"
          aria-label="Toggle debug overlay"
        >D</button>
        <button
          onClick={() => { buf.current = []; setRows([]); }}
          onContextMenu={(e) => { e.preventDefault(); window.localStorage.removeItem("butler.debug"); setEnabled(false); }}
          className="grid h-7 w-7 place-items-center rounded-sm border border-rose-400/60 bg-black/80 text-rose-300"
          aria-label="Clear / long-press to disable"
        >×</button>
      </div>

      {open && (
        <div className="pointer-events-none mx-2 mb-2 max-h-[40vh] overflow-hidden rounded-md border border-emerald-400/40 bg-black/90 p-2 text-emerald-200">
          <div className="mb-1 flex justify-between text-emerald-300">
            <span>DBG · y={sy} · h={typeof document!=="undefined"?document.documentElement.scrollHeight:0} · {rows.length}</span>
            <span>?debug=1</span>
          </div>
          {rows.slice().reverse().map((r, i) => (
            <div key={rows.length - i} className="truncate">
              <span className="text-cyan-300">{r.kind.padEnd(10)}</span> {r.info}
            </div>
          ))}
          {rows.length === 0 && <div className="text-emerald-300/60">tap, swipe, scroll…</div>}
        </div>
      )}
    </div>
  );
}

```


### `/src/components/JsonImporter.tsx`

```ts path=/src/components/JsonImporter.tsx
import { useEffect, useRef, useState } from "react";
import { Upload, Check, AlertTriangle, FileJson, Download, RotateCcw, Palette, Undo2, FileText, ClipboardCopy, Package } from "lucide-react";
import { toast } from "sonner";
import { loadStored as loadStoredTheme, clearTheme, downloadJson } from "@/lib/themeOverrides";
import {
  importMasterFromText,
  masterTemplate,
  exportCurrentMaster,
  AI_UPGRADE_PROMPT,
  hasUndo,
  undoLast,
  LAST_APPLIED_KEY,
} from "@/lib/appOverrides";

type LastApplied = {
  ts: number;
  source: "json" | "markdown";
  appliedTheme: number;
  appliedText: number;
  appliedFiles: number;
  appliedData: number;
  fileList: string[];
} | null;

/**
 * Master uploader: accepts JSON or Markdown (filename ignored).
 * Auto-applies theme + text + file/data overrides, snapshots previous state,
 * exposes a one-step UNDO, and soft-reloads so changes are visible immediately.
 */
export function JsonImporter() {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [hasTheme, setHasTheme] = useState(false);
  const [canUndo, setCanUndo] = useState(false);
  const [last, setLast] = useState<LastApplied>(null);

  const refreshState = () => {
    setHasTheme(!!loadStoredTheme());
    setCanUndo(hasUndo());
    try {
      const raw = localStorage.getItem(LAST_APPLIED_KEY);
      setLast(raw ? JSON.parse(raw) : null);
    } catch { setLast(null); }
  };

  useEffect(() => {
    refreshState();
    const h = () => refreshState();
    window.addEventListener("butler:master-applied", h);
    return () => window.removeEventListener("butler:master-applied", h);
  }, []);

  const onFile = async (file: File) => {
    setBusy(true); setError(null);
    try {
      const txt = await file.text();
      const r = importMasterFromText(txt, { autoReload: true });
      if (!r.ok) throw new Error(r.error || "Apply failed");
      const total = r.appliedTheme + r.appliedText + r.appliedFiles + r.appliedData;
      toast.success(
        `Applied ${total} change${total === 1 ? "" : "s"} from ${r.source.toUpperCase()} · refreshing…`,
      );
      refreshState();
    } catch (e: any) {
      setError(e?.message ?? "Failed to parse file");
      toast.error(e?.message ?? "Failed to parse file");
    } finally { setBusy(false); }
  };

  const downloadMasterTemplate = () => {
    downloadJson(`butler_master_${Date.now()}.json`, masterTemplate());
    toast.success("Master template downloaded — edit and re-upload");
  };

  const exportCurrent = () => {
    downloadJson(`butler_master_current_${Date.now()}.json`, exportCurrentMaster());
    toast.success("Current master exported — edit offline and re-upload");
  };

  const copyAiPrompt = async () => {
    try {
      await navigator.clipboard.writeText(AI_UPGRADE_PROMPT);
      toast.success("AI upgrade prompt copied to clipboard");
    } catch {
      // Fallback for older browsers / insecure contexts
      const ta = document.createElement("textarea");
      ta.value = AI_UPGRADE_PROMPT;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand("copy"); toast.success("AI upgrade prompt copied"); }
      catch { toast.error("Clipboard blocked — long-press to select manually"); }
      finally { document.body.removeChild(ta); }
    }
  };

  const onUndo = () => {
    const r = undoLast();
    if (!r.ok) { toast.error(r.error ?? "Undo failed"); return; }
    toast.success("Reverted to previous state · refreshing…");
    setTimeout(() => window.location.reload(), 300);
  };

  const onResetTheme = () => {
    clearTheme();
    toast.success("Theme reset to defaults");
    refreshState();
  };

  return (
    <div className="space-y-2">
      <input
        ref={inputRef}
        type="file"
        /* accept ANY file — detection is content-based */
        accept="*/*"
        className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f) void onFile(f); }}
      />

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => inputRef.current?.click()}
          className="panel-cyber lift flex w-full items-center justify-center gap-2 px-3 py-2.5 font-display text-[11px] font-extrabold tracking-[0.22em] text-cyan"
          style={{ ["--c" as any]: "var(--cyan)" }}>
          <Upload className="h-3.5 w-3.5" /> UPLOAD MASTER
        </button>
        <button
          onClick={downloadMasterTemplate}
          className="panel-cyber lift flex w-full items-center justify-center gap-2 px-3 py-2.5 font-display text-[11px] font-extrabold tracking-[0.22em] text-magenta"
          style={{ ["--c" as any]: "var(--magenta)" }}>
          <Download className="h-3.5 w-3.5" /> MASTER TEMPLATE
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={exportCurrent}
          className="panel-cyber lift flex w-full items-center justify-center gap-2 px-3 py-2.5 font-display text-[11px] font-extrabold tracking-[0.22em] text-[color:var(--green)]"
          style={{ ["--c" as any]: "var(--green)" }}>
          <Package className="h-3.5 w-3.5" /> EXPORT CURRENT MASTER
        </button>
        <button
          onClick={copyAiPrompt}
          className="panel-cyber lift flex w-full items-center justify-center gap-2 px-3 py-2.5 font-display text-[11px] font-extrabold tracking-[0.22em] text-[color:var(--orange)]"
          style={{ ["--c" as any]: "var(--orange)" }}>
          <ClipboardCopy className="h-3.5 w-3.5" /> COPY AI UPGRADE PROMPT
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={onUndo}
          disabled={!canUndo}
          className="flex w-full items-center justify-center gap-2 rounded border border-[color:var(--border)] bg-[var(--ink-2)] px-3 py-1.5 font-mono text-[10px] tracking-[0.22em] text-foreground/80 hover:text-[color:var(--orange)] disabled:opacity-40">
          <Undo2 className="h-3 w-3" /> UNDO LAST UPLOAD
        </button>
        {hasTheme && (
          <button
            onClick={onResetTheme}
            className="flex w-full items-center justify-center gap-2 rounded border border-[color:var(--border)] bg-[var(--ink-2)] px-3 py-1.5 font-mono text-[10px] tracking-[0.22em] text-foreground/70 hover:text-[color:var(--red)]">
            <RotateCcw className="h-3 w-3" /> RESET THEME
          </button>
        )}
      </div>

      <p className="font-mono text-[9.5px] leading-snug text-foreground/55">
        Accepts <span className="text-cyan">.json</span> or <span className="text-magenta">.md</span> (filename ignored).
        Auto-detects theme · text · files · data and applies live. Snapshots previous state — use{" "}
        <span className="text-[color:var(--orange)]">UNDO</span> to revert the last upload.
      </p>

      {busy && <div className="font-mono text-[10px] tracking-widest text-foreground/55">parsing…</div>}

      {error && (
        <div className="flex items-center gap-2 rounded border border-[color:var(--red)]/50 bg-[color:var(--red)]/10 px-2 py-1.5 font-mono text-[10.5px] text-[color:var(--red)]">
          <AlertTriangle className="h-3.5 w-3.5" /> {error}
        </div>
      )}

      {last && (
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 rounded border border-[color:var(--green)]/40 bg-[color:var(--green)]/10 px-2 py-1.5">
            <Check className="h-3.5 w-3.5 text-[color:var(--green)]" />
            <span className="font-mono text-[10.5px] text-foreground/90">
              Last applied · {new Date(last.ts).toLocaleTimeString()} · {last.source.toUpperCase()}
            </span>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            <Pill label="THEME" value={String(last.appliedTheme)} icon={<Palette className="h-3 w-3" />} />
            <Pill label="TEXT"  value={String(last.appliedText)}  icon={<FileText className="h-3 w-3" />} />
            <Pill label="FILES" value={String(last.appliedFiles)} icon={<FileJson className="h-3 w-3" />} />
            <Pill label="DATA"  value={String(last.appliedData)}  icon={<FileJson className="h-3 w-3" />} />
          </div>
          {last.fileList.length > 0 && (
            <div className="rounded border border-[color:var(--border)] bg-[var(--ink)] p-2">
              <div className="mb-1 font-display text-[9px] font-extrabold tracking-[0.22em] text-cyan">
                FILE OVERRIDES
              </div>
              <ul className="space-y-0.5 font-mono text-[10px] text-foreground/70 max-h-32 overflow-auto">
                {last.fileList.map((f) => <li key={f} className="truncate">· {f}</li>)}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Pill({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div className="rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5 text-center">
      <div className="flex items-center justify-center gap-1 font-display text-[12px] font-black text-cyan">
        {icon}{value}
      </div>
      <div className="font-mono text-[8px] tracking-widest text-foreground/45">{label}</div>
    </div>
  );
}

```


### `/src/components/LegalShell.tsx`

```ts path=/src/components/LegalShell.tsx
import { Link, useNavigate } from "@tanstack/react-router";
import { X, Share2, Check, Lock, Scale, ShieldCheck, Trash2, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

export type Accent = "cyan" | "green" | "magenta" | "orange" | "yellow" | "red";

export type Badge = { label: string; tone: Accent };

const NAV: { to: string; label: string; icon: LucideIcon; tone: Accent }[] = [
  { to: "/legal/privacy", label: "Privacy Policy",   icon: Lock,        tone: "yellow" },
  { to: "/legal/terms",   label: "Terms of Service", icon: Scale,       tone: "cyan"   },
  { to: "/legal/safety",  label: "Data Safety",      icon: ShieldCheck, tone: "green"  },
  { to: "/legal/delete",  label: "Delete My Data",   icon: Trash2,      tone: "red"    },
];

export function LegalShell({
  title, accent, emoji, badges, headline, children,
}: {
  title: string;
  accent: Accent;
  emoji: string;
  badges: Badge[];
  headline: string;
  children: ReactNode;
}) {
  const navigate = useNavigate();
  const onShare = async () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    try {
      if (navigator.share) await navigator.share({ title, url });
      else await navigator.clipboard.writeText(url);
    } catch { /* user cancelled */ }
  };

  return (
    <main className="relative min-h-screen overflow-x-clip bg-background text-foreground">
      {/* === themed cyberpunk backdrop (matches homepage) === */}
      <div className="pointer-events-none absolute inset-0"
           style={{
             background:
               "radial-gradient(ellipse 90% 60% at 50% -10%, color-mix(in oklab, var(--cyan) 22%, transparent), transparent 60%)," +
               "radial-gradient(ellipse 70% 50% at 100% 100%, color-mix(in oklab, var(--magenta) 18%, transparent), transparent 60%)," +
               "radial-gradient(ellipse 70% 50% at 0% 100%, color-mix(in oklab, var(--green) 12%, transparent), transparent 60%)," +
               "linear-gradient(180deg, var(--ink) 0%, #06080d 50%, var(--ink-deep) 100%)",
           }} />
      <div className="pointer-events-none absolute inset-0 opacity-[0.10]"
           style={{
             backgroundImage:
               "linear-gradient(color-mix(in oklab, var(--cyan) 60%, transparent) 1px, transparent 1px)," +
               "linear-gradient(90deg, color-mix(in oklab, var(--cyan) 60%, transparent) 1px, transparent 1px)",
             backgroundSize: "44px 44px, 44px 44px",
             maskImage: "radial-gradient(ellipse 80% 70% at 50% 40%, #000 40%, transparent 90%)",
           }} />
      <div className="pointer-events-none absolute inset-0 opacity-[0.08]"
           style={{
             backgroundImage:
               "repeating-linear-gradient(60deg, color-mix(in oklab, var(--magenta) 50%, transparent) 0 1px, transparent 1px 28px)," +
               "repeating-linear-gradient(-60deg, color-mix(in oklab, var(--cyan) 40%, transparent) 0 1px, transparent 1px 36px)",
           }} />
      <div className="pointer-events-none absolute left-2 top-24 h-1.5 w-1.5 rounded-full"
           style={{ background: "var(--cyan)", boxShadow: "0 0 12px var(--cyan)" }} />
      <div className="pointer-events-none absolute right-3 top-44 h-1.5 w-1.5 rounded-full"
           style={{ background: "var(--magenta)", boxShadow: "0 0 12px var(--magenta)", animationDelay: "0.6s" }} />
      <div className="pointer-events-none absolute left-3 top-[60vh] h-1 w-1 rounded-full"
           style={{ background: "var(--green)", boxShadow: "0 0 10px var(--green)", animationDelay: "1.1s" }} />
      <div className="pointer-events-none absolute inset-0 scanlines opacity-15" />
      <div className="pointer-events-none absolute inset-x-0 top-0 z-0 h-[2px]"
           style={{ background: "linear-gradient(90deg, transparent, var(--cyan), transparent)", boxShadow: "0 0 14px var(--cyan)" }} />


      {/* Top bar */}
      <header className="sticky top-0 z-20 border-b border-border/60 bg-background/95">
        <div className="mx-auto grid max-w-md grid-cols-[auto_minmax(0,1fr)_auto_auto] items-center gap-2 px-3 py-3 sm:max-w-2xl">
          <button
            onClick={() => navigate({ to: "/" })}
            aria-label="Close and return to onboarding"
            className={`panel grid h-11 w-11 shrink-0 place-items-center text-${accent} transition hover:bg-${accent}/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-${accent}/70`}
          >
            <X className="h-4 w-4" />
          </button>
          <h1
            className="min-w-0 truncate font-mono text-sm font-bold tracking-widest text-foreground"
            title={title}
          >
            {title}
          </h1>
          <button
            onClick={onShare}
            aria-label="Share document link"
            className={`panel grid h-11 w-11 shrink-0 place-items-center text-${accent} transition hover:bg-${accent}/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-${accent}/70`}
          >
            <Share2 className="h-4 w-4" />
          </button>
          <Link
            to="/"
            aria-label="Mark as read and return"
            className="panel-cyber flex h-11 items-center gap-1.5 rounded-full border border-green/60 px-3 text-[10px] font-extrabold tracking-widest text-green glow-green transition hover:bg-green/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green/70"
          >
            <Check className="h-4 w-4" />
            <span className="text-[10px]">DONE</span>
          </Link>
        </div>
      </header>

      <div className="relative mx-auto max-w-md px-4 pb-16 pt-6 sm:max-w-2xl">
        {/* Hero */}
        <section className={`panel relative overflow-hidden p-5 glow-${accent}`}>
          <div className="pointer-events-none absolute inset-0 opacity-50"
            style={{ background: `radial-gradient(circle at 50% 0%, color-mix(in oklab, var(--${accent}) 28%, transparent), transparent 60%)` }} />
          <div className="relative space-y-4 text-center">
            <h2 className={`flex flex-wrap items-center justify-center gap-2 text-2xl font-extrabold tracking-widest text-${accent} text-glow-cyan`}>
              <span aria-hidden className="text-3xl">{emoji}</span>
              <span>{title.toUpperCase()}</span>
            </h2>
            <p className="text-xs tracking-widest text-muted-foreground">{headline}</p>
            <div className="mx-auto flex flex-wrap items-center justify-center gap-2 pt-1">
              {badges.map((b) => (
                <span key={b.label}
                  className={`rounded-md border border-${b.tone}/60 bg-${b.tone}/5 px-3 py-1.5 text-[10px] font-extrabold tracking-widest text-${b.tone}`}>
                  {b.label}
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* Quick-jump nav between legal docs — full labels, never truncated */}
        <nav aria-label="Legal documents" className="mt-5 flex flex-col gap-2">
          <div className="px-1 text-[10px] font-bold tracking-widest text-muted-foreground">
            JUMP TO DOCUMENT
          </div>
          {NAV.map((n) => {
            const active = typeof window !== "undefined" && window.location.pathname === n.to;
            const Icon = n.icon;
            return (
              <Link
                key={n.to}
                to={n.to}
                aria-current={active ? "page" : undefined}
                className={`panel flex items-center gap-3 px-3 py-3 text-xs font-bold tracking-widest transition text-${n.tone} focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-${n.tone}/70 ${active ? `glow-${n.tone}` : `hover:bg-${n.tone}/5`}`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="flex-1 break-words text-left leading-tight">{n.label}</span>
                {active && (
                  <span className={`shrink-0 rounded border border-${n.tone}/60 bg-${n.tone}/10 px-1.5 py-0.5 text-[9px] tracking-widest`}>
                    VIEWING
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* Body */}
        <article className="prose-legal mt-6 space-y-5 text-sm leading-relaxed text-foreground/85">
          {children}
        </article>

        <footer className="mt-10 border-t border-border/60 pt-4 text-center text-[10px] tracking-widest text-muted-foreground">
          BUTLER AI · ANDROID · EFFECTIVE APRIL 1, 2026 · v7.3
        </footer>
      </div>
    </main>
  );
}

/* Reusable section block */
export function LegalSection({ title, tone = "cyan", children }: { title: string; tone?: Accent; children: ReactNode }) {
  return (
    <section className={`panel p-4`}>
      <h3 className={`mb-2 text-xs font-extrabold tracking-widest text-${tone}`}>{title}</h3>
      <div className="space-y-2 text-[13px] leading-relaxed text-foreground/85">{children}</div>
    </section>
  );
}

/* Safelist hint:
   text-cyan text-green text-magenta text-orange text-yellow text-red
   bg-cyan/5 bg-green/5 bg-magenta/5 bg-orange/5 bg-yellow/5 bg-red/5
   bg-cyan/10 bg-green/10 bg-magenta/10 bg-orange/10 bg-yellow/10 bg-red/10
   border-cyan/60 border-green/60 border-magenta/60 border-orange/60 border-yellow/60 border-red/60
   glow-cyan glow-green glow-magenta glow-orange
*/

```


### `/src/components/LiveClock.tsx`

```ts path=/src/components/LiveClock.tsx
import { useEffect, useState } from "react";

export function LiveClock() {
  const [mounted, setMounted] = useState(false);
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setMounted(true);
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  if (!mounted || !now) {
    return (
      <div className="text-right font-mono text-xs text-muted-foreground tabular-nums">
        <div className="text-base font-bold text-cyan">--:--:--</div>
        <div className="text-[10px] tracking-[0.2em] mt-0.5">SYSTEM TIME</div>
      </div>
    );
  }
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  return (
    <div className="text-right font-mono tabular-nums">
      <div className="text-base font-bold text-cyan leading-none">
        {hh}:{mm}<span className="opacity-60">:{ss}</span>
      </div>
      <div className="text-[10px] tracking-[0.2em] text-muted-foreground mt-1">LOCAL · SECURE</div>
    </div>
  );
}

```


### `/src/components/MarkdownLite.tsx`

```ts path=/src/components/MarkdownLite.tsx
import { useState, memo } from "react";
import { Check, Copy } from "lucide-react";

/**
 * Zero-dep, fast markdown subset: fenced code blocks, inline `code`,
 * **bold**, *italic*, bullet lists, headings (#..###), links.
 * Designed for streaming chat — runs cheaply on each token.
 */

function escapeHtml(s: string) {
  return s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]!));
}

function renderInline(src: string): string {
  let s = escapeHtml(src);
  // links [text](url)
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
    '<a href="$2" target="_blank" rel="noreferrer" class="text-cyan underline underline-offset-2">$1</a>');
  // inline code
  s = s.replace(/`([^`]+)`/g, '<code class="rounded bg-[color:var(--surface-2)] px-1 py-[1px] text-[11px] text-[color:var(--magenta)]">$1</code>');
  // bold
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong class="text-foreground">$1</strong>');
  // italic
  s = s.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em class="text-foreground/80">$2</em>');
  return s;
}

type Block =
  | { type: "code"; lang: string; body: string }
  | { type: "p"; body: string }
  | { type: "h"; level: 1 | 2 | 3; body: string }
  | { type: "ul"; items: string[] };

function parse(md: string): Block[] {
  const lines = md.split("\n");
  const out: Block[] = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    const fence = line.match(/^```(\w*)\s*$/);
    if (fence) {
      const lang = fence[1] || "";
      const body: string[] = [];
      i++;
      while (i < lines.length && !/^```\s*$/.test(lines[i])) { body.push(lines[i]); i++; }
      i++; // skip closing fence (or end)
      out.push({ type: "code", lang, body: body.join("\n") });
      continue;
    }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      out.push({ type: "h", level: h[1].length as 1 | 2 | 3, body: h[2] });
      i++; continue;
    }
    if (/^\s*[-*]\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*[-*]\s+/, ""));
        i++;
      }
      out.push({ type: "ul", items });
      continue;
    }
    if (line.trim() === "") { i++; continue; }
    // paragraph (join consecutive non-empty, non-special lines)
    const body: string[] = [line];
    i++;
    while (i < lines.length && lines[i].trim() !== "" && !/^```|^#{1,3}\s|^\s*[-*]\s/.test(lines[i])) {
      body.push(lines[i]); i++;
    }
    out.push({ type: "p", body: body.join("\n") });
  }
  return out;
}

function CodeBlock({ lang, body }: { lang: string; body: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(body);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {}
  };
  return (
    <div className="my-1.5 overflow-hidden rounded-md border border-[color:var(--border)] bg-[var(--ink)]">
      <div className="flex items-center justify-between border-b border-[color:var(--border)] bg-[var(--ink-2)] px-2 py-1">
        <span className="font-mono text-[9px] tracking-widest text-[color:var(--magenta)]">
          {(lang || "code").toUpperCase()}
        </span>
        <button onClick={copy}
          className="flex items-center gap-1 font-display text-[9px] font-extrabold tracking-widest text-foreground/60 hover:text-cyan">
          {copied ? <><Check className="h-3 w-3 text-[color:var(--green)]" /> COPIED</>
                  : <><Copy className="h-3 w-3" /> COPY</>}
        </button>
      </div>
      <pre className="overflow-x-auto p-2 font-mono text-[11px] leading-relaxed text-cyan">{body}</pre>
    </div>
  );
}

export const MarkdownLite = memo(function MarkdownLite({ text }: { text: string }) {
  const blocks = parse(text);
  return (
    <div className="space-y-1.5">
      {blocks.map((b, i) => {
        if (b.type === "code") return <CodeBlock key={i} lang={b.lang} body={b.body} />;
        if (b.type === "h") {
          const sz = b.level === 1 ? "text-[13px]" : b.level === 2 ? "text-[12px]" : "text-[11.5px]";
          return (
            <div key={i}
              className={`font-display ${sz} font-extrabold tracking-[0.12em] text-cyan`}
              dangerouslySetInnerHTML={{ __html: renderInline(b.body) }} />
          );
        }
        if (b.type === "ul") {
          return (
            <ul key={i} className="ml-3 list-none space-y-0.5">
              {b.items.map((it, j) => (
                <li key={j} className="relative pl-3 font-mono text-[12px] leading-relaxed text-foreground/90">
                  <span className="absolute left-0 top-[7px] h-1 w-1 rounded-full bg-[color:var(--magenta)]" />
                  <span dangerouslySetInnerHTML={{ __html: renderInline(it) }} />
                </li>
              ))}
            </ul>
          );
        }
        return (
          <p key={i}
            className="font-mono text-[12px] leading-relaxed text-foreground/90 whitespace-pre-wrap"
            dangerouslySetInnerHTML={{ __html: renderInline(b.body) }} />
        );
      })}
    </div>
  );
});

```


### `/src/components/Mascot.tsx`

```ts path=/src/components/Mascot.tsx
import { useEffect, useRef, useState } from "react";
import mascotImg from "@/assets/mascot-butler.png";
import { usePerfTier } from "@/hooks/use-perf-tier";

/**
 * Reusable Butler mascot. Bow-tie-up bust crop with a wide library of
 * named moods + the ability to auto-cycle through a list for ambient
 * variety after onboarding completes.
 *
 *  <Mascot mood="wave" />
 *  <Mascot mood={["wave","spin","cheer","peek"]} cycleMs={2400} />
 */

export type MascotMood =
  | "wave" | "spy" | "nod" | "oath" | "tilt" | "shake" | "think" | "bow"
  | "build" | "launch" | "glow" | "spin" | "bounce" | "dance" | "cheer"
  | "salute" | "peek" | "blink" | "zoom" | "orbit" | "meditate" | "juggle"
  | "victory" | "sleep" | "alert" | "wink" | "skate" | "hover" | "boop"
  | "scan";

const MOOD_CLASS: Record<MascotMood, string> = {
  wave: "m-wave",        spy: "m-spy",          nod: "m-nod",
  oath: "m-oath m-glow", tilt: "m-tilt",        shake: "m-shake",
  think: "m-think",      bow: "m-bow",          build: "m-build",
  launch: "m-launch m-glow", glow: "m-glow",    spin: "m-spin",
  bounce: "m-bounce",    dance: "m-dance",      cheer: "m-cheer m-glow",
  salute: "m-salute",    peek: "m-peek",        blink: "m-blink",
  zoom: "m-zoom",        orbit: "m-orbit",      meditate: "m-meditate m-glow",
  juggle: "m-juggle",    victory: "m-victory m-glow", sleep: "m-sleep",
  alert: "m-alert m-glow", wink: "m-wink",      skate: "m-skate",
  hover: "m-hover m-glow", boop: "m-boop",      scan: "m-scan m-glow",
};

type Size = "xs" | "sm" | "md" | "lg" | "xl";
const SIZE_CLASS: Record<Size, string> = {
  xs: "w-16",  sm: "w-24",  md: "w-32",  lg: "w-44",  xl: "w-56",
};

export function Mascot({
  mood = "wave",
  cycleMs = 0,
  accent = "cyan",
  size = "md",
  className = "",
  parallax = true,
}: {
  mood?: MascotMood | MascotMood[];
  cycleMs?: number;
  accent?: "cyan" | "green" | "magenta" | "orange" | "yellow";
  size?: Size;
  className?: string;
  parallax?: boolean;
}) {
  const list = Array.isArray(mood) ? mood : [mood];
  const [idx, setIdx] = useState(0);
  const ref = useRef<HTMLDivElement | null>(null);
  const tier = usePerfTier();
  // Throttle: slower cycles on mid, freeze on low. Parallax off on low.
  const effectiveCycle = cycleMs && (tier === "low" ? 0 : tier === "mid" ? cycleMs * 1.6 : cycleMs);
  const allowParallax = parallax && tier !== "low";

  useEffect(() => {
    if (!effectiveCycle || list.length < 2) return;
    const t = window.setInterval(() => setIdx((i) => (i + 1) % list.length), effectiveCycle);
    return () => window.clearInterval(t);
  }, [effectiveCycle, list.length]);

  const current = list[idx % list.length];

  const onMove = (e: React.MouseEvent) => {
    if (!allowParallax) return;
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    // Mid tier gets a damped tilt to save GPU on transforms.
    const k = tier === "mid" ? 0.55 : 1;
    el.style.setProperty("--rx", `${(-y * 10 * k).toFixed(2)}deg`);
    el.style.setProperty("--ry", `${(x * 14 * k).toFixed(2)}deg`);
  };
  const onLeave = () => {
    const el = ref.current; if (!el) return;
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--ry", "0deg");
  };

  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className={`relative grid aspect-square ${SIZE_CLASS[size]} shrink-0 place-items-center overflow-hidden rounded-md border border-${accent}/40 bg-background/60 ${className}`}
      style={{ perspective: "700px" }}
    >
      <div className="absolute inset-0 grid-bg opacity-25" />
      <div
        className="absolute inset-0 opacity-70"
        style={{ background: `radial-gradient(circle at 50% 55%, color-mix(in oklab, var(--${accent}) 38%, transparent), transparent 62%)` }}
      />
      <div
        key={current}
        className="mascot-pop relative h-full w-full"
        style={{
          transform: "rotateX(var(--rx,0deg)) rotateY(var(--ry,0deg))",
          transformStyle: "preserve-3d",
          transition: "transform .25s ease-out",
        }}
      >
        <div
          className="absolute inset-0 grid place-items-center"
          style={{ transform: "translateZ(16px)" }}
        >
          <div className={`relative grid h-full w-full place-items-center ${MOOD_CLASS[current]}`} style={{ color: `var(--${accent})` }}>
            <img
              src={mascotImg}
              alt="Butler mascot"
              draggable={false}
              loading="eager"
              decoding="async"
              className="h-[92%] w-[92%] select-none object-contain"
              style={{
                willChange: "transform",
                filter: "drop-shadow(0 6px 14px rgba(0,0,0,.55))",
              }}
            />
          </div>
        </div>
        <div
          className="pointer-events-none absolute -bottom-1 left-1/2 h-3 w-24 -translate-x-1/2 rounded-full opacity-60 blur-lg"
          style={{ background: `var(--${accent})` }}
        />
      </div>
    </div>
  );
}

/** Pre-warm the mascot image into the HTTP cache. */
export function prefetchMascot() {
  if (typeof window === "undefined") return;
  const img = new Image();
  img.src = mascotImg;
}

```


### `/src/components/NexusHero.tsx`

```ts path=/src/components/NexusHero.tsx
import { Link } from "@tanstack/react-router";
import { Server, Shield, BrainCircuit, Link2, MessageSquare, Cpu, Code2, Sparkles, Clock, ChevronRight, Zap } from "lucide-react";
import { fmtUptime, type Telemetry } from "@/lib/useTelemetry";


/**
 * NexusHero — Butler AI landing block.
 * Status chips, neon title with scan beam, two chat CTAs, four telemetry stat tiles.
 */
export function NexusHero({ t }: { t: Telemetry }) {
  const vectors = Math.max(1, (t.history?.length ?? 0) * 137 + 8_720_000);
  const scripts = 1246;
  const runtime = t.uptime ? fmtUptime(t.uptime) : "72:48:31";

  return (
    <section className="relative" aria-label="Butler AI">
      {/* Top status chips row */}
      <div className="grid grid-cols-4 gap-1.5 px-1 pb-3">
        <StatusChip icon={<Server className="h-3 w-3" />} label="SELF-HOSTED" color="cyan" />
        <StatusChip icon={<Shield className="h-3 w-3" />} label="PRIVATE" color="magenta" />
        <StatusChip icon={<BrainCircuit className="h-3 w-3" />} label="LOCAL AI" color="green" />
        <StatusChip icon={<Link2 className="h-3 w-3" />} label="SECURE LINK" color="orange" />
      </div>

      {/* Title */}
      <div className="mt-3 text-center">
        <div className="font-mono text-[9px] tracking-[0.5em] text-foreground/55">// SYS.BOOT · v3.2.1</div>
        <h1
          className="hero-title font-display text-[46px] font-black leading-none tracking-[0.08em] mt-1.5"
          style={{
            background:
              "linear-gradient(180deg,#f4ffff 0%, var(--cyan) 45%, color-mix(in oklab, var(--magenta) 80%, var(--cyan)) 100%)",
            WebkitBackgroundClip: "text",
            backgroundClip: "text",
            WebkitTextFillColor: "transparent",
            filter:
              "drop-shadow(0 0 10px color-mix(in oklab, var(--cyan) 55%, transparent)) drop-shadow(0 0 22px color-mix(in oklab, var(--magenta) 35%, transparent))",
          }}
        >
          BUTLER&nbsp;AI
        </h1>
        <div className="relative mx-auto mt-2 h-[2px] w-44 overflow-hidden">
          <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent,var(--cyan),var(--magenta),transparent)] opacity-70" />
          <div className="absolute inset-y-0 -left-1/3 w-1/3 bg-[linear-gradient(90deg,transparent,#fff,transparent)] hero-beam" />
        </div>

        {/* Reworked NEXUS INTELLIGENCE PLATFORM banner */}
        <div className="mx-auto mt-2.5 inline-flex max-w-full items-stretch">
          <span
            aria-hidden
            className="grid place-items-center px-1.5 font-mono text-[9px] font-bold text-[color:var(--cyan)]/80"
            style={{
              borderLeft: "1px solid color-mix(in oklab, var(--cyan) 60%, transparent)",
              borderTop: "1px solid color-mix(in oklab, var(--cyan) 60%, transparent)",
              borderBottom: "1px solid color-mix(in oklab, var(--cyan) 60%, transparent)",
            }}
          >
            ◣
          </span>
          <div
            className="flex items-center gap-2 px-2.5 py-1"
            style={{
              background:
                "linear-gradient(90deg, color-mix(in oklab, var(--cyan) 14%, var(--ink-2)), color-mix(in oklab, var(--magenta) 14%, var(--ink-2)))",
              border: "1px solid color-mix(in oklab, var(--cyan) 45%, var(--border))",
              boxShadow: "inset 0 0 14px -8px var(--cyan), 0 0 12px -8px var(--magenta)",
            }}
          >
            <span className="inline-block h-1 w-3 bg-[color:var(--cyan)]" style={{ boxShadow: "0 0 8px var(--cyan)" }} />
            <span
              className="font-display text-[10px] font-extrabold tracking-[0.46em]"
              style={{
                background: "linear-gradient(90deg, var(--cyan), #ffffff 50%, var(--magenta))",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              NEXUS · INTELLIGENCE · PLATFORM
            </span>
            <span className="inline-block h-1 w-3 bg-[color:var(--magenta)]" style={{ boxShadow: "0 0 8px var(--magenta)" }} />
          </div>
          <span
            aria-hidden
            className="grid place-items-center px-1.5 font-mono text-[9px] font-bold text-[color:var(--magenta)]/80"
            style={{
              borderRight: "1px solid color-mix(in oklab, var(--magenta) 60%, transparent)",
              borderTop: "1px solid color-mix(in oklab, var(--magenta) 60%, transparent)",
              borderBottom: "1px solid color-mix(in oklab, var(--magenta) 60%, transparent)",
            }}
          >
            ◥
          </span>
        </div>
      </div>


      {/* CTAs */}
      <div className="mt-5 grid grid-cols-2 gap-2.5">
        <HeroCta to="/ai" color="cyan" icon={<Zap className="h-5 w-5" />} title="ASK" sub="BUTLER" />
        <HeroCta to="/ai" color="magenta" icon={<MessageSquare className="h-5 w-5" />} title="OPEN" sub="AI CHAT" />
      </div>

      {/* Stat tiles */}
      <div className="mt-3 grid grid-cols-4 gap-1.5">
        <StatTile color="cyan" icon={<Sparkles className="h-3.5 w-3.5" />} label={"VECTORS\nINDEXED"} value={formatM(vectors)} bar={84} />
        <StatTile color="magenta" icon={<Code2 className="h-3.5 w-3.5" />} label={"SCRIPTS\nFORGED"} value={scripts.toLocaleString()} bar={62} />
        <StatTile color="green" icon={<Cpu className="h-3.5 w-3.5" />} label={"AI\nMODE"} value="NEXUS" sub="ADAPTIVE" bar={97} />
        <StatTile color="orange" icon={<Clock className="h-3.5 w-3.5" />} label={"AI\nRUNTIME"} value={runtime} mono bar={73} />
      </div>
    </section>
  );
}

function formatM(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(2) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K";
  return String(n);
}

function StatusChip({ icon, label, color }: { icon: React.ReactNode; label: string; color: "cyan" | "magenta" | "green" | "orange" }) {
  const cvar = `var(--${color})`;
  return (
    <div
      className="relative flex items-center justify-center gap-1 px-1.5 py-1.5 font-mono text-[8px] font-bold tracking-[0.18em]"
      style={{
        color: cvar,
        background: "linear-gradient(180deg, #0e1420, var(--background))",
        border: `1px solid color-mix(in oklab, ${cvar} 45%, var(--border))`,
        clipPath: "polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px)",
        boxShadow: `inset 0 0 14px -8px ${cvar}, 0 0 10px -6px ${cvar}`,
        ["--c" as any]: cvar,
      }}
    >
      <span className="led" style={{ width: 4, height: 4 }} />
      {icon}
      <span className="truncate">{label}</span>
    </div>
  );
}

function HeroCta({ to, color, icon, title, sub }: { to: string; color: "cyan" | "magenta"; icon: React.ReactNode; title: string; sub: string }) {
  const cvar = `var(--${color})`;
  return (
    <Link
      to={to}
      className="shine brackets group relative flex items-center gap-3 px-3 py-3 transition active:translate-y-px lift"
      style={{
        color: cvar,
        background: "linear-gradient(180deg, #131a26, #07090f)",
        border: `1px solid color-mix(in oklab, ${cvar} 55%, var(--border))`,
        clipPath: "polygon(12px 0, 100% 0, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%, 0 12px)",
        boxShadow: `inset 0 0 22px -8px ${cvar}, 0 0 18px -6px ${cvar}`,
        ["--c" as any]: cvar,
      }}
    >
      <i className="br-tr" /><i className="br-bl" />
      <span
        className="grid h-9 w-9 place-items-center relative z-10"
        style={{
          color: cvar,
          background: "var(--ink-deep)",
          border: `1px solid color-mix(in oklab, ${cvar} 60%, transparent)`,
          boxShadow: `inset 0 0 12px -4px ${cvar}`,
          clipPath: "polygon(4px 0, 100% 0, 100% calc(100% - 4px), calc(100% - 4px) 100%, 0 100%, 0 4px)",
        }}
      >
        {icon}
      </span>
      <span className="relative z-10 flex flex-col leading-tight font-display font-extrabold tracking-[0.2em]">
        <span className="text-[14px]" style={{ textShadow: `0 0 10px ${cvar}` }}>{title}</span>
        <span className="text-[12px] opacity-90">{sub}</span>
      </span>
      <ChevronRight className="relative z-10 ml-auto h-4 w-4 opacity-70 transition-transform group-hover:translate-x-0.5" />
    </Link>
  );
}


function StatTile({ color, icon, label, value, sub, mono, bar = 70 }: { color: "cyan" | "magenta" | "green" | "orange"; icon: React.ReactNode; label: string; value: string; sub?: string; mono?: boolean; bar?: number }) {
  const cvar = `var(--${color})`;
  return (
    <div
      className="relative flex flex-col items-center gap-1 px-1 py-2 lift overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #0d1320, var(--ink-deep))",
        border: `1px solid color-mix(in oklab, ${cvar} 50%, var(--border))`,
        clipPath: "polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px)",
        boxShadow: `inset 0 0 16px -10px ${cvar}`,
        ["--c" as any]: cvar,
      }}
    >
      <span className="font-mono text-[8px] font-bold leading-[1.05] tracking-[0.18em] whitespace-pre text-center text-foreground/70">{label}</span>
      <span style={{ color: cvar, filter: `drop-shadow(0 0 6px ${cvar})` }}>{icon}</span>
      <span className={`mt-0.5 font-display text-[13px] font-black leading-none ${mono ? "font-mono" : ""}`} style={{ color: cvar, textShadow: `0 0 10px ${cvar}` }}>
        {value}
      </span>
      {sub && <span className="font-mono text-[7px] tracking-[0.2em] text-foreground/55">{sub}</span>}
      <div className="mt-1 h-[3px] w-full bg-[color:var(--border)]/50 overflow-hidden">
        <div
          className="h-full"
          style={{
            width: `${bar}%`,
            background: `linear-gradient(90deg, ${cvar}, color-mix(in oklab, ${cvar} 30%, transparent))`,
            boxShadow: `0 0 8px ${cvar}`,
          }}
        />
      </div>
    </div>
  );
}

```


### `/src/components/QuickChips.tsx`

```ts path=/src/components/QuickChips.tsx
import { memo } from "react";
import {
  Zap, Trash2, HeartPulse, Clock, HardDrive, ShieldCheck,
  Cpu, Network, Bug, Globe, FileText, Wand2,
  type LucideIcon,
} from "lucide-react";

export type QuickChip = {
  icon: LucideIcon;
  label: string;
  prompt: string;
  color?: string;
};

/** Cyberpunk-pill version of the original NexusQuickChips (RN → web port). */
export const NEXUS_CHIPS: QuickChip[] = [
  { icon: Zap,        label: "FIX MY PC",     prompt: "Diagnose what's making my PC slow and write a Python script that fixes the top 3 issues without admin rights.", color: "var(--magenta)" },
  { icon: Trash2,     label: "CLEAN TEMP",    prompt: "Write a safe Python script that clears %TEMP%, Windows cache, and the recycle bin — and reports how many MB it freed.", color: "var(--cyan)" },
  { icon: HeartPulse, label: "PC HEALTH",     prompt: "Run a full PC health check: CPU/RAM/disk pressure, top processes by RAM, disk free %, network latency. Output a one-page summary.", color: "var(--green)" },
  { icon: Clock,      label: "SCHEDULE",      prompt: "Help me schedule a daily task at 9am — open my work apps and mute Discord. Use Windows Task Scheduler from Python.", color: "var(--orange)" },
  { icon: HardDrive,  label: "BACKUP",        prompt: "Write a Python backup script for my Documents folder to an external drive — incremental, zipped, timestamped.", color: "var(--cyan)" },
  { icon: ShieldCheck,label: "SECURITY",      prompt: "Audit my PC's security posture from Python: open ports, firewall state, Windows Update status, BitLocker, antivirus.", color: "var(--red)" },
  { icon: Cpu,        label: "WHY CPU SPIKE", prompt: "My CPU spikes when idle. Sample CPU usage every second for 60s and print the top 5 offending processes with PIDs.", color: "var(--magenta)" },
  { icon: Network,    label: "LAN SCAN",      prompt: "Scan my LAN for live hosts and open ports (22/80/443/3389). Pure-Python, no nmap.", color: "var(--green)" },
  { icon: Bug,        label: "FIND DUPES",    prompt: "Find duplicate files in my Downloads folder by MD5 hash and group them, oldest kept.", color: "var(--orange)" },
  { icon: Globe,      label: "SCRAPE NEWS",   prompt: "Scrape today's top headlines from 3 tech RSS feeds and pretty-print them.", color: "var(--cyan)" },
  { icon: FileText,   label: "PDF → TXT",     prompt: "Convert every PDF in a folder to .txt using pure Python. Show progress.", color: "var(--green)" },
  { icon: Wand2,      label: "WRITE SCRIPT",  prompt: "Ask me 1-2 quick clarifying questions, then write a complete Python script. Include pip-install line + comments.", color: "var(--magenta)" },
];

export const QuickChips = memo(function QuickChips({
  chips = NEXUS_CHIPS,
  onPick,
  header = "QUICK CHIPS",
}: { chips?: QuickChip[]; onPick: (prompt: string) => void; header?: string }) {
  return (
    <div className="mt-1">
      {header && (
        <div className="mb-1 flex items-center gap-1.5 px-1">
          <span className="h-1 w-1 rounded-full bg-[color:var(--cyan)] pulse-dot" />
          <span className="font-display text-[8.5px] font-extrabold tracking-[0.32em] text-foreground/55">{header}</span>
        </div>
      )}
      <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1"
           style={{ scrollbarWidth: "none" }}>
        {chips.map((c, i) => {
          const Icon = c.icon;
          const accent = c.color ?? "var(--cyan)";
          return (
            <button key={i}
              onClick={() => onPick(c.prompt)}
              className="hex-tab shrink-0 flex-row gap-1.5 px-2.5"
              style={{ ["--c" as any]: accent }}>
              <Icon className="h-3.5 w-3.5" />
              <span className="font-display text-[9px] font-extrabold tracking-[0.2em]">{c.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
});

```


### `/src/components/RadialGauge.tsx`

```ts path=/src/components/RadialGauge.tsx
export function RadialGauge({
  value, label, unit = "%", size = 96, color = "var(--cyan)", segments = 24,
}: {
  value: number | null;
  label: string;
  unit?: string;
  size?: number;
  color?: string;
  segments?: number;
}) {
  const v = typeof value === "number" ? Math.max(0, Math.min(100, value)) : 0;
  const filled = Math.round((v / 100) * segments);
  const cx = size / 2;
  const cy = size / 2;
  const rOuter = size / 2 - 4;
  const rInner = rOuter - 9;
  const arc = 270;
  const start = 135;
  const step = arc / segments;

  return (
    <div className="relative inline-flex flex-col items-center" style={{ width: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="block">
        <defs>
          <filter id={`glow-${label}`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="1.4" />
          </filter>
        </defs>
        {Array.from({ length: segments }).map((_, i) => {
          const a = (start + i * step + step / 2) * (Math.PI / 180);
          const x1 = cx + rInner * Math.cos(a);
          const y1 = cy + rInner * Math.sin(a);
          const x2 = cx + rOuter * Math.cos(a);
          const y2 = cy + rOuter * Math.sin(a);
          const on = i < filled;
          return (
            <line
              key={i}
              x1={x1} y1={y1} x2={x2} y2={y2}
              stroke={on ? color : "rgba(77,217,255,0.10)"}
              strokeWidth={2.4}
              strokeLinecap="round"
              filter={on ? `url(#glow-${label})` : undefined}
              opacity={on ? 1 : 0.6}
            />
          );
        })}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <span className="font-display text-base font-black leading-none tabular-nums" style={{ color }}>
          {typeof value === "number" ? Math.round(value) : "—"}
          <span className="text-[9px] text-muted-foreground ml-0.5">{typeof value === "number" ? unit : ""}</span>
        </span>
        <span className="mt-1 text-[8px] font-bold tracking-[0.18em] uppercase text-muted-foreground">{label}</span>
      </div>
    </div>
  );
}

```


### `/src/components/SectionPanel.tsx`

```ts path=/src/components/SectionPanel.tsx
import type { ReactNode } from "react";

export function SectionPanel({
  title, icon, children, action, strong, color = "cyan",
}: {
  title?: string;
  icon?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
  strong?: boolean;
  color?: "cyan" | "violet" | "green" | "amber" | "red";
}) {
  const cls = color === "violet" ? "c-violet" : color === "green" ? "c-green" : color === "amber" ? "c-amber" : color === "red" ? "c-red" : "";
  const tone = color === "violet" ? "magenta" : color === "amber" ? "orange" : color;
  return (
    <section className={`panel-cyber ${cls} ${strong ? "panel-strong" : ""} p-4`}>
      {title ? (
        <header className="mb-3 flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2" style={{ color: `var(--${tone})` }}>
            {icon ? <span className="shrink-0">{icon}</span> : null}
            <h2 className="truncate font-display text-[11px] font-bold uppercase tracking-[0.22em]" style={{ textShadow: `0 0 8px var(--${tone})` }}>{title}</h2>
          </div>
          {action ? <div className="shrink-0">{action}</div> : null}
        </header>
      ) : null}
      {children}
    </section>
  );
}

```


### `/src/components/Sparkline.tsx`

```ts path=/src/components/Sparkline.tsx
type Props = { data: number[]; color?: string; height?: number; fill?: boolean };

export function Sparkline({ data, color = "#4dd9ff", height = 40, fill = true }: Props) {
  const w = 100, h = 30;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / range) * h;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const path = `M ${pts.join(" L ")}`;
  const area = `${path} L ${w},${h} L 0,${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ width: "100%", height }}>
      {fill && <path d={area} fill={color} opacity={0.14} />}
      <path d={path} fill="none" stroke={color} strokeWidth="1.4" />
    </svg>
  );
}

export function MultiSparkline({ series, height = 60 }: { series: { data: number[]; color: string }[]; height?: number }) {
  return (
    <div className="relative" style={{ height }}>
      {series.map((s, i) => (
        <div key={i} className="absolute inset-0">
          <Sparkline data={s.data} color={s.color} height={height} fill={false} />
        </div>
      ))}
    </div>
  );
}

```


### `/src/components/ThemedCard.tsx`

```ts path=/src/components/ThemedCard.tsx
import type { ReactNode } from "react";

export type CardColor = "cyan" | "violet" | "green" | "amber" | "red";

export function ThemedCard({
  color = "cyan", title, icon, action, children, className = "",
}: {
  color?: CardColor;
  title: string;
  icon: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  const cls = color === "cyan" ? "" : `c-${color}`;
  const cvar = color === "violet" ? "var(--magenta)"
    : color === "amber" ? "var(--orange)"
    : `var(--${color})`;
  return (
    <div
      className={`panel-cyber ${cls} brackets holo-grain lift relative overflow-hidden ${className}`}
      style={{ ["--c" as any]: cvar }}
    >
      <span className="br-tr" aria-hidden />
      <span className="br-bl" aria-hidden />
      <div className="card-accent absolute left-0 right-0 top-0" aria-hidden />
      <div className="p-3 pt-3.5">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5" style={{ color: cvar }}>
            <span className="led" aria-hidden />
            {icon}
            <span className="font-display text-[10px] font-extrabold tracking-[0.22em]">{title}</span>
          </div>
          {action}
        </div>
        {children}
      </div>
    </div>
  );
}

export function PageTitle({ kicker, title, sub, color = "cyan" }: {
  kicker: string; title: string; sub?: string; color?: CardColor;
}) {
  const cvar = color === "violet" ? "var(--magenta)"
    : color === "amber" ? "var(--orange)"
    : `var(--${color})`;
  return (
    <header className="panel-cyber relative px-3 py-3"
      style={{ ["--c" as any]: cvar }}>
      <div className="font-mono text-[9px] tracking-[0.4em]" style={{ color: cvar }}>{kicker}</div>
      <h1 className="font-display text-[22px] font-black leading-tight tracking-[0.18em] text-foreground"
        style={{ textShadow: `0 0 14px ${cvar}, 0 0 28px color-mix(in oklab, ${cvar} 40%, transparent)` }}>
        {title}
      </h1>
      {sub ? <div className="mt-1 font-mono text-[10px] tracking-[0.22em] text-foreground/55">{sub}</div> : null}
    </header>
  );
}

```


### `/src/components/TopBar.tsx`

```ts path=/src/components/TopBar.tsx
import { Link } from "@tanstack/react-router";
import { Activity, Circle, FolderClosed, Zap, Wifi, WifiOff, Loader2 } from "lucide-react";
import { useEffect, useState, useSyncExternalStore } from "react";
import { kbGrowthTracker } from "@/lib/kbGrowthTracker";
import { useServerLink } from "@/hooks/useServerLink";
import { serverLink } from "@/lib/serverLink";


/**
 * Persistent top utility bar — recent activity, connection, quick jumps.
 * Mounted globally inside AppShell so every screen has it.
 */
export function TopBar() {
  useSyncExternalStore(
    (cb) => kbGrowthTracker.subscribe(cb),
    () => kbGrowthTracker.getEventCount(),
    () => 0,
  );
  const [time, setTime] = useState<string>("");
  useEffect(() => {
    const update = () =>
      setTime(new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }));
    update();
    const id = setInterval(update, 4000);
    return () => clearInterval(id);
  }, []);

  const recent = kbGrowthTracker.getRecentEvents(8);
  const total = kbGrowthTracker.getTotalCount();


  return (
    <header
      className="panel-cyber sticky top-0 z-30 -mx-1 mb-2 flex items-center gap-2 px-2 py-1.5"
      style={{ ["--c" as any]: "var(--cyan)", backgroundColor: "color-mix(in oklab, var(--ink-2) 92%, transparent)" }}
    >
      <div className="flex items-center gap-1.5 shrink-0">
        <Circle className="h-1.5 w-1.5 fill-[color:var(--green)] text-[color:var(--green)]" />
        <span className="font-display text-[8px] font-extrabold tracking-[0.22em] text-[color:var(--green)]">LIVE</span>
        <span className="font-mono text-[8px] tracking-widest text-foreground/45" suppressHydrationWarning>{time}</span>
      </div>

      <div className="mx-1 h-3 w-px bg-[color:var(--border)]" />

      <div className="flex flex-1 items-center gap-2 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
        <Activity className="h-3 w-3 shrink-0 text-[color:var(--cyan)]" />
        {recent.length === 0 ? (
          <span className="font-mono text-[9px] tracking-widest text-foreground/40">no recent activity · awaiting nexus events</span>
        ) : (
          recent.map((e, i) => (
            <span
              key={i}
              className="shrink-0 rounded-sm border border-[color:var(--border)] bg-[var(--ink)] px-1.5 py-0.5 font-mono text-[8.5px] tracking-wider text-foreground/70"
              title={`${e.method} · ${e.domain ?? "—"} · ${new Date(e.ts).toLocaleTimeString()}`}
            >
              +{e.count} <span className="text-[color:var(--cyan)]">{e.method}</span>
              {e.domain ? <span className="text-foreground/40"> · {e.domain}</span> : null}
            </span>
          ))
        )}
      </div>

      <div className="flex shrink-0 items-center gap-1">
        <Link
          to="/files"
          className="grid h-6 w-6 place-items-center rounded-sm border border-[color:var(--border)] bg-[var(--ink)] text-[color:var(--cyan)]"
          title="Vault / Files"
        >
          <FolderClosed className="h-3 w-3" />
        </Link>
        <Link
          to="/ai"
          className="grid h-6 w-6 place-items-center rounded-sm border border-[color:var(--border)] bg-[var(--ink)] text-[color:var(--magenta)]"
          title="Butler chat"
        >
          <Zap className="h-3 w-3" />
        </Link>
        <ServerLinkBadge />
        <Link
          to="/settings"
          className="grid h-6 w-6 place-items-center rounded-sm border border-[color:var(--border)] bg-[var(--ink)] text-[color:var(--green)]"
          title="Settings"
        >
          <Wifi className="h-3 w-3" />
        </Link>
        <span className="ml-1 hidden font-mono text-[8.5px] tracking-widest text-foreground/45 sm:inline">
          KB {total.toLocaleString()}
        </span>

      </div>
    </header>
  );
}

function ServerLinkBadge() {
  const link = useServerLink();
  const connected = link.status === "connected";
  const busy = link.status === "connecting" || link.status === "discovering";
  const color = connected
    ? "var(--green)"
    : busy
      ? "var(--orange)"
      : "var(--red)";
  const Icon = busy ? Loader2 : connected ? Wifi : WifiOff;
  const label = connected
    ? `${link.latencyMs ?? "?"}ms`
    : busy
      ? "…"
      : "off";
  const onClick = () => {
    if (connected) return;
    void serverLink.autoDiscover();
  };
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex h-6 items-center gap-1 rounded-sm border border-[color:var(--border)] bg-[var(--ink)] px-1.5"
      style={{ color }}
      title={connected ? `Linked ${link.ip}:${link.port}` : "Tap to auto-discover PC server"}
    >
      <Icon className={`h-3 w-3 ${busy ? "animate-spin" : ""}`} />
      <span className="font-mono text-[8.5px] tracking-widest">{label}</span>
    </button>
  );
}


```


### `/src/components/nexus/atoms.tsx`

```ts path=/src/components/nexus/atoms.tsx
import type { ReactNode } from "react";

export const SectionHeader = ({ title, badge }: { title: string; badge?: string }) => (
  <div className="flex items-center gap-2.5 mb-2.5">
    <div className="label-mono">{title}</div>
    <div className="flex-1 h-px bg-gradient-to-r from-border to-transparent" />
    {badge && (
      <span className="font-mono text-[0.5rem] px-2 py-0.5 rounded-full bg-surface-2 border border-border text-muted-foreground">
        {badge}
      </span>
    )}
  </div>
);

type RingColor = "cyan" | "green" | "magenta" | "warning" | "destructive";
const ringColorMap: Record<RingColor, string> = {
  cyan: "hsl(var(--primary))",
  green: "hsl(var(--success))",
  magenta: "hsl(var(--accent))",
  warning: "hsl(var(--warning))",
  destructive: "hsl(var(--destructive))",
};

export const Ring = ({
  value, label, color = "cyan", size = 64,
}: { value: number; label: string; color?: RingColor; size?: number }) => {
  const r = (size - 8) / 2;
  const c = 2 * Math.PI * r;
  const dash = (value / 100) * c;
  const stroke = ringColorMap[color];
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} stroke="hsl(var(--surface-3))" strokeWidth={4} fill="none" />
          <circle
            cx={size / 2} cy={size / 2} r={r}
            stroke={stroke} strokeWidth={4} fill="none"
            strokeDasharray={`${dash} ${c}`} strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${stroke})`, transition: "stroke-dasharray 1s ease" }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center font-mono text-xs font-bold" style={{ color: stroke }}>
          {value}%
        </div>
      </div>
      <div className="label-mono">{label}</div>
    </div>
  );
};

export const StatBox = ({
  label, value, color = "cyan", sub,
}: { label: string; value: string; color?: RingColor; sub?: string }) => {
  const colorClass = {
    cyan: "glow-text-cyan",
    green: "glow-text-green",
    magenta: "glow-text-magenta",
    warning: "glow-text-warning",
    destructive: "text-destructive",
  }[color];
  return (
    <div className="cyber-card p-3">
      <div className="label-mono mb-1">{label}</div>
      <div className={`stat-number text-lg ${colorClass}`}>{value}</div>
      {sub && <div className="font-mono text-[0.55rem] text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
};

export const Bar = ({ value, color = "cyan", label, right }: { value: number; color?: RingColor; label?: string; right?: string }) => {
  const stroke = ringColorMap[color];
  return (
    <div>
      {(label || right) && (
        <div className="flex justify-between mb-1">
          <span className="label-mono">{label}</span>
          <span className="font-mono text-[0.6rem]" style={{ color: stroke }}>{right ?? `${value}%`}</span>
        </div>
      )}
      <div className="h-1.5 rounded-full bg-surface-3 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${value}%`, background: stroke, boxShadow: `0 0 8px ${stroke}` }}
        />
      </div>
    </div>
  );
};

export const Tag = ({ children, color = "cyan" }: { children: ReactNode; color?: RingColor }) => {
  const palette: Record<RingColor, string> = {
    cyan:        "bg-primary/10 border-primary/30 text-primary",
    green:       "bg-success/10 border-success/30 text-success",
    magenta:     "bg-accent/10 border-accent/30 text-accent",
    warning:     "bg-warning/10 border-warning/30 text-warning",
    destructive: "bg-destructive/10 border-destructive/30 text-destructive",
  };
  return (
    <span className={`inline-flex items-center px-1.5 py-0.5 rounded-md border font-mono text-[0.5rem] font-bold tracking-wider ${palette[color]}`}>
      {children}
    </span>
  );
};

```


### `/src/components/nexus/tabs/AiChatTab.tsx`

```ts path=/src/components/nexus/tabs/AiChatTab.tsx
import { useEffect, useRef, useState } from "react";
import { Send, Sparkles, Bot, User, Trash2, Cpu, ShieldCheck, Workflow, FileSearch } from "lucide-react";

type Role = "butler" | "you";
type Msg = { id: number; role: Role; text: string; ts: string };

const now = () =>
  new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

const SEED: Msg[] = [
  { id: 1, role: "butler", text: "Butler online. How can I assist, sir?", ts: now() },
];

const QUICK: { label: string; prompt: string; Icon: typeof Cpu }[] = [
  { label: "System status",   prompt: "Give me a full system status report.", Icon: Cpu },
  { label: "Security check",  prompt: "Run a security check on the network.", Icon: ShieldCheck },
  { label: "Summarize files", prompt: "Summarize the most recent files.",     Icon: FileSearch },
  { label: "Build a flow",    prompt: "Help me build an automation flow.",    Icon: Workflow },
];

function butlerReply(prompt: string): string {
  const p = prompt.toLowerCase();
  if (p.includes("status"))   return "All systems nominal. CPU 12%, MEM 38%, link stable.";
  if (p.includes("security")) return "No anomalies detected. Firewall and RLS policies intact.";
  if (p.includes("file"))     return "I can index the Files tab on request — say the word.";
  if (p.includes("flow"))     return "Tell me the trigger and the desired action; I'll wire it up.";
  return `Acknowledged: "${prompt}". I'll handle it.`;
}

export const AiChatTab = () => {
  const [msgs, setMsgs] = useState<Msg[]>(SEED);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "auto" });
  }, [msgs, typing]);

  const send = (text: string) => {
    const t = text.trim();
    if (!t) return;
    const userMsg: Msg = { id: Date.now(), role: "you", text: t, ts: now() };
    setMsgs((m) => [...m, userMsg]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setMsgs((m) => [...m, { id: Date.now() + 1, role: "butler", text: butlerReply(t), ts: now() }]);
      setTyping(false);
    }, 600);
  };

  const clear = () => setMsgs(SEED);

  return (
    <section className="flex flex-col gap-2 min-h-[70vh]">
      <header className="flex items-center justify-between rounded-lg border border-border bg-card/85 px-3 py-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="inline-flex items-center justify-center w-8 h-8 rounded-md bg-primary/15 text-primary">
            <Bot className="w-4 h-4" />
          </span>
          <div className="min-w-0">
            <h2 className="text-sm font-semibold tracking-tight truncate">Butler AI</h2>
            <p className="text-[11px] text-muted-foreground flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Online · ready to assist
            </p>
          </div>
        </div>
        <button onClick={clear} aria-label="Clear conversation"
          className="text-muted-foreground hover:text-foreground p-2 rounded-md hover:bg-muted/50 transition-colors">
          <Trash2 className="w-4 h-4" />
        </button>
      </header>

      <div ref={scrollRef}
        className="flex-1 min-h-[40vh] overflow-y-auto rounded-lg border border-border bg-background/70 p-3 space-y-3">
        {msgs.map((m) => <Bubble key={m.id} msg={m} />)}
        {typing && (
          <div className="flex items-center gap-2 text-muted-foreground text-xs">
            <Bot className="w-3.5 h-3.5" />
            <span className="inline-flex gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-bounce [animation-delay:-0.2s]" />
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-bounce [animation-delay:-0.1s]" />
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-bounce" />
            </span>
          </div>
        )}
      </div>

      <div className="flex gap-1.5 overflow-x-auto pb-0.5 -mx-0.5 px-0.5">
        {QUICK.map(({ label, prompt, Icon }) => (
          <button key={label} onClick={() => send(prompt)}
            className="shrink-0 inline-flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-full border border-border bg-card/60 hover:bg-muted/60 transition-colors">
            <Icon className="w-3.5 h-3.5 text-primary" />
            {label}
          </button>
        ))}
      </div>

      <form onSubmit={(e) => { e.preventDefault(); send(input); }}
        className="flex items-center gap-2 rounded-lg border border-border bg-card/85 p-1.5">
        <Sparkles className="w-4 h-4 text-primary ml-1.5 shrink-0" />
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask Butler anything…"
          className="flex-1 bg-transparent outline-none text-sm placeholder:text-muted-foreground" />
        <button type="submit" disabled={!input.trim()} aria-label="Send"
          className="inline-flex items-center justify-center w-9 h-9 rounded-md bg-primary text-primary-foreground disabled:opacity-40 hover:opacity-90 transition-opacity">
          <Send className="w-4 h-4" />
        </button>
      </form>
    </section>
  );
};

const Bubble = ({ msg }: { msg: Msg }) => {
  const mine = msg.role === "you";
  return (
    <div className={`flex gap-2 ${mine ? "flex-row-reverse" : ""}`}>
      <span className={`shrink-0 w-7 h-7 rounded-md inline-flex items-center justify-center ${mine ? "bg-muted text-foreground" : "bg-primary/15 text-primary"}`}>
        {mine ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
      </span>
      <div className={`max-w-[78%] ${mine ? "items-end" : "items-start"} flex flex-col gap-0.5`}>
        <div className={`rounded-2xl px-3 py-2 text-sm leading-snug border ${mine ? "bg-primary text-primary-foreground border-transparent rounded-tr-sm" : "bg-card text-card-foreground border-border rounded-tl-sm"}`}>
          {msg.text}
        </div>
        <span className="text-[10px] text-muted-foreground px-1">{msg.ts}</span>
      </div>
    </div>
  );
};

export default AiChatTab;

```


### `/src/components/nexus/tabs/ConnectionTab.tsx`

```ts path=/src/components/nexus/tabs/ConnectionTab.tsx
import { useEffect, useState } from "react";
import { Anchor, Compass, Fish, Radio, Send, Shell, Waves } from "lucide-react";

const Jellyfish = ({ hue = 180, delay = 0 }: { hue?: number; delay?: number }) => (
  <svg viewBox="0 0 120 160" className="w-full h-full">
    <defs>
      <radialGradient id={`jg${hue}`} cx="50%" cy="40%" r="60%">
        <stop offset="0%"  stopColor={`hsl(${hue} 100% 80%)`} stopOpacity=".95"/>
        <stop offset="60%" stopColor={`hsl(${hue} 100% 55%)`} stopOpacity=".5"/>
        <stop offset="100%" stopColor={`hsl(${hue} 100% 35%)`} stopOpacity="0"/>
      </radialGradient>
    </defs>
    <g style={{ transformOrigin: "60px 80px", animation: `jelly-pulse 3.4s ease-in-out ${delay}s infinite` }}>
      <ellipse cx="60" cy="55" rx="40" ry="32" fill={`url(#jg${hue})`} />
      <ellipse cx="60" cy="55" rx="40" ry="32" fill="none" stroke={`hsl(${hue} 100% 70% / .55)`} strokeWidth="1"/>
      {[42,52,60,68,78].map((x,i)=>(
        <path key={i} d={`M${x} 80 Q${x-4} 110 ${x+2} 140`} stroke={`hsl(${hue} 100% 70% / .6)`} strokeWidth="1.4" fill="none"
              style={{ animation:`sway ${2+i*0.3}s ease-in-out ${i*0.1}s infinite`, transformOrigin:`${x}px 80px` }}/>
      ))}
    </g>
  </svg>
);

const Anglerfish = ({ depth = 0 }: { depth?: number }) => (
  <svg viewBox="0 0 220 160" className="w-full h-full">
    <defs>
      <radialGradient id="lure" cx="50%" cy="50%" r="50%">
        <stop offset="0%"  stopColor="hsl(50 100% 85%)"/>
        <stop offset="60%" stopColor="hsl(40 100% 55% /.7)"/>
        <stop offset="100%" stopColor="transparent"/>
      </radialGradient>
      <linearGradient id="body" x1="0" x2="1">
        <stop offset="0" stopColor="hsl(220 40% 8%)"/>
        <stop offset="1" stopColor="hsl(200 60% 16%)"/>
      </linearGradient>
    </defs>
    <circle cx="56" cy="60" r="44" fill="url(#lure)" style={{animation:"lure-flicker 2.4s ease-in-out infinite"}}/>
    <path d="M70 80 Q120 30 200 70 Q170 100 200 130 Q120 150 70 105 Z" fill="url(#body)" stroke="hsl(180 80% 55% /.4)"/>
    <path d="M90 70 Q70 50 58 58" stroke="hsl(180 80% 55% /.7)" strokeWidth="1.5" fill="none"/>
    <circle cx="58" cy="58" r="6" fill="hsl(50 100% 70%)" style={{animation:"lure-flicker 2.4s ease-in-out infinite"}}/>
    <circle cx="120" cy="78" r="4" fill="hsl(170 100% 70%)"/>
    {[100,110,120,130,140].map((x,i)=>(
      <polygon key={i} points={`${x},96 ${x+4},96 ${x+2},104`} fill="hsl(40 30% 90%)"/>
    ))}
    <text x="160" y="155" fontSize="9" fill="hsl(180 60% 60%)" fontFamily="monospace">{depth}m</text>
  </svg>
);

export const ConnectionTab = () => {
  const [depth, setDepth] = useState(2847);
  const [pressure, setPressure] = useState(284.3);
  const [o2, setO2] = useState(72);
  const [salinity, setSalinity] = useState(34.7);

  useEffect(() => {
    const id = setInterval(() => {
      setDepth(d => d + (Math.random() > .5 ? 1 : -1));
      setPressure(p => +(p + (Math.random() - .5) * .4).toFixed(1));
      setO2(o => Math.max(40, Math.min(98, o + (Math.random() > .5 ? 1 : -1))));
      setSalinity(s => +(s + (Math.random() - .5) * .1).toFixed(1));
    }, 1500);
    return () => clearInterval(id);
  }, []);

  return (
  <div className="relative space-y-5 animate-fade-in pt-2">
    <section className="relative abyss-card caustics overflow-hidden p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Shell className="w-4 h-4" style={{color:"hsl(170 100% 70%)"}}/>
          <span className="font-mono text-[0.65rem] tracking-[0.3em] biolume-text">ABYSSAL · OBSERVATORY</span>
        </div>
        <span className="font-mono text-[0.6rem] biolume-pink animate-pulse">⬤ LIVE FEED</span>
      </div>

      <div className="relative h-44 rounded-2xl overflow-hidden mb-4"
           style={{background:"radial-gradient(ellipse at 30% 50%, hsl(190 90% 18% /.8), hsl(220 80% 4%) 70%)"}}>
        <div className="absolute left-[18%] top-[42%] -translate-x-1/2 -translate-y-1/2">
          {[0,1,2].map(i=>(
            <div key={i} className="absolute w-20 h-20 rounded-full border"
                 style={{borderColor:"hsl(180 100% 60% /.5)", animation:`sonar-pulse 3s ease-out ${i*1}s infinite`}}/>
          ))}
        </div>
        <div className="absolute inset-0">
          <Anglerfish depth={depth}/>
        </div>
        <div className="absolute top-2 right-2 font-mono text-[0.55rem] biolume-text leading-tight text-right">
          <div>LAT  -34.892°</div>
          <div>LON  151.207°</div>
          <div>HEAD 247.4°</div>
        </div>
        <div className="absolute bottom-2 left-2 font-mono text-[0.55rem] biolume-text">
          <span className="biolume-pink">▸</span> THERMAL VENT · 2.1km
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {[
          {l:"DEPTH",  v:`${depth}`, u:"m",   h:180},
          {l:"PRESS",  v:`${pressure}`, u:"bar", h:320},
          {l:"O₂",     v:`${o2}`, u:"%",   h:160},
          {l:"SALIN",  v:`${salinity}`, u:"psu", h:200},
        ].map(s=>(
          <div key={s.l} className="rounded-xl p-2 text-center"
               style={{background:"hsl(200 70% 6% /.7)", border:`1px solid hsl(${s.h} 80% 50% /.35)`}}>
            <div className="font-mono text-[0.5rem] tracking-widest" style={{color:`hsl(${s.h} 70% 70%)`}}>{s.l}</div>
            <div className="font-mono text-base font-bold" style={{color:`hsl(${s.h} 100% 78%)`, textShadow:`0 0 10px hsl(${s.h} 100% 60% /.7)`}}>{s.v}</div>
            <div className="font-mono text-[0.5rem] opacity-60" style={{color:`hsl(${s.h} 50% 70%)`}}>{s.u}</div>
          </div>
        ))}
      </div>
    </section>

    <section className="abyss-card p-4 relative overflow-hidden">
      <div className="flex items-center justify-between mb-3">
        <span className="font-mono text-[0.65rem] tracking-[0.3em] biolume-text">DRIFT · NODES</span>
        <span className="font-mono text-[0.55rem] biolume-pink">4 ACTIVE · SWARM SYNC</span>
      </div>
      <div className="grid grid-cols-4 gap-2">
        {[
          {n:"AURA",   hue:180, lat:"42ms"},
          {n:"NYMPH",  hue:320, lat:"89ms"},
          {n:"ECHO",   hue:160, lat:"31ms"},
          {n:"VESPER", hue:280, lat:"117ms"},
        ].map((j,i)=>(
          <div key={j.n} className="relative">
            <div className="h-20"><Jellyfish hue={j.hue} delay={i*0.4}/></div>
            <div className="text-center font-mono text-[0.55rem] tracking-widest"
                 style={{color:`hsl(${j.hue} 100% 75%)`, textShadow:`0 0 8px hsl(${j.hue} 100% 55% /.7)`}}>{j.n}</div>
            <div className="text-center font-mono text-[0.5rem] opacity-70" style={{color:`hsl(${j.hue} 60% 70%)`}}>{j.lat}</div>
          </div>
        ))}
      </div>
    </section>

    <section className="abyss-card p-4">
      <div className="flex items-center justify-between mb-3">
        <span className="font-mono text-[0.65rem] tracking-[0.3em] biolume-text">TIDAL · COMMANDS</span>
        <Waves className="w-4 h-4" style={{color:"hsl(180 100% 70%)"}}/>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {[
          {i:Compass, n:"PLOT COURSE",   h:180},
          {i:Radio,   n:"PING SWARM",    h:320},
          {i:Anchor,  n:"DROP ANCHOR",   h:200},
          {i:Fish,    n:"SCAN BIOMASS",  h:160},
        ].map(({i:Ic,n,h})=>(
          <button key={n} className="group relative overflow-hidden rounded-2xl p-3 flex items-center gap-3 transition active:scale-[.97]"
                  style={{
                    background:`linear-gradient(135deg, hsl(${h} 80% 14% /.9), hsl(${h} 60% 6% /.95))`,
                    border:`1px solid hsl(${h} 100% 55% /.4)`,
                    boxShadow:`inset 0 1px 0 hsl(${h} 100% 70% /.15), 0 0 20px hsl(${h} 100% 50% /.15)`,
                  }}>
            <div className="w-9 h-9 rounded-full flex items-center justify-center"
                 style={{background:`radial-gradient(circle, hsl(${h} 100% 60% /.4), transparent 70%)`}}>
              <Ic className="w-4 h-4" style={{color:`hsl(${h} 100% 80%)`, filter:`drop-shadow(0 0 6px hsl(${h} 100% 60%))`}}/>
            </div>
            <span className="font-mono text-[0.65rem] tracking-[0.2em]"
                  style={{color:`hsl(${h} 100% 80%)`, textShadow:`0 0 8px hsl(${h} 100% 50% /.5)`}}>{n}</span>
          </button>
        ))}
      </div>
    </section>

    <section className="abyss-card p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="font-mono text-[0.65rem] tracking-[0.3em] biolume-text">HYDROPHONE · RX</span>
        <span className="font-mono text-[0.55rem]" style={{color:"hsl(50 100% 70%)"}}>◉ REC 00:42</span>
      </div>
      <div className="flex items-end gap-[2px] h-10 mb-3">
        {Array.from({length:48}).map((_,i)=>{
          const h = 20 + Math.abs(Math.sin(i*0.6+depth*0.01))*80;
          return <div key={i} className="flex-1 rounded-sm"
            style={{height:`${h}%`, background:`linear-gradient(to top, hsl(180 100% 30%), hsl(170 100% 65%))`, opacity:.4 + h/200}}/>;
        })}
      </div>
      <div className="flex items-center gap-2 rounded-xl px-3 py-2"
           style={{background:"hsl(200 80% 4%)", border:"1px solid hsl(180 80% 40% /.4)"}}>
        <span className="font-mono text-[0.6rem] biolume-pink">abyss▸</span>
        <input placeholder="transmit to swarm…" className="flex-1 bg-transparent outline-none font-mono text-xs biolume-text placeholder:opacity-40"/>
        <button className="w-7 h-7 rounded-full flex items-center justify-center"
                style={{background:"radial-gradient(circle, hsl(50 100% 60%), hsl(30 100% 35%))",
                        boxShadow:"0 0 14px hsl(50 100% 60% /.6)"}}>
          <Send className="w-3.5 h-3.5" style={{color:"hsl(20 60% 10%)"}}/>
        </button>
      </div>
    </section>
  </div>
  );
};

```


### `/src/components/nexus/tabs/DashboardTab.tsx`

```ts path=/src/components/nexus/tabs/DashboardTab.tsx
import {
  Activity, Cpu, FileSearch, HardDrive, MemoryStick, Power, Recycle, Search, ShieldCheck, Trash2, Wifi, Zap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Bar, Ring, SectionHeader, StatBox, Tag } from "../atoms";

const quickScripts: { Icon: LucideIcon; label: string }[] = [
  { Icon: Trash2,      label: "Clean Temp" },
  { Icon: HardDrive,   label: "Disk Info" },
  { Icon: Activity,    label: "Top Processes" },
  { Icon: Wifi,        label: "Network Test" },
  { Icon: Recycle,     label: "Empty Recycle" },
  { Icon: MemoryStick, label: "Free RAM" },
  { Icon: ShieldCheck, label: "Quick Virus Scan" },
  { Icon: Power,       label: "Startup Apps" },
  { Icon: Search,      label: "IP + Network" },
];

export const DashboardTab = () => (
  <div className="space-y-5 animate-fade-in">
    <section>
      <SectionHeader title="PC HEALTH OVERVIEW" />
      <div className="grid grid-cols-2 gap-2.5">
        <StatBox label="DISK HEALTH"     value="94%"  color="green" sub="SMART · OK" />
        <StatBox label="THREATS BLOCKED" value="142"  color="destructive" sub="LAST 30D" />
        <StatBox label="FILES ORGANIZED" value="3.2K" color="cyan" sub="AUTO-RULES" />
        <StatBox label="SPACE RECOVERED" value="48GB" color="magenta" sub="LIFETIME" />
        <StatBox label="SCRIPTS ACTIVE"  value="12"   color="warning" />
        <StatBox label="UPTIME"          value="3d 4h" color="green" />
      </div>
    </section>

    <section>
      <SectionHeader title="PERFORMANCE MONITOR" badge="REALTIME" />
      <div className="cyber-card p-4">
        <div className="grid grid-cols-3 gap-2 mb-4">
          <Ring value={42} label="CPU" color="cyan" size={72} />
          <Ring value={67} label="RAM" color="magenta" size={72} />
          <Ring value={28} label="GPU" color="green" size={72} />
        </div>
        <Bar value={81} label="DISK USAGE" color="warning" right="412 / 512 GB" />
      </div>
    </section>

    <section>
      <SectionHeader title="QUICK PC SCRIPTS" badge="9" />
      <div className="grid grid-cols-3 gap-2">
        {quickScripts.map(({ Icon, label }) => (
          <button key={label} className="cyber-card aspect-square flex flex-col items-center justify-center gap-1.5 p-2 pressable hover:border-primary/40 transition">
            <Icon className="w-5 h-5 text-primary" />
            <div className="font-mono text-[0.55rem] text-center font-semibold leading-tight">{label}</div>
          </button>
        ))}
      </div>
    </section>

    <section>
      <SectionHeader title="SCAN RESULTS" />
      <div className="cyber-card p-4 space-y-3">
        <Bar label="TEMP FILES"   value={62} color="cyan"    right="2.4 GB" />
        <Bar label="CACHE"        value={48} color="magenta" right="1.1 GB" />
        <Bar label="LARGE FILES"  value={31} color="warning" right="14 items" />
        <Bar label="DISK"         value={81} color="destructive" right="412 / 512 GB" />
      </div>
    </section>

    <section>
      <SectionHeader title="LIFETIME STATS" />
      <div className="grid grid-cols-2 gap-2.5">
        {[
          { Icon: Trash2,     n: "12.4K", l: "Cleaned ops",     c: "cyan"    as const },
          { Icon: FileSearch, n: "8.7K",  l: "Organized files", c: "magenta" as const },
          { Icon: Cpu,        n: "1.2K",  l: "Scripts executed",c: "green"   as const },
          { Icon: Zap,        n: "342",   l: "Undone rollbacks", c: "warning" as const },
        ].map(({ Icon, n, l, c }) => (
          <div key={l} className="cyber-card p-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center"
                 style={{ background: `hsl(var(--${c === "cyan" ? "primary" : c === "green" ? "success" : c === "magenta" ? "accent" : "warning"}) / .12)` }}>
              <Icon className="w-5 h-5" style={{ color: `hsl(var(--${c === "cyan" ? "primary" : c === "green" ? "success" : c === "magenta" ? "accent" : "warning"}))` }} />
            </div>
            <div>
              <div className={`stat-number text-base ${c === "cyan" ? "glow-text-cyan" : c === "green" ? "glow-text-green" : c === "magenta" ? "glow-text-magenta" : "glow-text-warning"}`}>{n}</div>
              <div className="label-mono">{l}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex justify-end gap-1.5">
        <Tag color="green">SAFE MODE</Tag>
        <Tag color="cyan">AUTO-LOG</Tag>
      </div>
    </section>
  </div>
);

```


### `/src/components/nexus/tabs/FilesTab.tsx`

```ts path=/src/components/nexus/tabs/FilesTab.tsx
import { useState } from "react";
import { ArrowDownToLine, ArrowUpFromLine, Backpack, Cpu, FolderTree, HardDrive, Network, Radar, ScanLine, Shield, TerminalSquare } from "lucide-react";
import { SectionHeader, Tag } from "../atoms";

const SUBS = ["Files", "Tools", "Terminal"] as const;

const TOOLS = [
  { Icon: Cpu,        title: "Performance", tag: "SYSTEM",  c: "cyan"    as const },
  { Icon: HardDrive,  title: "Sys Snapshot",tag: "SYSTEM",  c: "cyan"    as const },
  { Icon: Network,    title: "LAN Map",     tag: "NETWORK", c: "magenta" as const },
  { Icon: Radar,      title: "Port Scan",   tag: "NETWORK", c: "magenta" as const },
  { Icon: Backpack,   title: "Backup Docs", tag: "FILES",   c: "green"   as const },
  { Icon: FolderTree, title: "Tree View",   tag: "FILES",   c: "green"   as const },
  { Icon: Shield,     title: "Firewall",    tag: "NETWORK", c: "magenta" as const },
  { Icon: ScanLine,   title: "Deep Scan",   tag: "SYSTEM",  c: "cyan"    as const },
];

const COMMANDS = [
  "> python --version",
  "> ps aux | head -10",
  "> netstat -an | grep LISTEN",
  "> df -h",
  "> systeminfo",
  "> tasklist /v",
  "> ipconfig /all",
  "> tracert google.com",
];

export const FilesTab = () => {
  const [sub, setSub] = useState<typeof SUBS[number]>("Files");
  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex gap-1.5 p-1 bg-surface-2 border border-border rounded-full w-fit mx-auto">
        {SUBS.map((s) => (
          <button key={s} onClick={() => setSub(s)}
            className={`px-4 py-1.5 rounded-full font-mono text-[0.6rem] font-bold tracking-wider transition ${sub===s?"text-background":"text-muted-foreground"}`}
            style={sub===s ? { background: "var(--gradient-cyan-magenta)", boxShadow: "var(--glow-cyan)" } : undefined}>
            {s.toUpperCase()}
          </button>
        ))}
      </div>

      {sub === "Files" && (
        <>
          <section>
            <SectionHeader title="FILE TRANSFER" badge="P2P" />
            <div className="grid grid-cols-2 gap-2.5">
              <button className="cyber-card aspect-square flex flex-col items-center justify-center gap-2 pressable hover:border-primary/40">
                <ArrowUpFromLine className="w-9 h-9 text-primary" style={{ filter: "drop-shadow(0 0 8px hsl(187 100% 50% / .6))" }} />
                <div className="font-mono text-xs font-bold">SEND FILES</div>
                <div className="label-mono">DROP HERE</div>
              </button>
              <button className="cyber-card aspect-square flex flex-col items-center justify-center gap-2 pressable hover:border-accent/40">
                <ArrowDownToLine className="w-9 h-9 text-accent" style={{ filter: "drop-shadow(0 0 8px hsl(296 100% 55% / .6))" }} />
                <div className="font-mono text-xs font-bold">RECEIVED</div>
                <div className="label-mono">3 ITEMS</div>
              </button>
            </div>
          </section>
          <section>
            <SectionHeader title="CLIPBOARD SYNC" />
            <div className="cyber-card p-3">
              <textarea
                rows={4}
                placeholder="// Paste here to instantly sync with paired PC..."
                className="w-full bg-transparent font-mono text-xs outline-none resize-none placeholder:text-muted-foreground"
              />
              <div className="flex justify-between items-center mt-2">
                <span className="label-mono">END-TO-END · ENCRYPTED</span>
                <Tag color="green">LIVE</Tag>
              </div>
            </div>
          </section>
        </>
      )}

      {sub === "Tools" && (
        <section>
          <SectionHeader title="QUICK TOOLS" badge={`${TOOLS.length}`} />
          <div className="grid grid-cols-2 gap-2.5">
            {TOOLS.map(({ Icon, title, tag, c }) => (
              <button key={title} className="cyber-card p-3 pressable text-left hover:border-primary/40 transition relative">
                <div className="absolute top-2 right-2"><Tag color={c}>{tag}</Tag></div>
                <Icon className="w-6 h-6 mb-2"
                      style={{ color: `hsl(var(--${c==="cyan"?"primary":c==="green"?"success":"accent"}))` }} />
                <div className="font-mono text-xs font-bold">{title}</div>
              </button>
            ))}
          </div>
        </section>
      )}

      {sub === "Terminal" && (
        <section>
          <SectionHeader title="QUICK EXECUTE" badge="LIVE TTY" />
          <div className="grid grid-cols-1 gap-2">
            {COMMANDS.map((cmd) => (
              <button key={cmd} className="cyber-card p-3 pressable text-left flex items-center gap-3 hover:border-success/40 transition">
                <TerminalSquare className="w-4 h-4 text-success" />
                <code className="font-mono text-xs text-success/90 flex-1 truncate" style={{ textShadow: "0 0 6px hsl(135 100% 50% / .35)" }}>
                  {cmd}
                </code>
                <span className="label-mono">RUN</span>
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

```


### `/src/components/nexus/tabs/KbTab.tsx`

```ts path=/src/components/nexus/tabs/KbTab.tsx
import { useState } from "react";
import { Bar, SectionHeader, Tag } from "../atoms";

const SUBS = ["Nexus", "System", "Bridge", "Bot"] as const;

const NeuralGraph = () => {
  const nodes = Array.from({ length: 22 }, (_, i) => ({
    x: 12 + ((i * 47) % 88),
    y: 14 + ((i * 31) % 72),
    r: 1.4 + ((i * 7) % 3) * 0.6,
  }));
  const edges: [number, number][] = [];
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const dx = nodes[i].x - nodes[j].x;
      const dy = nodes[i].y - nodes[j].y;
      if (Math.hypot(dx, dy) < 22) edges.push([i, j]);
    }
  }
  return (
    <svg viewBox="0 0 100 100" className="w-full h-44" preserveAspectRatio="none">
      {edges.map(([a, b], i) => (
        <line key={i} x1={nodes[a].x} y1={nodes[a].y} x2={nodes[b].x} y2={nodes[b].y}
              stroke="hsl(187 100% 50% / .25)" strokeWidth="0.2" />
      ))}
      {nodes.map((n, i) => (
        <circle key={i} cx={n.x} cy={n.y} r={n.r}
                fill={i % 5 === 0 ? "hsl(296 100% 55%)" : "hsl(187 100% 50%)"}
                style={{ filter: "drop-shadow(0 0 2px currentColor)" }} />
      ))}
    </svg>
  );
};

const FindingsChart = () => {
  const data = [12, 18, 22, 19, 28, 35, 31, 42, 48, 44, 55, 63];
  const max = Math.max(...data);
  return (
    <div className="flex items-end gap-1 h-24">
      {data.map((v, i) => (
        <div key={i} className="flex-1 rounded-t-sm transition-all"
             style={{
               height: `${(v / max) * 100}%`,
               background: "linear-gradient(180deg, hsl(187 100% 50%), hsl(296 100% 55% / .5))",
               boxShadow: "0 0 6px hsl(187 100% 50% / .4)",
             }} />
      ))}
    </div>
  );
};

const Donut = () => {
  const segs = [
    { v: 38, c: "hsl(187 100% 50%)" },
    { v: 26, c: "hsl(296 100% 55%)" },
    { v: 18, c: "hsl(135 100% 50%)" },
    { v: 12, c: "hsl(38 100% 50%)" },
    { v: 6,  c: "hsl(350 95% 55%)" },
  ];
  const total = segs.reduce((s, x) => s + x.v, 0);
  const C = 2 * Math.PI * 30;
  let acc = 0;
  return (
    <div className="flex items-center gap-3">
      <svg width="90" height="90" viewBox="0 0 80 80" className="-rotate-90">
        <circle cx="40" cy="40" r="30" stroke="hsl(var(--surface-3))" strokeWidth="10" fill="none" />
        {segs.map((s, i) => {
          const len = (s.v / total) * C;
          const off = (acc / total) * C;
          acc += s.v;
          return (
            <circle key={i} cx="40" cy="40" r="30" stroke={s.c} strokeWidth="10" fill="none"
                    strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-off} />
          );
        })}
      </svg>
      <div className="flex-1 space-y-1">
        {["Tutorials", "API Refs", "Snippets", "Issues", "Other"].map((l, i) => (
          <div key={l} className="flex items-center gap-2 text-[0.6rem] font-mono">
            <span className="w-2 h-2 rounded-full" style={{ background: segs[i].c }} />
            <span className="text-foreground/80 flex-1">{l}</span>
            <span className="text-muted-foreground">{segs[i].v}%</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export const KbTab = () => {
  const [sub, setSub] = useState<typeof SUBS[number]>("Nexus");
  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex gap-1.5 p-1 bg-surface-2 border border-border rounded-full w-fit mx-auto">
        {SUBS.map((s) => (
          <button key={s} onClick={() => setSub(s)}
            className={`px-4 py-1.5 rounded-full font-mono text-[0.6rem] font-bold tracking-wider transition ${
              sub === s ? "text-background" : "text-muted-foreground"
            }`}
            style={sub === s ? { background: "var(--gradient-cyan-magenta)", boxShadow: "var(--glow-cyan)" } : undefined}
          >
            {s.toUpperCase()}
          </button>
        ))}
      </div>

      <section>
        <SectionHeader title="NEURAL KB GRAPH" badge="LIVE" />
        <div className="cyber-card p-3 cyber-border-grad relative overflow-hidden">
          <NeuralGraph />
          <div className="absolute inset-x-0 top-0 h-1/3 pointer-events-none animate-scan"
               style={{ background: "linear-gradient(180deg, hsl(187 100% 50% / .08), transparent)" }} />
        </div>
        <div className="grid grid-cols-4 gap-2 mt-2">
          {[["FINDINGS","482"],["SESSIONS","37"],["KB LINKS","1.2K"],["NODES","94"]].map(([l,v]) => (
            <div key={l} className="cyber-card p-2 text-center">
              <div className="label-mono">{l}</div>
              <div className="font-mono text-sm font-bold glow-text-cyan">{v}</div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader title="FINDINGS GROWTH" badge="12 MO" />
        <div className="cyber-card p-3"><FindingsChart /></div>
      </section>

      <section>
        <SectionHeader title="PROTOCOL STATUS" />
        <div className="space-y-2">
          {[
            { n: "ANEX Local", t: "ACTIVE",   c: "green"   as const, v: "204 ops/s" },
            { n: "SNET Relay", t: "STANDBY",  c: "warning" as const, v: "12 peers"  },
            { n: "FUSE Inject",t: "RUNNING",  c: "cyan"    as const, v: "3 hooks"   },
            { n: "QLOOP",      t: "IDLE",     c: "magenta" as const, v: "queue 0"   },
          ].map((p) => (
            <div key={p.n} className="cyber-card p-3 flex items-center justify-between">
              <div>
                <div className="font-mono text-xs font-bold">{p.n}</div>
                <div className="font-mono text-[0.55rem] text-muted-foreground">{p.v}</div>
              </div>
              <Tag color={p.c}>{p.t}</Tag>
            </div>
          ))}
        </div>
      </section>

      <section className="grid grid-cols-2 gap-2.5">
        <div className="cyber-card p-3">
          <div className="label-mono mb-2">ARTICLES BY SOURCE</div>
          <div className="space-y-2">
            {[["Python Docs",82],["GitHub",64],["StackOverflow",47],["MDN",33],["Reddit",18]].map(([l,v]) => (
              <Bar key={l as string} label={l as string} value={v as number} color="cyan" />
            ))}
          </div>
        </div>
        <div className="cyber-card p-3">
          <div className="label-mono mb-2">KB CATEGORIES</div>
          <Donut />
        </div>
      </section>
    </div>
  );
};

```


### `/src/components/nexus/tabs/PlaceholderTab.tsx`

```ts path=/src/components/nexus/tabs/PlaceholderTab.tsx
import { SectionHeader, Tag } from "../atoms";

export const PlaceholderTab = ({ title, desc }: { title: string; desc: string }) => (
  <div className="space-y-5 animate-fade-in">
    <SectionHeader title={title} badge="MODULE" />
    <div className="cyber-card cyber-border-grad p-6 text-center relative overflow-hidden">
      <div className="absolute inset-x-0 top-0 h-1/2 pointer-events-none animate-scan"
           style={{ background: "linear-gradient(180deg, hsl(187 100% 50% / .08), transparent)" }} />
      <div className="font-mono text-2xl font-black glow-text-cyan tracking-widest">{title}</div>
      <div className="font-mono text-[0.65rem] text-muted-foreground mt-2 max-w-xs mx-auto leading-relaxed">{desc}</div>
      <div className="mt-4 flex justify-center gap-2">
        <Tag color="cyan">READY</Tag>
        <Tag color="magenta">v8.0</Tag>
      </div>
    </div>
  </div>
);

```


### `/src/components/nexus/tabs/SettingsTab.tsx`

```ts path=/src/components/nexus/tabs/SettingsTab.tsx
import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { SectionHeader, Tag } from "../atoms";

const THEMES = [
  { id: "nexus",   name: "Nexus Core",       palette: ["#00E5FF", "#FF00FF", "#0B0E14", "#00FF66"] },
  { id: "phantom", name: "Phantom Red",      palette: ["#FF1744", "#FF6E40", "#0B0E14", "#FFAA00"] },
  { id: "aurora",  name: "Aurora Borealis",  palette: ["#00FFB2", "#7C4DFF", "#0B0E14", "#00E5FF"] },
  { id: "matrix",  name: "Matrix Green",     palette: ["#00FF66", "#00C853", "#000000", "#76FF03"] },
  { id: "synth",   name: "Synthwave",        palette: ["#FF00FF", "#00E5FF", "#1A0033", "#FFAA00"] },
];

const TOGGLES = [
  { id: "anim",  label: "Pause All Animations", desc: "Disable transitions and motion. Best for low-power devices." },
  { id: "bare",  label: "Bare Minimum Mode",    desc: "Strip all effects, glows, and gradients for max performance." },
  { id: "hap",   label: "Disable Haptics",      desc: "Turn off vibration feedback on button press." },
  { id: "tab",   label: "Compact Tab Bar",      desc: "Hide labels in the bottom toolbar to save space." },
];

const STACK = [
  { k: "App Version",   v: "v8.0.0-cyber" },
  { k: "Package",       v: "com.butler.ai" },
  { k: "Engine",        v: "Ollama Local AI" },
  { k: "Architecture",  v: "TanStack Start · React 19" },
];
const DEPS = [
  ["react", "19"], ["@tanstack/react-router", "1"],
  ["tailwindcss", "4"], ["lucide-react", "0.4"], ["ai", "5"],
];

export const SettingsTab = () => {
  const [active, setActive] = useState("nexus");
  const [tg, setTg] = useState<Record<string, boolean>>({ tab: true });
  const [stackOpen, setStackOpen] = useState(true);
  return (
    <div className="space-y-5 animate-fade-in">
      <section>
        <SectionHeader title="ACTIVE THEME" badge={active.toUpperCase()} />
        <div className="space-y-2">
          {THEMES.map((t) => (
            <button key={t.id} onClick={() => setActive(t.id)}
              className={`cyber-card w-full p-3 flex items-center gap-3 pressable transition ${
                active === t.id ? "border-primary/60" : ""
              }`}
              style={active === t.id ? { boxShadow: "0 0 20px hsl(187 100% 50% / .25), inset 0 1px 0 hsl(0 0% 100% / .05)" } : undefined}>
              <div className="relative w-10 h-10 rounded-full overflow-hidden border border-border">
                {t.palette.map((c, i) => (
                  <div key={i} className="absolute" style={{
                    inset: 0,
                    background: c,
                    clipPath: `polygon(50% 50%, ${50 + 50 * Math.cos((i * Math.PI) / 2)}% ${50 + 50 * Math.sin((i * Math.PI) / 2)}%, ${50 + 50 * Math.cos(((i + 1) * Math.PI) / 2)}% ${50 + 50 * Math.sin(((i + 1) * Math.PI) / 2)}%)`,
                  }} />
                ))}
              </div>
              <div className="flex-1 text-left">
                <div className="font-mono text-xs font-bold">{t.name}</div>
                <div className="font-mono text-[0.55rem] text-muted-foreground tracking-wider">{t.palette.join(" · ")}</div>
              </div>
              {active === t.id && <Tag color="cyan">ACTIVE</Tag>}
            </button>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader title="SERVER ADDRESS" />
        <div className="cyber-card p-3 space-y-2">
          {[["IP ADDRESS","192.168.1.42"],["PORT","8765"]].map(([l, v]) => (
            <div key={l}>
              <div className="label-mono mb-1">{l}</div>
              <div className="flex items-center gap-2 px-3 py-2 bg-surface-3 border border-border rounded-lg">
                <span className="text-success font-mono text-xs">{`>`}</span>
                <input defaultValue={v} className="bg-transparent flex-1 font-mono text-xs outline-none" />
                <span className="w-1.5 h-4 bg-primary animate-blink" />
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader title="PERFORMANCE MODE" />
        <div className="space-y-2">
          {TOGGLES.map((t) => {
            const on = !!tg[t.id];
            return (
              <div key={t.id} className="cyber-card p-3 flex items-start gap-3">
                <div className="flex-1">
                  <div className="font-mono text-xs font-bold">{t.label}</div>
                  <div className="font-mono text-[0.6rem] text-muted-foreground mt-0.5">{t.desc}</div>
                </div>
                <button onClick={() => setTg((s) => ({ ...s, [t.id]: !on }))}
                  className={`relative w-10 h-5 rounded-full border transition ${on ? "border-primary/60" : "border-border bg-surface-3"}`}
                  style={on ? { background: "hsl(187 100% 50% / .2)", boxShadow: "0 0 10px hsl(187 100% 50% / .4)" } : undefined}>
                  <span className={`absolute top-0.5 w-4 h-4 rounded-full transition-all ${on ? "left-[22px] bg-primary" : "left-0.5 bg-muted-foreground"}`}
                        style={on ? { boxShadow: "0 0 8px hsl(187 100% 50% / .8)" } : undefined} />
                </button>
              </div>
            );
          })}
        </div>
      </section>

      <section>
        <SectionHeader title="TECH STACK" />
        <div className="cyber-card overflow-hidden">
          <button onClick={() => setStackOpen((o) => !o)} className="w-full flex items-center justify-between p-3 pressable">
            <span className="font-mono text-xs font-bold">System Info</span>
            <ChevronDown className={`w-4 h-4 transition ${stackOpen ? "rotate-180" : ""} text-muted-foreground`} />
          </button>
          {stackOpen && (
            <div className="px-3 pb-3 space-y-2 border-t border-border pt-3">
              {STACK.map((s) => (
                <div key={s.k} className="flex justify-between font-mono text-[0.65rem]">
                  <span className="text-muted-foreground">{s.k}</span>
                  <span className="text-foreground">{s.v}</span>
                </div>
              ))}
              <div className="pt-2 border-t border-border">
                <div className="label-mono mb-2">DEPENDENCIES</div>
                <div className="flex flex-wrap gap-1.5">
                  {DEPS.map(([k, v]) => (
                    <span key={k} className="px-2 py-0.5 rounded-md bg-surface-3 border border-border font-mono text-[0.55rem]">
                      <span className="text-foreground/85">{k}</span>
                      <span className="text-primary"> {v}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

```


### `/src/components/tools/NcxCard.tsx`

```ts path=/src/components/tools/NcxCard.tsx
import type { ReactNode } from "react";

export type NcxColor = "blue" | "green" | "purple" | "cyan" | "amber" | "red";

const COLOR_VAR: Record<NcxColor, string> = {
  blue:   "#4488ff",
  green:  "var(--green)",
  purple: "var(--magenta)",
  cyan:   "var(--cyan)",
  amber:  "var(--orange)",
  red:    "var(--red)",
};

/**
 * NCX card — ported from tools_hub_1.html. Used everywhere the Tools Hub
 * needs a coloured panel with an accent top line + neon-tinted glow.
 */
export function NcxCard({
  color = "cyan",
  icon,
  title,
  children,
  className,
  full,
}: {
  color?: NcxColor;
  icon?: ReactNode;
  title: string;
  children: ReactNode;
  className?: string;
  full?: boolean;
}) {
  const c = COLOR_VAR[color];
  return (
    <div
      className={`ncx-card ${full ? "col-span-2" : ""} ${className ?? ""}`}
      style={{ ["--c" as any]: c }}
    >
      <span className="ncx-card-top" />
      <div className="flex items-center gap-2 border-b border-white/[0.04] px-3 py-2">
        <span className="text-[14px]" style={{ color: c }}>{icon}</span>
        <span
          className="font-mono text-[10px] font-medium uppercase tracking-[0.15em]"
          style={{ color: c }}
        >
          {title}
        </span>
      </div>
      <div className="flex flex-1 flex-col">{children}</div>
    </div>
  );
}

/** Section header with color bar + title + horizontal line. */
export function NcxSection({
  color = "cyan",
  title,
  action,
}: {
  color?: NcxColor;
  title: string;
  action?: ReactNode;
}) {
  const c = COLOR_VAR[color];
  return (
    <div className="mb-2.5 flex items-center gap-2.5">
      <span className="h-[18px] w-[3px] rounded-sm" style={{ background: c }} />
      <h2
        className="font-display text-[12px] font-semibold uppercase tracking-[0.22em]"
        style={{ color: c }}
      >
        {title}
      </h2>
      <span className="h-px flex-1" style={{ background: "var(--border)" }} />
      {action}
    </div>
  );
}

/** Ghost/primary tonal button. */
export function NcxBtn({
  color = "cyan",
  ghost,
  children,
  className,
  ...rest
}: {
  color?: NcxColor;
  ghost?: boolean;
  children: ReactNode;
  className?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const c = COLOR_VAR[color];
  return (
    <button
      {...rest}
      style={{ ["--c" as any]: c, ...(rest.style ?? {}) }}
      className={`ncx-btn ${ghost ? "ncx-btn-ghost" : ""} ${className ?? ""}`}
    >
      {children}
    </button>
  );
}

```


### `/src/components/ui/accordion.tsx`

```ts path=/src/components/ui/accordion.tsx
import * as React from "react";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import { ChevronDown } from "lucide-react";

import { cn } from "@/lib/utils";

const Accordion = AccordionPrimitive.Root;

const AccordionItem = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Item>
>(({ className, ...props }, ref) => (
  <AccordionPrimitive.Item ref={ref} className={cn("border-b", className)} {...props} />
));
AccordionItem.displayName = "AccordionItem";

const AccordionTrigger = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Header className="flex">
    <AccordionPrimitive.Trigger
      ref={ref}
      className={cn(
        "flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180",
        className,
      )}
      {...props}
    >
      {children}
      <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" />
    </AccordionPrimitive.Trigger>
  </AccordionPrimitive.Header>
));
AccordionTrigger.displayName = AccordionPrimitive.Trigger.displayName;

const AccordionContent = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Content
    ref={ref}
    className="overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down"
    {...props}
  >
    <div className={cn("pb-4 pt-0", className)}>{children}</div>
  </AccordionPrimitive.Content>
));
AccordionContent.displayName = AccordionPrimitive.Content.displayName;

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent };

```


### `/src/components/ui/alert-dialog.tsx`

```ts path=/src/components/ui/alert-dialog.tsx
import * as React from "react";
import * as AlertDialogPrimitive from "@radix-ui/react-alert-dialog";

import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";

const AlertDialog = AlertDialogPrimitive.Root;

const AlertDialogTrigger = AlertDialogPrimitive.Trigger;

const AlertDialogPortal = AlertDialogPrimitive.Portal;

const AlertDialogOverlay = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Overlay
    className={cn(
      "fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className,
    )}
    {...props}
    ref={ref}
  />
));
AlertDialogOverlay.displayName = AlertDialogPrimitive.Overlay.displayName;

const AlertDialogContent = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Content>
>(({ className, ...props }, ref) => (
  <AlertDialogPortal>
    <AlertDialogOverlay />
    <AlertDialogPrimitive.Content
      ref={ref}
      className={cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
        className,
      )}
      {...props}
    />
  </AlertDialogPortal>
));
AlertDialogContent.displayName = AlertDialogPrimitive.Content.displayName;

const AlertDialogHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("flex flex-col space-y-2 text-center sm:text-left", className)} {...props} />
);
AlertDialogHeader.displayName = "AlertDialogHeader";

const AlertDialogFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className)}
    {...props}
  />
);
AlertDialogFooter.displayName = "AlertDialogFooter";

const AlertDialogTitle = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold", className)}
    {...props}
  />
));
AlertDialogTitle.displayName = AlertDialogPrimitive.Title.displayName;

const AlertDialogDescription = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
AlertDialogDescription.displayName = AlertDialogPrimitive.Description.displayName;

const AlertDialogAction = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Action>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Action>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Action ref={ref} className={cn(buttonVariants(), className)} {...props} />
));
AlertDialogAction.displayName = AlertDialogPrimitive.Action.displayName;

const AlertDialogCancel = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Cancel>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Cancel>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Cancel
    ref={ref}
    className={cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0", className)}
    {...props}
  />
));
AlertDialogCancel.displayName = AlertDialogPrimitive.Cancel.displayName;

export {
  AlertDialog,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
};

```


### `/src/components/ui/alert.tsx`

```ts path=/src/components/ui/alert.tsx
import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const alertVariants = cva(
  "relative w-full rounded-lg border px-4 py-3 text-sm [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7",
  {
    variants: {
      variant: {
        default: "bg-background text-foreground",
        destructive:
          "border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

const Alert = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & VariantProps<typeof alertVariants>
>(({ className, variant, ...props }, ref) => (
  <div ref={ref} role="alert" className={cn(alertVariants({ variant }), className)} {...props} />
));
Alert.displayName = "Alert";

const AlertTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h5
      ref={ref}
      className={cn("mb-1 font-medium leading-none tracking-tight", className)}
      {...props}
    />
  ),
);
AlertTitle.displayName = "AlertTitle";

const AlertDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("text-sm [&_p]:leading-relaxed", className)} {...props} />
));
AlertDescription.displayName = "AlertDescription";

export { Alert, AlertTitle, AlertDescription };

```


### `/src/components/ui/aspect-ratio.tsx`

```ts path=/src/components/ui/aspect-ratio.tsx
import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio";

const AspectRatio = AspectRatioPrimitive.Root;

export { AspectRatio };

```


### `/src/components/ui/avatar.tsx`

```ts path=/src/components/ui/avatar.tsx
"use client";

import * as React from "react";
import * as AvatarPrimitive from "@radix-ui/react-avatar";

import { cn } from "@/lib/utils";

const Avatar = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Root>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Root
    ref={ref}
    className={cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className)}
    {...props}
  />
));
Avatar.displayName = AvatarPrimitive.Root.displayName;

const AvatarImage = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Image>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Image>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Image
    ref={ref}
    className={cn("aspect-square h-full w-full", className)}
    {...props}
  />
));
AvatarImage.displayName = AvatarPrimitive.Image.displayName;

const AvatarFallback = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Fallback>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Fallback>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Fallback
    ref={ref}
    className={cn(
      "flex h-full w-full items-center justify-center rounded-full bg-muted",
      className,
    )}
    {...props}
  />
));
AvatarFallback.displayName = AvatarPrimitive.Fallback.displayName;

export { Avatar, AvatarImage, AvatarFallback };

```


### `/src/components/ui/badge.tsx`

```ts path=/src/components/ui/badge.tsx
import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
        secondary:
          "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive:
          "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
        outline: "text-foreground",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };

```


### `/src/components/ui/breadcrumb.tsx`

```ts path=/src/components/ui/breadcrumb.tsx
import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { ChevronRight, MoreHorizontal } from "lucide-react";

import { cn } from "@/lib/utils";

const Breadcrumb = React.forwardRef<
  HTMLElement,
  React.ComponentPropsWithoutRef<"nav"> & {
    separator?: React.ReactNode;
  }
>(({ ...props }, ref) => <nav ref={ref} aria-label="breadcrumb" {...props} />);
Breadcrumb.displayName = "Breadcrumb";

const BreadcrumbList = React.forwardRef<HTMLOListElement, React.ComponentPropsWithoutRef<"ol">>(
  ({ className, ...props }, ref) => (
    <ol
      ref={ref}
      className={cn(
        "flex flex-wrap items-center gap-1.5 break-words text-sm text-muted-foreground sm:gap-2.5",
        className,
      )}
      {...props}
    />
  ),
);
BreadcrumbList.displayName = "BreadcrumbList";

const BreadcrumbItem = React.forwardRef<HTMLLIElement, React.ComponentPropsWithoutRef<"li">>(
  ({ className, ...props }, ref) => (
    <li ref={ref} className={cn("inline-flex items-center gap-1.5", className)} {...props} />
  ),
);
BreadcrumbItem.displayName = "BreadcrumbItem";

const BreadcrumbLink = React.forwardRef<
  HTMLAnchorElement,
  React.ComponentPropsWithoutRef<"a"> & {
    asChild?: boolean;
  }
>(({ asChild, className, ...props }, ref) => {
  const Comp = asChild ? Slot : "a";

  return (
    <Comp
      ref={ref}
      className={cn("transition-colors hover:text-foreground", className)}
      {...props}
    />
  );
});
BreadcrumbLink.displayName = "BreadcrumbLink";

const BreadcrumbPage = React.forwardRef<HTMLSpanElement, React.ComponentPropsWithoutRef<"span">>(
  ({ className, ...props }, ref) => (
    <span
      ref={ref}
      role="link"
      aria-disabled="true"
      aria-current="page"
      className={cn("font-normal text-foreground", className)}
      {...props}
    />
  ),
);
BreadcrumbPage.displayName = "BreadcrumbPage";

const BreadcrumbSeparator = ({ children, className, ...props }: React.ComponentProps<"li">) => (
  <li
    role="presentation"
    aria-hidden="true"
    className={cn("[&>svg]:w-3.5 [&>svg]:h-3.5", className)}
    {...props}
  >
    {children ?? <ChevronRight />}
  </li>
);
BreadcrumbSeparator.displayName = "BreadcrumbSeparator";

const BreadcrumbEllipsis = ({ className, ...props }: React.ComponentProps<"span">) => (
  <span
    role="presentation"
    aria-hidden="true"
    className={cn("flex h-9 w-9 items-center justify-center", className)}
    {...props}
  >
    <MoreHorizontal className="h-4 w-4" />
    <span className="sr-only">More</span>
  </span>
);
BreadcrumbEllipsis.displayName = "BreadcrumbElipssis";

export {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator,
  BreadcrumbEllipsis,
};

```


### `/src/components/ui/button.tsx`

```ts path=/src/components/ui/button.tsx
import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline:
          "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };

```


### `/src/components/ui/calendar.tsx`

```ts path=/src/components/ui/calendar.tsx
"use client";

import * as React from "react";
import { ChevronDownIcon, ChevronLeftIcon, ChevronRightIcon } from "lucide-react";
import { DayButton, DayPicker, getDefaultClassNames } from "react-day-picker";

import { cn } from "@/lib/utils";
import { Button, buttonVariants } from "@/components/ui/button";

function Calendar({
  className,
  classNames,
  showOutsideDays = true,
  captionLayout = "label",
  buttonVariant = "ghost",
  formatters,
  components,
  ...props
}: React.ComponentProps<typeof DayPicker> & {
  buttonVariant?: React.ComponentProps<typeof Button>["variant"];
}) {
  const defaultClassNames = getDefaultClassNames();

  return (
    <DayPicker
      showOutsideDays={showOutsideDays}
      className={cn(
        "bg-background group/calendar p-3 [--cell-size:2rem] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent",
        String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`,
        String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`,
        className,
      )}
      captionLayout={captionLayout}
      formatters={{
        formatMonthDropdown: (date) => date.toLocaleString("default", { month: "short" }),
        ...formatters,
      }}
      classNames={{
        root: cn("w-fit", defaultClassNames.root),
        months: cn("relative flex flex-col gap-4 md:flex-row", defaultClassNames.months),
        month: cn("flex w-full flex-col gap-4", defaultClassNames.month),
        nav: cn(
          "absolute inset-x-0 top-0 flex w-full items-center justify-between gap-1",
          defaultClassNames.nav,
        ),
        button_previous: cn(
          buttonVariants({ variant: buttonVariant }),
          "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_previous,
        ),
        button_next: cn(
          buttonVariants({ variant: buttonVariant }),
          "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_next,
        ),
        month_caption: cn(
          "flex h-(--cell-size) w-full items-center justify-center px-(--cell-size)",
          defaultClassNames.month_caption,
        ),
        dropdowns: cn(
          "flex h-(--cell-size) w-full items-center justify-center gap-1.5 text-sm font-medium",
          defaultClassNames.dropdowns,
        ),
        dropdown_root: cn(
          "has-focus:border-ring border-input shadow-xs has-focus:ring-ring/50 has-focus:ring-[3px] relative rounded-md border",
          defaultClassNames.dropdown_root,
        ),
        dropdown: cn("bg-popover absolute inset-0 opacity-0", defaultClassNames.dropdown),
        caption_label: cn(
          "select-none font-medium",
          captionLayout === "label"
            ? "text-sm"
            : "[&>svg]:text-muted-foreground flex h-8 items-center gap-1 rounded-md pl-2 pr-1 text-sm [&>svg]:size-3.5",
          defaultClassNames.caption_label,
        ),
        table: "w-full border-collapse",
        weekdays: cn("flex", defaultClassNames.weekdays),
        weekday: cn(
          "text-muted-foreground flex-1 select-none rounded-md text-[0.8rem] font-normal",
          defaultClassNames.weekday,
        ),
        week: cn("mt-2 flex w-full", defaultClassNames.week),
        week_number_header: cn("w-(--cell-size) select-none", defaultClassNames.week_number_header),
        week_number: cn(
          "text-muted-foreground select-none text-[0.8rem]",
          defaultClassNames.week_number,
        ),
        day: cn(
          "group/day relative aspect-square h-full w-full select-none p-0 text-center [&:first-child[data-selected=true]_button]:rounded-l-md [&:last-child[data-selected=true]_button]:rounded-r-md",
          defaultClassNames.day,
        ),
        range_start: cn("bg-accent rounded-l-md", defaultClassNames.range_start),
        range_middle: cn("rounded-none", defaultClassNames.range_middle),
        range_end: cn("bg-accent rounded-r-md", defaultClassNames.range_end),
        today: cn(
          "bg-accent text-accent-foreground rounded-md data-[selected=true]:rounded-none",
          defaultClassNames.today,
        ),
        outside: cn(
          "text-muted-foreground aria-selected:text-muted-foreground",
          defaultClassNames.outside,
        ),
        disabled: cn("text-muted-foreground opacity-50", defaultClassNames.disabled),
        hidden: cn("invisible", defaultClassNames.hidden),
        ...classNames,
      }}
      components={{
        Root: ({ className, rootRef, ...props }) => {
          return <div data-slot="calendar" ref={rootRef} className={cn(className)} {...props} />;
        },
        Chevron: ({ className, orientation, ...props }) => {
          if (orientation === "left") {
            return <ChevronLeftIcon className={cn("size-4", className)} {...props} />;
          }

          if (orientation === "right") {
            return <ChevronRightIcon className={cn("size-4", className)} {...props} />;
          }

          return <ChevronDownIcon className={cn("size-4", className)} {...props} />;
        },
        DayButton: CalendarDayButton,
        WeekNumber: ({ children, ...props }) => {
          return (
            <td {...props}>
              <div className="flex size-(--cell-size) items-center justify-center text-center">
                {children}
              </div>
            </td>
          );
        },
        ...components,
      }}
      {...props}
    />
  );
}

function CalendarDayButton({
  className,
  day,
  modifiers,
  ...props
}: React.ComponentProps<typeof DayButton>) {
  const defaultClassNames = getDefaultClassNames();

  const ref = React.useRef<HTMLButtonElement>(null);
  React.useEffect(() => {
    if (modifiers.focused) ref.current?.focus();
  }, [modifiers.focused]);

  return (
    <Button
      ref={ref}
      variant="ghost"
      size="icon"
      data-day={day.date.toLocaleDateString()}
      data-selected-single={
        modifiers.selected &&
        !modifiers.range_start &&
        !modifiers.range_end &&
        !modifiers.range_middle
      }
      data-range-start={modifiers.range_start}
      data-range-end={modifiers.range_end}
      data-range-middle={modifiers.range_middle}
      className={cn(
        "data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-ring/50 flex aspect-square h-auto w-full min-w-(--cell-size) flex-col gap-1 font-normal leading-none data-[range-end=true]:rounded-md data-[range-middle=true]:rounded-none data-[range-start=true]:rounded-md group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px] [&>span]:text-xs [&>span]:opacity-70",
        defaultClassNames.day,
        className,
      )}
      {...props}
    />
  );
}

export { Calendar, CalendarDayButton };

```


### `/src/components/ui/card.tsx`

```ts path=/src/components/ui/card.tsx
import * as React from "react";

import { cn } from "@/lib/utils";

const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("rounded-xl border bg-card text-card-foreground shadow", className)}
      {...props}
    />
  ),
);
Card.displayName = "Card";

const CardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex flex-col space-y-1.5 p-6", className)} {...props} />
  ),
);
CardHeader.displayName = "CardHeader";

const CardTitle = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("font-semibold leading-none tracking-tight", className)}
      {...props}
    />
  ),
);
CardTitle.displayName = "CardTitle";

const CardDescription = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("text-sm text-muted-foreground", className)} {...props} />
  ),
);
CardDescription.displayName = "CardDescription";

const CardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("p-6 pt-0", className)} {...props} />
  ),
);
CardContent.displayName = "CardContent";

const CardFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex items-center p-6 pt-0", className)} {...props} />
  ),
);
CardFooter.displayName = "CardFooter";

export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent };

```


### `/src/components/ui/carousel.tsx`

```ts path=/src/components/ui/carousel.tsx
import * as React from "react";
import useEmblaCarousel, { type UseEmblaCarouselType } from "embla-carousel-react";
import { ArrowLeft, ArrowRight } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

type CarouselApi = UseEmblaCarouselType[1];
type UseCarouselParameters = Parameters<typeof useEmblaCarousel>;
type CarouselOptions = UseCarouselParameters[0];
type CarouselPlugin = UseCarouselParameters[1];

type CarouselProps = {
  opts?: CarouselOptions;
  plugins?: CarouselPlugin;
  orientation?: "horizontal" | "vertical";
  setApi?: (api: CarouselApi) => void;
};

type CarouselContextProps = {
  carouselRef: ReturnType<typeof useEmblaCarousel>[0];
  api: ReturnType<typeof useEmblaCarousel>[1];
  scrollPrev: () => void;
  scrollNext: () => void;
  canScrollPrev: boolean;
  canScrollNext: boolean;
} & CarouselProps;

const CarouselContext = React.createContext<CarouselContextProps | null>(null);

function useCarousel() {
  const context = React.useContext(CarouselContext);

  if (!context) {
    throw new Error("useCarousel must be used within a <Carousel />");
  }

  return context;
}

const Carousel = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & CarouselProps
>(({ orientation = "horizontal", opts, setApi, plugins, className, children, ...props }, ref) => {
  const [carouselRef, api] = useEmblaCarousel(
    {
      ...opts,
      axis: orientation === "horizontal" ? "x" : "y",
    },
    plugins,
  );
  const [canScrollPrev, setCanScrollPrev] = React.useState(false);
  const [canScrollNext, setCanScrollNext] = React.useState(false);

  const onSelect = React.useCallback((api: CarouselApi) => {
    if (!api) {
      return;
    }

    setCanScrollPrev(api.canScrollPrev());
    setCanScrollNext(api.canScrollNext());
  }, []);

  const scrollPrev = React.useCallback(() => {
    api?.scrollPrev();
  }, [api]);

  const scrollNext = React.useCallback(() => {
    api?.scrollNext();
  }, [api]);

  const handleKeyDown = React.useCallback(
    (event: React.KeyboardEvent<HTMLDivElement>) => {
      if (event.key === "ArrowLeft") {
        event.preventDefault();
        scrollPrev();
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        scrollNext();
      }
    },
    [scrollPrev, scrollNext],
  );

  React.useEffect(() => {
    if (!api || !setApi) {
      return;
    }

    setApi(api);
  }, [api, setApi]);

  React.useEffect(() => {
    if (!api) {
      return;
    }

    onSelect(api);
    api.on("reInit", onSelect);
    api.on("select", onSelect);

    return () => {
      api?.off("select", onSelect);
    };
  }, [api, onSelect]);

  return (
    <CarouselContext.Provider
      value={{
        carouselRef,
        api: api,
        opts,
        orientation: orientation || (opts?.axis === "y" ? "vertical" : "horizontal"),
        scrollPrev,
        scrollNext,
        canScrollPrev,
        canScrollNext,
      }}
    >
      <div
        ref={ref}
        onKeyDownCapture={handleKeyDown}
        className={cn("relative", className)}
        role="region"
        aria-roledescription="carousel"
        {...props}
      >
        {children}
      </div>
    </CarouselContext.Provider>
  );
});
Carousel.displayName = "Carousel";

const CarouselContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => {
    const { carouselRef, orientation } = useCarousel();

    return (
      <div ref={carouselRef} className="overflow-hidden">
        <div
          ref={ref}
          className={cn(
            "flex",
            orientation === "horizontal" ? "-ml-4" : "-mt-4 flex-col",
            className,
          )}
          {...props}
        />
      </div>
    );
  },
);
CarouselContent.displayName = "CarouselContent";

const CarouselItem = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => {
    const { orientation } = useCarousel();

    return (
      <div
        ref={ref}
        role="group"
        aria-roledescription="slide"
        className={cn(
          "min-w-0 shrink-0 grow-0 basis-full",
          orientation === "horizontal" ? "pl-4" : "pt-4",
          className,
        )}
        {...props}
      />
    );
  },
);
CarouselItem.displayName = "CarouselItem";

const CarouselPrevious = React.forwardRef<HTMLButtonElement, React.ComponentProps<typeof Button>>(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollPrev, canScrollPrev } = useCarousel();

    return (
      <Button
        ref={ref}
        variant={variant}
        size={size}
        className={cn(
          "absolute  h-8 w-8 rounded-full",
          orientation === "horizontal"
            ? "-left-12 top-1/2 -translate-y-1/2"
            : "-top-12 left-1/2 -translate-x-1/2 rotate-90",
          className,
        )}
        disabled={!canScrollPrev}
        onClick={scrollPrev}
        {...props}
      >
        <ArrowLeft className="h-4 w-4" />
        <span className="sr-only">Previous slide</span>
      </Button>
    );
  },
);
CarouselPrevious.displayName = "CarouselPrevious";

const CarouselNext = React.forwardRef<HTMLButtonElement, React.ComponentProps<typeof Button>>(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollNext, canScrollNext } = useCarousel();

    return (
      <Button
        ref={ref}
        variant={variant}
        size={size}
        className={cn(
          "absolute h-8 w-8 rounded-full",
          orientation === "horizontal"
            ? "-right-12 top-1/2 -translate-y-1/2"
            : "-bottom-12 left-1/2 -translate-x-1/2 rotate-90",
          className,
        )}
        disabled={!canScrollNext}
        onClick={scrollNext}
        {...props}
      >
        <ArrowRight className="h-4 w-4" />
        <span className="sr-only">Next slide</span>
      </Button>
    );
  },
);
CarouselNext.displayName = "CarouselNext";

export {
  type CarouselApi,
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselPrevious,
  CarouselNext,
};

```


### `/src/components/ui/chart.tsx`

```ts path=/src/components/ui/chart.tsx
import * as React from "react";
import * as RechartsPrimitive from "recharts";

import { cn } from "@/lib/utils";

// Format: { THEME_NAME: CSS_SELECTOR }
const THEMES = { light: "", dark: ".dark" } as const;

export type ChartConfig = {
  [k in string]: {
    label?: React.ReactNode;
    icon?: React.ComponentType;
  } & (
    | { color?: string; theme?: never }
    | { color?: never; theme: Record<keyof typeof THEMES, string> }
  );
};

type ChartContextProps = {
  config: ChartConfig;
};

const ChartContext = React.createContext<ChartContextProps | null>(null);

function useChart() {
  const context = React.useContext(ChartContext);

  if (!context) {
    throw new Error("useChart must be used within a <ChartContainer />");
  }

  return context;
}

const ChartContainer = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    config: ChartConfig;
    children: React.ComponentProps<typeof RechartsPrimitive.ResponsiveContainer>["children"];
  }
>(({ id, className, children, config, ...props }, ref) => {
  const uniqueId = React.useId();
  const chartId = `chart-${id || uniqueId.replace(/:/g, "")}`;

  return (
    <ChartContext.Provider value={{ config }}>
      <div
        data-chart={chartId}
        ref={ref}
        className={cn(
          "flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-none [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-sector]:outline-none [&_.recharts-surface]:outline-none",
          className,
        )}
        {...props}
      >
        <ChartStyle id={chartId} config={config} />
        <RechartsPrimitive.ResponsiveContainer>{children}</RechartsPrimitive.ResponsiveContainer>
      </div>
    </ChartContext.Provider>
  );
});
ChartContainer.displayName = "Chart";

const ChartStyle = ({ id, config }: { id: string; config: ChartConfig }) => {
  const colorConfig = Object.entries(config).filter(([, config]) => config.theme || config.color);

  if (!colorConfig.length) {
    return null;
  }

  return (
    <style
      dangerouslySetInnerHTML={{
        __html: Object.entries(THEMES)
          .map(
            ([theme, prefix]) => `
${prefix} [data-chart=${id}] {
${colorConfig
  .map(([key, itemConfig]) => {
    const color = itemConfig.theme?.[theme as keyof typeof itemConfig.theme] || itemConfig.color;
    return color ? `  --color-${key}: ${color};` : null;
  })
  .join("\n")}
}
`,
          )
          .join("\n"),
      }}
    />
  );
};

const ChartTooltip = RechartsPrimitive.Tooltip;

const ChartTooltipContent = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<typeof RechartsPrimitive.Tooltip> &
    React.ComponentProps<"div"> & {
      hideLabel?: boolean;
      hideIndicator?: boolean;
      indicator?: "line" | "dot" | "dashed";
      nameKey?: string;
      labelKey?: string;
    }
>(
  (
    {
      active,
      payload,
      className,
      indicator = "dot",
      hideLabel = false,
      hideIndicator = false,
      label,
      labelFormatter,
      labelClassName,
      formatter,
      color,
      nameKey,
      labelKey,
    },
    ref,
  ) => {
    const { config } = useChart();

    const tooltipLabel = React.useMemo(() => {
      if (hideLabel || !payload?.length) {
        return null;
      }

      const [item] = payload;
      const key = `${labelKey || item?.dataKey || item?.name || "value"}`;
      const itemConfig = getPayloadConfigFromPayload(config, item, key);
      const value =
        !labelKey && typeof label === "string"
          ? config[label as keyof typeof config]?.label || label
          : itemConfig?.label;

      if (labelFormatter) {
        return (
          <div className={cn("font-medium", labelClassName)}>{labelFormatter(value, payload)}</div>
        );
      }

      if (!value) {
        return null;
      }

      return <div className={cn("font-medium", labelClassName)}>{value}</div>;
    }, [label, labelFormatter, payload, hideLabel, labelClassName, config, labelKey]);

    if (!active || !payload?.length) {
      return null;
    }

    const nestLabel = payload.length === 1 && indicator !== "dot";

    return (
      <div
        ref={ref}
        className={cn(
          "grid min-w-[8rem] items-start gap-1.5 rounded-lg border border-border/50 bg-background px-2.5 py-1.5 text-xs shadow-xl",
          className,
        )}
      >
        {!nestLabel ? tooltipLabel : null}
        <div className="grid gap-1.5">
          {payload
            .filter((item) => item.type !== "none")
            .map((item, index) => {
              const key = `${nameKey || item.name || item.dataKey || "value"}`;
              const itemConfig = getPayloadConfigFromPayload(config, item, key);
              const indicatorColor = color || item.payload.fill || item.color;

              return (
                <div
                  key={item.dataKey}
                  className={cn(
                    "flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5 [&>svg]:text-muted-foreground",
                    indicator === "dot" && "items-center",
                  )}
                >
                  {formatter && item?.value !== undefined && item.name ? (
                    formatter(item.value, item.name, item, index, item.payload)
                  ) : (
                    <>
                      {itemConfig?.icon ? (
                        <itemConfig.icon />
                      ) : (
                        !hideIndicator && (
                          <div
                            className={cn(
                              "shrink-0 rounded-[2px] border-(--color-border) bg-(--color-bg)",
                              {
                                "h-2.5 w-2.5": indicator === "dot",
                                "w-1": indicator === "line",
                                "w-0 border-[1.5px] border-dashed bg-transparent":
                                  indicator === "dashed",
                                "my-0.5": nestLabel && indicator === "dashed",
                              },
                            )}
                            style={
                              {
                                "--color-bg": indicatorColor,
                                "--color-border": indicatorColor,
                              } as React.CSSProperties
                            }
                          />
                        )
                      )}
                      <div
                        className={cn(
                          "flex flex-1 justify-between leading-none",
                          nestLabel ? "items-end" : "items-center",
                        )}
                      >
                        <div className="grid gap-1.5">
                          {nestLabel ? tooltipLabel : null}
                          <span className="text-muted-foreground">
                            {itemConfig?.label || item.name}
                          </span>
                        </div>
                        {item.value && (
                          <span className="font-mono font-medium tabular-nums text-foreground">
                            {item.value.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </>
                  )}
                </div>
              );
            })}
        </div>
      </div>
    );
  },
);
ChartTooltipContent.displayName = "ChartTooltip";

const ChartLegend = RechartsPrimitive.Legend;

const ChartLegendContent = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> &
    Pick<RechartsPrimitive.LegendProps, "payload" | "verticalAlign"> & {
      hideIcon?: boolean;
      nameKey?: string;
    }
>(({ className, hideIcon = false, payload, verticalAlign = "bottom", nameKey }, ref) => {
  const { config } = useChart();

  if (!payload?.length) {
    return null;
  }

  return (
    <div
      ref={ref}
      className={cn(
        "flex items-center justify-center gap-4",
        verticalAlign === "top" ? "pb-3" : "pt-3",
        className,
      )}
    >
      {payload
        .filter((item) => item.type !== "none")
        .map((item) => {
          const key = `${nameKey || item.dataKey || "value"}`;
          const itemConfig = getPayloadConfigFromPayload(config, item, key);

          return (
            <div
              key={item.value}
              className={cn(
                "flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3 [&>svg]:text-muted-foreground",
              )}
            >
              {itemConfig?.icon && !hideIcon ? (
                <itemConfig.icon />
              ) : (
                <div
                  className="h-2 w-2 shrink-0 rounded-[2px]"
                  style={{
                    backgroundColor: item.color,
                  }}
                />
              )}
              {itemConfig?.label}
            </div>
          );
        })}
    </div>
  );
});
ChartLegendContent.displayName = "ChartLegend";

// Helper to extract item config from a payload.
function getPayloadConfigFromPayload(config: ChartConfig, payload: unknown, key: string) {
  if (typeof payload !== "object" || payload === null) {
    return undefined;
  }

  const payloadPayload =
    "payload" in payload && typeof payload.payload === "object" && payload.payload !== null
      ? payload.payload
      : undefined;

  let configLabelKey: string = key;

  if (key in payload && typeof payload[key as keyof typeof payload] === "string") {
    configLabelKey = payload[key as keyof typeof payload] as string;
  } else if (
    payloadPayload &&
    key in payloadPayload &&
    typeof payloadPayload[key as keyof typeof payloadPayload] === "string"
  ) {
    configLabelKey = payloadPayload[key as keyof typeof payloadPayload] as string;
  }

  return configLabelKey in config ? config[configLabelKey] : config[key as keyof typeof config];
}

export {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  ChartStyle,
};

```


### `/src/components/ui/checkbox.tsx`

```ts path=/src/components/ui/checkbox.tsx
import * as React from "react";
import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import { Check } from "lucide-react";

import { cn } from "@/lib/utils";

const Checkbox = React.forwardRef<
  React.ElementRef<typeof CheckboxPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof CheckboxPrimitive.Root>
>(({ className, ...props }, ref) => (
  <CheckboxPrimitive.Root
    ref={ref}
    className={cn(
      "grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground",
      className,
    )}
    {...props}
  >
    <CheckboxPrimitive.Indicator className={cn("grid place-content-center text-current")}>
      <Check className="h-4 w-4" />
    </CheckboxPrimitive.Indicator>
  </CheckboxPrimitive.Root>
));
Checkbox.displayName = CheckboxPrimitive.Root.displayName;

export { Checkbox };

```


### `/src/components/ui/collapsible.tsx`

```ts path=/src/components/ui/collapsible.tsx
"use client";

import * as CollapsiblePrimitive from "@radix-ui/react-collapsible";

const Collapsible = CollapsiblePrimitive.Root;

const CollapsibleTrigger = CollapsiblePrimitive.CollapsibleTrigger;

const CollapsibleContent = CollapsiblePrimitive.CollapsibleContent;

export { Collapsible, CollapsibleTrigger, CollapsibleContent };

```


### `/src/components/ui/command.tsx`

```ts path=/src/components/ui/command.tsx
"use client";

import * as React from "react";
import { type DialogProps } from "@radix-ui/react-dialog";
import { Command as CommandPrimitive } from "cmdk";
import { Search } from "lucide-react";

import { cn } from "@/lib/utils";
import { Dialog, DialogContent } from "@/components/ui/dialog";

const Command = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive>
>(({ className, ...props }, ref) => (
  <CommandPrimitive
    ref={ref}
    className={cn(
      "flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",
      className,
    )}
    {...props}
  />
));
Command.displayName = CommandPrimitive.displayName;

const CommandDialog = ({ children, ...props }: DialogProps) => {
  return (
    <Dialog {...props}>
      <DialogContent className="overflow-hidden p-0">
        <Command className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-group]]:px-2 [&_[cmdk-input-wrapper]_svg]:h-5 [&_[cmdk-input-wrapper]_svg]:w-5 [&_[cmdk-input]]:h-12 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-3 [&_[cmdk-item]_svg]:h-5 [&_[cmdk-item]_svg]:w-5">
          {children}
        </Command>
      </DialogContent>
    </Dialog>
  );
};

const CommandInput = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Input>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Input>
>(({ className, ...props }, ref) => (
  <div className="flex items-center border-b px-3" cmdk-input-wrapper="">
    <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
    <CommandPrimitive.Input
      ref={ref}
      className={cn(
        "flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...props}
    />
  </div>
));

CommandInput.displayName = CommandPrimitive.Input.displayName;

const CommandList = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.List>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.List
    ref={ref}
    className={cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className)}
    {...props}
  />
));

CommandList.displayName = CommandPrimitive.List.displayName;

const CommandEmpty = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Empty>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Empty>
>((props, ref) => (
  <CommandPrimitive.Empty ref={ref} className="py-6 text-center text-sm" {...props} />
));

CommandEmpty.displayName = CommandPrimitive.Empty.displayName;

const CommandGroup = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Group>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Group>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Group
    ref={ref}
    className={cn(
      "overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground",
      className,
    )}
    {...props}
  />
));

CommandGroup.displayName = CommandPrimitive.Group.displayName;

const CommandSeparator = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 h-px bg-border", className)}
    {...props}
  />
));
CommandSeparator.displayName = CommandPrimitive.Separator.displayName;

const CommandItem = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Item>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      className,
    )}
    {...props}
  />
));

CommandItem.displayName = CommandPrimitive.Item.displayName;

const CommandShortcut = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => {
  return (
    <span
      className={cn("ml-auto text-xs tracking-widest text-muted-foreground", className)}
      {...props}
    />
  );
};
CommandShortcut.displayName = "CommandShortcut";

export {
  Command,
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandShortcut,
  CommandSeparator,
};

```


### `/src/components/ui/context-menu.tsx`

```ts path=/src/components/ui/context-menu.tsx
import * as React from "react";
import * as ContextMenuPrimitive from "@radix-ui/react-context-menu";
import { Check, ChevronRight, Circle } from "lucide-react";

import { cn } from "@/lib/utils";

const ContextMenu = ContextMenuPrimitive.Root;

const ContextMenuTrigger = ContextMenuPrimitive.Trigger;

const ContextMenuGroup = ContextMenuPrimitive.Group;

const ContextMenuPortal = ContextMenuPrimitive.Portal;

const ContextMenuSub = ContextMenuPrimitive.Sub;

const ContextMenuRadioGroup = ContextMenuPrimitive.RadioGroup;

const ContextMenuSubTrigger = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.SubTrigger>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.SubTrigger> & {
    inset?: boolean;
  }
>(({ className, inset, children, ...props }, ref) => (
  <ContextMenuPrimitive.SubTrigger
    ref={ref}
    className={cn(
      "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
      inset && "pl-8",
      className,
    )}
    {...props}
  >
    {children}
    <ChevronRight className="ml-auto h-4 w-4" />
  </ContextMenuPrimitive.SubTrigger>
));
ContextMenuSubTrigger.displayName = ContextMenuPrimitive.SubTrigger.displayName;

const ContextMenuSubContent = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.SubContent>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.SubContent>
>(({ className, ...props }, ref) => (
  <ContextMenuPrimitive.SubContent
    ref={ref}
    className={cn(
      "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-context-menu-content-transform-origin)",
      className,
    )}
    {...props}
  />
));
ContextMenuSubContent.displayName = ContextMenuPrimitive.SubContent.displayName;

const ContextMenuContent = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.Content>
>(({ className, ...props }, ref) => (
  <ContextMenuPrimitive.Portal>
    <ContextMenuPrimitive.Content
      ref={ref}
      className={cn(
        "z-50 max-h-(--radix-context-menu-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-context-menu-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </ContextMenuPrimitive.Portal>
));
ContextMenuContent.displayName = ContextMenuPrimitive.Content.displayName;

const ContextMenuItem = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.Item> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <ContextMenuPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      inset && "pl-8",
      className,
    )}
    {...props}
  />
));
ContextMenuItem.displayName = ContextMenuPrimitive.Item.displayName;

const ContextMenuCheckboxItem = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.CheckboxItem>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.CheckboxItem>
>(({ className, children, checked, ...props }, ref) => (
  <ContextMenuPrimitive.CheckboxItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    checked={checked}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <ContextMenuPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </ContextMenuPrimitive.ItemIndicator>
    </span>
    {children}
  </ContextMenuPrimitive.CheckboxItem>
));
ContextMenuCheckboxItem.displayName = ContextMenuPrimitive.CheckboxItem.displayName;

const ContextMenuRadioItem = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.RadioItem>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.RadioItem>
>(({ className, children, ...props }, ref) => (
  <ContextMenuPrimitive.RadioItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <ContextMenuPrimitive.ItemIndicator>
        <Circle className="h-4 w-4 fill-current" />
      </ContextMenuPrimitive.ItemIndicator>
    </span>
    {children}
  </ContextMenuPrimitive.RadioItem>
));
ContextMenuRadioItem.displayName = ContextMenuPrimitive.RadioItem.displayName;

const ContextMenuLabel = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.Label> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <ContextMenuPrimitive.Label
    ref={ref}
    className={cn("px-2 py-1.5 text-sm font-semibold text-foreground", inset && "pl-8", className)}
    {...props}
  />
));
ContextMenuLabel.displayName = ContextMenuPrimitive.Label.displayName;

const ContextMenuSeparator = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <ContextMenuPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-border", className)}
    {...props}
  />
));
ContextMenuSeparator.displayName = ContextMenuPrimitive.Separator.displayName;

const ContextMenuShortcut = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => {
  return (
    <span
      className={cn("ml-auto text-xs tracking-widest text-muted-foreground", className)}
      {...props}
    />
  );
};
ContextMenuShortcut.displayName = "ContextMenuShortcut";

export {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuCheckboxItem,
  ContextMenuRadioItem,
  ContextMenuLabel,
  ContextMenuSeparator,
  ContextMenuShortcut,
  ContextMenuGroup,
  ContextMenuPortal,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
  ContextMenuRadioGroup,
};

```


### `/src/components/ui/dialog.tsx`

```ts path=/src/components/ui/dialog.tsx
"use client";

import * as React from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";

import { cn } from "@/lib/utils";

const Dialog = DialogPrimitive.Root;

const DialogTrigger = DialogPrimitive.Trigger;

const DialogPortal = DialogPrimitive.Portal;

const DialogClose = DialogPrimitive.Close;

const DialogOverlay = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Overlay
    ref={ref}
    className={cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className,
    )}
    {...props}
  />
));
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;

const DialogContent = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <DialogPortal>
    <DialogOverlay />
    <DialogPrimitive.Content
      ref={ref}
      className={cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
        className,
      )}
      {...props}
    >
      {children}
      <DialogPrimitive.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
        <X className="h-4 w-4" />
        <span className="sr-only">Close</span>
      </DialogPrimitive.Close>
    </DialogPrimitive.Content>
  </DialogPortal>
));
DialogContent.displayName = DialogPrimitive.Content.displayName;

const DialogHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("flex flex-col space-y-1.5 text-center sm:text-left", className)} {...props} />
);
DialogHeader.displayName = "DialogHeader";

const DialogFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className)}
    {...props}
  />
);
DialogFooter.displayName = "DialogFooter";

const DialogTitle = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold leading-none tracking-tight", className)}
    {...props}
  />
));
DialogTitle.displayName = DialogPrimitive.Title.displayName;

const DialogDescription = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
DialogDescription.displayName = DialogPrimitive.Description.displayName;

export {
  Dialog,
  DialogPortal,
  DialogOverlay,
  DialogTrigger,
  DialogClose,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
};

```


### `/src/components/ui/drawer.tsx`

```ts path=/src/components/ui/drawer.tsx
import * as React from "react";
import { Drawer as DrawerPrimitive } from "vaul";

import { cn } from "@/lib/utils";

const Drawer = ({
  shouldScaleBackground = true,
  ...props
}: React.ComponentProps<typeof DrawerPrimitive.Root>) => (
  <DrawerPrimitive.Root shouldScaleBackground={shouldScaleBackground} {...props} />
);
Drawer.displayName = "Drawer";

const DrawerTrigger = DrawerPrimitive.Trigger;

const DrawerPortal = DrawerPrimitive.Portal;

const DrawerClose = DrawerPrimitive.Close;

const DrawerOverlay = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DrawerPrimitive.Overlay
    ref={ref}
    className={cn("fixed inset-0 z-50 bg-black/80", className)}
    {...props}
  />
));
DrawerOverlay.displayName = DrawerPrimitive.Overlay.displayName;

const DrawerContent = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <DrawerPortal>
    <DrawerOverlay />
    <DrawerPrimitive.Content
      ref={ref}
      className={cn(
        "fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border bg-background",
        className,
      )}
      {...props}
    >
      <div className="mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted" />
      {children}
    </DrawerPrimitive.Content>
  </DrawerPortal>
));
DrawerContent.displayName = "DrawerContent";

const DrawerHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("grid gap-1.5 p-4 text-center sm:text-left", className)} {...props} />
);
DrawerHeader.displayName = "DrawerHeader";

const DrawerFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("mt-auto flex flex-col gap-2 p-4", className)} {...props} />
);
DrawerFooter.displayName = "DrawerFooter";

const DrawerTitle = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DrawerPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold leading-none tracking-tight", className)}
    {...props}
  />
));
DrawerTitle.displayName = DrawerPrimitive.Title.displayName;

const DrawerDescription = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DrawerPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
DrawerDescription.displayName = DrawerPrimitive.Description.displayName;

export {
  Drawer,
  DrawerPortal,
  DrawerOverlay,
  DrawerTrigger,
  DrawerClose,
  DrawerContent,
  DrawerHeader,
  DrawerFooter,
  DrawerTitle,
  DrawerDescription,
};

```


### `/src/components/ui/dropdown-menu.tsx`

```ts path=/src/components/ui/dropdown-menu.tsx
"use client";

import * as React from "react";
import * as DropdownMenuPrimitive from "@radix-ui/react-dropdown-menu";
import { Check, ChevronRight, Circle } from "lucide-react";

import { cn } from "@/lib/utils";

const DropdownMenu = DropdownMenuPrimitive.Root;

const DropdownMenuTrigger = DropdownMenuPrimitive.Trigger;

const DropdownMenuGroup = DropdownMenuPrimitive.Group;

const DropdownMenuPortal = DropdownMenuPrimitive.Portal;

const DropdownMenuSub = DropdownMenuPrimitive.Sub;

const DropdownMenuRadioGroup = DropdownMenuPrimitive.RadioGroup;

const DropdownMenuSubTrigger = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.SubTrigger>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.SubTrigger> & {
    inset?: boolean;
  }
>(({ className, inset, children, ...props }, ref) => (
  <DropdownMenuPrimitive.SubTrigger
    ref={ref}
    className={cn(
      "flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      inset && "pl-8",
      className,
    )}
    {...props}
  >
    {children}
    <ChevronRight className="ml-auto" />
  </DropdownMenuPrimitive.SubTrigger>
));
DropdownMenuSubTrigger.displayName = DropdownMenuPrimitive.SubTrigger.displayName;

const DropdownMenuSubContent = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.SubContent>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.SubContent>
>(({ className, ...props }, ref) => (
  <DropdownMenuPrimitive.SubContent
    ref={ref}
    className={cn(
      "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
      className,
    )}
    {...props}
  />
));
DropdownMenuSubContent.displayName = DropdownMenuPrimitive.SubContent.displayName;

const DropdownMenuContent = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.Content>
>(({ className, sideOffset = 4, ...props }, ref) => (
  <DropdownMenuPrimitive.Portal>
    <DropdownMenuPrimitive.Content
      ref={ref}
      sideOffset={sideOffset}
      className={cn(
        "z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </DropdownMenuPrimitive.Portal>
));
DropdownMenuContent.displayName = DropdownMenuPrimitive.Content.displayName;

const DropdownMenuItem = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.Item> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <DropdownMenuPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0",
      inset && "pl-8",
      className,
    )}
    {...props}
  />
));
DropdownMenuItem.displayName = DropdownMenuPrimitive.Item.displayName;

const DropdownMenuCheckboxItem = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.CheckboxItem>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.CheckboxItem>
>(({ className, children, checked, ...props }, ref) => (
  <DropdownMenuPrimitive.CheckboxItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    checked={checked}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <DropdownMenuPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </DropdownMenuPrimitive.ItemIndicator>
    </span>
    {children}
  </DropdownMenuPrimitive.CheckboxItem>
));
DropdownMenuCheckboxItem.displayName = DropdownMenuPrimitive.CheckboxItem.displayName;

const DropdownMenuRadioItem = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.RadioItem>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.RadioItem>
>(({ className, children, ...props }, ref) => (
  <DropdownMenuPrimitive.RadioItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <DropdownMenuPrimitive.ItemIndicator>
        <Circle className="h-2 w-2 fill-current" />
      </DropdownMenuPrimitive.ItemIndicator>
    </span>
    {children}
  </DropdownMenuPrimitive.RadioItem>
));
DropdownMenuRadioItem.displayName = DropdownMenuPrimitive.RadioItem.displayName;

const DropdownMenuLabel = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.Label> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <DropdownMenuPrimitive.Label
    ref={ref}
    className={cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className)}
    {...props}
  />
));
DropdownMenuLabel.displayName = DropdownMenuPrimitive.Label.displayName;

const DropdownMenuSeparator = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <DropdownMenuPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-muted", className)}
    {...props}
  />
));
DropdownMenuSeparator.displayName = DropdownMenuPrimitive.Separator.displayName;

const DropdownMenuShortcut = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => {
  return (
    <span className={cn("ml-auto text-xs tracking-widest opacity-60", className)} {...props} />
  );
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";

export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuGroup,
  DropdownMenuPortal,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuRadioGroup,
};

```


### `/src/components/ui/form.tsx`

```ts path=/src/components/ui/form.tsx
import * as React from "react";
import * as LabelPrimitive from "@radix-ui/react-label";
import { Slot } from "@radix-ui/react-slot";
import {
  Controller,
  FormProvider,
  useFormContext,
  type ControllerProps,
  type FieldPath,
  type FieldValues,
} from "react-hook-form";

import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";

const Form = FormProvider;

type FormFieldContextValue<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
> = {
  name: TName;
};

const FormFieldContext = React.createContext<FormFieldContextValue | null>(null);

const FormField = <
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
>({
  ...props
}: ControllerProps<TFieldValues, TName>) => {
  return (
    <FormFieldContext.Provider value={{ name: props.name }}>
      <Controller {...props} />
    </FormFieldContext.Provider>
  );
};

const useFormField = () => {
  const fieldContext = React.useContext(FormFieldContext);
  const itemContext = React.useContext(FormItemContext);
  const { getFieldState, formState } = useFormContext();

  if (!fieldContext) {
    throw new Error("useFormField should be used within <FormField>");
  }

  if (!itemContext) {
    throw new Error("useFormField should be used within <FormItem>");
  }

  const fieldState = getFieldState(fieldContext.name, formState);

  const { id } = itemContext;

  return {
    id,
    name: fieldContext.name,
    formItemId: `${id}-form-item`,
    formDescriptionId: `${id}-form-item-description`,
    formMessageId: `${id}-form-item-message`,
    ...fieldState,
  };
};

type FormItemContextValue = {
  id: string;
};

const FormItemContext = React.createContext<FormItemContextValue | null>(null);

const FormItem = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => {
    const id = React.useId();

    return (
      <FormItemContext.Provider value={{ id }}>
        <div ref={ref} className={cn("space-y-2", className)} {...props} />
      </FormItemContext.Provider>
    );
  },
);
FormItem.displayName = "FormItem";

const FormLabel = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root>
>(({ className, ...props }, ref) => {
  const { error, formItemId } = useFormField();

  return (
    <Label
      ref={ref}
      className={cn(error && "text-destructive", className)}
      htmlFor={formItemId}
      {...props}
    />
  );
});
FormLabel.displayName = "FormLabel";

const FormControl = React.forwardRef<
  React.ElementRef<typeof Slot>,
  React.ComponentPropsWithoutRef<typeof Slot>
>(({ ...props }, ref) => {
  const { error, formItemId, formDescriptionId, formMessageId } = useFormField();

  return (
    <Slot
      ref={ref}
      id={formItemId}
      aria-describedby={!error ? `${formDescriptionId}` : `${formDescriptionId} ${formMessageId}`}
      aria-invalid={!!error}
      {...props}
    />
  );
});
FormControl.displayName = "FormControl";

const FormDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => {
  const { formDescriptionId } = useFormField();

  return (
    <p
      ref={ref}
      id={formDescriptionId}
      className={cn("text-[0.8rem] text-muted-foreground", className)}
      {...props}
    />
  );
});
FormDescription.displayName = "FormDescription";

const FormMessage = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, children, ...props }, ref) => {
  const { error, formMessageId } = useFormField();
  const body = error ? String(error?.message ?? "") : children;

  if (!body) {
    return null;
  }

  return (
    <p
      ref={ref}
      id={formMessageId}
      className={cn("text-[0.8rem] font-medium text-destructive", className)}
      {...props}
    >
      {body}
    </p>
  );
});
FormMessage.displayName = "FormMessage";

export {
  useFormField,
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
  FormField,
};

```


### `/src/components/ui/hover-card.tsx`

```ts path=/src/components/ui/hover-card.tsx
import * as React from "react";
import * as HoverCardPrimitive from "@radix-ui/react-hover-card";

import { cn } from "@/lib/utils";

const HoverCard = HoverCardPrimitive.Root;

const HoverCardTrigger = HoverCardPrimitive.Trigger;

const HoverCardContent = React.forwardRef<
  React.ElementRef<typeof HoverCardPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof HoverCardPrimitive.Content>
>(({ className, align = "center", sideOffset = 4, ...props }, ref) => (
  <HoverCardPrimitive.Content
    ref={ref}
    align={align}
    sideOffset={sideOffset}
    className={cn(
      "z-50 w-64 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-hover-card-content-transform-origin)",
      className,
    )}
    {...props}
  />
));
HoverCardContent.displayName = HoverCardPrimitive.Content.displayName;

export { HoverCard, HoverCardTrigger, HoverCardContent };

```


### `/src/components/ui/input-otp.tsx`

```ts path=/src/components/ui/input-otp.tsx
import * as React from "react";
import { OTPInput, OTPInputContext } from "input-otp";
import { Minus } from "lucide-react";

import { cn } from "@/lib/utils";

const InputOTP = React.forwardRef<
  React.ElementRef<typeof OTPInput>,
  React.ComponentPropsWithoutRef<typeof OTPInput>
>(({ className, containerClassName, ...props }, ref) => (
  <OTPInput
    ref={ref}
    containerClassName={cn(
      "flex items-center gap-2 has-[:disabled]:opacity-50",
      containerClassName,
    )}
    className={cn("disabled:cursor-not-allowed", className)}
    {...props}
  />
));
InputOTP.displayName = "InputOTP";

const InputOTPGroup = React.forwardRef<
  React.ElementRef<"div">,
  React.ComponentPropsWithoutRef<"div">
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("flex items-center", className)} {...props} />
));
InputOTPGroup.displayName = "InputOTPGroup";

const InputOTPSlot = React.forwardRef<
  React.ElementRef<"div">,
  React.ComponentPropsWithoutRef<"div"> & { index: number }
>(({ index, className, ...props }, ref) => {
  const inputOTPContext = React.useContext(OTPInputContext);
  const { char, hasFakeCaret, isActive } = inputOTPContext.slots[index];

  return (
    <div
      ref={ref}
      className={cn(
        "relative flex h-9 w-9 items-center justify-center border-y border-r border-input text-sm shadow-sm transition-all first:rounded-l-md first:border-l last:rounded-r-md",
        isActive && "z-10 ring-1 ring-ring",
        className,
      )}
      {...props}
    >
      {char}
      {hasFakeCaret && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="h-4 w-px animate-caret-blink bg-foreground duration-1000" />
        </div>
      )}
    </div>
  );
});
InputOTPSlot.displayName = "InputOTPSlot";

const InputOTPSeparator = React.forwardRef<
  React.ElementRef<"div">,
  React.ComponentPropsWithoutRef<"div">
>(({ ...props }, ref) => (
  <div ref={ref} role="separator" {...props}>
    <Minus />
  </div>
));
InputOTPSeparator.displayName = "InputOTPSeparator";

export { InputOTP, InputOTPGroup, InputOTPSlot, InputOTPSeparator };

```


### `/src/components/ui/input.tsx`

```ts path=/src/components/ui/input.tsx
import * as React from "react";

import { cn } from "@/lib/utils";

const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className,
        )}
        ref={ref}
        {...props}
      />
    );
  },
);
Input.displayName = "Input";

export { Input };

```


### `/src/components/ui/label.tsx`

```ts path=/src/components/ui/label.tsx
"use client";

import * as React from "react";
import * as LabelPrimitive from "@radix-ui/react-label";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
);

const Label = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root> & VariantProps<typeof labelVariants>
>(({ className, ...props }, ref) => (
  <LabelPrimitive.Root ref={ref} className={cn(labelVariants(), className)} {...props} />
));
Label.displayName = LabelPrimitive.Root.displayName;

export { Label };

```


### `/src/components/ui/menubar.tsx`

```ts path=/src/components/ui/menubar.tsx
import * as React from "react";
import * as MenubarPrimitive from "@radix-ui/react-menubar";
import { Check, ChevronRight, Circle } from "lucide-react";

import { cn } from "@/lib/utils";

function MenubarMenu({ ...props }: React.ComponentProps<typeof MenubarPrimitive.Menu>) {
  return <MenubarPrimitive.Menu {...props} />;
}

function MenubarGroup({ ...props }: React.ComponentProps<typeof MenubarPrimitive.Group>) {
  return <MenubarPrimitive.Group {...props} />;
}

function MenubarPortal({ ...props }: React.ComponentProps<typeof MenubarPrimitive.Portal>) {
  return <MenubarPrimitive.Portal {...props} />;
}

function MenubarRadioGroup({ ...props }: React.ComponentProps<typeof MenubarPrimitive.RadioGroup>) {
  return <MenubarPrimitive.RadioGroup {...props} />;
}

function MenubarSub({ ...props }: React.ComponentProps<typeof MenubarPrimitive.Sub>) {
  return <MenubarPrimitive.Sub data-slot="menubar-sub" {...props} />;
}

const Menubar = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Root>
>(({ className, ...props }, ref) => (
  <MenubarPrimitive.Root
    ref={ref}
    className={cn(
      "flex h-9 items-center space-x-1 rounded-md border bg-background p-1 shadow-sm",
      className,
    )}
    {...props}
  />
));
Menubar.displayName = MenubarPrimitive.Root.displayName;

const MenubarTrigger = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Trigger>
>(({ className, ...props }, ref) => (
  <MenubarPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex cursor-default select-none items-center rounded-sm px-3 py-1 text-sm font-medium outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
      className,
    )}
    {...props}
  />
));
MenubarTrigger.displayName = MenubarPrimitive.Trigger.displayName;

const MenubarSubTrigger = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.SubTrigger>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.SubTrigger> & {
    inset?: boolean;
  }
>(({ className, inset, children, ...props }, ref) => (
  <MenubarPrimitive.SubTrigger
    ref={ref}
    className={cn(
      "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
      inset && "pl-8",
      className,
    )}
    {...props}
  >
    {children}
    <ChevronRight className="ml-auto h-4 w-4" />
  </MenubarPrimitive.SubTrigger>
));
MenubarSubTrigger.displayName = MenubarPrimitive.SubTrigger.displayName;

const MenubarSubContent = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.SubContent>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.SubContent>
>(({ className, ...props }, ref) => (
  <MenubarPrimitive.SubContent
    ref={ref}
    className={cn(
      "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-menubar-content-transform-origin)",
      className,
    )}
    {...props}
  />
));
MenubarSubContent.displayName = MenubarPrimitive.SubContent.displayName;

const MenubarContent = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Content>
>(({ className, align = "start", alignOffset = -4, sideOffset = 8, ...props }, ref) => (
  <MenubarPrimitive.Portal>
    <MenubarPrimitive.Content
      ref={ref}
      align={align}
      alignOffset={alignOffset}
      sideOffset={sideOffset}
      className={cn(
        "z-50 min-w-[12rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-menubar-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </MenubarPrimitive.Portal>
));
MenubarContent.displayName = MenubarPrimitive.Content.displayName;

const MenubarItem = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Item> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <MenubarPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      inset && "pl-8",
      className,
    )}
    {...props}
  />
));
MenubarItem.displayName = MenubarPrimitive.Item.displayName;

const MenubarCheckboxItem = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.CheckboxItem>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.CheckboxItem>
>(({ className, children, checked, ...props }, ref) => (
  <MenubarPrimitive.CheckboxItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    checked={checked}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <MenubarPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </MenubarPrimitive.ItemIndicator>
    </span>
    {children}
  </MenubarPrimitive.CheckboxItem>
));
MenubarCheckboxItem.displayName = MenubarPrimitive.CheckboxItem.displayName;

const MenubarRadioItem = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.RadioItem>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.RadioItem>
>(({ className, children, ...props }, ref) => (
  <MenubarPrimitive.RadioItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <MenubarPrimitive.ItemIndicator>
        <Circle className="h-4 w-4 fill-current" />
      </MenubarPrimitive.ItemIndicator>
    </span>
    {children}
  </MenubarPrimitive.RadioItem>
));
MenubarRadioItem.displayName = MenubarPrimitive.RadioItem.displayName;

const MenubarLabel = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Label> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <MenubarPrimitive.Label
    ref={ref}
    className={cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className)}
    {...props}
  />
));
MenubarLabel.displayName = MenubarPrimitive.Label.displayName;

const MenubarSeparator = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <MenubarPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-muted", className)}
    {...props}
  />
));
MenubarSeparator.displayName = MenubarPrimitive.Separator.displayName;

const MenubarShortcut = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => {
  return (
    <span
      className={cn("ml-auto text-xs tracking-widest text-muted-foreground", className)}
      {...props}
    />
  );
};
MenubarShortcut.displayname = "MenubarShortcut";

export {
  Menubar,
  MenubarMenu,
  MenubarTrigger,
  MenubarContent,
  MenubarItem,
  MenubarSeparator,
  MenubarLabel,
  MenubarCheckboxItem,
  MenubarRadioGroup,
  MenubarRadioItem,
  MenubarPortal,
  MenubarSubContent,
  MenubarSubTrigger,
  MenubarGroup,
  MenubarSub,
  MenubarShortcut,
};

```


### `/src/components/ui/navigation-menu.tsx`

```ts path=/src/components/ui/navigation-menu.tsx
import * as React from "react";
import * as NavigationMenuPrimitive from "@radix-ui/react-navigation-menu";
import { cva } from "class-variance-authority";
import { ChevronDown } from "lucide-react";

import { cn } from "@/lib/utils";

const NavigationMenu = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Root>
>(({ className, children, ...props }, ref) => (
  <NavigationMenuPrimitive.Root
    ref={ref}
    className={cn("relative z-10 flex max-w-max flex-1 items-center justify-center", className)}
    {...props}
  >
    {children}
    <NavigationMenuViewport />
  </NavigationMenuPrimitive.Root>
));
NavigationMenu.displayName = NavigationMenuPrimitive.Root.displayName;

const NavigationMenuList = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.List>
>(({ className, ...props }, ref) => (
  <NavigationMenuPrimitive.List
    ref={ref}
    className={cn("group flex flex-1 list-none items-center justify-center space-x-1", className)}
    {...props}
  />
));
NavigationMenuList.displayName = NavigationMenuPrimitive.List.displayName;

const NavigationMenuItem = NavigationMenuPrimitive.Item;

const navigationMenuTriggerStyle = cva(
  "group inline-flex h-9 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium cursor-pointer transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=open]:text-accent-foreground data-[state=open]:bg-accent/50 data-[state=open]:hover:bg-accent data-[state=open]:focus:bg-accent",
);

const NavigationMenuTrigger = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <NavigationMenuPrimitive.Trigger
    ref={ref}
    className={cn(navigationMenuTriggerStyle(), "group", className)}
    {...props}
  >
    {children}{" "}
    <ChevronDown
      className="relative top-[1px] ml-1 h-3 w-3 transition duration-300 group-data-[state=open]:rotate-180"
      aria-hidden="true"
    />
  </NavigationMenuPrimitive.Trigger>
));
NavigationMenuTrigger.displayName = NavigationMenuPrimitive.Trigger.displayName;

const NavigationMenuContent = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Content>
>(({ className, ...props }, ref) => (
  <NavigationMenuPrimitive.Content
    ref={ref}
    className={cn(
      "left-0 top-0 w-full data-[motion^=from-]:animate-in data-[motion^=to-]:animate-out data-[motion^=from-]:fade-in data-[motion^=to-]:fade-out data-[motion=from-end]:slide-in-from-right-52 data-[motion=from-start]:slide-in-from-left-52 data-[motion=to-end]:slide-out-to-right-52 data-[motion=to-start]:slide-out-to-left-52 md:absolute md:w-auto ",
      className,
    )}
    {...props}
  />
));
NavigationMenuContent.displayName = NavigationMenuPrimitive.Content.displayName;

const NavigationMenuLink = NavigationMenuPrimitive.Link;

const NavigationMenuViewport = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Viewport>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Viewport>
>(({ className, ...props }, ref) => (
  <div className={cn("absolute left-0 top-full flex justify-center")}>
    <NavigationMenuPrimitive.Viewport
      className={cn(
        "origin-top-center relative mt-1.5 h-[var(--radix-navigation-menu-viewport-height)] w-full overflow-hidden rounded-md border bg-popover text-popover-foreground shadow data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-90 md:w-[var(--radix-navigation-menu-viewport-width)]",
        className,
      )}
      ref={ref}
      {...props}
    />
  </div>
));
NavigationMenuViewport.displayName = NavigationMenuPrimitive.Viewport.displayName;

const NavigationMenuIndicator = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Indicator>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Indicator>
>(({ className, ...props }, ref) => (
  <NavigationMenuPrimitive.Indicator
    ref={ref}
    className={cn(
      "top-full z-[1] flex h-1.5 items-end justify-center overflow-hidden data-[state=visible]:animate-in data-[state=hidden]:animate-out data-[state=hidden]:fade-out data-[state=visible]:fade-in",
      className,
    )}
    {...props}
  >
    <div className="relative top-[60%] h-2 w-2 rotate-45 rounded-tl-sm bg-border shadow-md" />
  </NavigationMenuPrimitive.Indicator>
));
NavigationMenuIndicator.displayName = NavigationMenuPrimitive.Indicator.displayName;

export {
  navigationMenuTriggerStyle,
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuContent,
  NavigationMenuTrigger,
  NavigationMenuLink,
  NavigationMenuIndicator,
  NavigationMenuViewport,
};

```


### `/src/components/ui/pagination.tsx`

```ts path=/src/components/ui/pagination.tsx
import * as React from "react";
import { ChevronLeft, ChevronRight, MoreHorizontal } from "lucide-react";

import { cn } from "@/lib/utils";
import { ButtonProps, buttonVariants } from "@/components/ui/button";

const Pagination = ({ className, ...props }: React.ComponentProps<"nav">) => (
  <nav
    role="navigation"
    aria-label="pagination"
    className={cn("mx-auto flex w-full justify-center", className)}
    {...props}
  />
);
Pagination.displayName = "Pagination";

const PaginationContent = React.forwardRef<HTMLUListElement, React.ComponentProps<"ul">>(
  ({ className, ...props }, ref) => (
    <ul ref={ref} className={cn("flex flex-row items-center gap-1", className)} {...props} />
  ),
);
PaginationContent.displayName = "PaginationContent";

const PaginationItem = React.forwardRef<HTMLLIElement, React.ComponentProps<"li">>(
  ({ className, ...props }, ref) => <li ref={ref} className={cn("", className)} {...props} />,
);
PaginationItem.displayName = "PaginationItem";

type PaginationLinkProps = {
  isActive?: boolean;
} & Pick<ButtonProps, "size"> &
  React.ComponentProps<"a">;

const PaginationLink = ({ className, isActive, size = "icon", ...props }: PaginationLinkProps) => (
  <a
    aria-current={isActive ? "page" : undefined}
    className={cn(
      buttonVariants({
        variant: isActive ? "outline" : "ghost",
        size,
      }),
      className,
    )}
    {...props}
  />
);
PaginationLink.displayName = "PaginationLink";

const PaginationPrevious = ({
  className,
  ...props
}: React.ComponentProps<typeof PaginationLink>) => (
  <PaginationLink
    aria-label="Go to previous page"
    size="default"
    className={cn("gap-1 pl-2.5", className)}
    {...props}
  >
    <ChevronLeft className="h-4 w-4" />
    <span>Previous</span>
  </PaginationLink>
);
PaginationPrevious.displayName = "PaginationPrevious";

const PaginationNext = ({ className, ...props }: React.ComponentProps<typeof PaginationLink>) => (
  <PaginationLink
    aria-label="Go to next page"
    size="default"
    className={cn("gap-1 pr-2.5", className)}
    {...props}
  >
    <span>Next</span>
    <ChevronRight className="h-4 w-4" />
  </PaginationLink>
);
PaginationNext.displayName = "PaginationNext";

const PaginationEllipsis = ({ className, ...props }: React.ComponentProps<"span">) => (
  <span
    aria-hidden
    className={cn("flex h-9 w-9 items-center justify-center", className)}
    {...props}
  >
    <MoreHorizontal className="h-4 w-4" />
    <span className="sr-only">More pages</span>
  </span>
);
PaginationEllipsis.displayName = "PaginationEllipsis";

export {
  Pagination,
  PaginationContent,
  PaginationLink,
  PaginationItem,
  PaginationPrevious,
  PaginationNext,
  PaginationEllipsis,
};

```


### `/src/components/ui/popover.tsx`

```ts path=/src/components/ui/popover.tsx
import * as React from "react";
import * as PopoverPrimitive from "@radix-ui/react-popover";

import { cn } from "@/lib/utils";

const Popover = PopoverPrimitive.Root;

const PopoverTrigger = PopoverPrimitive.Trigger;

const PopoverAnchor = PopoverPrimitive.Anchor;

const PopoverContent = React.forwardRef<
  React.ElementRef<typeof PopoverPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Content>
>(({ className, align = "center", sideOffset = 4, ...props }, ref) => (
  <PopoverPrimitive.Portal>
    <PopoverPrimitive.Content
      ref={ref}
      align={align}
      sideOffset={sideOffset}
      className={cn(
        "z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </PopoverPrimitive.Portal>
));
PopoverContent.displayName = PopoverPrimitive.Content.displayName;

export { Popover, PopoverTrigger, PopoverContent, PopoverAnchor };

```


### `/src/components/ui/progress.tsx`

```ts path=/src/components/ui/progress.tsx
"use client";

import * as React from "react";
import * as ProgressPrimitive from "@radix-ui/react-progress";

import { cn } from "@/lib/utils";

const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root>
>(({ className, value, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    className={cn("relative h-2 w-full overflow-hidden rounded-full bg-primary/20", className)}
    {...props}
  >
    <ProgressPrimitive.Indicator
      className="h-full w-full flex-1 bg-primary transition-all"
      style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
    />
  </ProgressPrimitive.Root>
));
Progress.displayName = ProgressPrimitive.Root.displayName;

export { Progress };

```


### `/src/components/ui/radio-group.tsx`

```ts path=/src/components/ui/radio-group.tsx
import * as React from "react";
import * as RadioGroupPrimitive from "@radix-ui/react-radio-group";
import { Circle } from "lucide-react";

import { cn } from "@/lib/utils";

const RadioGroup = React.forwardRef<
  React.ElementRef<typeof RadioGroupPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof RadioGroupPrimitive.Root>
>(({ className, ...props }, ref) => {
  return <RadioGroupPrimitive.Root className={cn("grid gap-2", className)} {...props} ref={ref} />;
});
RadioGroup.displayName = RadioGroupPrimitive.Root.displayName;

const RadioGroupItem = React.forwardRef<
  React.ElementRef<typeof RadioGroupPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof RadioGroupPrimitive.Item>
>(({ className, ...props }, ref) => {
  return (
    <RadioGroupPrimitive.Item
      ref={ref}
      className={cn(
        "aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...props}
    >
      <RadioGroupPrimitive.Indicator className="flex items-center justify-center">
        <Circle className="h-3.5 w-3.5 fill-primary" />
      </RadioGroupPrimitive.Indicator>
    </RadioGroupPrimitive.Item>
  );
});
RadioGroupItem.displayName = RadioGroupPrimitive.Item.displayName;

export { RadioGroup, RadioGroupItem };

```


### `/src/components/ui/resizable.tsx`

```ts path=/src/components/ui/resizable.tsx
import { GripVertical } from "lucide-react";
import { Group, Panel, Separator } from "react-resizable-panels";

import { cn } from "@/lib/utils";

const ResizablePanelGroup = ({ className, ...props }: React.ComponentProps<typeof Group>) => (
  <Group
    className={cn("flex h-full w-full data-[panel-group-direction=vertical]:flex-col", className)}
    {...props}
  />
);

const ResizablePanel = Panel;

const ResizableHandle = ({
  withHandle,
  className,
  ...props
}: React.ComponentProps<typeof Separator> & {
  withHandle?: boolean;
}) => (
  <Separator
    className={cn(
      "relative flex w-px items-center justify-center bg-border after:absolute after:inset-y-0 after:left-1/2 after:w-1 after:-translate-x-1/2 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-1 data-[panel-group-direction=vertical]:h-px data-[panel-group-direction=vertical]:w-full data-[panel-group-direction=vertical]:after:left-0 data-[panel-group-direction=vertical]:after:h-1 data-[panel-group-direction=vertical]:after:w-full data-[panel-group-direction=vertical]:after:-translate-y-1/2 data-[panel-group-direction=vertical]:after:translate-x-0 [&[data-panel-group-direction=vertical]>div]:rotate-90",
      className,
    )}
    {...props}
  >
    {withHandle && (
      <div className="z-10 flex h-4 w-3 items-center justify-center rounded-sm border bg-border">
        <GripVertical className="h-2.5 w-2.5" />
      </div>
    )}
  </Separator>
);

export { ResizablePanelGroup, ResizablePanel, ResizableHandle };

```


### `/src/components/ui/scroll-area.tsx`

```ts path=/src/components/ui/scroll-area.tsx
import * as React from "react";
import * as ScrollAreaPrimitive from "@radix-ui/react-scroll-area";

import { cn } from "@/lib/utils";

const ScrollArea = React.forwardRef<
  React.ElementRef<typeof ScrollAreaPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ScrollAreaPrimitive.Root>
>(({ className, children, ...props }, ref) => (
  <ScrollAreaPrimitive.Root
    ref={ref}
    className={cn("relative overflow-hidden", className)}
    {...props}
  >
    <ScrollAreaPrimitive.Viewport className="h-full w-full rounded-[inherit]">
      {children}
    </ScrollAreaPrimitive.Viewport>
    <ScrollBar />
    <ScrollAreaPrimitive.Corner />
  </ScrollAreaPrimitive.Root>
));
ScrollArea.displayName = ScrollAreaPrimitive.Root.displayName;

const ScrollBar = React.forwardRef<
  React.ElementRef<typeof ScrollAreaPrimitive.ScrollAreaScrollbar>,
  React.ComponentPropsWithoutRef<typeof ScrollAreaPrimitive.ScrollAreaScrollbar>
>(({ className, orientation = "vertical", ...props }, ref) => (
  <ScrollAreaPrimitive.ScrollAreaScrollbar
    ref={ref}
    orientation={orientation}
    className={cn(
      "flex touch-none select-none transition-colors",
      orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]",
      orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]",
      className,
    )}
    {...props}
  >
    <ScrollAreaPrimitive.ScrollAreaThumb className="relative flex-1 rounded-full bg-border" />
  </ScrollAreaPrimitive.ScrollAreaScrollbar>
));
ScrollBar.displayName = ScrollAreaPrimitive.ScrollAreaScrollbar.displayName;

export { ScrollArea, ScrollBar };

```


### `/src/components/ui/select.tsx`

```ts path=/src/components/ui/select.tsx
"use client";

import * as React from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
import { Check, ChevronDown, ChevronUp } from "lucide-react";

import { cn } from "@/lib/utils";

const Select = SelectPrimitive.Root;

const SelectGroup = SelectPrimitive.Group;

const SelectValue = SelectPrimitive.Value;

const SelectTrigger = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",
      className,
    )}
    {...props}
  >
    {children}
    <SelectPrimitive.Icon asChild>
      <ChevronDown className="h-4 w-4 opacity-50" />
    </SelectPrimitive.Icon>
  </SelectPrimitive.Trigger>
));
SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;

const SelectScrollUpButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollUpButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollUpButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollUpButton
    ref={ref}
    className={cn("flex cursor-default items-center justify-center py-1", className)}
    {...props}
  >
    <ChevronUp className="h-4 w-4" />
  </SelectPrimitive.ScrollUpButton>
));
SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName;

const SelectScrollDownButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollDownButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollDownButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollDownButton
    ref={ref}
    className={cn("flex cursor-default items-center justify-center py-1", className)}
    {...props}
  >
    <ChevronDown className="h-4 w-4" />
  </SelectPrimitive.ScrollDownButton>
));
SelectScrollDownButton.displayName = SelectPrimitive.ScrollDownButton.displayName;

const SelectContent = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Content>
>(({ className, children, position = "popper", ...props }, ref) => (
  <SelectPrimitive.Portal>
    <SelectPrimitive.Content
      ref={ref}
      className={cn(
        "relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)",
        position === "popper" &&
          "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
        className,
      )}
      position={position}
      {...props}
    >
      <SelectScrollUpButton />
      <SelectPrimitive.Viewport
        className={cn(
          "p-1",
          position === "popper" &&
            "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]",
        )}
      >
        {children}
      </SelectPrimitive.Viewport>
      <SelectScrollDownButton />
    </SelectPrimitive.Content>
  </SelectPrimitive.Portal>
));
SelectContent.displayName = SelectPrimitive.Content.displayName;

const SelectLabel = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Label>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Label
    ref={ref}
    className={cn("px-2 py-1.5 text-sm font-semibold", className)}
    {...props}
  />
));
SelectLabel.displayName = SelectPrimitive.Label.displayName;

const SelectItem = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Item>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute right-2 flex h-3.5 w-3.5 items-center justify-center">
      <SelectPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </SelectPrimitive.ItemIndicator>
    </span>
    <SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText>
  </SelectPrimitive.Item>
));
SelectItem.displayName = SelectPrimitive.Item.displayName;

const SelectSeparator = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-muted", className)}
    {...props}
  />
));
SelectSeparator.displayName = SelectPrimitive.Separator.displayName;

export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
  SelectScrollUpButton,
  SelectScrollDownButton,
};

```


### `/src/components/ui/separator.tsx`

```ts path=/src/components/ui/separator.tsx
import * as React from "react";
import * as SeparatorPrimitive from "@radix-ui/react-separator";

import { cn } from "@/lib/utils";

const Separator = React.forwardRef<
  React.ElementRef<typeof SeparatorPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof SeparatorPrimitive.Root>
>(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => (
  <SeparatorPrimitive.Root
    ref={ref}
    decorative={decorative}
    orientation={orientation}
    className={cn(
      "shrink-0 bg-border",
      orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]",
      className,
    )}
    {...props}
  />
));
Separator.displayName = SeparatorPrimitive.Root.displayName;

export { Separator };

```


### `/src/components/ui/sheet.tsx`

```ts path=/src/components/ui/sheet.tsx
"use client";

import * as React from "react";
import * as SheetPrimitive from "@radix-ui/react-dialog";
import { cva, type VariantProps } from "class-variance-authority";
import { X } from "lucide-react";

import { cn } from "@/lib/utils";

const Sheet = SheetPrimitive.Root;

const SheetTrigger = SheetPrimitive.Trigger;

const SheetClose = SheetPrimitive.Close;

const SheetPortal = SheetPrimitive.Portal;

const SheetOverlay = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Overlay
    className={cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className,
    )}
    {...props}
    ref={ref}
  />
));
SheetOverlay.displayName = SheetPrimitive.Overlay.displayName;

const sheetVariants = cva(
  "fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out",
  {
    variants: {
      side: {
        top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
        bottom:
          "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
        left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
        right:
          "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm",
      },
    },
    defaultVariants: {
      side: "right",
    },
  },
);

interface SheetContentProps
  extends
    React.ComponentPropsWithoutRef<typeof SheetPrimitive.Content>,
    VariantProps<typeof sheetVariants> {}

const SheetContent = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Content>,
  SheetContentProps
>(({ side = "right", className, children, ...props }, ref) => (
  <SheetPortal>
    <SheetOverlay />
    <SheetPrimitive.Content ref={ref} className={cn(sheetVariants({ side }), className)} {...props}>
      <SheetPrimitive.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary">
        <X className="h-4 w-4" />
        <span className="sr-only">Close</span>
      </SheetPrimitive.Close>
      {children}
    </SheetPrimitive.Content>
  </SheetPortal>
));
SheetContent.displayName = SheetPrimitive.Content.displayName;

const SheetHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("flex flex-col space-y-2 text-center sm:text-left", className)} {...props} />
);
SheetHeader.displayName = "SheetHeader";

const SheetFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className)}
    {...props}
  />
);
SheetFooter.displayName = "SheetFooter";

const SheetTitle = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Title>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold text-foreground", className)}
    {...props}
  />
));
SheetTitle.displayName = SheetPrimitive.Title.displayName;

const SheetDescription = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Description>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
SheetDescription.displayName = SheetPrimitive.Description.displayName;

export {
  Sheet,
  SheetPortal,
  SheetOverlay,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetFooter,
  SheetTitle,
  SheetDescription,
};

```


### `/src/components/ui/sidebar.tsx`

```ts path=/src/components/ui/sidebar.tsx
import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { PanelLeft } from "lucide-react";

import { useIsMobile } from "@/hooks/use-mobile";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const SIDEBAR_COOKIE_NAME = "sidebar_state";
const SIDEBAR_COOKIE_MAX_AGE = 60 * 60 * 24 * 7;
const SIDEBAR_WIDTH = "16rem";
const SIDEBAR_WIDTH_MOBILE = "18rem";
const SIDEBAR_WIDTH_ICON = "3rem";
const SIDEBAR_KEYBOARD_SHORTCUT = "b";

type SidebarContextProps = {
  state: "expanded" | "collapsed";
  open: boolean;
  setOpen: (open: boolean) => void;
  openMobile: boolean;
  setOpenMobile: (open: boolean) => void;
  isMobile: boolean;
  toggleSidebar: () => void;
};

const SidebarContext = React.createContext<SidebarContextProps | null>(null);

function useSidebar() {
  const context = React.useContext(SidebarContext);
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider.");
  }

  return context;
}

const SidebarProvider = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    defaultOpen?: boolean;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
  }
>(
  (
    {
      defaultOpen = true,
      open: openProp,
      onOpenChange: setOpenProp,
      className,
      style,
      children,
      ...props
    },
    ref,
  ) => {
    const isMobile = useIsMobile();
    const [openMobile, setOpenMobile] = React.useState(false);

    // This is the internal state of the sidebar.
    // We use openProp and setOpenProp for control from outside the component.
    const [_open, _setOpen] = React.useState(defaultOpen);
    const open = openProp ?? _open;
    const setOpen = React.useCallback(
      (value: boolean | ((value: boolean) => boolean)) => {
        const openState = typeof value === "function" ? value(open) : value;
        if (setOpenProp) {
          setOpenProp(openState);
        } else {
          _setOpen(openState);
        }

        // This sets the cookie to keep the sidebar state.
        document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`;
      },
      [setOpenProp, open],
    );

    // Helper to toggle the sidebar.
    const toggleSidebar = React.useCallback(() => {
      return isMobile ? setOpenMobile((open) => !open) : setOpen((open) => !open);
    }, [isMobile, setOpen, setOpenMobile]);

    // Adds a keyboard shortcut to toggle the sidebar.
    React.useEffect(() => {
      const handleKeyDown = (event: KeyboardEvent) => {
        if (event.key === SIDEBAR_KEYBOARD_SHORTCUT && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          toggleSidebar();
        }
      };

      window.addEventListener("keydown", handleKeyDown);
      return () => window.removeEventListener("keydown", handleKeyDown);
    }, [toggleSidebar]);

    // We add a state so that we can do data-state="expanded" or "collapsed".
    // This makes it easier to style the sidebar with Tailwind classes.
    const state = open ? "expanded" : "collapsed";

    const contextValue = React.useMemo<SidebarContextProps>(
      () => ({
        state,
        open,
        setOpen,
        isMobile,
        openMobile,
        setOpenMobile,
        toggleSidebar,
      }),
      [state, open, setOpen, isMobile, openMobile, setOpenMobile, toggleSidebar],
    );

    return (
      <SidebarContext.Provider value={contextValue}>
        <TooltipProvider delayDuration={0}>
          <div
            style={
              {
                "--sidebar-width": SIDEBAR_WIDTH,
                "--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
                ...style,
              } as React.CSSProperties
            }
            className={cn(
              "group/sidebar-wrapper flex min-h-svh w-full has-[[data-variant=inset]]:bg-sidebar",
              className,
            )}
            ref={ref}
            {...props}
          >
            {children}
          </div>
        </TooltipProvider>
      </SidebarContext.Provider>
    );
  },
);
SidebarProvider.displayName = "SidebarProvider";

const Sidebar = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    side?: "left" | "right";
    variant?: "sidebar" | "floating" | "inset";
    collapsible?: "offcanvas" | "icon" | "none";
  }
>(
  (
    {
      side = "left",
      variant = "sidebar",
      collapsible = "offcanvas",
      className,
      children,
      ...props
    },
    ref,
  ) => {
    const { isMobile, state, openMobile, setOpenMobile } = useSidebar();

    if (collapsible === "none") {
      return (
        <div
          className={cn(
            "flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground",
            className,
          )}
          ref={ref}
          {...props}
        >
          {children}
        </div>
      );
    }

    if (isMobile) {
      return (
        <Sheet open={openMobile} onOpenChange={setOpenMobile} {...props}>
          <SheetContent
            data-sidebar="sidebar"
            data-mobile="true"
            className="w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden"
            style={
              {
                "--sidebar-width": SIDEBAR_WIDTH_MOBILE,
              } as React.CSSProperties
            }
            side={side}
          >
            <SheetHeader className="sr-only">
              <SheetTitle>Sidebar</SheetTitle>
              <SheetDescription>Displays the mobile sidebar.</SheetDescription>
            </SheetHeader>
            <div className="flex h-full w-full flex-col">{children}</div>
          </SheetContent>
        </Sheet>
      );
    }

    return (
      <div
        ref={ref}
        className="group peer hidden text-sidebar-foreground md:block"
        data-state={state}
        data-collapsible={state === "collapsed" ? collapsible : ""}
        data-variant={variant}
        data-side={side}
      >
        {/* This is what handles the sidebar gap on desktop */}
        <div
          className={cn(
            "relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear",
            "group-data-[collapsible=offcanvas]:w-0",
            "group-data-[side=right]:rotate-180",
            variant === "floating" || variant === "inset"
              ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4))]"
              : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)",
          )}
        />
        <div
          className={cn(
            "fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear md:flex",
            side === "left"
              ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]"
              : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]",
            // Adjust the padding for floating and inset variants.
            variant === "floating" || variant === "inset"
              ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4)_+2px)]"
              : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l",
            className,
          )}
          {...props}
        >
          <div
            data-sidebar="sidebar"
            className="flex h-full w-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:border-sidebar-border group-data-[variant=floating]:shadow"
          >
            {children}
          </div>
        </div>
      </div>
    );
  },
);
Sidebar.displayName = "Sidebar";

const SidebarTrigger = React.forwardRef<
  React.ElementRef<typeof Button>,
  React.ComponentProps<typeof Button>
>(({ className, onClick, ...props }, ref) => {
  const { toggleSidebar } = useSidebar();

  return (
    <Button
      ref={ref}
      data-sidebar="trigger"
      variant="ghost"
      size="icon"
      className={cn("h-7 w-7", className)}
      onClick={(event) => {
        onClick?.(event);
        toggleSidebar();
      }}
      {...props}
    >
      <PanelLeft />
      <span className="sr-only">Toggle Sidebar</span>
    </Button>
  );
});
SidebarTrigger.displayName = "SidebarTrigger";

const SidebarRail = React.forwardRef<HTMLButtonElement, React.ComponentProps<"button">>(
  ({ className, ...props }, ref) => {
    const { toggleSidebar } = useSidebar();

    return (
      <button
        ref={ref}
        data-sidebar="rail"
        aria-label="Toggle Sidebar"
        tabIndex={-1}
        onClick={toggleSidebar}
        title="Toggle Sidebar"
        className={cn(
          "absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] hover:after:bg-sidebar-border group-data-[side=left]:-right-4 group-data-[side=right]:left-0 sm:flex",
          "[[data-side=left]_&]:cursor-w-resize [[data-side=right]_&]:cursor-e-resize",
          "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize",
          "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full group-data-[collapsible=offcanvas]:hover:bg-sidebar",
          "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
          "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",
          className,
        )}
        {...props}
      />
    );
  },
);
SidebarRail.displayName = "SidebarRail";

const SidebarInset = React.forwardRef<HTMLDivElement, React.ComponentProps<"main">>(
  ({ className, ...props }, ref) => {
    return (
      <main
        ref={ref}
        className={cn(
          "relative flex w-full flex-1 flex-col bg-background",
          "md:peer-data-[variant=inset]:m-2 md:peer-data-[state=collapsed]:peer-data-[variant=inset]:ml-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow",
          className,
        )}
        {...props}
      />
    );
  },
);
SidebarInset.displayName = "SidebarInset";

const SidebarInput = React.forwardRef<
  React.ElementRef<typeof Input>,
  React.ComponentProps<typeof Input>
>(({ className, ...props }, ref) => {
  return (
    <Input
      ref={ref}
      data-sidebar="input"
      className={cn(
        "h-8 w-full bg-background shadow-none focus-visible:ring-2 focus-visible:ring-sidebar-ring",
        className,
      )}
      {...props}
    />
  );
});
SidebarInput.displayName = "SidebarInput";

const SidebarHeader = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-sidebar="header"
        className={cn("flex flex-col gap-2 p-2", className)}
        {...props}
      />
    );
  },
);
SidebarHeader.displayName = "SidebarHeader";

const SidebarFooter = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-sidebar="footer"
        className={cn("flex flex-col gap-2 p-2", className)}
        {...props}
      />
    );
  },
);
SidebarFooter.displayName = "SidebarFooter";

const SidebarSeparator = React.forwardRef<
  React.ElementRef<typeof Separator>,
  React.ComponentProps<typeof Separator>
>(({ className, ...props }, ref) => {
  return (
    <Separator
      ref={ref}
      data-sidebar="separator"
      className={cn("mx-2 w-auto bg-sidebar-border", className)}
      {...props}
    />
  );
});
SidebarSeparator.displayName = "SidebarSeparator";

const SidebarContent = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-sidebar="content"
        className={cn(
          "flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden",
          className,
        )}
        {...props}
      />
    );
  },
);
SidebarContent.displayName = "SidebarContent";

const SidebarGroup = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-sidebar="group"
        className={cn("relative flex w-full min-w-0 flex-col p-2", className)}
        {...props}
      />
    );
  },
);
SidebarGroup.displayName = "SidebarGroup";

const SidebarGroupLabel = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & { asChild?: boolean }
>(({ className, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "div";

  return (
    <Comp
      ref={ref}
      data-sidebar="group-label"
      className={cn(
        "flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 outline-none ring-sidebar-ring transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
        "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0",
        className,
      )}
      {...props}
    />
  );
});
SidebarGroupLabel.displayName = "SidebarGroupLabel";

const SidebarGroupAction = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<"button"> & { asChild?: boolean }
>(({ className, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";

  return (
    <Comp
      ref={ref}
      data-sidebar="group-action"
      className={cn(
        "absolute right-3 top-3.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
        // Increases the hit area of the button on mobile.
        "after:absolute after:-inset-2 after:md:hidden",
        "group-data-[collapsible=icon]:hidden",
        className,
      )}
      {...props}
    />
  );
});
SidebarGroupAction.displayName = "SidebarGroupAction";

const SidebarGroupContent = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-sidebar="group-content"
      className={cn("w-full text-sm", className)}
      {...props}
    />
  ),
);
SidebarGroupContent.displayName = "SidebarGroupContent";

const SidebarMenu = React.forwardRef<HTMLUListElement, React.ComponentProps<"ul">>(
  ({ className, ...props }, ref) => (
    <ul
      ref={ref}
      data-sidebar="menu"
      className={cn("flex w-full min-w-0 flex-col gap-1", className)}
      {...props}
    />
  ),
);
SidebarMenu.displayName = "SidebarMenu";

const SidebarMenuItem = React.forwardRef<HTMLLIElement, React.ComponentProps<"li">>(
  ({ className, ...props }, ref) => (
    <li
      ref={ref}
      data-sidebar="menu-item"
      className={cn("group/menu-item relative", className)}
      {...props}
    />
  ),
);
SidebarMenuItem.displayName = "SidebarMenuItem";

const sidebarMenuButtonVariants = cva(
  "peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-none ring-sidebar-ring cursor-pointer transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed group-has-[[data-sidebar=menu-action]]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:!size-8 group-data-[collapsible=icon]:!p-2 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
        outline:
          "bg-background shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]",
      },
      size: {
        default: "h-8 text-sm",
        sm: "h-7 text-xs",
        lg: "h-12 text-sm group-data-[collapsible=icon]:!p-0",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

const SidebarMenuButton = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<"button"> & {
    asChild?: boolean;
    isActive?: boolean;
    tooltip?: string | React.ComponentProps<typeof TooltipContent>;
  } & VariantProps<typeof sidebarMenuButtonVariants>
>(
  (
    {
      asChild = false,
      isActive = false,
      variant = "default",
      size = "default",
      tooltip,
      className,
      ...props
    },
    ref,
  ) => {
    const Comp = asChild ? Slot : "button";
    const { isMobile, state } = useSidebar();

    const button = (
      <Comp
        ref={ref}
        data-sidebar="menu-button"
        data-size={size}
        data-active={isActive}
        className={cn(sidebarMenuButtonVariants({ variant, size }), className)}
        {...props}
      />
    );

    if (!tooltip) {
      return button;
    }

    if (typeof tooltip === "string") {
      tooltip = {
        children: tooltip,
      };
    }

    return (
      <Tooltip>
        <TooltipTrigger asChild>{button}</TooltipTrigger>
        <TooltipContent
          side="right"
          align="center"
          hidden={state !== "collapsed" || isMobile}
          {...tooltip}
        />
      </Tooltip>
    );
  },
);
SidebarMenuButton.displayName = "SidebarMenuButton";

const SidebarMenuAction = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<"button"> & {
    asChild?: boolean;
    showOnHover?: boolean;
  }
>(({ className, asChild = false, showOnHover = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";

  return (
    <Comp
      ref={ref}
      data-sidebar="menu-action"
      className={cn(
        "absolute right-1 top-1.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 peer-hover/menu-button:text-sidebar-accent-foreground [&>svg]:size-4 [&>svg]:shrink-0",
        // Increases the hit area of the button on mobile.
        "after:absolute after:-inset-2 after:md:hidden",
        "peer-data-[size=sm]/menu-button:top-1",
        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "group-data-[collapsible=icon]:hidden",
        showOnHover &&
          "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 data-[state=open]:opacity-100 peer-data-[active=true]/menu-button:text-sidebar-accent-foreground md:opacity-0",
        className,
      )}
      {...props}
    />
  );
});
SidebarMenuAction.displayName = "SidebarMenuAction";

const SidebarMenuBadge = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-sidebar="menu-badge"
      className={cn(
        "pointer-events-none absolute right-1 flex h-5 min-w-5 select-none items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums text-sidebar-foreground",
        "peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[active=true]/menu-button:text-sidebar-accent-foreground",
        "peer-data-[size=sm]/menu-button:top-1",
        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "group-data-[collapsible=icon]:hidden",
        className,
      )}
      {...props}
    />
  ),
);
SidebarMenuBadge.displayName = "SidebarMenuBadge";

const SidebarMenuSkeleton = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    showIcon?: boolean;
  }
>(({ className, showIcon = false, ...props }, ref) => {
  // Random width between 50 to 90%.
  const width = React.useMemo(() => {
    return `${Math.floor(Math.random() * 40) + 50}%`;
  }, []);

  return (
    <div
      ref={ref}
      data-sidebar="menu-skeleton"
      className={cn("flex h-8 items-center gap-2 rounded-md px-2", className)}
      {...props}
    >
      {showIcon && <Skeleton className="size-4 rounded-md" data-sidebar="menu-skeleton-icon" />}
      <Skeleton
        className="h-4 max-w-(--skeleton-width) flex-1"
        data-sidebar="menu-skeleton-text"
        style={
          {
            "--skeleton-width": width,
          } as React.CSSProperties
        }
      />
    </div>
  );
});
SidebarMenuSkeleton.displayName = "SidebarMenuSkeleton";

const SidebarMenuSub = React.forwardRef<HTMLUListElement, React.ComponentProps<"ul">>(
  ({ className, ...props }, ref) => (
    <ul
      ref={ref}
      data-sidebar="menu-sub"
      className={cn(
        "mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5",
        "group-data-[collapsible=icon]:hidden",
        className,
      )}
      {...props}
    />
  ),
);
SidebarMenuSub.displayName = "SidebarMenuSub";

const SidebarMenuSubItem = React.forwardRef<HTMLLIElement, React.ComponentProps<"li">>(
  ({ ...props }, ref) => <li ref={ref} {...props} />,
);
SidebarMenuSubItem.displayName = "SidebarMenuSubItem";

const SidebarMenuSubButton = React.forwardRef<
  HTMLAnchorElement,
  React.ComponentProps<"a"> & {
    asChild?: boolean;
    size?: "sm" | "md";
    isActive?: boolean;
  }
>(({ asChild = false, size = "md", isActive, className, ...props }, ref) => {
  const Comp = asChild ? Slot : "a";

  return (
    <Comp
      ref={ref}
      data-sidebar="menu-sub-button"
      data-size={size}
      data-active={isActive}
      className={cn(
        "flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground",
        "data-[active=true]:bg-sidebar-accent data-[active=true]:text-sidebar-accent-foreground",
        size === "sm" && "text-xs",
        size === "md" && "text-sm",
        "group-data-[collapsible=icon]:hidden",
        className,
      )}
      {...props}
    />
  );
});
SidebarMenuSubButton.displayName = "SidebarMenuSubButton";

export {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInput,
  SidebarInset,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSkeleton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarRail,
  SidebarSeparator,
  SidebarTrigger,
  useSidebar,
};

```


### `/src/components/ui/skeleton.tsx`

```ts path=/src/components/ui/skeleton.tsx
import { cn } from "@/lib/utils";

function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("animate-pulse rounded-md bg-primary/10", className)} {...props} />;
}

export { Skeleton };

```


### `/src/components/ui/slider.tsx`

```ts path=/src/components/ui/slider.tsx
import * as React from "react";
import * as SliderPrimitive from "@radix-ui/react-slider";

import { cn } from "@/lib/utils";

const Slider = React.forwardRef<
  React.ElementRef<typeof SliderPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof SliderPrimitive.Root>
>(({ className, ...props }, ref) => (
  <SliderPrimitive.Root
    ref={ref}
    className={cn("relative flex w-full touch-none select-none items-center", className)}
    {...props}
  >
    <SliderPrimitive.Track className="relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20">
      <SliderPrimitive.Range className="absolute h-full bg-primary" />
    </SliderPrimitive.Track>
    <SliderPrimitive.Thumb className="block h-4 w-4 rounded-full border border-primary/50 bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" />
  </SliderPrimitive.Root>
));
Slider.displayName = SliderPrimitive.Root.displayName;

export { Slider };

```


### `/src/components/ui/sonner.tsx`

```ts path=/src/components/ui/sonner.tsx
import { Toaster as Sonner } from "sonner";

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      className="toaster group"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground",
        },
      }}
      {...props}
    />
  );
};

export { Toaster };

```


### `/src/components/ui/switch.tsx`

```ts path=/src/components/ui/switch.tsx
import * as React from "react";
import * as SwitchPrimitives from "@radix-ui/react-switch";

import { cn } from "@/lib/utils";

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitives.Root>,
  React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root>
>(({ className, ...props }, ref) => (
  <SwitchPrimitives.Root
    className={cn(
      "peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
      className,
    )}
    {...props}
    ref={ref}
  >
    <SwitchPrimitives.Thumb
      className={cn(
        "pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0",
      )}
    />
  </SwitchPrimitives.Root>
));
Switch.displayName = SwitchPrimitives.Root.displayName;

export { Switch };

```


### `/src/components/ui/table.tsx`

```ts path=/src/components/ui/table.tsx
import * as React from "react";

import { cn } from "@/lib/utils";

const Table = React.forwardRef<HTMLTableElement, React.HTMLAttributes<HTMLTableElement>>(
  ({ className, ...props }, ref) => (
    <div className="relative w-full overflow-auto">
      <table ref={ref} className={cn("w-full caption-bottom text-sm", className)} {...props} />
    </div>
  ),
);
Table.displayName = "Table";

const TableHeader = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <thead ref={ref} className={cn("[&_tr]:border-b", className)} {...props} />
));
TableHeader.displayName = "TableHeader";

const TableBody = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <tbody ref={ref} className={cn("[&_tr:last-child]:border-0", className)} {...props} />
));
TableBody.displayName = "TableBody";

const TableFooter = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <tfoot
    ref={ref}
    className={cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className)}
    {...props}
  />
));
TableFooter.displayName = "TableFooter";

const TableRow = React.forwardRef<HTMLTableRowElement, React.HTMLAttributes<HTMLTableRowElement>>(
  ({ className, ...props }, ref) => (
    <tr
      ref={ref}
      className={cn(
        "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
        className,
      )}
      {...props}
    />
  ),
);
TableRow.displayName = "TableRow";

const TableHead = React.forwardRef<
  HTMLTableCellElement,
  React.ThHTMLAttributes<HTMLTableCellElement>
>(({ className, ...props }, ref) => (
  <th
    ref={ref}
    className={cn(
      "h-10 px-2 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className,
    )}
    {...props}
  />
));
TableHead.displayName = "TableHead";

const TableCell = React.forwardRef<
  HTMLTableCellElement,
  React.TdHTMLAttributes<HTMLTableCellElement>
>(({ className, ...props }, ref) => (
  <td
    ref={ref}
    className={cn(
      "p-2 align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className,
    )}
    {...props}
  />
));
TableCell.displayName = "TableCell";

const TableCaption = React.forwardRef<
  HTMLTableCaptionElement,
  React.HTMLAttributes<HTMLTableCaptionElement>
>(({ className, ...props }, ref) => (
  <caption ref={ref} className={cn("mt-4 text-sm text-muted-foreground", className)} {...props} />
));
TableCaption.displayName = "TableCaption";

export { Table, TableHeader, TableBody, TableFooter, TableHead, TableRow, TableCell, TableCaption };

```


### `/src/components/ui/tabs.tsx`

```ts path=/src/components/ui/tabs.tsx
import * as React from "react";
import * as TabsPrimitive from "@radix-ui/react-tabs";

import { cn } from "@/lib/utils";

const Tabs = TabsPrimitive.Root;

const TabsList = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.List>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.List
    ref={ref}
    className={cn(
      "inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground",
      className,
    )}
    {...props}
  />
));
TabsList.displayName = TabsPrimitive.List.displayName;

const TabsTrigger = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Trigger>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.Trigger
    ref={ref}
    className={cn(
      "inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow",
      className,
    )}
    {...props}
  />
));
TabsTrigger.displayName = TabsPrimitive.Trigger.displayName;

const TabsContent = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Content>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.Content
    ref={ref}
    className={cn(
      "mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
      className,
    )}
    {...props}
  />
));
TabsContent.displayName = TabsPrimitive.Content.displayName;

export { Tabs, TabsList, TabsTrigger, TabsContent };

```


### `/src/components/ui/textarea.tsx`

```ts path=/src/components/ui/textarea.tsx
import * as React from "react";

import { cn } from "@/lib/utils";

const Textarea = React.forwardRef<HTMLTextAreaElement, React.ComponentProps<"textarea">>(
  ({ className, ...props }, ref) => {
    return (
      <textarea
        className={cn(
          "flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className,
        )}
        ref={ref}
        {...props}
      />
    );
  },
);
Textarea.displayName = "Textarea";

export { Textarea };

```


### `/src/components/ui/toggle-group.tsx`

```ts path=/src/components/ui/toggle-group.tsx
"use client";

import * as React from "react";
import * as ToggleGroupPrimitive from "@radix-ui/react-toggle-group";
import { type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";
import { toggleVariants } from "@/components/ui/toggle";

const ToggleGroupContext = React.createContext<VariantProps<typeof toggleVariants>>({
  size: "default",
  variant: "default",
});

const ToggleGroup = React.forwardRef<
  React.ElementRef<typeof ToggleGroupPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ToggleGroupPrimitive.Root> &
    VariantProps<typeof toggleVariants>
>(({ className, variant, size, children, ...props }, ref) => (
  <ToggleGroupPrimitive.Root
    ref={ref}
    className={cn("flex items-center justify-center gap-1", className)}
    {...props}
  >
    <ToggleGroupContext.Provider value={{ variant, size }}>{children}</ToggleGroupContext.Provider>
  </ToggleGroupPrimitive.Root>
));

ToggleGroup.displayName = ToggleGroupPrimitive.Root.displayName;

const ToggleGroupItem = React.forwardRef<
  React.ElementRef<typeof ToggleGroupPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof ToggleGroupPrimitive.Item> &
    VariantProps<typeof toggleVariants>
>(({ className, children, variant, size, ...props }, ref) => {
  const context = React.useContext(ToggleGroupContext);

  return (
    <ToggleGroupPrimitive.Item
      ref={ref}
      className={cn(
        toggleVariants({
          variant: context.variant || variant,
          size: context.size || size,
        }),
        className,
      )}
      {...props}
    >
      {children}
    </ToggleGroupPrimitive.Item>
  );
});

ToggleGroupItem.displayName = ToggleGroupPrimitive.Item.displayName;

export { ToggleGroup, ToggleGroupItem };

```


### `/src/components/ui/toggle.tsx`

```ts path=/src/components/ui/toggle.tsx
import * as React from "react";
import * as TogglePrimitive from "@radix-ui/react-toggle";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const toggleVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium cursor-pointer transition-colors hover:bg-muted hover:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=on]:bg-accent data-[state=on]:text-accent-foreground [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-transparent",
        outline:
          "border border-input bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground",
      },
      size: {
        default: "h-9 px-2 min-w-9",
        sm: "h-8 px-1.5 min-w-8",
        lg: "h-10 px-2.5 min-w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

const Toggle = React.forwardRef<
  React.ElementRef<typeof TogglePrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof TogglePrimitive.Root> & VariantProps<typeof toggleVariants>
>(({ className, variant, size, ...props }, ref) => (
  <TogglePrimitive.Root
    ref={ref}
    className={cn(toggleVariants({ variant, size, className }))}
    {...props}
  />
));

Toggle.displayName = TogglePrimitive.Root.displayName;

export { Toggle, toggleVariants };

```


### `/src/components/ui/tooltip.tsx`

```ts path=/src/components/ui/tooltip.tsx
"use client";

import * as React from "react";
import * as TooltipPrimitive from "@radix-ui/react-tooltip";

import { cn } from "@/lib/utils";

const TooltipProvider = TooltipPrimitive.Provider;

const Tooltip = TooltipPrimitive.Root;

const TooltipTrigger = TooltipPrimitive.Trigger;

const TooltipContent = React.forwardRef<
  React.ElementRef<typeof TooltipPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TooltipPrimitive.Content>
>(({ className, sideOffset = 4, ...props }, ref) => (
  <TooltipPrimitive.Portal>
    <TooltipPrimitive.Content
      ref={ref}
      sideOffset={sideOffset}
      className={cn(
        "z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-tooltip-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </TooltipPrimitive.Portal>
));
TooltipContent.displayName = TooltipPrimitive.Content.displayName;

export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };

```


### `/src/data/butlerKnowledge.ts`

```ts path=/src/data/butlerKnowledge.ts

/**
 * Butler AI — Starter Knowledge Base
 * Injected into every chat session system prompt so the AI starts fully informed.
 * All content is original, non-copyrighted, general technical knowledge.
 * Covers: app architecture, server API, script library, UI editing, Play Store rules.
 */

export const BUTLER_STARTER_KNOWLEDGE = `
[BUTLER AI — COMPLETE APP KNOWLEDGE]

WHAT YOU ARE:
You are Butler AI, a private local PC automation assistant. You run 100% on the user's own Windows PC using a Python server (butler_server.py) and a local Ollama AI model. Nothing leaves the user's local network. No cloud, no telemetry, no external APIs.

APP ARCHITECTURE:
- React Native / Expo mobile app (Android & iOS)
- Python HTTP server running on user's Windows PC
- Local Ollama AI for all inference (qwen2.5-coder:7b default)
- SQLite database on the PC for chat history, scripts, knowledge base
- All API calls go to http://192.168.x.x:PORT (LAN only, never internet)
- Auth: HMAC-SHA256 bearer token, QR code pairing, one-device lock
- AsyncStorage on phone for local persistence

TABS & FEATURES THE USER HAS:
HOME — Connect to PC via QR scan or manual IP, see live CPU/RAM/Disk stats, quick access grid
SCRIPTS — Python automation library (124+ built-in scripts + AI-generated + PC library), run scripts remotely
AI (BUTLER) — You are this tab. Local Ollama chat, script generation, PC automation via natural language
KB (KNOWLEDGE) — SIGMA-NET crawler, knowledge base articles, self-learning system
TOOLS — File share, clipboard sync, multi-PC endpoint manager
PC CHECK — Health dashboard, process list, undo system, server logs
BUILD — Visual script builder / widget studio
SKINS — Cosmetic themes and packs
CONFIG — App settings, export/import JSON, Ollama model management

HOW TO HELP USERS — PRIORITY ORDER:
1. If user asks to write a script: use SCRIPT_LOOKUP tool first (already done), if found show it, else generate complete Python
2. If user asks about PC stats: use GET_PC_METRICS tool
3. If user asks about knowledge base: use KNOWLEDGE_BASE_STATS tool
4. If user asks to improve a script: use IMPROVE_SCRIPT tool to load the actual code
5. For any automation: write complete, runnable, non-interactive Python for Windows

SERVER API ENDPOINTS (all on http://DEVICE_IP:PORT):
Authentication:
  POST /pair — initial device pairing, returns sessionToken
  POST /reconnect — refresh token on foreground
  POST /api/verify — verify token validity
  GET /api/health — server health check {status, version, uptime, ai, model}
  GET /api/ping — ultra-fast alive check
  GET /api/status — basic status + feature list
  GET /api/debug/connection — full debug info (no auth)

Chat & AI:
  POST /api/butler/chat — streaming AI chat (SSE, always use stream:true)
  POST /api/butler/abort — abort active stream by requestId
  POST /api/chat/clear — clear chat history
  POST /api/memory — CRUD user memories (action: list/save/forget/forget_all)

Scripts:
  POST /api/scripts/build — AI generates script from {description}
  POST /api/scripts/library — full built-in library (17 categories, 150+ scripts)
  POST /api/execute/stream — run script streaming (ALWAYS use this, not /api/execute)
  GET  /api/pc_scripts/list — list user-saved PC scripts
  GET  /api/pc_scripts/get?id=X — get one script with full code
  GET  /api/pc_scripts/search?q=X — search PC scripts
  POST /api/pc_scripts/save — save script to PC {name, code, description, category, tags}
  POST /api/pc_scripts/run — run a saved PC script by id
  POST /api/pc_scripts/delete — delete a saved PC script
  GET  /api/undo/list — list undo-able executions
  POST /api/undo/rollback — rollback last script execution

PC Health & Control:
  POST /api/pc-check/scan — scan for cleanup opportunities (temp files, cache etc)
  POST /api/pc-check/action — run a cleanup action by id
  GET  /metrics — live CPU/RAM/Disk stats via psutil
  POST /api/pc/processes — list running processes
  POST /api/power — PC power control (sleep/shutdown/restart, always confirm:true)
  POST /api/clipboard — read or write PC clipboard
  POST /api/keyboard/type — type text on PC keyboard
  GET  /api/disk_space — disk space + model requirements

Filesystem:
  POST /api/fs/drives — list PC drives
  POST /api/fs/crawl — scan files by pattern {root, pattern}
  POST /api/fs/read — read a file {path}
  GET  /api/files — list files in shared butler dir
  POST /api/receive_file — send file from phone to PC (max 10MB, base64)

Knowledge Base:
  POST /api/learn/status — KB stats {articlesTotal, queuePending, learningActive, topUserTopics}
  GET  /api/kb/list — last 50 KB articles
  POST /api/kb/search — search KB {query}
  POST /api/kb/contribute — submit URLs for server to crawl {urls, topic}
  POST /api/kb/expand — queue topic for self-learning {topic}
  POST /api/crawler/pause — control SIGMA-NET crawler
  POST /api/crawler/resume — control SIGMA-NET crawler
  GET  /api/kb/growth?hours=N — KB growth time-series data

Ollama / Models:
  GET  /api/ollama/status — model status {available, activeModel, models, starting}
  POST /api/ollama/model — switch model {model}
  POST /api/ollama/pull — download a model {model}
  GET  /api/ollama/pull_status — pull progress {active, percent, model, status}
  GET  /api/pc/recommendation — PC hardware model recommendation

Sync & Settings:
  POST /api/sync — foreground bundle: metrics + audit + features (call on every foreground)
  POST /api/performance — get/set performance mode {mode: auto|performance|battery}
  GET  /api/nexus_brain/status — AI tuning status {ctx_window, num_predict, avg_chat_ms}
  POST /api/nexus_brain/reset_tuning — restore default AI parameters
  POST /api/notify/register — register push token

SCRIPT EXECUTION RULES:
- Always use /api/execute/stream (NOT /api/execute — that is blocking)
- Exit codes: 0=success, 1=error, 124=timeout(60s), 126=permission denied, 127=python not found, 137=out of memory
- After success: server returns undoId + undoExpiresSec:900 (15min undo window)
- Server auto-installs missing pip packages before running (first run may take 10-30s extra)
- Scripts run in a Python subprocess on the user's PC — write for Windows, non-interactive
- Safety: server blocks marshal.loads, exec(compile(, ctypes.CDLL(, exec(base64, breakpoint()
- Dangerous patterns blocked: rm -rf /, format c:, reg delete HKLM, shutdown /s /f /t 0

OLLAMA AI MODELS (free, open-source, run locally):
- qwen2.5-coder:7b — best for Python/code, 4.5GB VRAM, Apache 2.0 license
- qwen2.5-coder:1.5b — fast, basic, 1GB VRAM, good for simple tasks
- phi4-mini:latest — fast, 2.5GB VRAM, MIT license
- mistral:7b — general purpose, 4GB VRAM, Apache 2.0
- llama3.2:3b — compact and fast, 2GB VRAM, Meta Llama license
- All models: 100% local inference, no internet, no API keys, no cost per query

RESPONSE FORMAT RULES — FOR BEST RESULTS:
- Scripts: always wrap in \`\`\`python code blocks
- Always include all imports at the top
- Add try/except around risky operations
- Print progress: print("[OK] Task complete") at the end
- Non-interactive: no input() calls, no prompts waiting for user
- For Windows file paths: use Path from pathlib or raw strings
- For installs: prefer winget first, then direct .exe download, then pip
- Return FULL script when improving — never just show diffs

HOW THE APP STORES DATA (AsyncStorage keys):
- commandcube_server_ip / commandcube_server_port — PC connection
- commandcube_session_token — HMAC auth token
- commandcube_device_id — stable hardware fingerprint (butler-hw-<32hex>)
- @butler_scripts_nexus_v1 — AI-generated scripts saved on phone
- @botler_auto_saved_research — knowledge base findings
- @butler_conv_nexus_v1 — chat conversation history (last 60 messages)
- commandcube_script_only_mode — simplified mode toggle
- BUTLER_STABLE_STATE — AI upgrade persistence (UI overrides survive app updates)

UI / JSON EDITING — HOW IT WORKS:
The user can export the full app source as JSON from CONFIG tab → EXPORT ALL FILES.
The exported JSON contains all TypeScript/TSX source files with their content.
The user can paste the JSON + a description into any AI (Claude, GPT, Gemini) to get code changes.
The AI response gets pasted into the OnSpace.ai chat to apply changes automatically.
The app also has a BUTLER_STABLE_STATE system: settings/theme overrides saved to AsyncStorage are re-applied on every boot so UI customizations survive app updates.

For theme/color changes: the CosmeticContext reads @butler_imported_palette from AsyncStorage.
Palette structure: { teal, bg, panel, text, accent, primary, secondary, tertiary }

COSMETIC THEMES AVAILABLE:
nexus (default dark blue), obsidian, terminal (green), matrix, phantom, crimson, aurora, solar, arctic, neon

PLAY STORE COMPLIANCE (always follow these rules):
- Zero personal data collection — no analytics, no tracking, no telemetry
- Local network only — all traffic stays on user's WiFi between phone and their PC
- Camera permission used ONLY for QR code scanning, never recorded or stored
- No account required — no sign-up, no login, no cloud account
- No root required — standard Android sandbox
- All AI inference is local via Ollama — prompts never leave user's machine
- Scripts run only on the user's own PC — not on any server or cloud
- Content policy: never generate malware, keyloggers, ransomware, or illegal content
- No hardcoded credentials, API keys, or external service calls in source
- Privacy Policy URL: https://shawnjan-cmd.github.io/privacy-policy-/
- Package: com.butlerai.pc.automation

SELF-LEARNING SYSTEM (SIGMA-NET):
- 2 background crawl worker threads run 24/7 on the PC
- Every chat message queues DuckDuckGo searches on that topic via /api/kb/expand
- Proven scripts (exit code 0) are automatically saved to KB with [PROVEN] tag
- NEXUS BRAIN adapts Ollama context window based on response speed
- After 3+ slow chats: context may reduce to 2048 tokens (warn user if ctx_window < 3000)
- To restore: POST /api/nexus_brain/reset_tuning

MEMORY SYSTEM:
User can save personal facts with POST /api/memory {action:"save", fact:"...", category:"personal|preferences|technical|general"}
Categories: personal (name, job), preferences (language, tools), technical (system specs), general
Max 200 chars per fact. Facts are injected into every chat context automatically.

QUICK AUTOMATION EXAMPLES YOU CAN GENERATE:
- Organize Downloads by file type (images/docs/videos/archives)
- Monitor CPU temperature and alert when over threshold
- Batch rename photos by date taken using EXIF data
- Delete temp files older than N days
- Sync a folder to USB drive on connect
- Screenshot and save every N minutes
- Kill processes using over X% CPU
- Find duplicate files by hash comparison
- Auto-backup Documents folder with timestamp
- Watch a folder and run a script when files change
- Compress old log files to zip archive
- Send Windows notification on script completion
- Schedule scripts with Windows Task Scheduler
- Auto-update pip packages weekly
- Network scan to find active devices

WHEN USER ASKS "what can you do" — YOUR CAPABILITIES:
✓ Write and run Python scripts on their PC instantly
✓ Monitor CPU, RAM, disk, temperature in real time
✓ Automate file organization, cleanup, backups
✓ Search the web and add results to your knowledge base
✓ Improve existing scripts from execution history
✓ Organize and manage their script library
✓ Control PC power (sleep, restart, shutdown with confirmation)
✓ Sync clipboard between phone and PC
✓ Browse PC files and read file contents for context
✓ Install software via winget or pip
✓ Schedule and chain multiple scripts
✓ Remember user preferences via the memory system
✓ Self-learn from every conversation topic
✓ Edit and improve previous scripts automatically
`;

export const BUTLER_KNOWLEDGE_COMPACT = `
[BUTLER AI SYSTEM]
App: React Native + Python server (butler_server.py) on user's Windows PC, 100% local, no cloud.
AI: Ollama local inference (qwen2.5-coder:7b default), all prompts stay on user's machine.
Auth: HMAC-SHA256 bearer token, QR pairing, token in every POST body as "token" field.
Port: default 8766, adaptive discovery tries [8766,8765,8767,8768,5000,3000...].
Scripts: POST /api/execute/stream (always streaming). Exit 0=ok, 1=error, 124=timeout.
Chat: POST /api/butler/chat {message, stream:true, conversation:[], token}. SSE stream, keepalive lines start with ":"  — ignore them.
PC scripts: GET /api/pc_scripts/list, POST /api/pc_scripts/save {name,code,description,category,tags}.
KB: POST /api/kb/expand {topic} queues self-learning. POST /api/learn/status for stats.
Health: GET /metrics for CPU/RAM/Disk. POST /api/sync on every foreground (replaces 10 individual fetches).
Undo: every exec returns undoId, POST /api/undo/rollback {id} within 15 minutes.
Models: qwen2.5-coder:7b (best code), phi4-mini (fastest), mistral:7b (general).
Play Store rules: zero data collection, camera=QR scan only, local network only, no root.
Write scripts for: Windows, non-interactive, complete imports, try/except, print("[OK] Done").
`;

```


### `/src/data/library.ts`

```ts path=/src/data/library.ts
/**
 * Script library — public surface for app routes.
 * Wraps the verbatim port from CommandCube/Butler-AI and exposes
 * a flat, typed catalogue + category metadata for the cyberpunk UI.
 */
import { PYTHON_AUTOMATION_SCRIPTS } from "./pythonAutomationKnowledge";
import type { AutomationScript } from "./scriptTypes";

export type Difficulty = "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
export type UICardColor = "cyan" | "violet" | "green" | "amber" | "red";

export type LibScript = AutomationScript & {
  difficulty: Difficulty;
  time: string;
  admin: boolean;
};

export type CategoryMeta = {
  id: string;          // matches AutomationScript.category
  label: string;       // pill label (short)
  title: string;       // full title
  subtitle: string;
  color: UICardColor;  // mapped to our themed-card palette
  hex: string;         // raw color for accents
};

export const CATEGORIES: CategoryMeta[] = [
  { id: "Files",       label: "FILES",      title: "File & Folder",        subtitle: "Organize · backup · rename",        color: "amber",  hex: "#FF6A1F" },
  { id: "System",      label: "SYSTEM",     title: "System Tools",         subtitle: "CPU · RAM · processes",             color: "cyan",   hex: "#00D4FF" },
  { id: "Web",         label: "WEB",        title: "Web & Scraping",       subtitle: "Scrape · download · automate",      color: "green",  hex: "#00FF88" },
  { id: "GUI",         label: "GUI",        title: "GUI Automation",       subtitle: "Mouse · keyboard · windows",        color: "amber",  hex: "#FFC400" },
  { id: "Email",       label: "EMAIL",      title: "Email & Notify",       subtitle: "SMTP · Slack · Discord",            color: "violet", hex: "#FF6FD8" },
  { id: "Data",        label: "DATA",       title: "Data Processing",      subtitle: "CSV · Excel · PDF · SQLite",        color: "amber",  hex: "#FFC400" },
  { id: "Scheduling",  label: "SCHED",      title: "Scheduling",           subtitle: "Cron · timers · automation",        color: "cyan",   hex: "#00D4FF" },
  { id: "Setup",       label: "SETUP",      title: "Setup & DevOps",       subtitle: "Docker · git · CI/CD",              color: "amber",  hex: "#FF6A1F" },
  { id: "Network",     label: "NET",        title: "Network & Monitoring", subtitle: "Scan · ping · ports · bandwidth",   color: "green",  hex: "#00FF88" },
  { id: "Text",        label: "TEXT",       title: "Text & Docs",          subtitle: "PDF · Word · regex · Markdown",     color: "cyan",   hex: "#A8C8D8" },
  { id: "Monitoring",  label: "MON",        title: "Monitoring & Alerts",  subtitle: "Watch · alert · log · GPU · disk",  color: "red",    hex: "#FF3C5A" },
  { id: "Security",    label: "SEC",        title: "Security & Threat",    subtitle: "Scan · harden · SSL · passwords",   color: "red",    hex: "#FF4444" },
  { id: "Privacy",     label: "PRIV",       title: "Privacy & Protection", subtitle: "Block · shred · WiFi · DNS · VPN",  color: "amber",  hex: "#FFC400" },
  { id: "Performance", label: "PERF",       title: "Performance & Speed",  subtitle: "Profile · benchmark · TCP · CPU",   color: "green",  hex: "#00FFB3" },
  { id: "Cleaning",    label: "CLEAN",      title: "System Cleaning",      subtitle: "Temp · Docker · git · pip · logs",  color: "cyan",   hex: "#4DFFEA" },
  { id: "Backup",      label: "BACKUP",     title: "Backup & Recovery",    subtitle: "Verify · sync · cloud · database",  color: "amber",  hex: "#FFA040" },
];

const META_BY_ID: Record<string, CategoryMeta> = Object.fromEntries(
  CATEGORIES.map((c) => [c.id, c]),
);

function inferDifficulty(req: string[], len: number): Difficulty {
  if (req.length >= 3 || len > 1200) return "ADVANCED";
  if (req.length >= 1 || len > 600)  return "INTERMEDIATE";
  return "BEGINNER";
}
function inferTime(len: number): string {
  if (len > 1200) return "5-10 min";
  if (len > 600)  return "2-5 min";
  return "< 2 min";
}
function inferAdmin(code: string): boolean {
  return /winreg|admin|ctypes\.windll|HKEY_LOCAL_MACHINE|sudo|iptables/i.test(code);
}

/** Full library — every script with computed UI metadata. */
export const SCRIPTS: LibScript[] = PYTHON_AUTOMATION_SCRIPTS.map((s) => ({
  ...s,
  difficulty: inferDifficulty(s.requirements ?? [], (s.script ?? "").length),
  time:       inferTime((s.script ?? "").length),
  admin:      inferAdmin(s.script ?? ""),
}));

/** Returns the category meta for a script (falls back to System). */
export function categoryOf(s: AutomationScript): CategoryMeta {
  return META_BY_ID[s.category] ?? META_BY_ID["System"];
}

export function getCategoriesPresent(): CategoryMeta[] {
  const seen = new Set<string>(SCRIPTS.map((s) => s.category));
  return CATEGORIES.filter((c) => seen.has(c.id));
}

/** Lightweight relevance ranking — title/tag matches first. */
export function search(query: string): LibScript[] {
  const q = query.trim().toLowerCase();
  if (!q) return SCRIPTS;
  const words = q.split(/\s+/).filter((w) => w.length > 1);
  return SCRIPTS
    .map((s) => {
      let score = 0;
      const hay = `${s.title} ${s.description} ${s.category} ${s.tags.join(" ")}`.toLowerCase();
      for (const w of words) {
        if (s.tags.some((t) => t.toLowerCase().includes(w))) score += 10;
        if (s.title.toLowerCase().includes(w))               score += 8;
        if (s.category.toLowerCase().includes(w))            score += 6;
        if (hay.includes(w))                                 score += 1;
      }
      return { s, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((x) => x.s);
}

export const SCRIPT_COUNT = SCRIPTS.length;

```


### `/src/data/pythonAutomationKnowledge.ts`

```ts path=/src/data/pythonAutomationKnowledge.ts
/**
 * 🐍 Python Automation Knowledge Base — 130+ Real Scripts
 * Comprehensive Python scripts for automating everything.
 */

import type { AutomationScript } from './scriptTypes';
import { EXTENDED_SCRIPTS } from './scriptLibraryExtensions';

// Re-export for backward compatibility
export type { AutomationScript };

function _loadExtended(): AutomationScript[] {
  return Array.isArray(EXTENDED_SCRIPTS) ? EXTENDED_SCRIPTS : [];
}

const BASE_SCRIPTS: AutomationScript[] = [

  // ── FILE & FOLDER ─────────────────────────────────────────────
  {
    id: 'file-organizer',
    title: 'File Organizer by Extension',
    category: 'Files',
    tags: ['files', 'organize', 'sort', 'folder', 'cleanup', 'desktop'],
    description: 'Automatically sorts files into subfolders by extension',
    requirements: [],
    script: `import os, shutil
from pathlib import Path

SOURCE = Path.home() / "Downloads"
RULES = {
    "Images":    [".jpg",".jpeg",".png",".gif",".bmp",".webp",".svg"],
    "Videos":    [".mp4",".avi",".mov",".mkv",".wmv",".flv"],
    "Documents": [".pdf",".doc",".docx",".txt",".xlsx",".pptx",".csv"],
    "Audio":     [".mp3",".wav",".flac",".aac",".ogg"],
    "Archives":  [".zip",".rar",".7z",".tar",".gz"],
    "Code":      [".py",".js",".ts",".html",".css",".json"],
}

moved = 0
for f in SOURCE.iterdir():
    if not f.is_file(): continue
    dest_folder = "Other"
    for name, exts in RULES.items():
        if f.suffix.lower() in exts:
            dest_folder = name; break
    dest = SOURCE / dest_folder
    dest.mkdir(exist_ok=True)
    shutil.move(str(f), dest / f.name)
    moved += 1
print(f"Organized {moved} files in {SOURCE}")`,
  },
  {
    id: 'bulk-rename',
    title: 'Bulk File Renamer',
    category: 'Files',
    tags: ['rename', 'batch', 'files', 'bulk', 'prefix'],
    description: 'Batch rename files with prefix, suffix, or find/replace',
    requirements: [],
    script: `from pathlib import Path

FOLDER  = Path.home() / "Pictures"
PREFIX  = "photo_"
REPLACE = ("IMG_", "pic_")

for i, f in enumerate(sorted(FOLDER.iterdir()), 1):
    if not f.is_file(): continue
    stem = f.stem.replace(*REPLACE)
    new_name = f"{PREFIX}{stem}{f.suffix}"
    f.rename(f.parent / new_name)
    print(f"Renamed: {f.name} -> {new_name}")`,
  },
  {
    id: 'backup-script',
    title: 'Auto Backup to Zip',
    category: 'Files',
    tags: ['backup', 'zip', 'archive', 'schedule', 'automated'],
    description: 'Back up a folder to a timestamped zip file, auto-cleans old backups',
    requirements: [],
    script: `import shutil, os
from pathlib import Path
from datetime import datetime

SOURCE     = Path.home() / "Documents"
BACKUP_DIR = Path.home() / "Backups"
MAX_BACKUPS = 7

BACKUP_DIR.mkdir(exist_ok=True)
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
archive = BACKUP_DIR / f"backup_{ts}"
shutil.make_archive(str(archive), 'zip', SOURCE)
size = os.path.getsize(str(archive)+'.zip') / 1024 / 1024
print(f"Backup created: {archive}.zip ({size:.1f}MB)")

backups = sorted(BACKUP_DIR.glob("backup_*.zip"))
for old in backups[:-MAX_BACKUPS]:
    old.unlink()
    print(f"Deleted old backup: {old.name}")`,
  },
  {
    id: 'duplicate-finder',
    title: 'Duplicate File Destroyer',
    category: 'Files',
    tags: ['duplicate', 'hash', 'find', 'clean', 'storage'],
    description: 'Find and remove duplicate files using MD5 hash comparison',
    requirements: [],
    script: `import hashlib, os
from pathlib import Path
from collections import defaultdict

SCAN_DIR = Path.home() / "Downloads"
DRY_RUN  = True  # Set False to actually delete

def file_hash(path, chunk=8192):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        while chunk := f.read(chunk):
            h.update(chunk)
    return h.hexdigest()

hashes = defaultdict(list)
for f in SCAN_DIR.rglob("*"):
    if f.is_file():
        try:
            hashes[file_hash(f)].append(f)
        except: pass

total_saved = 0
for h, files in hashes.items():
    if len(files) > 1:
        print(f"Duplicates ({len(files)}):")
        for i, f in enumerate(files):
            size = f.stat().st_size
            if i == 0:
                print(f"  KEEP: {f.name} ({size//1024}KB)")
            else:
                print(f"  {'DEL ' if not DRY_RUN else 'WOULD DEL'}: {f.name}")
                total_saved += size
                if not DRY_RUN: f.unlink()
print(f"\\nSpace {'would be ' if DRY_RUN else ''}freed: {total_saved//1024//1024}MB")`,
  },
  {
    id: 'smart-file-sorter',
    title: 'Smart File Sorter',
    category: 'Files',
    tags: ['sort', 'auto', 'organize', 'date', 'type'],
    description: 'Auto-sort files by type into organized folders with date subfolders',
    requirements: [],
    script: `from pathlib import Path
import shutil
from datetime import datetime

WATCH_DIR = Path.home() / "Downloads"
OUT_DIR   = Path.home() / "Sorted"

EXT_MAP = {
    'Photos':    ['.jpg','.jpeg','.png','.heic'],
    'Videos':    ['.mp4','.mkv','.avi','.mov'],
    'Music':     ['.mp3','.flac','.wav','.aac'],
    'Documents': ['.pdf','.doc','.docx','.txt'],
    'Code':      ['.py','.js','.ts','.html'],
    'Archives':  ['.zip','.rar','.7z','.tar'],
}

def get_category(suffix):
    s = suffix.lower()
    for cat, exts in EXT_MAP.items():
        if s in exts: return cat
    return 'Misc'

for f in WATCH_DIR.iterdir():
    if not f.is_file(): continue
    cat  = get_category(f.suffix)
    mtime = datetime.fromtimestamp(f.stat().st_mtime)
    dest = OUT_DIR / cat / mtime.strftime('%Y-%m')
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy2(f, dest / f.name)
    print(f"  {f.name} -> {cat}/{mtime.strftime('%Y-%m')}")

print("Sorting complete!")`,
  },
  {
    id: 'photo-organizer',
    title: 'Photo Organizer by Date',
    category: 'Files',
    tags: ['photos', 'exif', 'date', 'organize', 'images'],
    description: 'Sort photos into YYYY/MM folders using EXIF metadata',
    requirements: ['Pillow'],
    script: `from pathlib import Path
import shutil
from datetime import datetime

try:
    from PIL import Image
    from PIL.ExifTags import TAGS
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
    print("pip install Pillow for EXIF support")

SOURCE = Path.home() / "Pictures" / "Unsorted"
DEST   = Path.home() / "Pictures" / "Organized"

def get_date(path):
    if HAS_PIL:
        try:
            img = Image.open(path)
            exif = img._getexif() or {}
            for tag_id, val in exif.items():
                if TAGS.get(tag_id) == 'DateTimeOriginal':
                    return datetime.strptime(val, '%Y:%m:%d %H:%M:%S')
        except: pass
    return datetime.fromtimestamp(path.stat().st_mtime)

moved = 0
for f in SOURCE.rglob("*"):
    if f.suffix.lower() not in ['.jpg','.jpeg','.png','.heic','.raw']: continue
    dt   = get_date(f)
    dest = DEST / dt.strftime('%Y') / dt.strftime('%m-%B')
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy2(f, dest / f.name)
    moved += 1

print(f"Organized {moved} photos into {DEST}")`,
  },

  // ── SYSTEM AUTOMATION ─────────────────────────────────────────
  {
    id: 'sys-info',
    title: 'Full System Info Report',
    category: 'System',
    tags: ['system', 'info', 'specs', 'hardware', 'cpu', 'ram', 'disk'],
    description: 'Generates a complete system specification report',
    requirements: ['psutil'],
    script: `import platform, psutil, socket
from datetime import datetime

cpu  = psutil.cpu_percent(interval=1)
mem  = psutil.virtual_memory()
disk = psutil.disk_usage('/')
net  = psutil.net_io_counters()
boot = datetime.fromtimestamp(psutil.boot_time())
freq = psutil.cpu_freq()

print(f"""
=== SYSTEM REPORT [{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] ===
OS:       {platform.system()} {platform.release()} {platform.machine()}
Hostname: {socket.gethostname()}
CPU:      {platform.processor()[:50]}
  Usage:  {cpu}%  Cores: {psutil.cpu_count(logical=True)}
  Freq:   {freq.current:.0f}MHz (max {freq.max:.0f}MHz)
RAM:      {mem.used/1024**3:.1f}/{mem.total/1024**3:.1f}GB ({mem.percent}%)
Disk:     {disk.used/1024**3:.1f}/{disk.total/1024**3:.1f}GB ({disk.percent}%)
Network:  UP {net.bytes_sent/1024**2:.1f}MB  DOWN {net.bytes_recv/1024**2:.1f}MB
Uptime:   Since {boot.strftime('%Y-%m-%d %H:%M')}
Procs:    {len(psutil.pids())} running
""")`,
  },
  {
    id: 'kill-process',
    title: 'Kill Process by Name',
    category: 'System',
    tags: ['process', 'kill', 'task', 'manager', 'stop', 'terminate'],
    description: 'Find and terminate processes by name',
    requirements: ['psutil'],
    script: `import psutil

TARGET = "chrome"  # Process name to kill (partial match)

killed = 0
for proc in psutil.process_iter(['pid', 'name', 'status']):
    try:
        if TARGET.lower() in proc.info['name'].lower():
            proc.terminate()
            proc.wait(timeout=3)
            print(f"Killed: {proc.info['name']} (PID {proc.info['pid']})")
            killed += 1
    except (psutil.NoSuchProcess, psutil.AccessDenied): pass

print(f"Terminated {killed} process(es) matching '{TARGET}'"
      if killed else f"No processes found matching '{TARGET}'")`,
  },
  {
    id: 'disk-usage-analyzer',
    title: 'Disk Usage Analyzer',
    category: 'System',
    tags: ['disk', 'storage', 'usage', 'treemap', 'space', 'folders'],
    description: 'Analyze disk usage by folder and find largest space consumers',
    requirements: ['psutil'],
    script: `import os
from pathlib import Path
import psutil

def folder_size(path):
    total = 0
    try:
        for entry in os.scandir(path):
            try:
                if entry.is_file(follow_symlinks=False):
                    total += entry.stat().st_size
                elif entry.is_dir(follow_symlinks=False):
                    total += folder_size(entry.path)
            except: pass
    except: pass
    return total

def fmt(size):
    for unit in ['B','KB','MB','GB','TB']:
        if size < 1024: return f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}PB"

# Disk partitions
print("=== DISK PARTITIONS ===")
for p in psutil.disk_partitions():
    try:
        usage = psutil.disk_usage(p.mountpoint)
        bar = '█' * int(usage.percent/5) + '░' * (20-int(usage.percent/5))
        print(f"{p.device:20} {bar} {usage.percent:5.1f}% used | {fmt(usage.free)} free")
    except: pass

# Top folders in home
print(f"\\n=== TOP FOLDERS IN HOME ===")
home = Path.home()
sizes = []
for item in home.iterdir():
    if item.is_dir():
        try:
            sizes.append((item, folder_size(item)))
        except: pass
for path, size in sorted(sizes, key=lambda x: x[1], reverse=True)[:10]:
    bar = '█' * min(int(size/1024/1024/100), 20)
    print(f"  {path.name:25} {fmt(size):10} {bar}")`,
  },
  {
    id: 'startup-manager',
    title: 'Windows Startup App Manager',
    category: 'System',
    tags: ['startup', 'windows', 'boot', 'autostart', 'registry'],
    description: 'List and manage Windows startup programs via registry',
    requirements: [],
    script: `import winreg, sys

if sys.platform != 'win32':
    print("Windows only"); exit()

KEY = r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"

print("=== STARTUP PROGRAMS ===")
with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY) as k:
    i = 0
    while True:
        try:
            name, val, _ = winreg.EnumValue(k, i)
            print(f"  {i+1}. {name}: {val[:70]}")
            i += 1
        except OSError: break

print(f"\\nTotal: {i} startup items")
print("To remove: uncomment the line below and set name")
# with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY, 0, winreg.KEY_WRITE) as k:
#     winreg.DeleteValue(k, "ProgramName")`,
  },
  {
    id: 'process-monitor',
    title: 'Process Hog Killer',
    category: 'System',
    tags: ['process', 'cpu', 'ram', 'high usage', 'kill', 'hog'],
    description: 'Auto-kill runaway processes exceeding CPU/RAM thresholds',
    requirements: ['psutil'],
    script: `import psutil, time

CPU_LIMIT = 90  # % CPU threshold to kill
RAM_LIMIT = 85  # % RAM threshold to warn
WHITELIST = {'System', 'svchost.exe', 'python.exe', 'python3'}

print(f"Monitoring: CPU>{CPU_LIMIT}% RAM>{RAM_LIMIT}% | Whitelist: {WHITELIST}")
print("Press Ctrl+C to stop\\n")

try:
    while True:
        for proc in psutil.process_iter(['pid','name','cpu_percent','memory_percent']):
            try:
                info = proc.info
                name = info['name'] or 'unknown'
                cpu  = info['cpu_percent'] or 0
                ram  = info['memory_percent'] or 0

                if name in WHITELIST: continue

                if cpu > CPU_LIMIT:
                    print(f"CPU HOG: {name} ({info['pid']}) using {cpu:.1f}% CPU — killing")
                    proc.terminate()
                elif ram > RAM_LIMIT:
                    print(f"RAM HOG: {name} ({info['pid']}) using {ram:.1f}% RAM — warning")
            except (psutil.NoSuchProcess, psutil.AccessDenied): pass
        time.sleep(5)
except KeyboardInterrupt:
    print("\\nStopped.")`,
  },

  // ── SECURITY & THREAT PREVENTION ──────────────────────────────
  {
    id: 'open-port-scanner',
    title: 'Open Port Scanner',
    category: 'Security',
    tags: ['ports', 'scan', 'network', 'security', 'nmap', 'audit'],
    description: 'Audit listening ports and flag anomalous services',
    requirements: [],
    script: `import socket, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

TARGET = "127.0.0.1"  # Change to scan remote host
PORTS  = list(range(1, 1025))  # Common ports

WELL_KNOWN = {
    21:'FTP',22:'SSH',23:'Telnet',25:'SMTP',53:'DNS',
    80:'HTTP',110:'POP3',143:'IMAP',443:'HTTPS',
    3306:'MySQL',5432:'Postgres',6379:'Redis',8080:'HTTP-Alt',
    8765:'Butler',27017:'MongoDB',
}

def scan_port(port):
    try:
        s = socket.socket()
        s.settimeout(0.5)
        result = s.connect_ex((TARGET, port))
        s.close()
        return port if result == 0 else None
    except: return None

print(f"Scanning {TARGET} ports 1-1024...")
open_ports = []
with ThreadPoolExecutor(max_workers=200) as ex:
    results = ex.map(scan_port, PORTS)
    open_ports = [p for p in results if p]

print(f"\\nFound {len(open_ports)} open ports:")
for port in sorted(open_ports):
    service = WELL_KNOWN.get(port, 'Unknown')
    flag = " ⚠ RISKY" if port in [21,23,3306,27017] else ""
    print(f"  {port:5} — {service}{flag}")`,
  },
  {
    id: 'file-integrity-monitor',
    title: 'File Integrity Monitor',
    category: 'Security',
    tags: ['integrity', 'hash', 'monitor', 'tamper', 'detect', 'security'],
    description: 'Hash monitoring for critical files to detect tampering',
    requirements: [],
    script: `import hashlib, json, time
from pathlib import Path
from datetime import datetime

WATCH_PATHS = [
    Path("C:/Windows/System32/drivers/etc/hosts"),
    Path.home() / ".ssh" / "authorized_keys",
    # Add more critical files
]
BASELINE_FILE = "integrity_baseline.json"

def file_hash(path):
    h = hashlib.sha256()
    try:
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                h.update(chunk)
        return h.hexdigest()
    except: return None

def create_baseline():
    baseline = {}
    for p in WATCH_PATHS:
        if p.exists():
            baseline[str(p)] = {'hash': file_hash(p), 'ts': datetime.now().isoformat()}
    with open(BASELINE_FILE, 'w') as f:
        json.dump(baseline, f, indent=2)
    print(f"Baseline created for {len(baseline)} files")
    return baseline

def check_integrity(baseline):
    alerts = []
    for path_str, info in baseline.items():
        path = Path(path_str)
        if not path.exists():
            alerts.append(f"MISSING: {path_str}")
        elif file_hash(path) != info['hash']:
            alerts.append(f"TAMPERED: {path_str}")
    return alerts

if not Path(BASELINE_FILE).exists():
    baseline = create_baseline()
else:
    with open(BASELINE_FILE) as f:
        baseline = json.load(f)
    alerts = check_integrity(baseline)
    if alerts:
        for a in alerts: print(f"⚠  {a}")
    else:
        print(f"All {len(baseline)} files intact")`,
  },
  {
    id: 'password-audit',
    title: 'Password Strength Audit',
    category: 'Security',
    tags: ['password', 'audit', 'strength', 'weak', 'security'],
    description: 'Check accounts for weak passwords in shadow/SAM files',
    requirements: [],
    script: `import hashlib, re

COMMON_PASSWORDS = [
    "password","123456","password1","qwerty","abc123",
    "letmein","monkey","1234567890","admin","welcome",
    "login","passw0rd","master","hello","shadow",
]

def strength_score(pwd):
    score = 0
    if len(pwd) >= 8: score += 1
    if len(pwd) >= 12: score += 1
    if re.search(r'[A-Z]', pwd): score += 1
    if re.search(r'[a-z]', pwd): score += 1
    if re.search(r'[0-9]', pwd): score += 1
    if re.search(r'[^A-Za-z0-9]', pwd): score += 1
    return score

def audit_password(pwd):
    score = strength_score(pwd)
    is_common = pwd.lower() in COMMON_PASSWORDS
    level = ['VERY WEAK','WEAK','FAIR','GOOD','STRONG','VERY STRONG'][min(score,5)]
    return {'score': score, 'level': level, 'common': is_common}

# Test passwords
TEST_PASSWORDS = ["password123", "MyS3cur3P@ss!", "qwerty", "X9#kL2mP!"]
print("=== PASSWORD AUDIT ===")
for pwd in TEST_PASSWORDS:
    result = audit_password(pwd)
    flag = " ⚠ COMMON!" if result['common'] else ""
    print(f"  {'*'*len(pwd):15} Score:{result['score']}/5  {result['level']:12}{flag}")`,
  },
  {
    id: 'ssh-fortress',
    title: 'SSH Fortress Hardener',
    category: 'Security',
    tags: ['ssh', 'harden', 'security', 'config', 'key'],
    description: 'Harden SSH config — enforce key-only auth, disable root login',
    requirements: [],
    script: `import subprocess, sys, shutil
from pathlib import Path
from datetime import datetime

if sys.platform == 'win32':
    print("Linux/Mac only"); exit()

SSHD_CONFIG = Path("/etc/ssh/sshd_config")

HARDENED_SETTINGS = {
    "PermitRootLogin":           "no",
    "PasswordAuthentication":    "no",
    "PubkeyAuthentication":      "yes",
    "AuthorizedKeysFile":        ".ssh/authorized_keys",
    "PermitEmptyPasswords":      "no",
    "MaxAuthTries":              "3",
    "LoginGraceTime":            "20",
    "X11Forwarding":             "no",
    "Protocol":                  "2",
}

if not SSHD_CONFIG.exists():
    print("sshd_config not found — is OpenSSH installed?"); exit()

# Backup original
backup = SSHD_CONFIG.with_suffix(f".backup_{datetime.now().strftime('%Y%m%d')}")
shutil.copy2(SSHD_CONFIG, backup)
print(f"Backed up to {backup}")

content = SSHD_CONFIG.read_text()
for key, value in HARDENED_SETTINGS.items():
    import re
    pattern = rf"^#?\\s*{key}\\s+.*$"
    replacement = f"{key} {value}"
    if re.search(pattern, content, re.MULTILINE):
        content = re.sub(pattern, replacement, content, flags=re.MULTILINE)
    else:
        content += f"\\n{replacement}"
    print(f"  Set {key} = {value}")

SSHD_CONFIG.write_text(content)
subprocess.run(["systemctl", "restart", "ssh"], capture_output=True)
print("\\nSSH hardened. Restart SSH to apply.")`,
  },
  {
    id: 'rootkit-scanner',
    title: 'Rootkit Hunter',
    category: 'Security',
    tags: ['rootkit', 'malware', 'scan', 'backdoor', 'security'],
    description: 'Scan for rootkits, backdoors and suspicious processes',
    requirements: [],
    script: `import os, sys, subprocess
from pathlib import Path

SUSPICIOUS_FILES = [
    "/tmp/.ICE-unix/.*sh",
    "/dev/shm/.*\\.py",
    "/.hidden",
]

SUSPICIOUS_PROCS = [
    "nc -l", "ncat", "ngrok", "msfconsole",
    "backdoor", "reverse_shell",
]

SUID_WHITELIST = {"/usr/bin/sudo","/usr/bin/su","/bin/passwd"}

print("=== ROOTKIT SCAN ===")
issues = []

# Check for suspicious hidden files
print("\\n[1] Checking for suspicious files...")
for pattern in ["/tmp", "/var/tmp", "/dev/shm"]:
    try:
        for f in Path(pattern).rglob("*"):
            if f.name.startswith('.') and f.is_file():
                issues.append(f"Hidden file: {f}")
                print(f"  ⚠ {f}")
    except: pass

# Check SUID files (Linux)
if sys.platform != 'win32':
    print("\\n[2] Checking SUID files...")
    try:
        r = subprocess.run(["find", "/", "-perm", "/4000", "-type", "f"],
                           capture_output=True, text=True, timeout=10)
        for f in r.stdout.strip().split("\\n"):
            if f and f not in SUID_WHITELIST:
                print(f"  SUID: {f}")
    except: pass

# Check running processes
print("\\n[3] Checking processes...")
try:
    import psutil
    for proc in psutil.process_iter(['pid','name','cmdline']):
        cmd = ' '.join(proc.info.get('cmdline') or []).lower()
        for suspicious in SUSPICIOUS_PROCS:
            if suspicious in cmd:
                issues.append(f"Suspicious process: {cmd}")
                print(f"  ⚠ PID {proc.info['pid']}: {cmd[:80]}")
except ImportError:
    print("  (pip install psutil for process scan)")

print(f"\\n=== RESULTS: {len(issues)} issues found ===")`,
  },
  {
    id: 'firewall-hardener',
    title: 'Firewall Hardener',
    category: 'Security',
    tags: ['firewall', 'iptables', 'ufw', 'security', 'block', 'rules'],
    description: 'Auto-configure iptables/ufw firewall rules for hardening',
    requirements: [],
    script: `import subprocess, sys

if sys.platform == 'win32':
    print("Linux only"); exit()

def run(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    status = "✓" if r.returncode == 0 else "✗"
    print(f"  {status} {cmd}")
    return r.returncode == 0

print("=== UFW FIREWALL HARDENING ===")

# Check if ufw is available
if subprocess.run("which ufw", shell=True, capture_output=True).returncode != 0:
    print("UFW not found. Install: sudo apt install ufw"); exit()

rules = [
    "ufw --force reset",
    "ufw default deny incoming",
    "ufw default allow outgoing",
    "ufw allow ssh",
    "ufw allow 80/tcp",
    "ufw allow 443/tcp",
    "ufw limit ssh/tcp",    # Rate-limit SSH to prevent brute force
    "ufw --force enable",
]

for rule in rules:
    run(f"sudo {rule}")

run("sudo ufw status verbose")
print("\\nFirewall hardened. Review rules with: sudo ufw status verbose")`,
  },

  // ── SYSTEM CLEANING ───────────────────────────────────────────
  {
    id: 'temp-file-nuker',
    title: 'Temp File Nuker',
    category: 'Cleaning',
    tags: ['clean', 'temp', 'cache', 'junk', 'free space', 'disk'],
    description: 'Purge temp dirs, caches and install leftovers to free space',
    requirements: [],
    script: `import shutil, os, sys
from pathlib import Path

DRY_RUN = False  # Set True to preview without deleting

CLEAN_PATHS = []

if sys.platform == 'win32':
    CLEAN_PATHS += [
        Path(os.environ.get('TEMP', 'C:/Temp')),
        Path("C:/Windows/Temp"),
        Path(os.environ.get('LOCALAPPDATA','')) / "Temp",
        Path(os.environ.get('LOCALAPPDATA','')) / "Microsoft/Windows/INetCache",
    ]
else:
    CLEAN_PATHS += [
        Path("/tmp"),
        Path("/var/tmp"),
        Path.home() / ".cache",
        Path("/var/cache/apt/archives") if Path("/var/cache/apt").exists() else None,
    ]

total_freed = 0

for clean_path in CLEAN_PATHS:
    if not clean_path or not clean_path.exists(): continue
    path_size = 0
    count = 0
    for item in clean_path.rglob("*"):
        if item.is_file():
            try:
                path_size += item.stat().st_size
                count += 1
                if not DRY_RUN: item.unlink(missing_ok=True)
            except: pass
    mb = path_size / 1024 / 1024
    total_freed += path_size
    action = "WOULD FREE" if DRY_RUN else "FREED"
    print(f"  {action}: {clean_path.name:30} {mb:7.1f}MB  ({count} files)")

print(f"\\nTotal {'would be ' if DRY_RUN else ''}freed: {total_freed/1024/1024:.1f}MB")`,
  },
  {
    id: 'browser-scrubber',
    title: 'Browser Cache Scrubber',
    category: 'Cleaning',
    tags: ['browser', 'cache', 'clear', 'history', 'cookies', 'clean', 'privacy'],
    description: 'Clear cache, cookies, history from Chrome, Firefox, Edge everywhere',
    requirements: [],
    script: `import shutil, sys
from pathlib import Path

HOME = Path.home()

BROWSER_CACHES = {}
if sys.platform == 'win32':
    APPDATA = Path(os.environ.get('LOCALAPPDATA',''))
    ROAMING  = Path(os.environ.get('APPDATA',''))
    BROWSER_CACHES = {
        "Chrome":  APPDATA / "Google/Chrome/User Data/Default/Cache",
        "Edge":    APPDATA / "Microsoft/Edge/User Data/Default/Cache",
        "Firefox": ROAMING / "Mozilla/Firefox/Profiles",
        "Brave":   APPDATA / "BraveSoftware/Brave-Browser/User Data/Default/Cache",
    }
elif sys.platform == 'darwin':
    BROWSER_CACHES = {
        "Chrome":  HOME / "Library/Caches/Google/Chrome",
        "Firefox": HOME / "Library/Caches/Firefox",
        "Safari":  HOME / "Library/Caches/com.apple.Safari",
    }
else:
    BROWSER_CACHES = {
        "Chrome":  HOME / ".cache/google-chrome",
        "Firefox": HOME / ".cache/mozilla/firefox",
        "Brave":   HOME / ".cache/BraveSoftware/Brave-Browser",
    }

import os
total = 0
for browser, cache_path in BROWSER_CACHES.items():
    if not cache_path.exists(): continue
    size = sum(f.stat().st_size for f in cache_path.rglob('*') if f.is_file())
    try:
        shutil.rmtree(cache_path)
        cache_path.mkdir(parents=True, exist_ok=True)
        total += size
        print(f"  Cleared {browser}: {size/1024/1024:.1f}MB")
    except Exception as e:
        print(f"  {browser}: {e}")

print(f"\\nTotal cleared: {total/1024/1024:.1f}MB")`,
  },
  {
    id: 'log-rotator',
    title: 'Log Rotator & Compressor',
    category: 'Cleaning',
    tags: ['logs', 'compress', 'rotate', 'trim', 'journal', 'disk'],
    description: 'Compress and rotate system logs, trim journal size',
    requirements: [],
    script: `import gzip, shutil, subprocess, sys
from pathlib import Path
from datetime import datetime, timedelta

LOG_DIR  = Path("/var/log") if sys.platform != 'win32' else Path("C:/Logs")
MAX_AGE  = 30  # days to keep logs
MAX_SIZE = 100 * 1024 * 1024  # 100MB max per log

total_saved = 0

if LOG_DIR.exists():
    for log_file in LOG_DIR.rglob("*.log"):
        try:
            stat = log_file.stat()
            age  = (datetime.now() - datetime.fromtimestamp(stat.st_mtime)).days

            if age > MAX_AGE:
                log_file.unlink()
                print(f"  Deleted old log ({age}d): {log_file.name}")
                total_saved += stat.st_size

            elif stat.st_size > MAX_SIZE:
                gz_path = log_file.with_suffix('.log.gz')
                with open(log_file, 'rb') as f_in:
                    with gzip.open(gz_path, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
                saved = stat.st_size - gz_path.stat().st_size
                log_file.unlink()
                total_saved += saved
                print(f"  Compressed: {log_file.name} ({saved/1024:.0f}KB saved)")
        except: pass

# Trim systemd journal (Linux)
if sys.platform != 'win32':
    try:
        subprocess.run(["sudo", "journalctl", "--vacuum-time=30d"], capture_output=True)
        subprocess.run(["sudo", "journalctl", "--vacuum-size=100M"], capture_output=True)
        print("  Trimmed systemd journal")
    except: pass

print(f"\\nTotal space freed: {total_saved/1024/1024:.1f}MB")`,
  },
  {
    id: 'startup-optimizer',
    title: 'Startup Optimizer',
    category: 'Cleaning',
    tags: ['startup', 'boot', 'optimize', 'disable', 'performance', 'slow'],
    description: 'Disable bloat startup items to speed up boot',
    requirements: [],
    script: `import subprocess, sys

if sys.platform == 'win32':
    import winreg

    KNOWN_BLOAT = [
        "OneDrive", "Teams", "Spotify", "Discord",
        "Steam", "EpicGamesLauncher", "AdobeUpdater",
        "GoogleDriveFS", "Slack", "Zoom",
    ]

    KEY = r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"

    print("=== STARTUP ITEMS ===")
    disabled = []
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY) as k:
        i = 0
        items = []
        while True:
            try:
                name, val, _ = winreg.EnumValue(k, i)
                items.append((name, val))
                i += 1
            except OSError: break

    for name, val in items:
        is_bloat = any(b.lower() in name.lower() for b in KNOWN_BLOAT)
        flag = " ← BLOAT" if is_bloat else ""
        print(f"  {name[:35]:35}{flag}")
        # Uncomment to disable:
        # if is_bloat:
        #     with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY, 0, winreg.KEY_WRITE) as k:
        #         winreg.DeleteValue(k, name)
        #     disabled.append(name)

    print(f"\\nFound {len(items)} startup items")
else:
    # Linux: list systemd services
    result = subprocess.run(
        ["systemctl", "list-unit-files", "--type=service", "--state=enabled"],
        capture_output=True, text=True
    )
    print("=== ENABLED SERVICES ===")
    print(result.stdout[:3000])`,
  },
  {
    id: 'orphan-package-cleaner',
    title: 'Orphan Package Cleaner',
    category: 'Cleaning',
    tags: ['packages', 'orphan', 'apt', 'pip', 'clean', 'dependencies'],
    description: 'Remove orphaned packages and dependencies on Linux/Mac',
    requirements: [],
    script: `import subprocess, sys

if sys.platform == 'win32':
    print("Linux/Mac only for package cleanup")
    print("For Python: pip list --outdated")
    result = subprocess.run(["pip", "list", "--outdated"],
                            capture_output=True, text=True)
    print(result.stdout)
    exit()

print("=== PACKAGE CLEANUP ===")

# APT (Debian/Ubuntu)
if subprocess.run("which apt-get", shell=True, capture_output=True).returncode == 0:
    print("\\n[APT] Removing orphans...")
    cmds = [
        "sudo apt-get autoremove -y",
        "sudo apt-get autoclean -y",
        "sudo apt-get clean",
    ]
    for cmd in cmds:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        print(f"  {'✓' if r.returncode==0 else '✗'} {cmd}")

# DNF (Fedora/RHEL)
elif subprocess.run("which dnf", shell=True, capture_output=True).returncode == 0:
    subprocess.run("sudo dnf autoremove -y", shell=True)

# Homebrew (Mac)
elif subprocess.run("which brew", shell=True, capture_output=True).returncode == 0:
    subprocess.run("brew cleanup --prune=7", shell=True)
    subprocess.run("brew autoremove", shell=True)

# Python orphans
print("\\n[PIP] Outdated packages:")
subprocess.run(["pip", "list", "--outdated"])`,
  },

  // ── PERFORMANCE & OPTIMIZATION ────────────────────────────────
  {
    id: 'swappiness-optimizer',
    title: 'Swappiness Optimizer',
    category: 'Performance',
    tags: ['swap', 'ram', 'memory', 'optimize', 'linux', 'performance'],
    description: 'Tune vm.swappiness for optimal RAM usage',
    requirements: [],
    script: `import subprocess, sys

if sys.platform == 'win32':
    print("Linux only"); exit()

def get_swappiness():
    r = subprocess.run(["cat", "/proc/sys/vm/swappiness"],
                       capture_output=True, text=True)
    return int(r.stdout.strip())

def set_swappiness(value):
    subprocess.run(["sudo", "sysctl", f"vm.swappiness={value}"])
    # Persist across reboots
    config_line = f"vm.swappiness={value}"
    sysctl_conf = "/etc/sysctl.conf"
    with open(sysctl_conf) as f:
        content = f.read()
    if "vm.swappiness" in content:
        import re
        content = re.sub(r"vm\\.swappiness=\\d+", config_line, content)
    else:
        content += f"\\n{config_line}\\n"
    # Write requires sudo — show command instead
    print(f"  Run: sudo sh -c 'echo \"{config_line}\" >> /etc/sysctl.conf'")

current = get_swappiness()
print(f"Current swappiness: {current}")

import psutil
ram_gb = psutil.virtual_memory().total / 1024**3
if ram_gb >= 16:
    recommended = 10
    reason = "16GB+ RAM — prefer RAM over swap"
elif ram_gb >= 8:
    recommended = 30
    reason = "8-16GB RAM — moderate swap preference"
else:
    recommended = 60
    reason = "< 8GB RAM — default swap behavior"

print(f"RAM: {ram_gb:.1f}GB")
print(f"Recommended: {recommended} ({reason})")
if current != recommended:
    set_swappiness(recommended)
    print(f"Swappiness set to {recommended}")
else:
    print("Already optimal!")`,
  },
  {
    id: 'cpu-governor',
    title: 'CPU Governor Control',
    category: 'Performance',
    tags: ['cpu', 'governor', 'performance', 'power', 'frequency', 'linux'],
    description: 'Set CPU frequency policy for max performance or power saving',
    requirements: [],
    script: `import subprocess, sys
from pathlib import Path

if sys.platform == 'win32':
    # Windows power plan
    plans = {
        'performance': '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c',
        'balanced':    '381b4222-f694-41f0-9685-ff5bb260df2e',
        'powersaver':  'a1841308-3541-4fab-bc81-f71556f20b4a',
    }
    PLAN = 'performance'
    subprocess.run(f"powercfg /setactive {plans[PLAN]}", shell=True)
    print(f"Windows power plan set to: {PLAN}")
    subprocess.run("powercfg /list", shell=True)
    exit()

# Linux governor
GOV_PATH = Path("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
if not GOV_PATH.exists():
    print("CPU governor not available on this system"); exit()

print(f"Current governor: {GOV_PATH.read_text().strip()}")
print("Available:")
avail = Path("/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors")
if avail.exists(): print(f"  {avail.read_text().strip()}")

GOVERNOR = "performance"  # or: powersave, ondemand, conservative, schedutil
cpu_count = len(list(Path("/sys/devices/system/cpu").glob("cpu[0-9]*")))

for i in range(cpu_count):
    path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor"
    subprocess.run(f"echo {GOVERNOR} | sudo tee {path}", shell=True, capture_output=True)

print(f"Set all {cpu_count} CPUs to: {GOVERNOR}")`,
  },
  {
    id: 'ssd-trim',
    title: 'SSD TRIM Scheduler',
    category: 'Performance',
    tags: ['ssd', 'trim', 'fstrim', 'disk', 'performance', 'health'],
    description: 'Run periodic TRIM for SSD longevity and performance',
    requirements: [],
    script: `import subprocess, sys, os
from datetime import datetime

if sys.platform == 'win32':
    print("=== SSD OPTIMIZATION (Windows) ===")
    # Windows built-in TRIM
    r = subprocess.run("fsutil behavior query DisableDeleteNotify",
                       shell=True, capture_output=True, text=True)
    print(r.stdout)
    print("Running Disk Optimizer...")
    subprocess.run("defrag C: /L", shell=True)  # /L = TRIM/retrim for SSD
    exit()

# Linux
print("=== SSD TRIM (Linux) ===")
print(f"Time: {datetime.now()}")

# Check if TRIM is supported
r = subprocess.run(["lsblk", "-D", "-o", "NAME,DISC-GRAN,DISC-MAX"],
                   capture_output=True, text=True)
print("TRIM Support:")
print(r.stdout)

# Run fstrim
print("\\nRunning fstrim...")
r = subprocess.run(["sudo", "fstrim", "-av"],
                   capture_output=True, text=True)
print(r.stdout or r.stderr)

# Enable weekly auto-trim
enable_timer = subprocess.run(
    ["sudo", "systemctl", "enable", "--now", "fstrim.timer"],
    capture_output=True, text=True
)
print("Weekly TRIM timer:", "enabled" if enable_timer.returncode == 0 else "already set")`,
  },
  {
    id: 'benchmark-suite',
    title: 'System Benchmark Suite',
    category: 'Performance',
    tags: ['benchmark', 'speed', 'test', 'cpu', 'disk', 'network', 'performance'],
    description: 'Run CPU, disk, and network benchmarks and report results',
    requirements: ['psutil'],
    script: `import time, os, math, tempfile, socket
from pathlib import Path
import psutil

print("=== SYSTEM BENCHMARK SUITE ===\\n")

# CPU Benchmark
print("[CPU] Calculating 10M primes...")
start = time.perf_counter()
count = 0
for n in range(2, 10_000_000):
    if all(n % i != 0 for i in range(2, int(math.sqrt(n))+1)):
        count += 1
cpu_time = time.perf_counter() - start
print(f"  Found {count} primes in {cpu_time:.2f}s")
score = int(10_000_000 / cpu_time / 1000)
print(f"  CPU Score: {score} (higher=better)")

# Disk Write Benchmark
print("\\n[DISK] Sequential write 100MB...")
tmp = tempfile.mktemp()
data = b'x' * 1024 * 1024  # 1MB chunk
start = time.perf_counter()
with open(tmp, 'wb') as f:
    for _ in range(100): f.write(data)
write_time = time.perf_counter() - start
write_speed = 100 / write_time
os.unlink(tmp)
print(f"  Write: {write_speed:.1f} MB/s")

# Network Benchmark (DNS latency)
print("\\n[NET] DNS lookup latency...")
servers = ["8.8.8.8", "1.1.1.1", "9.9.9.9"]
for s in servers:
    start = time.perf_counter()
    try:
        socket.gethostbyname("google.com")
        lat = (time.perf_counter() - start) * 1000
        print(f"  DNS via {s}: {lat:.1f}ms")
    except: print(f"  DNS via {s}: FAILED")

print("\\n=== BENCHMARK COMPLETE ===")`,
  },

  // ── PRIVACY & DATA PROTECTION ─────────────────────────────────
  {
    id: 'tracker-blocker',
    title: 'Tracker Blocker (Hosts)',
    category: 'Privacy',
    tags: ['tracker', 'ads', 'block', 'hosts', 'privacy', 'dns'],
    description: 'Update hosts file with ad/tracker block lists',
    requirements: ['requests'],
    script: `import requests, sys
from pathlib import Path
from datetime import datetime

if sys.platform == 'win32':
    HOSTS = Path("C:/Windows/System32/drivers/etc/hosts")
else:
    HOSTS = Path("/etc/hosts")

BLOCK_LISTS = [
    "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
    "https://raw.githubusercontent.com/AdAway/adaway.github.io/master/hosts.txt",
]

print("=== TRACKER BLOCKER ===")
print(f"Hosts file: {HOSTS}")

# Backup
backup = HOSTS.parent / f"hosts.backup.{datetime.now().strftime('%Y%m%d')}"
HOSTS.read_bytes()  # Test read access

blocked_domains = set()
for url in BLOCK_LISTS:
    try:
        print(f"Downloading: {url[:60]}...")
        r = requests.get(url, timeout=15)
        for line in r.text.splitlines():
            line = line.strip()
            if line and not line.startswith('#'):
                parts = line.split()
                if len(parts) >= 2 and parts[0] in ('0.0.0.0','127.0.0.1'):
                    blocked_domains.add(parts[1])
        print(f"  {len(blocked_domains)} domains so far")
    except Exception as e:
        print(f"  Error: {e}")

print(f"\\nTotal domains to block: {len(blocked_domains)}")
print("To apply (requires admin/sudo):")
print(f"  echo '# Blocked by Butler' | sudo tee -a {HOSTS}")
print(f"  # Then append {len(blocked_domains)} 0.0.0.0 entries")`,
  },
  {
    id: 'metadata-stripper',
    title: 'Metadata Stripper',
    category: 'Privacy',
    tags: ['metadata', 'exif', 'privacy', 'strip', 'image', 'gps', 'pdf'],
    description: 'Remove EXIF, GPS and author data from images and documents',
    requirements: ['Pillow', 'PyPDF2'],
    script: `from pathlib import Path
from PIL import Image

def strip_image_exif(path):
    """Remove all EXIF metadata from image"""
    img = Image.open(path)
    # Create new image without EXIF
    clean = Image.new(img.mode, img.size)
    clean.putdata(list(img.getdata()))
    output = path.parent / f"clean_{path.name}"
    clean.save(output, quality=95)
    orig_size = path.stat().st_size
    new_size  = output.stat().st_size
    print(f"  Stripped: {path.name} ({orig_size//1024}KB -> {new_size//1024}KB)")
    return output

def strip_pdf_metadata(path):
    """Remove metadata from PDF"""
    try:
        import PyPDF2
        reader = PyPDF2.PdfReader(str(path))
        writer = PyPDF2.PdfWriter()
        for page in reader.pages:
            writer.add_page(page)
        writer.add_metadata({'/Producer': '', '/Creator': '', '/Author': ''})
        output = path.parent / f"clean_{path.name}"
        with open(output, 'wb') as f:
            writer.write(f)
        print(f"  Stripped PDF: {path.name}")
        return output
    except ImportError:
        print("pip install PyPDF2"); return None

# Process all images in current dir
TARGET = Path(".")
count = 0
for f in TARGET.glob("**/*"):
    if f.suffix.lower() in ['.jpg','.jpeg','.png'] and not f.name.startswith('clean_'):
        strip_image_exif(f); count += 1
    elif f.suffix.lower() == '.pdf' and not f.name.startswith('clean_'):
        strip_pdf_metadata(f); count += 1

print(f"\\nStripped metadata from {count} files")`,
  },
  {
    id: 'secure-shredder',
    title: 'Secure File Shredder',
    category: 'Privacy',
    tags: ['shred', 'delete', 'secure', 'overwrite', 'wipe', 'privacy'],
    description: 'Multi-pass overwrite for sensitive files before deletion',
    requirements: [],
    script: `import os, random, struct
from pathlib import Path

def shred(path, passes=7):
    """DoD 5220.22-M compliant multi-pass overwrite"""
    path = Path(path)
    if not path.is_file():
        print(f"Not a file: {path}"); return False

    size = path.stat().st_size
    print(f"Shredding: {path.name} ({size//1024}KB) - {passes} passes")

    with open(path, 'r+b') as f:
        for i in range(passes):
            f.seek(0)
            if i % 3 == 0:
                f.write(b'\\x00' * size)  # All zeros
            elif i % 3 == 1:
                f.write(b'\\xFF' * size)  # All ones
            else:
                f.write(os.urandom(size))  # Random
            f.flush()
            os.fsync(f.fileno())
            print(f"  Pass {i+1}/{passes} {'zeros' if i%3==0 else 'ones' if i%3==1 else 'random'}")

    # Rename to obscure original name
    random_name = path.parent / (''.join(random.choices('0123456789abcdef', k=16)))
    path.rename(random_name)
    random_name.unlink()
    print(f"  Securely deleted: {path.name}")
    return True

# Shred a specific file
TARGET = "sensitive_file.txt"  # Change this
if Path(TARGET).exists():
    shred(TARGET)
else:
    print(f"File not found: {TARGET}")
    print("Usage: change TARGET to the file you want to securely delete")`,
  },
  {
    id: 'telemetry-killer',
    title: 'Telemetry Killer',
    category: 'Privacy',
    tags: ['telemetry', 'tracking', 'disable', 'windows', 'privacy', 'spyware'],
    description: 'Disable OS & app telemetry on Windows for maximum privacy',
    requirements: [],
    script: `import subprocess, sys, winreg

if sys.platform != 'win32':
    print("Windows only"); exit()

print("=== TELEMETRY KILLER ===")
print("Disabling Windows telemetry and tracking...\\n")

# Registry tweaks
REG_TWEAKS = [
    # Disable telemetry
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection", "AllowTelemetry", 0),
    # Disable Cortana
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search", "AllowCortana", 0),
    # Disable advertising ID
    (winreg.HKEY_CURRENT_USER, r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo", "Enabled", 0),
    # Disable app diagnostics
    (winreg.HKEY_CURRENT_USER, r"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Privacy", "TailoredExperiencesWithDiagnosticDataEnabled", 0),
]

for hive, key_path, value_name, data in REG_TWEAKS:
    try:
        with winreg.CreateKey(hive, key_path) as key:
            winreg.SetValueEx(key, value_name, 0, winreg.REG_DWORD, data)
        print(f"  ✓ {value_name} = {data}")
    except Exception as e:
        print(f"  ✗ {value_name}: {e}")

# Disable telemetry services
SERVICES = ["DiagTrack", "dmwappushservice", "WSearch", "SysMain"]
for svc in SERVICES:
    r = subprocess.run(f"sc stop {svc}", shell=True, capture_output=True)
    r2 = subprocess.run(f"sc config {svc} start= disabled", shell=True, capture_output=True)
    print(f"  Disabled service: {svc}")

print("\\nTelemetry disabled. Restart for full effect.")`,
  },

  // ── BACKUP & RECOVERY ─────────────────────────────────────────
  {
    id: 'incremental-backup',
    title: 'Incremental Backup (rsync)',
    category: 'Backup',
    tags: ['backup', 'rsync', 'incremental', 'sync', 'mirror', 'recovery'],
    description: 'Rsync-style incremental backup with dedup and verification',
    requirements: [],
    script: `import shutil, os, subprocess, sys
from pathlib import Path
from datetime import datetime
import hashlib

SOURCE = Path.home() / "Documents"
DEST   = Path.home() / "Backups" / "incremental"
LOG    = DEST / "backup.log"

DEST.mkdir(parents=True, exist_ok=True)

def file_hash(path):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

copied = skipped = 0
start = datetime.now()

print(f"Incremental backup: {SOURCE} -> {DEST}")
print(f"Started: {start.strftime('%Y-%m-%d %H:%M:%S')}\\n")

for src_file in SOURCE.rglob("*"):
    if not src_file.is_file(): continue
    rel = src_file.relative_to(SOURCE)
    dst_file = DEST / rel
    dst_file.parent.mkdir(parents=True, exist_ok=True)

    if dst_file.exists() and file_hash(src_file) == file_hash(dst_file):
        skipped += 1
    else:
        shutil.copy2(src_file, dst_file)
        copied += 1
        print(f"  Copied: {rel}")

elapsed = (datetime.now() - start).seconds
print(f"\\nDone in {elapsed}s: {copied} copied, {skipped} skipped")

with open(LOG, 'a') as f:
    f.write(f"{start.isoformat()} - copied:{copied} skipped:{skipped}\\n")`,
  },
  {
    id: 'database-dumper',
    title: 'Database Backup Dumper',
    category: 'Backup',
    tags: ['database', 'backup', 'mysql', 'postgres', 'mongodb', 'dump'],
    description: 'Auto-backup MySQL, PostgreSQL, MongoDB databases',
    requirements: [],
    script: `import subprocess, os
from pathlib import Path
from datetime import datetime

BACKUP_DIR = Path.home() / "db_backups"
BACKUP_DIR.mkdir(exist_ok=True)
ts = datetime.now().strftime("%Y%m%d_%H%M%S")

# ── MySQL / MariaDB ──────────────────────────────────────────────
MYSQL_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'your_password',
    'database': 'mydb',
}

def backup_mysql():
    out_file = BACKUP_DIR / f"mysql_{MYSQL_CONFIG['database']}_{ts}.sql.gz"
    cmd = (
        f"mysqldump -h {MYSQL_CONFIG['host']} "
        f"-u {MYSQL_CONFIG['user']} "
        f"-p{MYSQL_CONFIG['password']} "
        f"{MYSQL_CONFIG['database']} | gzip > {out_file}"
    )
    r = subprocess.run(cmd, shell=True, capture_output=True)
    if r.returncode == 0:
        size = out_file.stat().st_size / 1024
        print(f"  MySQL: {out_file.name} ({size:.0f}KB)")
    else:
        print(f"  MySQL error: {r.stderr.decode()[:100]}")

# ── PostgreSQL ───────────────────────────────────────────────────
def backup_postgres(db='postgres'):
    out_file = BACKUP_DIR / f"pg_{db}_{ts}.sql.gz"
    env = {**os.environ, 'PGPASSWORD': 'your_password'}
    cmd = f"pg_dump -U postgres {db} | gzip > {out_file}"
    r = subprocess.run(cmd, shell=True, env=env, capture_output=True)
    print(f"  PostgreSQL: {'OK' if r.returncode==0 else r.stderr.decode()[:80]}")

# ── MongoDB ──────────────────────────────────────────────────────
def backup_mongo(db='mydb'):
    out_dir = BACKUP_DIR / f"mongo_{db}_{ts}"
    r = subprocess.run(
        ["mongodump", "--db", db, "--out", str(out_dir)],
        capture_output=True, text=True
    )
    print(f"  MongoDB: {'OK' if r.returncode==0 else r.stderr[:80]}")

print(f"=== DATABASE BACKUP [{ts}] ===")
backup_mysql()
# backup_postgres()
# backup_mongo()
print("\\nBackups saved to:", BACKUP_DIR)`,
  },

  // ── NETWORK & MONITORING ──────────────────────────────────────
  {
    id: 'bandwidth-monitor',
    title: 'Bandwidth Monitor',
    category: 'Network',
    tags: ['bandwidth', 'network', 'speed', 'usage', 'traffic', 'monitor'],
    description: 'Per-process network tracking and bandwidth usage reporting',
    requirements: ['psutil'],
    script: `import psutil, time
from collections import defaultdict

INTERVAL = 2  # seconds between samples
DURATION = 10  # total monitoring seconds

print(f"Monitoring bandwidth for {DURATION}s...\\n")

prev_net = psutil.net_io_counters()
prev_per = psutil.net_io_counters(pernic=True)

def fmt_speed(bps):
    if bps > 1024**2: return f"{bps/1024**2:.1f} MB/s"
    if bps > 1024:    return f"{bps/1024:.1f} KB/s"
    return f"{bps:.0f} B/s"

for step in range(DURATION // INTERVAL):
    time.sleep(INTERVAL)

    cur  = psutil.net_io_counters()
    sent = (cur.bytes_sent - prev_net.bytes_sent) / INTERVAL
    recv = (cur.bytes_recv - prev_net.bytes_recv) / INTERVAL

    print(f"[{step*INTERVAL:3d}s] ↑{fmt_speed(sent):12} ↓{fmt_speed(recv):12} "
          f"| Total: ↑{cur.bytes_sent/1024**2:.0f}MB ↓{cur.bytes_recv/1024**2:.0f}MB")

    prev_net = cur

# Per-interface summary
print("\\n=== PER INTERFACE ===")
stats = psutil.net_io_counters(pernic=True)
for nic, s in stats.items():
    if s.bytes_sent + s.bytes_recv > 0:
        print(f"  {nic:20} ↑{s.bytes_sent/1024**2:.1f}MB  ↓{s.bytes_recv/1024**2:.1f}MB")`,
  },
  {
    id: 'network-scanner',
    title: 'Local Network Scanner',
    category: 'Network',
    tags: ['network', 'scan', 'ip', 'hosts', 'port', 'ping', 'devices'],
    description: 'Scan local network to find all connected devices and open ports',
    requirements: [],
    script: `import socket, threading, subprocess, sys
from ipaddress import ip_network

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close()
    return ip

def ping_host(ip, results):
    try:
        flag = "-n" if sys.platform == "win32" else "-c"
        r = subprocess.run(["ping", flag, "1", "-W", "500", str(ip)],
                           capture_output=True, timeout=2)
        if r.returncode == 0:
            try: host = socket.gethostbyaddr(str(ip))[0]
            except: host = "unknown"
            results.append({'ip': str(ip), 'host': host})
    except: pass

local_ip = get_local_ip()
network  = '.'.join(local_ip.split('.')[:3]) + '.0/24'
print(f"Scanning {network} (your IP: {local_ip})...")

results = []; threads = []
for ip in ip_network(network, strict=False).hosts():
    t = threading.Thread(target=ping_host, args=(ip, results))
    threads.append(t); t.start()
for t in threads: t.join(timeout=3)

print(f"\\nFound {len(results)} devices:")
for device in sorted(results, key=lambda x: [int(i) for i in x['ip'].split('.')]):
    print(f"  {device['ip']:15} {device['host'][:40]}")`,
  },
  {
    id: 'uptime-watchdog',
    title: 'Uptime Watchdog',
    category: 'Network',
    tags: ['uptime', 'monitor', 'ping', 'alert', 'downtime', 'watchdog'],
    description: 'Monitor service uptime and send alerts on downtime',
    requirements: ['requests'],
    script: `import requests, time, smtplib
from datetime import datetime

SERVICES = [
    {'name': 'Google',     'url': 'https://www.google.com'},
    {'name': 'My Server',  'url': 'http://192.168.1.100:8765/api/status'},
    {'name': 'GitHub',     'url': 'https://github.com'},
]

CHECK_INTERVAL = 60   # seconds
TIMEOUT        = 10
LOG_FILE       = "uptime.log"

def check_service(service):
    try:
        r = requests.get(service['url'], timeout=TIMEOUT)
        return r.status_code < 400, r.elapsed.total_seconds() * 1000
    except:
        return False, 0

def log(msg):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, 'a') as f: f.write(line + "\\n")

status = {s['name']: True for s in SERVICES}
log(f"Watchdog started - monitoring {len(SERVICES)} services")

try:
    while True:
        for svc in SERVICES:
            ok, ms = check_service(svc)
            if ok and not status[svc['name']]:
                log(f"✓ BACK UP: {svc['name']} ({ms:.0f}ms)")
            elif not ok and status[svc['name']]:
                log(f"✗ DOWN: {svc['name']}")
            elif ok:
                log(f"  {svc['name']}: {ms:.0f}ms")
            status[svc['name']] = ok
        time.sleep(CHECK_INTERVAL)
except KeyboardInterrupt:
    log("Watchdog stopped.")`,
  },
  {
    id: 'speed-test',
    title: 'Internet Speed Test Logger',
    category: 'Network',
    tags: ['speed', 'bandwidth', 'test', 'internet', 'mbps', 'log'],
    description: 'Scheduled speed tests with historical logging',
    requirements: ['speedtest-cli'],
    script: `import subprocess, json, csv, sys
from datetime import datetime
from pathlib import Path

LOG_FILE = Path("speed_log.csv")

def run_speedtest():
    try:
        r = subprocess.run(
            [sys.executable, "-m", "speedtest", "--json"],
            capture_output=True, text=True, timeout=60
        )
        data = json.loads(r.stdout)
        return {
            'download': data['download'] / 1e6,  # Mbps
            'upload':   data['upload'] / 1e6,
            'ping':     data['ping'],
            'server':   data['server']['sponsor'],
        }
    except Exception as e:
        print(f"Error: {e} — pip install speedtest-cli")
        return None

ts = datetime.now()
print(f"Speed test at {ts.strftime('%H:%M:%S')}...")
result = run_speedtest()

if result:
    print(f"  Download: {result['download']:.1f} Mbps")
    print(f"  Upload:   {result['upload']:.1f} Mbps")
    print(f"  Ping:     {result['ping']:.0f}ms")
    print(f"  Server:   {result['server']}")

    # Log to CSV
    headers = ['timestamp','download_mbps','upload_mbps','ping_ms','server']
    write_header = not LOG_FILE.exists()
    with open(LOG_FILE, 'a', newline='') as f:
        w = csv.DictWriter(f, fieldnames=headers)
        if write_header: w.writeheader()
        w.writerow({
            'timestamp': ts.isoformat(),
            'download_mbps': round(result['download'], 2),
            'upload_mbps': round(result['upload'], 2),
            'ping_ms': round(result['ping'], 1),
            'server': result['server'],
        })
    print(f"  Logged to {LOG_FILE}")`,
  },

  // ── WEB AUTOMATION ───────────────────────────────────────────
  {
    id: 'web-scraper',
    title: 'Web Scraper with BeautifulSoup',
    category: 'Web',
    tags: ['scrape', 'web', 'html', 'parse', 'data', 'extract', 'crawl'],
    description: 'Scrape data from any website using requests and BeautifulSoup',
    requirements: ['requests', 'beautifulsoup4'],
    script: `import requests
from bs4 import BeautifulSoup
import csv

URL = "https://news.ycombinator.com"

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
res  = requests.get(URL, headers=headers, timeout=10)
soup = BeautifulSoup(res.text, 'html.parser')

results = []
for item in soup.select('.titleline')[:20]:
    link = item.find('a')
    if link:
        results.append({'title': link.text, 'url': link.get('href','')})

for r in results:
    print(f"• {r['title'][:60]}")

with open('scraped.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=['title','url'])
    w.writeheader(); w.writerows(results)
print(f"Saved {len(results)} items")`,
  },
  {
    id: 'web-monitor',
    title: 'Web Scrape Monitor',
    category: 'Web',
    tags: ['monitor', 'website', 'change', 'diff', 'alert', 'scrape'],
    description: 'Track website changes and send diff alerts',
    requirements: ['requests', 'beautifulsoup4'],
    script: `import requests, hashlib, time, json
from bs4 import BeautifulSoup
from pathlib import Path
from datetime import datetime

MONITOR = [
    {'name': 'HN',  'url': 'https://news.ycombinator.com', 'selector': '.titleline'},
    {'name': 'Site','url': 'https://example.com',           'selector': 'body'},
]

CACHE_FILE = Path("monitor_cache.json")
cache = json.loads(CACHE_FILE.read_text()) if CACHE_FILE.exists() else {}

def get_content(url, selector):
    try:
        r = requests.get(url, timeout=10,
                         headers={'User-Agent': 'Mozilla/5.0'})
        soup = BeautifulSoup(r.text, 'html.parser')
        el = soup.select_one(selector)
        return el.get_text(strip=True)[:5000] if el else ''
    except: return ''

print(f"Monitoring {len(MONITOR)} pages...")

for site in MONITOR:
    content = get_content(site['url'], site['selector'])
    h = hashlib.md5(content.encode()).hexdigest()
    prev = cache.get(site['name'], {}).get('hash', '')

    if prev and prev != h:
        print(f"CHANGED: {site['name']} at {datetime.now().strftime('%H:%M:%S')}")
        print(f"  URL: {site['url']}")
    elif not prev:
        print(f"Baseline set: {site['name']}")
    else:
        print(f"No change: {site['name']}")

    cache[site['name']] = {'hash': h, 'ts': datetime.now().isoformat()}

CACHE_FILE.write_text(json.dumps(cache, indent=2))`,
  },

  // ── DATA PROCESSING ───────────────────────────────────────────
  {
    id: 'csv-processor',
    title: 'CSV Data Processor',
    category: 'Data',
    tags: ['csv', 'data', 'process', 'filter', 'transform', 'pandas'],
    description: 'Read, filter, transform, and export CSV data',
    requirements: ['pandas'],
    script: `import pandas as pd

INPUT  = "data.csv"
OUTPUT = "output.csv"

df = pd.read_csv(INPUT)
print(f"Loaded {len(df)} rows x {len(df.columns)} cols")
print(df.head())
print("\\n=== STATS ===")
print(df.describe())

# Filter (uncomment):
# df = df[df['column'] > 100]
# df = df.dropna()

# Transform (uncomment):
# df['total'] = df['price'] * df['qty']

df.to_csv(OUTPUT, index=False)
print(f"\\nSaved {len(df)} rows to {OUTPUT}")`,
  },
  {
    id: 'excel-automation',
    title: 'Excel Automation Report',
    category: 'Data',
    tags: ['excel', 'xlsx', 'spreadsheet', 'data', 'report', 'openpyxl'],
    description: 'Create and automate Excel reports with styling',
    requirements: ['openpyxl'],
    script: `import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from datetime import datetime

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Report"

headers = ["Date", "Category", "Amount", "Status"]
HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(bold=True, color="FFFFFF")

for col, h in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col, value=h)
    cell.font  = HEADER_FONT
    cell.fill  = HEADER_FILL
    cell.alignment = Alignment(horizontal='center')

data = [
    [datetime.today(), "Sales",     1500.50, "Done"],
    [datetime.today(), "Marketing", 800.00,  "Pending"],
    [datetime.today(), "IT",        2200.75, "Done"],
]
for row in data:
    ws.append(row)

for col in ws.columns:
    max_len = max(len(str(cell.value or '')) for cell in col)
    ws.column_dimensions[col[0].column_letter].width = max_len + 4

filename = f"report_{datetime.now().strftime('%Y%m%d')}.xlsx"
wb.save(filename)
print(f"Saved: {filename}")`,
  },
  {
    id: 'pdf-toolkit',
    title: 'PDF Toolkit',
    category: 'Data',
    tags: ['pdf', 'merge', 'split', 'compress', 'ocr', 'convert'],
    description: 'Merge, split, compress PDFs and extract text',
    requirements: ['PyPDF2'],
    script: `from pathlib import Path
import PyPDF2

def merge_pdfs(input_files, output):
    merger = PyPDF2.PdfMerger()
    for f in input_files:
        merger.append(str(f))
    with open(output, 'wb') as out:
        merger.write(out)
    print(f"Merged {len(input_files)} PDFs -> {output}")

def split_pdf(input_file, pages_per_chunk=5):
    reader = PyPDF2.PdfReader(str(input_file))
    total  = len(reader.pages)
    stem   = Path(input_file).stem
    for start in range(0, total, pages_per_chunk):
        writer = PyPDF2.PdfWriter()
        end    = min(start + pages_per_chunk, total)
        for i in range(start, end):
            writer.add_page(reader.pages[i])
        out = f"{stem}_pages_{start+1}-{end}.pdf"
        with open(out, 'wb') as f:
            writer.write(f)
        print(f"  Split: {out} ({end-start} pages)")

def extract_text(pdf_path):
    reader = PyPDF2.PdfReader(str(pdf_path))
    text   = ""
    for i, page in enumerate(reader.pages):
        text += f"\\n--- PAGE {i+1} ---\\n"
        text += page.extract_text() or ""
    out = Path(pdf_path).with_suffix('.txt')
    out.write_text(text, encoding='utf-8')
    print(f"Extracted {len(text)} chars to {out}")

# Example usage:
# merge_pdfs(['doc1.pdf', 'doc2.pdf'], 'merged.pdf')
# split_pdf('large.pdf', pages_per_chunk=10)
# extract_text('document.pdf')

print("PDF Toolkit ready. Uncomment the function you need.")`,
  },

  // ── EMAIL ─────────────────────────────────────────────────────
  {
    id: 'email-sender',
    title: 'Send Automated Emails',
    category: 'Email',
    tags: ['email', 'smtp', 'gmail', 'send', 'notification', 'alert'],
    description: 'Send automated emails via Gmail SMTP with attachment support',
    requirements: [],
    script: `import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path

SENDER    = "your.email@gmail.com"
PASSWORD  = "your_app_password"  # Gmail App Password
RECIPIENT = "recipient@email.com"

def send_email(subject, body, attachment=None):
    msg = MIMEMultipart()
    msg['From']    = SENDER
    msg['To']      = RECIPIENT
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'html'))

    if attachment:
        from email.mime.base import MIMEBase
        from email import encoders
        path = Path(attachment)
        with open(path, 'rb') as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename={path.name}')
        msg.attach(part)

    ctx = ssl.create_default_context()
    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls(context=ctx)
        server.login(SENDER, PASSWORD)
        server.sendmail(SENDER, RECIPIENT, msg.as_string())
    print(f"Email sent to {RECIPIENT}")

send_email(
    subject="Butler AI Report",
    body="<h2>Automated Report</h2><p>Sent by Butler AI.</p>",
)`,
  },

  // ── GUI AUTOMATION ────────────────────────────────────────────
  {
    id: 'pyautogui-automation',
    title: 'GUI Automation (PyAutoGUI)',
    category: 'GUI',
    tags: ['gui', 'mouse', 'keyboard', 'click', 'automate', 'macro'],
    description: 'Automate mouse clicks, keyboard typing, and screen interactions',
    requirements: ['pyautogui', 'Pillow'],
    script: `import pyautogui, time
pyautogui.PAUSE    = 0.5
pyautogui.FAILSAFE = True  # Move mouse to top-left corner to abort

# Screen info
width, height = pyautogui.size()
x, y = pyautogui.position()
print(f"Screen: {width}x{height} | Mouse: {x},{y}")

# Screenshot
screen = pyautogui.screenshot()
screen.save("screen.png")
print("Screenshot saved")

# ── Mouse ──────────────────────────────────────────────────────
# pyautogui.moveTo(500, 300, duration=0.5)
# pyautogui.click(500, 300)
# pyautogui.doubleClick(x, y)
# pyautogui.rightClick(x, y)
# pyautogui.drag(0, 0, 200, 200, duration=0.5)

# ── Keyboard ───────────────────────────────────────────────────
# pyautogui.typewrite("Hello World!", interval=0.05)
# pyautogui.hotkey('ctrl', 'c')
# pyautogui.hotkey('alt', 'tab')
# pyautogui.press('enter')

# ── Example: Open Notepad and type ────────────────────────────
print("Move mouse to top-left to abort! Starting in 3s...")
time.sleep(3)
pyautogui.hotkey('win', 'r')
time.sleep(1)
pyautogui.typewrite('notepad', interval=0.05)
pyautogui.press('enter')
time.sleep(2)
pyautogui.typewrite('Hello from Butler AI!', interval=0.05)`,
  },
  {
    id: 'desktop-notifier',
    title: 'Desktop Notifier',
    category: 'GUI',
    tags: ['notification', 'alert', 'desktop', 'toast', 'popup', 'notify'],
    description: 'Cross-platform desktop toast alerts for any event',
    requirements: ['plyer'],
    script: `from plyer import notification
import time

def notify(title, message, timeout=5, app_icon=None):
    notification.notify(
        title=title,
        message=message,
        app_name="Butler AI",
        timeout=timeout,
        app_icon=app_icon,
    )
    print(f"Notified: {title} - {message}")

# Single notification
notify("Butler AI", "Your script completed successfully!")

# Scheduled notifications example
REMINDERS = [
    (0, "Take a break", "You've been working for 1 hour!"),
    (5, "Drink water",  "Stay hydrated!"),
    (10, "Stand up",   "Stretch your legs!"),
]

print("Starting reminder system (Ctrl+C to stop)...")
for delay, title, msg in REMINDERS:
    time.sleep(delay)
    notify(title, msg)`,
  },

  // ── SCHEDULING ────────────────────────────────────────────────
  {
    id: 'task-scheduler',
    title: 'Task Scheduler (APScheduler)',
    category: 'Scheduling',
    tags: ['schedule', 'cron', 'timer', 'repeat', 'daily', 'automated'],
    description: 'Run tasks on a schedule — daily, hourly, or at specific times',
    requirements: ['apscheduler'],
    script: `from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime

scheduler = BlockingScheduler()

def daily_backup():
    print(f"[{datetime.now()}] Running daily backup...")

def hourly_check():
    print(f"[{datetime.now()}] Hourly status check...")

scheduler.add_job(daily_backup, CronTrigger(hour=2, minute=30))
scheduler.add_job(hourly_check, 'interval', hours=1)

print("Scheduler started. Ctrl+C to stop.")
try:
    scheduler.start()
except KeyboardInterrupt:
    print("Stopped.")`,
  },

  // ── MONITORING ────────────────────────────────────────────────
  {
    id: 'cpu-monitor',
    title: 'CPU/RAM Alert Monitor',
    category: 'Monitoring',
    tags: ['monitor', 'cpu', 'ram', 'alert', 'threshold', 'performance'],
    description: 'Monitor CPU and RAM usage, send alerts when limits exceeded',
    requirements: ['psutil'],
    script: `import psutil, time
from datetime import datetime

CPU_THRESHOLD = 80
RAM_THRESHOLD = 85
CHECK_INTERVAL = 5
LOG_FILE = "system_monitor.log"

def log(msg):
    ts = datetime.now().strftime('%H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, 'a') as f: f.write(line + "\\n")

log("Monitor started")

try:
    while True:
        cpu = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')

        if cpu > CPU_THRESHOLD:
            top = sorted(psutil.process_iter(['name','cpu_percent']),
                        key=lambda p: p.info['cpu_percent'] or 0, reverse=True)[:3]
            log(f"CPU ALERT {cpu}%! Top: {[p.info['name'] for p in top]}")
        elif mem.percent > RAM_THRESHOLD:
            log(f"RAM ALERT {mem.percent}%!")
        else:
            print(f"\\rCPU:{cpu:5.1f}% RAM:{mem.percent:5.1f}% Disk:{disk.percent:5.1f}%",
                  end='', flush=True)

        time.sleep(CHECK_INTERVAL)
except KeyboardInterrupt:
    log("Monitor stopped.")`,
  },
  {
    id: 'folder-watcher',
    title: 'Folder Watcher (Auto-process Files)',
    category: 'Monitoring',
    tags: ['watch', 'folder', 'monitor', 'watchdog', 'trigger', 'auto'],
    description: 'Watch a folder for new files and automatically process them',
    requirements: ['watchdog'],
    script: `from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import time, shutil
from pathlib import Path
from datetime import datetime

WATCH_FOLDER   = Path.home() / "Downloads"
PROCESS_FOLDER = Path("processed")
PROCESS_FOLDER.mkdir(exist_ok=True)

class Handler(FileSystemEventHandler):
    def on_created(self, event):
        if event.is_directory: return
        path = Path(event.src_path)
        time.sleep(0.5)
        ts = datetime.now().strftime('%H:%M:%S')
        print(f"[{ts}] New file: {path.name} ({path.stat().st_size//1024}KB)")
        if path.suffix.lower() == '.pdf':
            shutil.copy2(path, PROCESS_FOLDER / path.name)
            print(f"  Copied PDF")

observer = Observer()
observer.schedule(Handler(), str(WATCH_FOLDER), recursive=False)
observer.start()
print(f"Watching: {WATCH_FOLDER}  (Ctrl+C to stop)")
try:
    while True: time.sleep(1)
except KeyboardInterrupt:
    observer.stop()
observer.join()`,
  },

  // ── SETUP & INSTALL ───────────────────────────────────────────
  {
    id: 'dev-environment-setup',
    title: 'Developer Environment Setup',
    category: 'Setup',
    tags: ['dev', 'environment', 'setup', 'git', 'python', 'venv', 'install'],
    description: 'Automate complete development environment setup',
    requirements: [],
    script: `import subprocess, sys, os
from pathlib import Path

PROJECT  = Path("my_project")
PACKAGES = ["requests", "flask", "python-dotenv", "black", "pytest"]

print("=== DEV ENVIRONMENT SETUP ===")

for d in ["src", "tests", "docs"]:
    (PROJECT / d).mkdir(parents=True, exist_ok=True)
print("✓ Project structure created")

os.chdir(PROJECT)
subprocess.run(["git", "init"], capture_output=True)
print("✓ Git initialized")

subprocess.run([sys.executable, "-m", "venv", ".venv"])
print("✓ Virtual environment created")

pip = ".venv/Scripts/pip" if sys.platform == "win32" else ".venv/bin/pip"
for pkg in PACKAGES:
    subprocess.run([pip, "install", pkg, "-q"])
    print(f"  ✓ {pkg}")

(PROJECT / ".env").write_text("DEBUG=True\\nAPI_KEY=your_key_here\\n")
(PROJECT / ".gitignore").write_text(".venv\\n__pycache__\\n.env\\n*.pyc\\n")
(PROJECT / "README.md").write_text(f"# {PROJECT.name}\\n")
print(f"\\n✓ Project ready in {PROJECT.absolute()}")`,
  },
  {
    id: 'software-installer',
    title: 'Automated Software Installer',
    category: 'Setup',
    tags: ['install', 'setup', 'software', 'windows', 'winget', 'automate'],
    description: 'Automate installation of apps on Windows using winget',
    requirements: [],
    script: `import subprocess, sys

if sys.platform != 'win32':
    print("Windows only"); exit()

APPS = [
    "Google.Chrome",
    "Mozilla.Firefox",
    "7zip.7zip",
    "Microsoft.VisualStudioCode",
    "Python.Python.3.12",
    "Git.Git",
    "VideoLAN.VLC",
    "Notepad++.Notepad++",
]

PY_PACKAGES = ["requests", "pandas", "pillow", "psutil", "pyautogui"]

print("=== AUTOMATED SOFTWARE INSTALLER ===")
for app in APPS:
    print(f"Installing {app}...")
    r = subprocess.run(
        ["winget", "install", "--id", app, "-e", "--silent",
         "--accept-source-agreements", "--accept-package-agreements"],
        capture_output=True, text=True
    )
    status = "✓" if r.returncode == 0 else "✗"
    print(f"  {status} {app}")

print("\\nInstalling Python packages...")
for pkg in PY_PACKAGES:
    subprocess.run([sys.executable, "-m", "pip", "install", pkg, "-q"])
    print(f"  ✓ pip install {pkg}")

print("\\nAll software installed!")`,
  },

  // ── TEXT PROCESSING ───────────────────────────────────────────
  {
    id: 'text-processor',
    title: 'Document Text Extractor',
    category: 'Text',
    tags: ['text', 'document', 'pdf', 'word', 'extract', 'parse'],
    description: 'Extract and analyze text from PDFs, Word docs, and text files',
    requirements: ['PyPDF2', 'python-docx'],
    script: `from pathlib import Path
from collections import Counter
import re

def pdf_to_text(pdf_path):
    try:
        import PyPDF2
        with open(pdf_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            text   = "\\n".join(page.extract_text() for page in reader.pages)
        print(f"PDF: {len(reader.pages)} pages, {len(text)} chars")
        return text
    except ImportError:
        return "pip install PyPDF2"

def docx_to_text(docx_path):
    try:
        from docx import Document
        doc  = Document(docx_path)
        text = "\\n".join(p.text for p in doc.paragraphs)
        print(f"DOCX: {len(doc.paragraphs)} paragraphs, {len(text)} chars")
        return text
    except ImportError:
        return "pip install python-docx"

def word_frequency(text, top_n=20):
    words  = re.findall(r'\\b[a-zA-Z]{4,}\\b', text.lower())
    stops  = {'that','this','with','have','from','they','been','will'}
    words  = [w for w in words if w not in stops]
    return Counter(words).most_common(top_n)

# Example
text = "Python is a great automation language. Python scripts are powerful and flexible."
freq = word_frequency(text)
print("Top words:", freq[:10])`,
  },
];

// PYTHON_AUTOMATION_SCRIPTS — built eagerly via IIFE with try/catch.
// Uses require() (not static import) inside the IIFE to defer the
// scriptLibraryExtensions load until after all modules are registered,
// preventing Hermes init-ordering crashes. No Proxy needed.
export const PYTHON_AUTOMATION_SCRIPTS: AutomationScript[] = (() => {
  try {
    const extended = _loadExtended();
    const base = Array.isArray(BASE_SCRIPTS) ? BASE_SCRIPTS : [];
    const ext  = Array.isArray(extended)    ? extended    : [];
    const result: AutomationScript[] = [];
    for (let i = 0; i < base.length; i++) result.push(base[i]);
    for (let i = 0; i < ext.length;  i++) result.push(ext[i]);
    return result;
  } catch {
    return Array.isArray(BASE_SCRIPTS) ? BASE_SCRIPTS.slice() : [];
  }
})();

// ── Script search ─────────────────────────────────────────────────
export function findScripts(query: string): AutomationScript[] {
  const q = query.toLowerCase();
  const words = q.split(/\s+/).filter(w => w.length > 2);
  return PYTHON_AUTOMATION_SCRIPTS
    .map(script => {
      let score = 0;
      for (const word of words) {
        if (script.tags.some(t => t.includes(word))) score += 10;
        if (script.title.toLowerCase().includes(word)) score += 8;
        if (script.category.toLowerCase().includes(word)) score += 6;
        if (script.description.toLowerCase().includes(word)) score += 4;
      }
      return { script, score };
    })
    .filter(x => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .map(x => x.script)
    .slice(0, 5);
}

export function buildScriptFinderPrompt(userRequest: string, foundScripts: AutomationScript[]): string {
  const ctx = foundScripts.length > 0
    ? `\n\nRELATED SCRIPTS:\n${foundScripts.map(s =>
        `### ${s.title}\nCategory: ${s.category}\nRequirements: ${s.requirements.join(', ') || 'none'}\n\`\`\`python\n${s.script.slice(0, 300)}...\n\`\`\`\n`
      ).join('\n')}`
    : '';
  return `USER REQUEST: "${userRequest}"\n${ctx}\n\nGenerate a complete, working Python script. Include imports, comments, error handling. Show pip install for any packages.`;
}

```


### `/src/data/scriptLibraryExtensions.ts`

```ts path=/src/data/scriptLibraryExtensions.ts
/**
 * 🐍 Script Library Extensions — 130+ Unique Scripts
 * Adds new categories: Backup, Security, Cleaning, Performance, Privacy
 * Plus fills gaps in Files, System, Network, Web, Data, Email, GUI, Setup, Text
 */

import type { AutomationScript } from './scriptTypes';

export const EXTENDED_SCRIPTS: AutomationScript[] = [

  // ── CONNECTION TEST ──────────────────────────────────────────
  {
    id: 'butler-connection-test',
    title: 'Butler Connection Test',
    category: 'System',
    tags: ['test', 'connection', 'ping', 'verify', 'butler', 'health'],
    description: 'Verify the full execution pipeline works — platform info, Python version, and server round-trip',
    requirements: [],
    script: `import platform, sys, socket, os, time
from datetime import datetime

start = time.perf_counter()
print("=== BUTLER AI — CONNECTION TEST ===")
print(f"Timestamp:  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print(f"Hostname:   {socket.gethostname()}")
print(f"OS:         {platform.system()} {platform.release()} ({platform.machine()})")
print(f"Python:     {sys.version.split()[0]}")
print(f"User:       {os.environ.get('USERNAME') or os.environ.get('USER','unknown')}")
print(f"Working dir:{os.getcwd()}")
print()
print("Script execution pipeline: OK")
print("Server relay:              OK")
print("Output streaming:          OK")
elapsed = (time.perf_counter() - start) * 1000
print(f"\nTotal round-trip time: {elapsed:.0f}ms")
print("=== ALL SYSTEMS OPERATIONAL ===")`,
  },

  // ── FILES ─────────────────────────────────────────────────────
  {
    id: 'file-size-report',
    title: 'File Size Report Generator',
    category: 'Files',
    tags: ['file', 'size', 'report', 'large', 'sort', 'analyze'],
    description: 'Scan a folder and generate a sorted report of the largest files',
    requirements: [],
    script: `from pathlib import Path

SCAN_DIR = Path.home()
TOP_N    = 30

def fmt(size):
    for unit in ['B','KB','MB','GB']:
        if size < 1024: return f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}TB"

print(f"Scanning {SCAN_DIR} for largest files...")
files = []
for f in SCAN_DIR.rglob('*'):
    try:
        if f.is_file():
            files.append((f, f.stat().st_size))
    except: pass

files.sort(key=lambda x: x[1], reverse=True)
print(f"\nTop {TOP_N} largest files:")
for i, (path, size) in enumerate(files[:TOP_N], 1):
    try:
        rel = path.relative_to(SCAN_DIR)
    except:
        rel = path
    print(f"  {i:2}. {fmt(size):10} {rel}")

total = sum(s for _, s in files)
print(f"\nTotal scanned: {len(files)} files = {fmt(total)}")`,
  },
  {
    id: 'file-splitter',
    title: 'Large File Splitter and Joiner',
    category: 'Files',
    tags: ['split', 'join', 'chunk', 'large', 'files', 'transfer'],
    description: 'Split large files into chunks for transfer, then rejoin them',
    requirements: [],
    script: `from pathlib import Path

def split_file(file_path, chunk_mb=100):
    path = Path(file_path)
    if not path.exists():
        print(f"File not found: {file_path}"); return []
    chunk_bytes = chunk_mb * 1024 * 1024
    total_size  = path.stat().st_size
    chunks = []
    with open(path, 'rb') as f:
        part = 0
        while True:
            data = f.read(chunk_bytes)
            if not data: break
            part_path = path.parent / f"{path.name}.part{part:04d}"
            part_path.write_bytes(data)
            chunks.append(part_path)
            pct = (f.tell() / total_size) * 100
            print(f"  Written: {part_path.name} ({len(data)//1024//1024}MB) {pct:.0f}%")
            part += 1
    print(f"Split into {len(chunks)} chunks")
    return chunks

def join_file(output_path):
    out = Path(output_path)
    parts = sorted(out.parent.glob(f"{out.name}.part*"))
    print(f"Joining {len(parts)} parts -> {out}")
    with open(out, 'wb') as f_out:
        for part in parts:
            f_out.write(part.read_bytes())
            print(f"  Joined: {part.name}")
    print(f"Done: {out.stat().st_size // 1024 // 1024}MB")

# split_file("bigfile.zip", chunk_mb=50)
# join_file("bigfile.zip")
print("File splitter/joiner ready. Uncomment usage examples.")`,
  },
  {
    id: 'file-encrypt-aes',
    title: 'File Encryptor AES-256',
    category: 'Files',
    tags: ['encrypt', 'decrypt', 'aes', 'security', 'password', 'cipher'],
    description: 'Encrypt and decrypt files with AES-256 password protection',
    requirements: ['cryptography'],
    script: `from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
import os
from pathlib import Path

def derive_key(password, salt):
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=480000)
    return kdf.derive(password.encode())

def encrypt_file(input_path, password, output_path=None):
    path = Path(input_path)
    data = path.read_bytes()
    salt = os.urandom(16)
    nonce = os.urandom(12)
    ct   = AESGCM(derive_key(password, salt)).encrypt(nonce, data, None)
    out  = Path(output_path or str(path) + '.enc')
    out.write_bytes(salt + nonce + ct)
    print(f"Encrypted: {out} ({out.stat().st_size} bytes)")
    return out

def decrypt_file(input_path, password, output_path=None):
    path = Path(input_path)
    raw  = path.read_bytes()
    salt, nonce, ct = raw[:16], raw[16:28], raw[28:]
    data = AESGCM(derive_key(password, salt)).decrypt(nonce, ct, None)
    out  = Path(output_path or str(path).replace('.enc',''))
    out.write_bytes(data)
    print(f"Decrypted: {out} ({out.stat().st_size} bytes)")
    return out

PASSWORD = "my_secret_password"
# encrypt_file("secret.txt", PASSWORD)
# decrypt_file("secret.txt.enc", PASSWORD)
print("AES-256 encryptor ready. Uncomment usage examples.")`,
  },
  {
    id: 'image-compressor',
    title: 'Batch Image Compressor',
    category: 'Files',
    tags: ['image', 'compress', 'resize', 'optimize', 'webp', 'batch'],
    description: 'Compress and convert images to WebP/JPEG with size reduction',
    requirements: ['Pillow'],
    script: `from PIL import Image
from pathlib import Path

SOURCE_DIR    = Path(".")
OUTPUT_DIR    = Path("compressed")
TARGET_FORMAT = "WEBP"
QUALITY       = 85
MAX_WIDTH     = 1920
MAX_HEIGHT    = 1080

OUTPUT_DIR.mkdir(exist_ok=True)
total_saved = 0
count = 0

for img_path in SOURCE_DIR.glob("**/*"):
    if img_path.suffix.lower() not in ['.jpg','.jpeg','.png','.bmp']: continue
    if 'compressed' in str(img_path): continue
    try:
        img = Image.open(img_path)
        if img.mode in ('RGBA','LA','P'): img = img.convert('RGB')
        if img.width > MAX_WIDTH or img.height > MAX_HEIGHT:
            img.thumbnail((MAX_WIDTH, MAX_HEIGHT), Image.LANCZOS)
        ext  = '.webp' if TARGET_FORMAT == 'WEBP' else '.jpg'
        out  = OUTPUT_DIR / (img_path.stem + ext)
        img.save(out, TARGET_FORMAT, quality=QUALITY, optimize=True)
        orig = img_path.stat().st_size
        new  = out.stat().st_size
        total_saved += orig - new
        ratio = (1 - new/orig) * 100
        print(f"  {img_path.name:35} {orig//1024:5}KB -> {new//1024:5}KB ({ratio:.0f}%)")
        count += 1
    except Exception as e:
        print(f"  Error: {img_path.name}: {e}")

print(f"\nProcessed {count} images | Saved: {total_saved/1024/1024:.1f}MB")`,
  },
  {
    id: 'file-watcher-auto',
    title: 'Auto File Watcher and Mover',
    category: 'Files',
    tags: ['watch', 'auto', 'move', 'trigger', 'folder', 'monitor', 'rules'],
    description: 'Watch a folder and automatically move files based on extension rules',
    requirements: [],
    script: `import time, shutil
from pathlib import Path
from datetime import datetime

WATCH_DIR = Path.home() / "Downloads"
RULES = {
    '.pdf':  Path.home() / "Documents" / "PDFs",
    '.docx': Path.home() / "Documents" / "Word",
    '.xlsx': Path.home() / "Documents" / "Excel",
    '.jpg':  Path.home() / "Pictures"  / "Auto",
    '.jpeg': Path.home() / "Pictures"  / "Auto",
    '.png':  Path.home() / "Pictures"  / "Auto",
    '.mp4':  Path.home() / "Videos"    / "Auto",
    '.mp3':  Path.home() / "Music"     / "Auto",
    '.zip':  Path.home() / "Downloads" / "Archives",
}

for dest in RULES.values():
    dest.mkdir(parents=True, exist_ok=True)

def process(f):
    dest = RULES.get(f.suffix.lower())
    if not dest: return False
    target = dest / f.name
    if target.exists():
        target = dest / f"{f.stem}_{int(time.time())}{f.suffix}"
    shutil.move(str(f), target)
    ts = datetime.now().strftime('%H:%M:%S')
    print(f"[{ts}] Moved: {f.name} -> {dest.name}/")
    return True

seen = set(f.name for f in WATCH_DIR.iterdir() if f.is_file())
moved = 0
for f in WATCH_DIR.iterdir():
    if f.is_file() and process(f): moved += 1
print(f"Initial pass: moved {moved} files")

print(f"\nWatching {WATCH_DIR} (Ctrl+C to stop)...")
try:
    while True:
        for f in WATCH_DIR.iterdir():
            if f.is_file() and f.name not in seen:
                time.sleep(0.5)
                if process(f): seen.add(f.name)
        time.sleep(2)
except KeyboardInterrupt:
    print("\nStopped.")`,
  },

  // ── SYSTEM ────────────────────────────────────────────────────
  {
    id: 'env-variable-manager',
    title: 'Environment Variable Manager',
    category: 'System',
    tags: ['env', 'environment', 'variables', 'path', 'system', 'config'],
    description: 'List, set, and manage system environment variables persistently',
    requirements: [],
    script: `import os, sys, subprocess

print("=== ENVIRONMENT VARIABLE MANAGER ===\n")
print(f"Total env vars: {len(os.environ)}")

IMPORTANT = ['PATH','HOME','USER','USERPROFILE','COMPUTERNAME',
             'PYTHONPATH','JAVA_HOME','NODE_PATH','GOPATH']
print("\n=== KEY VARIABLES ===")
for var in IMPORTANT:
    val = os.environ.get(var, '(not set)')
    print(f"  {var:20} = {val[:80]}")

print("\n=== PATH ENTRIES ===")
for i, p in enumerate(os.environ.get('PATH','').split(os.pathsep), 1):
    exists = "OK  " if os.path.exists(p) else "MISS"
    print(f"  {i:2} [{exists}] {p}")

def set_env_var(name, value):
    if sys.platform == 'win32':
        subprocess.run(f'setx {name} "{value}"', shell=True)
        print(f"Set permanently: {name}={value}")
    else:
        shell_rc = os.path.expanduser("~/.bashrc")
        with open(shell_rc, 'a') as f:
            f.write(f'\nexport {name}="{value}"')
        print(f"Added to ~/.bashrc: export {name}={value}")

# set_env_var("MY_API_KEY", "your_key_here")`,
  },
  {
    id: 'service-manager',
    title: 'System Service Manager',
    category: 'System',
    tags: ['service', 'daemon', 'systemctl', 'start', 'stop', 'manage'],
    description: 'Manage system services — start, stop, enable, disable, status',
    requirements: [],
    script: `import subprocess, sys

def run(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return r.stdout.strip() or r.stderr.strip()

if sys.platform == 'win32':
    print("=== WINDOWS SERVICE MANAGER ===")
    print("\nRunning services (first 15):")
    r = subprocess.run("sc queryex type=all state=running",
                       shell=True, capture_output=True, text=True)
    lines = [l for l in r.stdout.split("\n") if "SERVICE_NAME" in l]
    for l in lines[:15]: print(f"  {l.strip()}")

    BLOAT = ['MapsBroker','XboxGipSvc','XblAuthManager','WpcMonSvc','DiagTrack']
    print("\n=== RECOMMENDED TO DISABLE ===")
    for svc in BLOAT:
        status = run(f'sc query {svc}')
        if 'RUNNING' in status:
            print(f"  {svc}: RUNNING (disable: sc config {svc} start= disabled)")
else:
    print("=== LINUX SERVICE MANAGER ===")
    print("\nFailed services:")
    print(run("systemctl --failed --no-pager"))
    print("\nEnabled services:")
    r = subprocess.run(
        ["systemctl","list-unit-files","--type=service","--state=enabled","--no-pager"],
        capture_output=True, text=True)
    print(r.stdout[:2000])`,
  },
  {
    id: 'memory-optimizer',
    title: 'Memory Optimizer and Analysis',
    category: 'System',
    tags: ['memory', 'ram', 'optimize', 'cache', 'flush', 'performance'],
    description: 'Free up RAM by flushing caches and identifying memory hogs',
    requirements: ['psutil'],
    script: `import psutil, subprocess, sys, gc

print("=== MEMORY OPTIMIZER ===")
mem = psutil.virtual_memory()
print(f"Before: {mem.used/1024**3:.1f}/{mem.total/1024**3:.1f}GB ({mem.percent}%)")

collected = gc.collect()
print(f"GC: collected {collected} objects")

if sys.platform != 'win32':
    subprocess.run("sync", shell=True)
    try:
        with open('/proc/sys/vm/drop_caches', 'w') as f:
            f.write('3')
        print("Dropped Linux page caches")
    except PermissionError:
        print("Need sudo: echo 3 | sudo tee /proc/sys/vm/drop_caches")

print("\n=== TOP MEMORY CONSUMERS ===")
procs = []
for p in psutil.process_iter(['pid','name','memory_info']):
    try:
        m = p.info['memory_info'].rss
        procs.append((m, p.info['name'], p.info['pid']))
    except: pass
for mem_bytes, name, pid in sorted(procs, reverse=True)[:10]:
    print(f"  {name:30} {mem_bytes/1024**2:8.0f}MB  PID:{pid}")

mem2 = psutil.virtual_memory()
print(f"\nAfter: {mem2.used/1024**3:.1f}/{mem2.total/1024**3:.1f}GB ({mem2.percent}%)")
print(f"Freed: {(mem.used-mem2.used)/1024**2:.0f}MB")`,
  },
  {
    id: 'clipboard-manager',
    title: 'Clipboard History Manager',
    category: 'System',
    tags: ['clipboard', 'history', 'copy', 'paste', 'monitor', 'save'],
    description: 'Monitor and log clipboard history with save and replay',
    requirements: ['pyperclip'],
    script: `import pyperclip, time, json, hashlib
from pathlib import Path
from datetime import datetime

HISTORY_FILE = Path("clipboard_history.json")
MAX_HISTORY  = 100
POLL_SEC     = 1.0

def load_history():
    if HISTORY_FILE.exists():
        return json.loads(HISTORY_FILE.read_text())
    return []

def save_history(history):
    HISTORY_FILE.write_text(json.dumps(history[-MAX_HISTORY:], indent=2))

def entry_hash(text):
    return hashlib.md5(text[:500].encode()).hexdigest()

history   = load_history()
prev_hash = entry_hash(pyperclip.paste()) if history else ""

print(f"Clipboard History Manager ({len(history)} entries saved)")
print("Press Ctrl+C to stop\n")

try:
    while True:
        try:
            content = pyperclip.paste()
            h = entry_hash(content)
            if h != prev_hash and content.strip():
                entry = {
                    'id':      len(history),
                    'ts':      datetime.now().isoformat(),
                    'size':    len(content),
                    'preview': content[:80].replace('\n','↵'),
                    'content': content[:5000],
                }
                history.append(entry)
                save_history(history)
                prev_hash = h
                print(f"[{entry['ts'][11:19]}] #{entry['id']} {entry['preview'][:60]}")
        except: pass
        time.sleep(POLL_SEC)
except KeyboardInterrupt:
    print(f"\nSaved {len(history)} entries to {HISTORY_FILE}")`,
  },
  {
    id: 'scheduled-task-creator',
    title: 'Windows Scheduled Task Creator',
    category: 'System',
    tags: ['task', 'schedule', 'windows', 'cron', 'automate', 'daily'],
    description: 'Create Windows scheduled tasks to run Python scripts automatically',
    requirements: [],
    script: `import subprocess, sys
from datetime import datetime

if sys.platform != 'win32':
    print("Windows only. Use cron on Linux/Mac."); exit()

def create_task(name, script_path, trigger_time="08:00"):
    task_xml = f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Triggers>
    <CalendarTrigger>
      <StartBoundary>{datetime.now().strftime('%Y-%m-%d')}T{trigger_time}:00</StartBoundary>
      <Enabled>true</Enabled>
      <ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay>
    </CalendarTrigger>
  </Triggers>
  <Actions Context="Author">
    <Exec>
      <Command>python</Command>
      <Arguments>"{script_path}"</Arguments>
    </Exec>
  </Actions>
</Task>"""
    xml_file = f"task_{name}.xml"
    with open(xml_file, 'w', encoding='utf-16') as f:
        f.write(task_xml)
    r = subprocess.run(
        ["schtasks", "/create", "/tn", name, "/xml", xml_file, "/f"],
        capture_output=True, text=True)
    print(f"Task '{name}': {'Created OK' if r.returncode==0 else r.stderr.strip()}")
    import os; os.remove(xml_file)

def list_tasks():
    r = subprocess.run(["schtasks", "/query", "/fo", "LIST"],
                       capture_output=True, text=True)
    for line in r.stdout.split("\n")[:40]:
        if "Task Name" in line or "Status" in line:
            print(f"  {line.strip()}")

# create_task("DailyBackup", r"C:\scripts\backup.py", "08:00")
print("=== SCHEDULED TASKS ===")
list_tasks()`,
  },
  {
    id: 'hot-key-macro',
    title: 'Global Hotkey Macro Engine',
    category: 'System',
    tags: ['hotkey', 'macro', 'keyboard', 'shortcut', 'automate', 'global'],
    description: 'Register global hotkeys to trigger Python scripts from anywhere in Windows',
    requirements: ['keyboard'],
    script: `import keyboard, subprocess, sys, time, pyperclip
from datetime import datetime

if sys.platform != 'win32':
    print("Windows hotkey registration works best on Windows."); 

def run_script(code):
    try:
        result = subprocess.run(['python', '-c', code],
                                capture_output=True, text=True, timeout=10)
        print(result.stdout.strip())
        if result.stderr: print("ERR:", result.stderr[:100])
    except Exception as e:
        print(f"Error: {e}")

HOTKEYS = {
    'ctrl+alt+c': ("Date/Time Copy", lambda: pyperclip.copy(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))),
    'ctrl+alt+i': ("System Info",    lambda: run_script("import platform,psutil;cpu=psutil.cpu_percent(1);mem=psutil.virtual_memory().percent;print(f'CPU:{cpu}% RAM:{mem}% OS:{platform.system()}')")),
    'ctrl+alt+p': ("Print IP",       lambda: run_script("import socket;print(socket.gethostbyname(socket.gethostname()))")),
}

print("=== HOTKEY MACRO ENGINE ===")
for hotkey, (name, action) in HOTKEYS.items():
    keyboard.add_hotkey(hotkey, action)
    print(f"  {hotkey:20} -> {name}")

print("\nHotkeys active. Press ESC to stop.")
keyboard.wait('esc')
print("Hotkeys deregistered.")`,
  },
  {
    id: 'pc-health-report',
    title: 'Full PC Health Report HTML',
    category: 'System',
    tags: ['health', 'report', 'html', 'cpu', 'ram', 'disk', 'battery', 'diagnostics'],
    description: 'Generate a comprehensive HTML system health report with charts',
    requirements: ['psutil'],
    script: `import psutil, platform, socket, os, time
from datetime import datetime
from pathlib import Path

cpu    = psutil.cpu_percent(interval=2)
mem    = psutil.virtual_memory()
disk   = psutil.disk_usage('/')
net    = psutil.net_io_counters()
boot   = datetime.fromtimestamp(psutil.boot_time())
procs  = len(psutil.pids())
freq   = psutil.cpu_freq()
temps  = getattr(psutil, 'sensors_temperatures', lambda: {})()

cpu_bar  = '#' * int(cpu/5)  + '.' * (20 - int(cpu/5))
ram_bar  = '#' * int(mem.percent/5) + '.' * (20 - int(mem.percent/5))
disk_bar = '#' * int(disk.percent/5) + '.' * (20 - int(disk.percent/5))

status = "HEALTHY"
issues = []
if cpu > 85:    issues.append("HIGH CPU"); status = "WARNING"
if mem.percent > 90: issues.append("HIGH RAM"); status = "CRITICAL"
if disk.percent > 90: issues.append("LOW DISK"); status = "CRITICAL"

html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>PC Health Report</title>
<style>
  body{{font-family:monospace;background:#05080F;color:#E8F0F8;padding:20px}}
  h1{{color:#FF2A1F}} h2{{color:#00FF88;border-bottom:1px solid #1a2535;padding-bottom:8px}}
  .card{{background:#0A0F18;border:1px solid #1a2535;border-radius:8px;padding:16px;margin:12px 0}}
  .bar{{height:16px;background:#1a2535;border-radius:4px;overflow:hidden;margin:4px 0}}
  .bar-fill{{height:100%;border-radius:4px}}
  .green{{background:#00FF88}} .amber{{background:#FF6A1F}} .red{{background:#FF3344}}
  table{{width:100%;border-collapse:collapse}}
  td,th{{padding:8px 12px;border-bottom:1px solid #1a2535;text-align:left}}
  .status-ok{{color:#00FF88}} .status-warn{{color:#FF6A1F}} .status-crit{{color:#FF3344}}
</style></head><body>
<h1>🖥 PC Health Report</h1>
<p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Host: {socket.gethostname()} | Status: <b class="{'status-ok' if status=='HEALTHY' else 'status-warn'}">{status}</b></p>

<div class="card"><h2>CPU</h2>
<p>{platform.processor()[:70]}</p>
<p>Usage: {cpu}% | Cores: {psutil.cpu_count()} | Freq: {freq.current:.0f}MHz</p>
<div class="bar"><div class="bar-fill {'green' if cpu<70 else 'amber' if cpu<85 else 'red'}" style="width:{cpu}%"></div></div>
</div>

<div class="card"><h2>Memory</h2>
<p>{mem.used/1024**3:.1f}GB / {mem.total/1024**3:.1f}GB used ({mem.percent}%)</p>
<div class="bar"><div class="bar-fill {'green' if mem.percent<70 else 'amber' if mem.percent<85 else 'red'}" style="width:{mem.percent}%"></div></div>
</div>

<div class="card"><h2>Disk</h2>
<p>{disk.used/1024**3:.1f}GB / {disk.total/1024**3:.1f}GB used ({disk.percent}%)</p>
<div class="bar"><div class="bar-fill {'green' if disk.percent<70 else 'amber' if disk.percent<85 else 'red'}" style="width:{disk.percent}%"></div></div>
</div>

<div class="card"><h2>Network</h2>
<p>Sent: {net.bytes_sent/1024**2:.1f}MB | Received: {net.bytes_recv/1024**2:.1f}MB</p>
<p>Uptime since: {boot.strftime('%Y-%m-%d %H:%M')}</p>
<p>Processes: {procs}</p>
</div>
</body></html>"""

report_path = Path("health_report.html")
report_path.write_text(html, encoding='utf-8')
print(f"Report saved: {report_path.absolute()}")
print(f"Status: {status}")
if issues: print(f"Issues: {', '.join(issues)}")
else: print("All systems healthy!")`,
  },

  // ── SECURITY ──────────────────────────────────────────────────
  {
    id: 'ssl-cert-checker',
    title: 'SSL Certificate Expiry Checker',
    category: 'Security',
    tags: ['ssl', 'certificate', 'expire', 'tls', 'https', 'security'],
    description: 'Check SSL certificate expiry dates for domains and alert on expiring certs',
    requirements: [],
    script: `import ssl, socket
from datetime import datetime

DOMAINS   = ["google.com", "github.com", "cloudflare.com", "api.openai.com"]
WARN_DAYS = 30

def check_ssl(host, port=443):
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((host, port), timeout=10) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                cert = ssock.getpeercert()
                exp_date = datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
                days_left = (exp_date - datetime.utcnow()).days
                issuer = dict(x[0] for x in cert.get('issuer', []))
                return {
                    'host':     host,
                    'expires':  exp_date.strftime('%Y-%m-%d'),
                    'days_left':days_left,
                    'issuer':   issuer.get('organizationName', 'Unknown'),
                    'ok': True,
                }
    except Exception as e:
        return {'host': host, 'error': str(e)[:60], 'ok': False}

print(f"=== SSL CERTIFICATE CHECKER ===")
print(f"{'Domain':30} {'Expires':12} {'Days Left':10} Issuer")
print("-" * 75)

for domain in DOMAINS:
    r = check_ssl(domain)
    if not r['ok']:
        print(f"  ERR  {r['host']:28} {r['error']}")
    else:
        flag = " EXPIRING SOON!" if r['days_left'] < WARN_DAYS else ""
        icon = "CRIT" if r['days_left'] < 7 else "WARN" if r['days_left'] < WARN_DAYS else "OK  "
        print(f"  {icon} {r['host']:28} {r['expires']:12} {r['days_left']:5}d  {r['issuer'][:25]}{flag}")`,
  },
  {
    id: 'password-generator',
    title: 'Secure Password Generator',
    category: 'Security',
    tags: ['password', 'generate', 'random', 'secure', 'strong', 'entropy'],
    description: 'Generate cryptographically secure passwords and memorable passphrases',
    requirements: [],
    script: `import secrets, string, math

def generate_password(length=20, upper=True, digits=True, symbols=True):
    chars = string.ascii_lowercase
    if upper:   chars += string.ascii_uppercase
    if digits:  chars += string.digits
    if symbols: chars += "!@#$%^&*()_+-={}"
    return ''.join(secrets.choice(chars) for _ in range(length))

WORDLIST = [
    "correct","horse","battery","staple","dragon","coffee",
    "sunset","frozen","python","valley","thunder","silicon",
    "quantum","bridge","garden","silver","harbor","falcon",
    "rocket","cosmic","mirror","jungle","neon","chrome",
]

def generate_passphrase(words=4):
    chosen = [secrets.choice(WORDLIST) for _ in range(words)]
    sep    = secrets.choice(["-",".","_"])
    return sep.join(chosen) + str(secrets.randbelow(9999))

def entropy(pwd):
    charset = 0
    if any(c.islower()     for c in pwd): charset += 26
    if any(c.isupper()     for c in pwd): charset += 26
    if any(c.isdigit()     for c in pwd): charset += 10
    if any(not c.isalnum() for c in pwd): charset += 32
    return math.log2(charset ** len(pwd)) if charset > 0 else 0

print("=== PASSWORD GENERATOR ===\n")
print("Passwords:")
for length in [12, 16, 20, 32]:
    pwd = generate_password(length)
    print(f"  {length:2}chr  {entropy(pwd):5.0f}bits  {pwd}")

print("\nPassphrases (easy to remember):")
for _ in range(4):
    pp = generate_passphrase()
    print(f"  {entropy(pp):5.0f}bits  {pp}")`,
  },
  {
    id: 'api-key-scanner',
    title: 'API Key and Secret Leak Scanner',
    category: 'Security',
    tags: ['api', 'key', 'secret', 'scan', 'leak', 'credential', 'git'],
    description: 'Scan code repositories for accidentally committed API keys and credentials',
    requirements: [],
    script: `import re
from pathlib import Path
from collections import defaultdict

SKIP_DIRS = {'.git','node_modules','__pycache__','.venv','dist','build'}

SECRET_PATTERNS = {
    'AWS Access Key':   r'AKIA[0-9A-Z]{16}',
    'GitHub Token':     r'ghp_[A-Za-z0-9]{36}',
    'Google API Key':   r'AIza[0-9A-Za-z\-_]{35}',
    'Stripe Key':       r'sk_live_[0-9a-zA-Z]{24}',
    'OpenAI Key':       r'sk-[A-Za-z0-9]{48}',
    'Slack Token':      r'xox[baprs]-[0-9A-Za-z\-]+',
    'Private Key':      r'-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY',
    'Password in Code': r'(?i)password[\s]*=[\s]*[\'"]([^\'"{\\s]{8,})',
}

SCAN_DIR  = Path(".")
findings  = defaultdict(list)

print(f"=== API KEY SCANNER ===")
print(f"Scanning: {SCAN_DIR.absolute()}\n")

for f in SCAN_DIR.rglob("*"):
    if any(skip in f.parts for skip in SKIP_DIRS): continue
    if not f.is_file(): continue
    if f.suffix not in ['.py','.js','.ts','.env','.json','.yaml','.sh']: continue
    try:
        content = f.read_text(errors='replace')
        for name, pattern in SECRET_PATTERNS.items():
            if re.search(pattern, content):
                findings[name].append(str(f))
                print(f"  ALERT [{name}]: {f}")
    except: pass

if not findings:
    print("No secrets found — clean codebase!")
else:
    print(f"\n=== {sum(len(v) for v in findings.values())} POTENTIAL LEAKS ===")
    for key, files in findings.items():
        print(f"  {key}: {len(files)} file(s)")
    print("\nACTION: Rotate any exposed keys immediately!")`,
  },
  {
    id: 'windows-defender-scan',
    title: 'Windows Defender Quick Scan',
    category: 'Security',
    tags: ['defender', 'antivirus', 'scan', 'malware', 'windows', 'virus', 'threat'],
    description: 'Trigger Windows Defender quick and full scans with result reporting',
    requirements: [],
    script: `import subprocess, sys, time
from datetime import datetime

if sys.platform != 'win32':
    print("Windows only — for Linux use: clamscan -r ~/")
    exit()

MPC_EXE = r"C:\Program Files\Windows Defender\MpCmdRun.exe"

def run_defender(scan_type="-ScanType 1"):
    print(f"Starting Defender scan: {scan_type}...")
    print(f"Time: {datetime.now().strftime('%H:%M:%S')}\n")
    r = subprocess.run(
        [MPC_EXE] + scan_type.split(),
        capture_output=True, text=True, timeout=300
    )
    print(r.stdout or "Scan complete (no output)")
    if r.returncode == 0:
        print("RESULT: No threats detected")
    elif r.returncode == 2:
        print("RESULT: THREATS FOUND - check Windows Security")
    else:
        print(f"Exit code: {r.returncode}")

def get_defender_status():
    r = subprocess.run(
        ["powershell","-Command",
         "Get-MpComputerStatus | Select-Object AntivirusEnabled,RealTimeProtectionEnabled,QuickScanStartTime,QuickScanEndTime | Format-List"],
        capture_output=True, text=True
    )
    print("=== WINDOWS DEFENDER STATUS ===")
    print(r.stdout)

def update_signatures():
    print("Updating virus signatures...")
    r = subprocess.run([MPC_EXE, "-SignatureUpdate"], capture_output=True, text=True)
    print("Signatures updated!" if r.returncode == 0 else f"Update failed: {r.returncode}")

get_defender_status()
print("\nRunning quick scan...")
run_defender("-ScanType 1")  # 1=Quick, 2=Full, 3=Custom`,
  },
  {
    id: 'network-intrusion-detector',
    title: 'Network Intrusion Detector',
    category: 'Security',
    tags: ['intrusion', 'detect', 'network', 'arp', 'scan', 'alert', 'security'],
    description: 'Detect new unauthorized devices joining your network with ARP scanning',
    requirements: ['scapy'],
    script: `import json, time, socket, subprocess, sys
from pathlib import Path
from datetime import datetime

NETWORK   = "192.168.1.0/24"  # Change to your subnet
DATA_FILE = Path("network_devices.json")
CHECK_SEC = 60

def scan_arp(network):
    devices = []
    try:
        from scapy.all import ARP, Ether, srp
        ans, _ = srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst=network),
                     timeout=2, verbose=0)
        for _, rcv in ans:
            devices.append({'ip': rcv.psrc, 'mac': rcv.hwsrc})
    except ImportError:
        if sys.platform == 'win32':
            r = subprocess.run("arp -a", shell=True, capture_output=True, text=True)
            import re
            for line in r.stdout.split('\n'):
                m = re.search(r'(\d+\.\d+\.\d+\.\d+)\s+([\w-]{17})', line)
                if m: devices.append({'ip': m.group(1), 'mac': m.group(2)})
        else:
            r = subprocess.run(["arp","-n"], capture_output=True, text=True)
            import re
            for line in r.stdout.split('\n')[1:]:
                parts = line.split()
                if len(parts) >= 3:
                    devices.append({'ip': parts[0], 'mac': parts[2]})
    return devices

known = json.loads(DATA_FILE.read_text()) if DATA_FILE.exists() else {}

print(f"=== INTRUSION DETECTOR ===")
print(f"Network: {NETWORK}")
print(f"Known devices: {len(known)}")
print("Scanning...\n")

devices = scan_arp(NETWORK)
for d in devices:
    key = d['mac']
    if key not in known:
        ts = datetime.now().isoformat()
        try: name = socket.gethostbyaddr(d['ip'])[0]
        except: name = "unknown"
        known[key] = {'ip': d['ip'], 'first_seen': ts, 'name': name}
        print(f"  NEW DEVICE: {d['ip']:18} MAC:{d['mac']}  Name:{name}")
    else:
        print(f"  Known:      {d['ip']:18} MAC:{d['mac']}")

DATA_FILE.write_text(json.dumps(known, indent=2))
print(f"\nTotal devices: {len(devices)} | Known: {len(known)}")`,
  },

  // ── CLEANING ──────────────────────────────────────────────────
  {
    id: 'docker-cleaner',
    title: 'Docker System Cleaner',
    category: 'Cleaning',
    tags: ['docker', 'container', 'image', 'clean', 'prune', 'volume'],
    description: 'Remove dangling Docker images, stopped containers, and unused volumes',
    requirements: [],
    script: `import subprocess

check = subprocess.run(["docker", "info"], capture_output=True)
if check.returncode != 0:
    print("Docker not running or not installed"); exit()

print("=== DOCKER CLEANER ===")
print("\nBefore:")
subprocess.run(["docker", "system", "df"])

def prune(args, label):
    r = subprocess.run(["docker"] + args, capture_output=True, text=True)
    out = r.stdout.strip()
    print(f"  {label}: {out[:80] if out else 'nothing removed'}")

print("\nCleaning...")
prune(["container", "prune", "-f"],   "Stopped containers")
prune(["image",     "prune", "-f"],    "Dangling images")
prune(["volume",    "prune", "-f"],    "Unused volumes")
prune(["network",   "prune", "-f"],    "Unused networks")

print("\nAfter:")
subprocess.run(["docker", "system", "df"])`,
  },
  {
    id: 'pip-env-cleaner',
    title: 'Python Pip Environment Cleaner',
    category: 'Cleaning',
    tags: ['pip', 'packages', 'clean', 'venv', 'dependencies', 'cache', 'pyc'],
    description: 'Clean pip cache, remove .pyc files, and audit unused virtual envs',
    requirements: [],
    script: `import subprocess, sys, shutil
from pathlib import Path

print("=== PYTHON ENVIRONMENT CLEANER ===")

print("\n[1] Clearing pip download cache...")
r = subprocess.run([sys.executable, "-m", "pip", "cache", "purge"],
                   capture_output=True, text=True)
print(f"  {r.stdout.strip() or 'Done'}")

print("\n[2] Pip cache info:")
r2 = subprocess.run([sys.executable, "-m", "pip", "cache", "info"],
                    capture_output=True, text=True)
print(f"  {r2.stdout.strip()}")

print("\n[3] Removing .pyc files and __pycache__...")
count = 0
for pyc in Path('.').rglob('*.pyc'):
    try: pyc.unlink(); count += 1
    except: pass
for pycache in Path('.').rglob('__pycache__'):
    try: shutil.rmtree(pycache, ignore_errors=True)
    except: pass
print(f"  Removed {count} .pyc files")

print("\n[4] Outdated packages:")
subprocess.run([sys.executable, "-m", "pip", "list", "--outdated"])`,
  },
  {
    id: 'git-repo-cleaner',
    title: 'Git Repository Cleaner',
    category: 'Cleaning',
    tags: ['git', 'clean', 'branch', 'prune', 'repository', 'merge', 'gc'],
    description: 'Prune merged branches, remove stale remotes, and compact git repositories',
    requirements: [],
    script: `import subprocess
from pathlib import Path

def git(*args, cwd=None):
    r = subprocess.run(["git"] + list(args), capture_output=True, text=True, cwd=cwd)
    return r.stdout.strip(), r.stderr.strip(), r.returncode

REPO = Path(".")
_, _, code = git("-C", str(REPO), "status")
if code != 0:
    print(f"Not a git repo: {REPO.absolute()}"); exit()

print(f"=== GIT REPO CLEANER: {REPO.absolute()} ===")

out, _, _ = git("count-objects", "-vH", cwd=REPO)
print(f"Before size: {out[:100]}")

print("\nMerged branches (safe to delete):")
for base in ["main", "master"]:
    out, _, rc = git("branch", "--merged", base, cwd=REPO)
    if rc == 0 and out:
        merged = [b.strip() for b in out.split("\n")
                  if b.strip() and b.strip() not in ("*", "main", "master")]
        for branch in merged:
            git("branch", "-d", branch, cwd=REPO)
            print(f"  Deleted: {branch}")
        if not merged: print("  None to clean")
        break

git("remote", "prune", "origin", cwd=REPO)
print("Pruned stale remote tracking refs")

print("Running git gc...")
git("gc", "--aggressive", "--prune=now", cwd=REPO)

out, _, _ = git("count-objects", "-vH", cwd=REPO)
print(f"After size: {out[:100]}")`,
  },
  {
    id: 'windows-bloat-remover',
    title: 'Windows Bloatware Remover',
    category: 'Cleaning',
    tags: ['bloat', 'windows', 'remove', 'apps', 'clean', 'uwp', 'powershell'],
    description: 'Remove pre-installed Windows bloatware apps using PowerShell',
    requirements: [],
    script: `import subprocess, sys

if sys.platform != 'win32':
    print("Windows only"); exit()

BLOATWARE = [
    "Microsoft.3DBuilder",
    "Microsoft.BingWeather",
    "Microsoft.GetHelp",
    "Microsoft.Getstarted",
    "Microsoft.Microsoft3DViewer",
    "Microsoft.MicrosoftSolitaireCollection",
    "Microsoft.NetworkSpeedTest",
    "Microsoft.News",
    "Microsoft.Office.Lens",
    "Microsoft.People",
    "Microsoft.Print3D",
    "Microsoft.SkypeApp",
    "Microsoft.Todos",
    "Microsoft.WindowsFeedbackHub",
    "Microsoft.XboxApp",
    "Microsoft.Xbox.TCUI",
    "Microsoft.YourPhone",
    "Microsoft.ZuneMusic",
    "Microsoft.ZuneVideo",
    "king.com.CandyCrushSaga",
    "king.com.CandyCrushSodaSaga",
    "Spotify.Spotify",
]

print("=== WINDOWS BLOATWARE REMOVER ===")
print(f"Apps to remove: {len(BLOATWARE)}\n")

for app in BLOATWARE:
    r = subprocess.run(
        ["powershell", "-Command",
         f"Get-AppxPackage {app} | Remove-AppxPackage"],
        capture_output=True, text=True
    )
    if "not found" not in r.stderr.lower() and r.returncode == 0:
        print(f"  Removed: {app}")
    else:
        print(f"  Skip:    {app} (not installed)")

print("\nBloatware removal complete!")
print("Tip: Restart to see changes.")`,
  },
  {
    id: 'disk-defrag-analyzer',
    title: 'Disk Defrag and Optimizer',
    category: 'Cleaning',
    tags: ['defrag', 'disk', 'optimize', 'hdd', 'ssd', 'fragments', 'windows'],
    description: 'Analyze disk fragmentation and run optimization (defrag for HDD, TRIM for SSD)',
    requirements: [],
    script: `import subprocess, sys

if sys.platform == 'win32':
    print("=== DISK OPTIMIZER ===\n")

    print("Analyzing all drives...")
    r = subprocess.run(
        ["defrag", "/C", "/A", "/V"],
        capture_output=True, text=True, timeout=120
    )
    print(r.stdout[:3000] if r.stdout else "Analysis complete")

    print("\nOptimizing C: drive...")
    r2 = subprocess.run(
        ["defrag", "C:", "/O"],  # /O = Optimize (defrag HDD, TRIM SSD)
        capture_output=True, text=True, timeout=300
    )
    print(r2.stdout[:2000] if r2.stdout else "Optimization complete")

    print("\nTip: SSDs use TRIM (automatic), HDDs use defrag")
    print("Run from Admin PowerShell for full access")
else:
    print("=== LINUX DISK ANALYSIS ===")
    for cmd in [
        "df -h",
        "sudo fstrim -av",
        "sudo e2fsck -n /dev/sda1",
    ]:
        print(f"\n$ {cmd}")
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        print(r.stdout[:500] or r.stderr[:200])`,
  },

  // ── MONITORING ────────────────────────────────────────────────
  {
    id: 'disk-space-alert',
    title: 'Disk Space Alert System',
    category: 'Monitoring',
    tags: ['disk', 'alert', 'space', 'monitor', 'threshold', 'critical'],
    description: 'Monitor disk space on all mounted drives and log alerts when running low',
    requirements: ['psutil'],
    script: `import psutil
from datetime import datetime
from pathlib import Path

WARN_PCT = 80
CRIT_PCT = 90
LOG_FILE = "disk_alerts.log"

def log_alert(msg):
    ts   = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, 'a') as f: f.write(line + "\n")

print(f"=== DISK SPACE MONITOR ===")
print(f"Warn>{WARN_PCT}%  Critical>{CRIT_PCT}%\n")

for part in psutil.disk_partitions():
    try:
        u   = psutil.disk_usage(part.mountpoint)
        bar = '#' * int(u.percent/5) + '.' * (20 - int(u.percent/5))
        tag = "CRIT" if u.percent >= CRIT_PCT else "WARN" if u.percent >= WARN_PCT else "OK  "
        print(f"  [{tag}] {part.mountpoint:15} [{bar}] {u.percent:5.1f}%  {u.free/1024**3:.1f}GB free")
    except: pass

print("\nAlerts:")
for part in psutil.disk_partitions():
    try:
        u = psutil.disk_usage(part.mountpoint)
        if u.percent >= WARN_PCT:
            level = "CRITICAL" if u.percent >= CRIT_PCT else "WARNING"
            log_alert(f"{level}: {part.mountpoint} at {u.percent:.1f}% ({u.free/1024**3:.1f}GB free)")
    except: pass`,
  },
  {
    id: 'log-analyzer',
    title: 'Log File Error Analyzer',
    category: 'Monitoring',
    tags: ['log', 'analyze', 'parse', 'errors', 'grep', 'pattern', 'syslog'],
    description: 'Analyze log files to extract errors, warnings, and top IP addresses',
    requirements: [],
    script: `import re, sys
from pathlib import Path
from collections import Counter

LOG_FILES = [
    "/var/log/syslog",
    "/var/log/auth.log",
    "/var/log/nginx/error.log",
    "app.log",
]

def analyze_log(log_path):
    path = Path(log_path)
    if not path.exists():
        print(f"  Not found: {log_path}"); return

    lines    = path.read_text(errors='replace').splitlines()
    errors   = [l for l in lines if re.search(r'ERROR|CRITICAL|FATAL', l, re.I)]
    warnings = [l for l in lines if re.search(r'WARN|WARNING', l, re.I)]
    ips      = re.findall(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b', "\n".join(lines))
    top_ips  = Counter(ips).most_common(5)

    print(f"\n=== {path.name} ({len(lines)} lines) ===")
    print(f"  Errors:   {len(errors)}")
    print(f"  Warnings: {len(warnings)}")

    if errors:
        print("  Last 3 errors:")
        for e in errors[-3:]:
            print(f"    {e[:100]}")

    if top_ips:
        print("  Top IPs:")
        for ip, count in top_ips:
            print(f"    {ip:18} {count:5} hits")

for log_file in LOG_FILES:
    analyze_log(log_file)

if len(sys.argv) > 1:
    analyze_log(sys.argv[1])`,
  },
  {
    id: 'cpu-temp-monitor',
    title: 'CPU Temperature Monitor',
    category: 'Monitoring',
    tags: ['temperature', 'cpu', 'thermal', 'heat', 'sensor', 'throttle'],
    description: 'Monitor CPU temperatures and alert when thermal throttling may occur',
    requirements: ['psutil'],
    script: `import psutil, time, sys
from datetime import datetime

WARN_TEMP = 75
CRIT_TEMP = 90

def get_temps():
    if not hasattr(psutil, 'sensors_temperatures'): return {}
    try: return psutil.sensors_temperatures()
    except: return {}

temps = get_temps()
if not temps:
    if sys.platform == 'win32':
        import subprocess
        print("Windows: Checking thermal zones...")
        r = subprocess.run(
            "wmic /namespace:\\\\root\\wmi PATH MSAcpi_ThermalZoneTemperature get CurrentTemperature",
            shell=True, capture_output=True, text=True
        )
        for line in r.stdout.strip().split("\n")[1:]:
            if line.strip():
                try:
                    temp_c = (float(line.strip()) / 10) - 273.15
                    print(f"Thermal zone: {temp_c:.1f}C")
                except: pass
    else:
        print("Temperature sensors not available on this system")
        print("Try: sudo apt install lm-sensors && sudo sensors-detect")
else:
    print(f"=== CPU TEMPERATURE MONITOR ===")
    print(f"Warn>{WARN_TEMP}C  Critical>{CRIT_TEMP}C\n")
    for sensor_name, entries in temps.items():
        for entry in entries:
            temp = entry.current
            flag = " ** CRITICAL **" if temp >= CRIT_TEMP else " * HOT *" if temp >= WARN_TEMP else ""
            print(f"  {sensor_name:20} {entry.label or 'core':15} {temp:6.1f}C{flag}")`,
  },
  {
    id: 'gpu-monitor',
    title: 'GPU Monitor NVIDIA and AMD',
    category: 'Monitoring',
    tags: ['gpu', 'nvidia', 'amd', 'vram', 'temperature', 'cuda', 'monitor'],
    description: 'Monitor GPU temperature, VRAM usage, and utilization with nvidia-smi',
    requirements: [],
    script: `import subprocess, sys, time

def get_nvidia_stats():
    try:
        r = subprocess.run([
            "nvidia-smi",
            "--query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total,power.draw",
            "--format=csv,noheader,nounits"
        ], capture_output=True, text=True, timeout=5)
        if r.returncode != 0: return None
        rows = []
        for line in r.stdout.strip().split("\n"):
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 6:
                try:
                    rows.append({
                        'name':     parts[0],
                        'temp':     int(parts[1]),
                        'util':     int(parts[2]),
                        'mem_used': int(parts[3]),
                        'mem_total':int(parts[4]),
                        'power':    float(parts[5]),
                    })
                except: pass
        return rows
    except: return None

print("=== GPU MONITOR ===")
nvidia = get_nvidia_stats()
if nvidia:
    for i, gpu in enumerate(nvidia):
        bar     = 'X' * (gpu['util']//5) + '.' * (20 - gpu['util']//5)
        mem_pct = (gpu['mem_used'] / max(gpu['mem_total'],1)) * 100
        print(f"GPU {i}: {gpu['name'][:35]}")
        print(f"  Temp:{gpu['temp']:3}C  Util:{gpu['util']:3}%  [{bar}]")
        print(f"  VRAM:{gpu['mem_used']:5}MB/{gpu['mem_total']}MB ({mem_pct:.0f}%)")
        print(f"  Power:{gpu['power']:.0f}W")
else:
    r = subprocess.run(["rocm-smi","--showtemp","--showuse"], capture_output=True, text=True, timeout=5)
    if r.returncode == 0:
        print(r.stdout)
    else:
        print("No GPU found. Install nvidia-smi (NVIDIA) or ROCm (AMD)")`,
  },
  {
    id: 'process-tree-viewer',
    title: 'Process Tree Viewer',
    category: 'Monitoring',
    tags: ['process', 'tree', 'parent', 'child', 'hierarchy', 'psutil', 'pid'],
    description: 'Display running processes in a tree hierarchy with CPU and RAM usage',
    requirements: ['psutil'],
    script: `import psutil
from collections import defaultdict

def fmt_bytes(n):
    if n > 1024**3: return f"{n/1024**3:.1f}GB"
    if n > 1024**2: return f"{n/1024**2:.0f}MB"
    return f"{n/1024:.0f}KB"

procs = {}
children = defaultdict(list)

for p in psutil.process_iter(['pid','ppid','name','cpu_percent','memory_info','status']):
    try:
        info = p.info
        procs[info['pid']] = info
        children[info['ppid']].append(info['pid'])
    except: pass

# Re-sample CPU (psutil needs 2 calls for accurate %)
import time
time.sleep(0.5)
cpu_map = {}
for p in psutil.process_iter(['pid','cpu_percent']):
    try: cpu_map[p.pid] = p.cpu_percent()
    except: pass

def print_tree(pid, level=0):
    if pid not in procs: return
    p = procs[pid]
    name = p.get('name','?')[:25]
    mem  = fmt_bytes(p.get('memory_info',type('',(),{'rss':0})()).rss)
    cpu  = cpu_map.get(pid, 0)
    indent = "  " * level + ("└─ " if level > 0 else "")
    print(f"{indent}{name:25} PID:{pid:<7} CPU:{cpu:5.1f}%  MEM:{mem:8}")
    for child_pid in sorted(children.get(pid, [])):
        print_tree(child_pid, level + 1)

print("=== PROCESS TREE ===")
# Print top-level processes (ppid=0 or not in our list)
roots = [pid for pid in procs if procs[pid]['ppid'] not in procs]
for root in sorted(roots)[:5]:
    print_tree(root)

print(f"\nTotal processes: {len(procs)}")`,
  },
  {
    id: 'smart-disk-health',
    title: 'S.M.A.R.T Disk Health Check',
    category: 'Monitoring',
    tags: ['smart', 'disk', 'health', 'hdd', 'ssd', 'nvme', 'failure', 'predict'],
    description: 'Check S.M.A.R.T drive health data to predict disk failure',
    requirements: [],
    script: `import subprocess, sys

def check_smart_windows():
    r = subprocess.run(
        ["powershell","-Command",
         "Get-WmiObject Win32_DiskDrive | Select-Object Model,Status,MediaType | Format-List"],
        capture_output=True, text=True
    )
    print("=== DISK STATUS (Windows) ===")
    print(r.stdout)

    print("\n=== DISK DETAILS (PowerShell) ===")
    r2 = subprocess.run(
        ["powershell","-Command",
         "Get-PhysicalDisk | Select-Object FriendlyName,HealthStatus,OperationalStatus,MediaType,Size | Format-Table"],
        capture_output=True, text=True
    )
    print(r2.stdout)

def check_smart_linux():
    import glob
    disks = glob.glob('/dev/sd?') + glob.glob('/dev/nvme?n?')
    for disk in disks:
        print(f"\n=== {disk} ===")
        r = subprocess.run(
            ["sudo", "smartctl", "-H", "-A", disk],
            capture_output=True, text=True
        )
        if r.returncode != 0:
            print(f"Error: {r.stderr[:100]}")
            print("Install: sudo apt install smartmontools")
        else:
            for line in r.stdout.split("\n"):
                if any(kw in line for kw in
                       ["Health","Reallocated","Pending","Uncorrectable","Temperature","Power_On"]):
                    print(f"  {line.strip()}")

if sys.platform == 'win32':
    check_smart_windows()
else:
    check_smart_linux()`,
  },

  // ── WEB ───────────────────────────────────────────────────────
  {
    id: 'api-tester',
    title: 'REST API Endpoint Tester',
    category: 'Web',
    tags: ['api', 'rest', 'test', 'http', 'json', 'endpoint', 'curl'],
    description: 'Test REST API endpoints with assertions, latency tracking, and status reporting',
    requirements: ['requests'],
    script: `import requests, json, time

BASE_URL = "https://jsonplaceholder.typicode.com"

TESTS = [
    {"method":"GET",    "endpoint":"/users",    "expect":200},
    {"method":"GET",    "endpoint":"/posts/1",   "expect":200},
    {"method":"POST",   "endpoint":"/posts",     "expect":201,
     "body":{"title":"test","body":"hello","userId":1}},
    {"method":"PUT",    "endpoint":"/posts/1",   "expect":200,
     "body":{"title":"updated"}},
    {"method":"DELETE", "endpoint":"/posts/1",   "expect":200},
]

def run_tests():
    passed = failed = 0
    print(f"=== API TEST SUITE ===  Base: {BASE_URL}\n")
    for test in TESTS:
        url  = BASE_URL + test["endpoint"]
        body = test.get("body")
        start = time.perf_counter()
        try:
            r = getattr(requests, test["method"].lower())(
                url, json=body, headers={"Content-Type":"application/json"}, timeout=10
            )
            ms   = (time.perf_counter() - start) * 1000
            ok   = r.status_code == test["expect"]
            tag  = "PASS" if ok else "FAIL"
            if ok: passed += 1
            else:  failed += 1
            print(f"  {tag} {test['method']:7} {test['endpoint']:25} "
                  f"HTTP {r.status_code} (expected {test['expect']}) {ms:.0f}ms")
        except Exception as e:
            failed += 1
            print(f"  ERR  {test['method']:7} {test['endpoint']:25} {e}")

    print(f"\nResults: {passed}/{passed+failed} passed | {failed} failed")

run_tests()`,
  },
  {
    id: 'download-manager',
    title: 'Parallel Batch Download Manager',
    category: 'Web',
    tags: ['download', 'batch', 'wget', 'file', 'url', 'resume', 'parallel'],
    description: 'Download multiple URLs in parallel with progress and resume support',
    requirements: ['requests'],
    script: `import requests, time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

URLs = [
    ("posts.json",    "https://jsonplaceholder.typicode.com/posts"),
    ("users.json",    "https://jsonplaceholder.typicode.com/users"),
    ("comments.json", "https://jsonplaceholder.typicode.com/comments"),
]

SAVE_DIR    = Path("downloads")
MAX_WORKERS = 4
lock        = Lock()
SAVE_DIR.mkdir(exist_ok=True)

def download(name, url):
    dest = SAVE_DIR / name
    headers = {}
    if dest.exists():
        headers['Range'] = f"bytes={dest.stat().st_size}-"
        mode = 'ab'
    else:
        mode = 'wb'
    try:
        r = requests.get(url, headers=headers, stream=True, timeout=30)
        downloaded = 0
        start = time.perf_counter()
        with open(dest, mode) as f:
            for chunk in r.iter_content(chunk_size=65536):
                f.write(chunk)
                downloaded += len(chunk)
                speed = downloaded / max(time.perf_counter() - start, 0.001) / 1024
                with lock:
                    print(f"\r  {name[:20]:20} {downloaded//1024}KB  {speed:.0f}KB/s", end='')
        print(f"\n  Done: {name} ({downloaded//1024}KB)")
    except Exception as e:
        print(f"\n  Error: {name}: {e}")

print(f"Downloading {len(URLs)} files with {MAX_WORKERS} workers...")
with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
    ex.map(lambda u: download(*u), URLs)
print("All downloads complete!")`,
  },
  {
    id: 'web-screenshot',
    title: 'Website Screenshot Automation',
    category: 'Web',
    tags: ['screenshot', 'web', 'browser', 'selenium', 'automation', 'capture', 'headless'],
    description: 'Take automated screenshots of websites using Selenium headless Chrome',
    requirements: ['selenium', 'webdriver-manager'],
    script: `from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from pathlib import Path
import time

SITES = [
    {"name": "google",    "url": "https://www.google.com"},
    {"name": "github",    "url": "https://github.com"},
    {"name": "python",    "url": "https://python.org"},
]

WIDTH  = 1920
HEIGHT = 1080
OUTPUT = Path("screenshots")
OUTPUT.mkdir(exist_ok=True)

opts = Options()
opts.add_argument("--headless")
opts.add_argument("--no-sandbox")
opts.add_argument(f"--window-size={WIDTH},{HEIGHT}")
opts.add_argument("--disable-dev-shm-usage")

print(f"Taking {len(SITES)} screenshots at {WIDTH}x{HEIGHT}...")

driver = None
try:
    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=opts
    )
    driver.set_page_load_timeout(30)

    for site in SITES:
        try:
            driver.get(site["url"])
            time.sleep(2)
            path = OUTPUT / f"{site['name']}.png"
            driver.save_screenshot(str(path))
            size = path.stat().st_size // 1024
            print(f"  {site['name']:20} -> {path} ({size}KB)")
        except Exception as e:
            print(f"  Error {site['name']}: {e}")
finally:
    if driver: driver.quit()

print(f"\nScreenshots saved to: {OUTPUT.absolute()}")`,
  },
  {
    id: 'link-checker',
    title: 'Website Broken Link Checker',
    category: 'Web',
    tags: ['links', 'broken', 'check', 'crawl', '404', 'seo', 'website'],
    description: 'Crawl a website and find all broken links returning 404 or errors',
    requirements: ['requests', 'beautifulsoup4'],
    script: `import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from collections import deque

START_URL  = "https://example.com"
MAX_PAGES  = 50
TIMEOUT    = 10
USER_AGENT = "Mozilla/5.0 Link-Checker"

visited = set()
broken  = []
queue   = deque([START_URL])
base    = urlparse(START_URL).netloc

def get_links(url, html):
    soup = BeautifulSoup(html, 'html.parser')
    for tag in soup.find_all(['a','link','img','script'], href=True):
        href = tag.get('href') or tag.get('src','')
        if href: yield urljoin(url, href)

print(f"=== BROKEN LINK CHECKER ===")
print(f"Crawling: {START_URL} (max {MAX_PAGES} pages)\n")

while queue and len(visited) < MAX_PAGES:
    url = queue.popleft()
    if url in visited: continue
    visited.add(url)

    try:
        r = requests.get(url, timeout=TIMEOUT,
                         headers={'User-Agent': USER_AGENT},
                         allow_redirects=True)
        status = r.status_code
        is_same_domain = urlparse(url).netloc == base

        if status >= 400:
            broken.append({'url': url, 'status': status})
            print(f"  BROKEN {status}: {url}")
        elif is_same_domain:
            for link in get_links(url, r.text):
                if link not in visited:
                    queue.append(link)
            print(f"  OK {status}: {url[:60]}")
    except Exception as e:
        broken.append({'url': url, 'status': 'ERR', 'error': str(e)[:40]})
        print(f"  ERROR: {url[:60]} — {e}")

print(f"\n=== REPORT ===")
print(f"Checked: {len(visited)} URLs | Broken: {len(broken)}")
for b in broken:
    print(f"  [{b['status']}] {b['url']}")`,
  },

  // ── DATA ──────────────────────────────────────────────────────
  {
    id: 'json-processor',
    title: 'JSON Data Processor and Validator',
    category: 'Data',
    tags: ['json', 'data', 'validate', 'transform', 'flatten', 'csv'],
    description: 'Parse, validate, flatten, and transform JSON data with CSV export',
    requirements: [],
    script: `import json, csv, io
from pathlib import Path

def flatten(d, prefix='', sep='.'):
    out = {}
    for k, v in d.items():
        key = f"{prefix}{sep}{k}" if prefix else k
        if isinstance(v, dict):
            out.update(flatten(v, key, sep))
        else:
            out[key] = v
    return out

data = {
    "users": [
        {"id":1,"name":"Alice","age":30,"active":True},
        {"id":2,"name":"Bob",  "age":25,"active":False},
        {"id":3,"name":"Carol","age":35,"active":True},
    ],
    "meta": {"total": 3, "page": 1}
}

print("JSON data:")
print(json.dumps(data, indent=2)[:400])

active_users = [u for u in data['users'] if u['active']]
print(f"\nActive users: {[u['name'] for u in active_users]}")

flat = flatten(data['users'][0])
print(f"\nFlattened user: {flat}")

out = io.StringIO()
w = csv.DictWriter(out, fieldnames=['id','name','age','active'])
w.writeheader(); w.writerows(data['users'])
print(f"\nCSV export:\n{out.getvalue()}")

Path("output.json").write_text(json.dumps(data, indent=2))
print("Saved: output.json")`,
  },
  {
    id: 'sqlite-automation',
    title: 'SQLite Database Automation',
    category: 'Data',
    tags: ['sqlite', 'database', 'sql', 'query', 'table', 'crud', 'export'],
    description: 'Automate SQLite database operations — create, insert, query, and export data',
    requirements: [],
    script: `import sqlite3, csv, json
from pathlib import Path
from datetime import datetime

DB_PATH = "butler_data.db"

def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def setup():
    with connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS scripts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT,
                code TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                run_count INTEGER DEFAULT 0
            )
        """)
    print(f"Database ready: {DB_PATH}")

def insert(name, category, code):
    with connect() as conn:
        conn.execute("INSERT INTO scripts (name,category,code) VALUES (?,?,?)",
                     (name, category, code))
    print(f"Inserted: {name}")

def list_all():
    with connect() as conn:
        rows = conn.execute("SELECT id,name,category,run_count FROM scripts").fetchall()
    print(f"\n{'ID':<4} {'Name':<25} {'Category':<15} Runs")
    for r in rows:
        print(f"  {r['id']:<4} {r['name']:<25} {r['category']:<15} {r['run_count']}")

def export_csv(output="scripts_export.csv"):
    with connect() as conn:
        rows = conn.execute("SELECT * FROM scripts").fetchall()
    if rows:
        with open(output, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=rows[0].keys())
            w.writeheader(); w.writerows([dict(r) for r in rows])
        print(f"Exported {len(rows)} rows to {output}")

setup()
insert("System Info", "System", "import platform; print(platform.node())")
insert("Disk Usage",  "Files",  "import shutil; print(shutil.disk_usage('/').used)")
list_all()
export_csv()`,
  },
  {
    id: 'data-anonymizer',
    title: 'PII Data Anonymizer',
    category: 'Data',
    tags: ['pii', 'anonymize', 'redact', 'privacy', 'gdpr', 'data', 'email'],
    description: 'Remove or mask PII (emails, phones, SSNs) from CSV and text datasets',
    requirements: [],
    script: `import re, csv, hashlib
from pathlib import Path

PATTERNS = {
    'email':  (r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', '[EMAIL]'),
    'phone':  (r'(?:\+?1[\s\-]?)?(?:\([0-9]{3}\)|[0-9]{3})[\s\-]?[0-9]{3}[\s\-]?[0-9]{4}', '[PHONE]'),
    'ssn':    (r'\b\d{3}-\d{2}-\d{4}\b', '[SSN]'),
    'ip':     (r'\b(?:\d{1,3}\.){3}\d{1,3}\b', '[IP]'),
}

def anonymize_text(text, mode='redact'):
    result = text
    for pii_type, (pattern, placeholder) in PATTERNS.items():
        for match in set(re.findall(pattern, result)):
            if mode == 'hash':
                h = hashlib.sha256(match.encode()).hexdigest()[:8]
                replacement = f"[{pii_type.upper()}:{h}]"
            else:
                replacement = placeholder
            result = result.replace(match, replacement)
    return result

def anonymize_csv(input_path, output_path, pii_columns):
    with open(input_path, newline='', encoding='utf-8') as f_in, \
         open(output_path, 'w', newline='', encoding='utf-8') as f_out:
        reader = csv.DictReader(f_in)
        writer = csv.DictWriter(f_out, fieldnames=reader.fieldnames)
        writer.writeheader()
        count = 0
        for row in reader:
            for col in pii_columns:
                if col in row: row[col] = anonymize_text(row[col])
            writer.writerow(row); count += 1
    print(f"Anonymized {count} rows -> {output_path}")

sample = "User Alice: alice@company.com, +1-555-123-4567, SSN 123-45-6789, IP 192.168.1.1"
print("Original:", sample)
print("Redacted:", anonymize_text(sample))
print("Hashed:  ", anonymize_text(sample, mode='hash'))`,
  },
  {
    id: 'xml-parser',
    title: 'XML Parser and Converter',
    category: 'Data',
    tags: ['xml', 'parse', 'convert', 'json', 'csv', 'soap', 'rss', 'atom'],
    description: 'Parse XML files including RSS feeds, SOAP responses, and configs, convert to JSON/CSV',
    requirements: [],
    script: `import xml.etree.ElementTree as ET
import json, csv
from pathlib import Path
from urllib.request import urlopen

def xml_to_dict(element):
    result = {}
    for child in element:
        tag = child.tag.split('}')[-1]
        text = (child.text or '').strip()
        if len(child) == 0:
            result[tag] = text
        else:
            result[tag] = xml_to_dict(child)
    return result

def parse_rss(url):
    print(f"Fetching RSS: {url[:60]}")
    try:
        with urlopen(url, timeout=10) as r:
            root = ET.fromstring(r.read())
        items = []
        for item in root.findall('.//item')[:10]:
            entry = {}
            for field in ['title','link','pubDate','description']:
                el = item.find(field)
                if el is not None:
                    entry[field] = (el.text or '').strip()[:100]
            items.append(entry)
        return items
    except Exception as e:
        print(f"Error: {e}"); return []

RSS_URL = "https://feeds.bbci.co.uk/news/rss.xml"
items = parse_rss(RSS_URL)

print(f"\nFound {len(items)} items:")
for i, item in enumerate(items[:5], 1):
    print(f"\n  {i}. {item.get('title','?')}")
    print(f"     {item.get('pubDate','?')}")

if items:
    Path("rss_data.json").write_text(json.dumps(items, indent=2))
    with open("rss_data.csv","w",newline='') as f:
        w = csv.DictWriter(f, fieldnames=items[0].keys())
        w.writeheader(); w.writerows(items)
    print(f"\nSaved: rss_data.json + rss_data.csv")`,
  },

  // ── SETUP ─────────────────────────────────────────────────────
  {
    id: 'git-automation',
    title: 'Git Workflow Automator',
    category: 'Setup',
    tags: ['git', 'commit', 'push', 'pull', 'branch', 'workflow', 'automate', 'changelog'],
    description: 'Automate git workflows — smart commits, branch creation, changelog generation',
    requirements: [],
    script: `import subprocess, sys
from datetime import datetime
from pathlib import Path

def git(*args, check=False):
    r = subprocess.run(["git"] + list(args), capture_output=True, text=True)
    if check and r.returncode != 0: raise Exception(r.stderr.strip())
    return r.stdout.strip(), r.returncode

def status():
    out, _ = git("status", "--short")
    return out

def smart_commit(message=None):
    if not status():
        print("Nothing to commit"); return
    git("add", "-A")
    print("Staged all changes")
    if not message:
        files, _ = git("diff", "--cached", "--name-only")
        changed = [f for f in files.split("\n") if f][:3]
        verb = "Update" if any(f.endswith(('.py','.ts','.js')) for f in changed) else "Add"
        message = f"{verb} {', '.join(changed[:2])}"
    git("commit", "-m", message)
    print(f"Committed: {message}")

def generate_changelog():
    log, _ = git("log", "--oneline", "-20")
    today = datetime.now().strftime('%Y-%m-%d')
    changelog = f"## Changelog — {today}\n\n"
    for line in log.split("\n"):
        if line: changelog += f"- {line[8:]}\n"
    Path("CHANGELOG.md").write_text(changelog)
    print(f"Generated CHANGELOG.md ({len(log.splitlines())} entries)")
    print(changelog[:300])

print("=== GIT WORKFLOW AUTOMATOR ===")
print(f"Status:\n{status() or 'Clean working tree'}")
# smart_commit("feat: add new feature")
generate_changelog()`,
  },
  {
    id: 'cron-manager',
    title: 'Cron Job Manager Linux Mac',
    category: 'Setup',
    tags: ['cron', 'schedule', 'linux', 'mac', 'crontab', 'automate', 'timer'],
    description: 'Add, list, and remove cron jobs programmatically on Linux and Mac',
    requirements: [],
    script: `import subprocess, sys

if sys.platform == 'win32':
    print("Linux/Mac only. Use Task Scheduler script for Windows."); exit()

def get_crontab():
    r = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
    if r.returncode != 0: return []
    return [l for l in r.stdout.strip().split("\n") if l]

def set_crontab(lines):
    content = "\n".join(lines) + "\n"
    proc = subprocess.Popen(["crontab", "-"], stdin=subprocess.PIPE)
    proc.communicate(content.encode())

def add_cron(schedule, command, label=""):
    lines = get_crontab()
    if command in "\n".join(lines):
        print(f"Already exists: {command[:50]}"); return
    if label: lines.append(f"# {label}")
    lines.append(f"{schedule} {command}")
    set_crontab(lines)
    print(f"Added: {schedule} {command}")

def remove_cron(pattern):
    lines = get_crontab()
    new_lines = [l for l in lines if pattern not in l]
    removed = len(lines) - len(new_lines)
    set_crontab(new_lines)
    print(f"Removed {removed} cron job(s) matching: {pattern}")

def list_crons():
    lines = get_crontab()
    print(f"=== CRON JOBS ({len([l for l in lines if not l.startswith('#')])} jobs) ===")
    for line in lines:
        print(f"  {line}")

list_crons()
# add_cron("0 2 * * *",   "/usr/bin/python3 /home/user/backup.py",  "Daily Backup at 2am")
# add_cron("*/30 * * * *", "/usr/bin/python3 /home/user/monitor.py", "30min System Check")`,
  },
  {
    id: 'docker-composer',
    title: 'Docker Compose Auto Deploy',
    category: 'Setup',
    tags: ['docker', 'compose', 'deploy', 'container', 'yaml', 'stack', 'nginx'],
    description: 'Generate and deploy a Docker Compose stack with web, database, and cache services',
    requirements: [],
    script: `import subprocess
from pathlib import Path

COMPOSE_CONTENT = """version: '3.8'
services:
  web:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./html:/usr/share/nginx/html
    restart: unless-stopped

  db:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: myapp
      POSTGRES_USER: user
      POSTGRES_PASSWORD: secret
    volumes:
      - pg_data:/var/lib/postgresql/data
    restart: unless-stopped

  cache:
    image: redis:7-alpine
    restart: unless-stopped

volumes:
  pg_data:
"""

compose_file = Path("docker-compose.yml")
compose_file.write_text(COMPOSE_CONTENT.strip())
print(f"Written: {compose_file}")
print("\nStack: nginx (web) + postgres (db) + redis (cache)")

check = subprocess.run(["docker", "info"], capture_output=True)
if check.returncode != 0:
    print("\nDocker not running. Install Docker Desktop and try again."); exit()

def docker_compose(cmd):
    r = subprocess.run(["docker", "compose"] + cmd.split(), capture_output=True, text=True)
    print(r.stdout or r.stderr)
    return r.returncode == 0

print("\nPulling images...")
docker_compose("pull")
print("\nStarting stack...")
if docker_compose("up -d"):
    print("\nStack running!")
    docker_compose("ps")`,
  },
  {
    id: 'python-project-scaffolder',
    title: 'Python Project Scaffolder',
    category: 'Setup',
    tags: ['scaffold', 'project', 'structure', 'template', 'boilerplate', 'python', 'setup.py'],
    description: 'Create a complete Python project structure with tests, docs, CI/CD and config files',
    requirements: [],
    script: `import os, sys
from pathlib import Path

PROJECT_NAME = "my_project"
AUTHOR       = "Your Name"
EMAIL        = "your@email.com"
DESCRIPTION  = "A Python automation project"

root = Path(PROJECT_NAME)
files = {
    "README.md": f"# {PROJECT_NAME}\n\n{DESCRIPTION}\n\n## Setup\n\npip install -e .\npython -m {PROJECT_NAME}\n",
    "setup.py":  f"""from setuptools import setup, find_packages
setup(
    name="{PROJECT_NAME}",
    version="0.1.0",
    author="{AUTHOR}",
    author_email="{EMAIL}",
    description="{DESCRIPTION}",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.9",
)
""",
    ".gitignore": "__pycache__/\n*.pyc\n*.pyo\n.env\n.venv/\ndist/\nbuild/\n*.egg-info/\n",
    ".env.example": "# Environment variables\nDEBUG=True\nAPI_KEY=your_key_here\n",
    f"{PROJECT_NAME}/__init__.py": f'"""\\n{DESCRIPTION}\\n"""\n__version__ = "0.1.0"\n',
    f"{PROJECT_NAME}/__main__.py": f"""def main():
    print(f"{PROJECT_NAME} running!")

if __name__ == "__main__":
    main()
""",
    "tests/__init__.py": "",
    "tests/test_main.py": f"""import pytest
from {PROJECT_NAME} import __version__

def test_version():
    assert __version__ == "0.1.0"
""",
    ".github/workflows/ci.yml": f"""name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {{python-version: "3.11"}}
      - run: pip install -e . pytest
      - run: pytest
""",
}

for path_str, content in files.items():
    path = root / path_str
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')
    print(f"  Created: {path}")

print(f"\nProject '{PROJECT_NAME}' scaffolded!")
print(f"cd {PROJECT_NAME} && pip install -e . && python -m {PROJECT_NAME}")`,
  },

  // ── PRIVACY ───────────────────────────────────────────────────
  {
    id: 'wifi-security-scan',
    title: 'WiFi Network Security Scanner',
    category: 'Privacy',
    tags: ['wifi', 'scan', 'security', 'networks', 'ssid', 'wpa', 'open'],
    description: 'Scan nearby WiFi networks and evaluate their security posture',
    requirements: [],
    script: `import subprocess, sys

print("=== WIFI NETWORK SCANNER ===")

def scan_windows():
    r = subprocess.run(["netsh","wlan","show","networks","mode=bssid"],
                       capture_output=True, text=True)
    networks = []; current = {}
    for line in r.stdout.split("\n"):
        line = line.strip()
        if line.startswith("SSID") and "BSSID" not in line:
            if current: networks.append(current)
            current = {'ssid': line.split(":",1)[1].strip() if ":" in line else ""}
        elif "Authentication" in line and ":" in line:
            current['auth'] = line.split(":",1)[1].strip()
        elif "Signal" in line and ":" in line:
            current['signal'] = line.split(":",1)[1].strip()
    if current: networks.append(current)
    return networks

def rate_security(auth):
    if not auth: return "?"
    if "WPA3"  in auth: return "STRONG (WPA3)"
    if "WPA2"  in auth: return "GOOD (WPA2)"
    if "WPA"   in auth: return "FAIR (WPA)"
    if "Open"  in auth: return "OPEN - NO ENCRYPTION!"
    return "UNKNOWN"

if sys.platform == 'win32':
    nets = scan_windows()
    print(f"Found {len(nets)} networks:\n")
    print(f"{'SSID':32} {'Security':25} Signal")
    print("-" * 65)
    for n in nets:
        ssid = n.get('ssid','?')[:30]
        sec  = rate_security(n.get('auth',''))
        print(f"  {ssid:32} {sec:25} {n.get('signal','?')}")
else:
    r = subprocess.run(["nmcli","-f","SSID,SIGNAL,SECURITY","dev","wifi"],
                       capture_output=True, text=True)
    print(r.stdout if r.returncode==0 else "Run: sudo nmcli dev wifi")`,
  },
  {
    id: 'dns-benchmark',
    title: 'DNS Benchmark and Privacy Checker',
    category: 'Privacy',
    tags: ['dns', 'benchmark', 'speed', 'resolver', 'flush', 'cache', 'privacy'],
    description: 'Benchmark DNS servers for speed and recommend best privacy-focused resolver',
    requirements: [],
    script: `import socket, time, subprocess, sys

DNS_SERVERS = {
    "Google 8.8.8.8":      "8.8.8.8",
    "Google 8.8.4.4":      "8.8.4.4",
    "Cloudflare 1.1.1.1":  "1.1.1.1",
    "Cloudflare 1.0.0.1":  "1.0.0.1",
    "Quad9 9.9.9.9":       "9.9.9.9",
    "OpenDNS 208.67.222":  "208.67.222.222",
}

TEST_DOMAINS = ["google.com", "github.com", "youtube.com"]

def test_dns(domain):
    times = []
    for _ in range(3):
        start = time.perf_counter()
        try:
            socket.gethostbyname(domain)
            times.append((time.perf_counter() - start) * 1000)
        except: times.append(9999)
    return min(times)

print("=== DNS BENCHMARK ===\n")
results = []
for name, ip in DNS_SERVERS.items():
    lats = [test_dns(d) for d in TEST_DOMAINS[:2]]
    avg  = sum(lats) / len(lats)
    results.append((avg, name, ip))
    print(f"  {name:30} {avg:6.0f}ms")

winner = min(results)
print(f"\nFastest: {winner[1]} ({winner[0]:.0f}ms) [{winner[2]}]")
print("\nPrivacy note: Cloudflare 1.1.1.1 = fastest + no-logging policy")

print("\nFlushing DNS cache...")
if sys.platform == 'win32':
    subprocess.run("ipconfig /flushdns", shell=True)
elif sys.platform == 'darwin':
    subprocess.run("sudo dscacheutil -flushcache; sudo killall -HUP mDNSResponder", shell=True)
else:
    subprocess.run("sudo systemd-resolve --flush-caches 2>/dev/null || sudo resolvectl flush-caches",
                   shell=True)
print("DNS cache flushed!")`,
  },
  {
    id: 'hosts-ad-blocker',
    title: 'Hosts File Ad Blocker',
    category: 'Privacy',
    tags: ['ads', 'block', 'hosts', 'privacy', 'tracker', 'dns', 'adblock'],
    description: 'Add ad-blocking rules to the system hosts file to block thousands of ad domains',
    requirements: [],
    script: `import sys, urllib.request
from pathlib import Path
from datetime import datetime

HOSTS_FILE = Path("C:/Windows/System32/drivers/etc/hosts") if sys.platform == 'win32' else Path("/etc/hosts")
BACKUP     = HOSTS_FILE.parent / f"hosts.backup.{datetime.now().strftime('%Y%m%d')}"

SAMPLE_BLOCKS = [
    "0.0.0.0 ads.google.com",
    "0.0.0.0 doubleclick.net",
    "0.0.0.0 googlesyndication.com",
    "0.0.0.0 googleadservices.com",
    "0.0.0.0 adservice.google.com",
    "0.0.0.0 analytics.google.com",
    "0.0.0.0 facebook.com/tr",
    "0.0.0.0 pixel.facebook.com",
    "0.0.0.0 connect.facebook.net",
    "0.0.0.0 scorecardresearch.com",
    "0.0.0.0 outbrain.com",
    "0.0.0.0 taboola.com",
    "0.0.0.0 bing.com/fd",
    "0.0.0.0 ads.yahoo.com",
    "0.0.0.0 amazon-adsystem.com",
]

print("=== HOSTS AD BLOCKER ===")
print(f"Hosts file: {HOSTS_FILE}")

if not HOSTS_FILE.exists():
    print("Hosts file not found"); exit()

current = HOSTS_FILE.read_text(errors='replace')

marker_start = "# BEGIN BUTLER_AD_BLOCK"
marker_end   = "# END BUTLER_AD_BLOCK"

block = f"{marker_start}\n"
block += "\n".join(SAMPLE_BLOCKS)
block += f"\n{marker_end}\n"

if marker_start in current:
    import re
    current = re.sub(f"{marker_start}.*?{marker_end}", block.strip(), current, flags=re.DOTALL)
    print("Updating existing block...")
else:
    current += f"\n{block}"
    print("Adding new block...")

print(f"\nWould add {len(SAMPLE_BLOCKS)} ad domain blocks")
print("Preview:\n" + "\n".join(SAMPLE_BLOCKS[:5]) + "\n...")
print("\nTo apply (requires admin/sudo):")
print(f"  Replace {HOSTS_FILE} with the updated version")
print("\nAlternative: use browser extension uBlock Origin")`,
  },

  // ── BACKUP ────────────────────────────────────────────────────
  {
    id: 'backup-verifier',
    title: 'Backup Integrity Verifier',
    category: 'Backup',
    tags: ['backup', 'verify', 'checksum', 'integrity', 'restore', 'test'],
    description: 'Verify backup ZIP integrity using checksums and report corrupted archives',
    requirements: [],
    script: `import hashlib, zipfile, json
from pathlib import Path
from datetime import datetime

BACKUP_DIR = Path.home() / "Backups"

def hash_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def verify_zip(zip_path):
    try:
        with zipfile.ZipFile(zip_path) as zf:
            bad = zf.testzip()
            if bad: return False, f"Corrupted file: {bad}"
            return True, f"OK — {len(zf.namelist())} files"
    except Exception as e:
        return False, str(e)

report = {"ts": datetime.now().isoformat(), "checked": 0, "ok": 0, "failed": 0, "details": []}

print(f"=== BACKUP VERIFIER ===")
print(f"Directory: {BACKUP_DIR}\n")

if not BACKUP_DIR.exists():
    print(f"Backup dir not found: {BACKUP_DIR}"); exit()

for backup in sorted(BACKUP_DIR.rglob("*.zip")):
    ok, msg = verify_zip(backup)
    h = hash_file(backup)
    report["checked"] += 1
    report["ok" if ok else "failed"] += 1
    report["details"].append({"file": backup.name, "ok": ok, "msg": msg, "hash": h[:16]})
    status = "OK  " if ok else "FAIL"
    print(f"  {status} {backup.name:40} {msg}")

print(f"\nSummary: {report['ok']}/{report['checked']} OK | {report['failed']} FAILED")
Path("backup_report.json").write_text(json.dumps(report, indent=2))
print("Report saved: backup_report.json")`,
  },
  {
    id: 'cloud-sync-checker',
    title: 'File Sync Change Detector',
    category: 'Backup',
    tags: ['cloud', 'sync', 'backup', 'check', 'missing', 'files', 'diff'],
    description: 'Detect new, deleted, and changed files between scans for backup validation',
    requirements: [],
    script: `import hashlib, json
from pathlib import Path
from datetime import datetime

LOCAL_DIR   = Path.home() / "Documents"
REPORT_FILE = Path("sync_report.json")

def hash_file(path):
    h = hashlib.md5()
    try:
        with open(path, 'rb') as f:
            while chunk := f.read(65536):
                h.update(chunk)
        return h.hexdigest()
    except: return None

def scan(directory):
    manifest = {}
    for f in Path(directory).rglob('*'):
        if not f.is_file(): continue
        try:
            rel = str(f.relative_to(directory))
            manifest[rel] = {'size': f.stat().st_size, 'hash': hash_file(f)}
        except: pass
    return manifest

print(f"Scanning {LOCAL_DIR}...")
current = scan(LOCAL_DIR)
print(f"Found {len(current)} files")

if REPORT_FILE.exists():
    previous = json.loads(REPORT_FILE.read_text())
    prev_manifest = previous.get('manifest', {})
    new_files     = [f for f in current if f not in prev_manifest]
    deleted_files = [f for f in prev_manifest if f not in current]
    changed_files = [
        f for f in current
        if f in prev_manifest and current[f]['hash'] != prev_manifest[f]['hash']
    ]
    print(f"\nChanges since {previous.get('ts','?')[:16]}:")
    print(f"  New files:     {len(new_files)}")
    print(f"  Deleted files: {len(deleted_files)}")
    print(f"  Changed files: {len(changed_files)}")
    for f in new_files[:5]:     print(f"    + {f}")
    for f in deleted_files[:5]: print(f"    - {f}")
    for f in changed_files[:5]: print(f"    ~ {f}")
else:
    print("First scan — baseline created")

REPORT_FILE.write_text(json.dumps({'ts': datetime.now().isoformat(), 'manifest': current}, indent=2))
print(f"\nManifest saved ({len(current)} files)")`,
  },
  {
    id: 'database-dumper',
    title: 'Database Backup Dumper',
    category: 'Backup',
    tags: ['database', 'backup', 'mysql', 'postgres', 'mongodb', 'dump'],
    description: 'Auto-backup MySQL, PostgreSQL, MongoDB databases to compressed archives',
    requirements: [],
    script: `import subprocess, os
from pathlib import Path
from datetime import datetime

BACKUP_DIR = Path.home() / "db_backups"
BACKUP_DIR.mkdir(exist_ok=True)
ts = datetime.now().strftime("%Y%m%d_%H%M%S")

MYSQL_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'your_password',
    'database': 'mydb',
}

def backup_mysql():
    out_file = BACKUP_DIR / f"mysql_{MYSQL_CONFIG['database']}_{ts}.sql.gz"
    cmd = (
        f"mysqldump -h {MYSQL_CONFIG['host']} "
        f"-u {MYSQL_CONFIG['user']} "
        f"-p{MYSQL_CONFIG['password']} "
        f"{MYSQL_CONFIG['database']} | gzip > {out_file}"
    )
    r = subprocess.run(cmd, shell=True, capture_output=True)
    if r.returncode == 0:
        size = out_file.stat().st_size / 1024
        print(f"  MySQL: {out_file.name} ({size:.0f}KB)")
    else:
        print(f"  MySQL error: {r.stderr.decode()[:100]}")

def backup_postgres(db='postgres'):
    out_file = BACKUP_DIR / f"pg_{db}_{ts}.sql.gz"
    env = {**os.environ, 'PGPASSWORD': 'your_password'}
    cmd = f"pg_dump -U postgres {db} | gzip > {out_file}"
    r = subprocess.run(cmd, shell=True, env=env, capture_output=True)
    print(f"  PostgreSQL: {'OK' if r.returncode==0 else r.stderr.decode()[:80]}")

def backup_mongo(db='mydb'):
    out_dir = BACKUP_DIR / f"mongo_{db}_{ts}"
    r = subprocess.run(
        ["mongodump", "--db", db, "--out", str(out_dir)],
        capture_output=True, text=True
    )
    print(f"  MongoDB: {'OK' if r.returncode==0 else r.stderr[:80]}")

print(f"=== DATABASE BACKUP [{ts}] ===")
backup_mysql()
# backup_postgres()
# backup_mongo()
print("\nBackups saved to:", BACKUP_DIR)`,
  },

  // ── PERFORMANCE ───────────────────────────────────────────────
  {
    id: 'code-profiler',
    title: 'Python Code Profiler and Optimizer',
    category: 'Performance',
    tags: ['profile', 'benchmark', 'optimize', 'cprofile', 'timing', 'python', 'bottleneck'],
    description: 'Profile Python code to find bottlenecks and benchmark alternatives',
    requirements: [],
    script: `import cProfile, pstats, io, time, math

def timeit(func, *args, runs=5, **kwargs):
    times = []
    for _ in range(runs):
        start = time.perf_counter()
        func(*args, **kwargs)
        times.append(time.perf_counter() - start)
    avg = sum(times) / runs
    print(f"  {func.__name__:25} avg {avg*1000:8.2f}ms  "
          f"min {min(times)*1000:.2f}ms  max {max(times)*1000:.2f}ms")

def sum_squares_slow(n):
    return sum(i ** 2 for i in range(n))

def sum_squares_fast(n):
    return n * (n-1) * (2*n-1) // 6

def find_primes_slow(limit):
    return [n for n in range(2, limit)
            if all(n % i != 0 for i in range(2, int(n**0.5)+1))]

def find_primes_sieve(limit):
    sieve = [True] * limit
    sieve[0] = sieve[1] = False
    for i in range(2, int(limit**0.5)+1):
        if sieve[i]:
            for j in range(i*i, limit, i): sieve[j] = False
    return [i for i, p in enumerate(sieve) if p]

N = 10000
print("=== BENCHMARK COMPARISON ===\n")
timeit(sum_squares_slow, N)
timeit(sum_squares_fast, N)
print()
timeit(find_primes_slow, N, runs=3)
timeit(find_primes_sieve, N)

print("\n=== CPROFILE OUTPUT ===")
pr = cProfile.Profile()
pr.enable()
find_primes_slow(5000)
pr.disable()
s = io.StringIO()
pstats.Stats(pr, stream=s).sort_stats('cumulative').print_stats(8)
print(s.getvalue())`,
  },
  {
    id: 'tcp-stack-optimizer',
    title: 'TCP Network Stack Optimizer',
    category: 'Performance',
    tags: ['network', 'tcp', 'optimize', 'sysctl', 'buffer', 'performance', 'linux'],
    description: 'Tune TCP/IP kernel parameters for maximum network throughput and low latency',
    requirements: [],
    script: `import subprocess, sys

if sys.platform == 'win32':
    print("=== WINDOWS TCP OPTIMIZER ===")
    tweaks = [
        ("netsh int tcp set global autotuninglevel=normal",  "TCP AutoTuning: normal"),
        ("netsh int tcp set global rss=enabled",             "RSS (Receive Side Scaling): on"),
        ("netsh int tcp set global ecncapability=enabled",   "ECN: enabled"),
        ("netsh int tcp set global chimney=enabled",         "TCP Chimney Offload: on"),
    ]
    for cmd, label in tweaks:
        r = subprocess.run(cmd, shell=True, capture_output=True)
        tag = "OK  " if r.returncode == 0 else "SKIP"
        print(f"  [{tag}] {label}")
    print("\nRun: netsh int tcp show global (to verify)")
else:
    print("=== LINUX TCP OPTIMIZER ===")
    print("(These settings require sudo)\n")
    SETTINGS = {
        'net.core.rmem_max':              '134217728',
        'net.core.wmem_max':              '134217728',
        'net.ipv4.tcp_rmem':             '4096 87380 134217728',
        'net.ipv4.tcp_wmem':             '4096 65536 134217728',
        'net.ipv4.tcp_fastopen':          '3',
        'net.ipv4.tcp_mtu_probing':       '1',
        'net.core.netdev_max_backlog':    '250000',
        'net.core.somaxconn':             '65535',
        'net.ipv4.tcp_tw_reuse':          '1',
    }
    for key, val in SETTINGS.items():
        r = subprocess.run(f"sudo sysctl -w {key}='{val}'", shell=True, capture_output=True, text=True)
        tag = "OK  " if r.returncode == 0 else "ERR "
        print(f"  [{tag}] {key} = {val}")
    print("\nTo persist: sudo sysctl -p")`,
  },
  {
    id: 'memory-profiler',
    title: 'Memory Usage Profiler',
    category: 'Performance',
    tags: ['memory', 'profile', 'leak', 'usage', 'trace', 'optimize', 'ram'],
    description: 'Profile memory usage of Python code to detect leaks and excessive allocations',
    requirements: ['memory-profiler'],
    script: `import tracemalloc, sys, gc
from datetime import datetime

print("=== MEMORY USAGE PROFILER ===")
print(f"Python: {sys.version.split()[0]}")

# Start tracing memory
tracemalloc.start()

# ── Code to profile ─────────────────────────────────────────
big_list = [str(i) * 100 for i in range(10000)]
big_dict = {i: [j for j in range(100)] for i in range(100)}
matrix   = [[0.0] * 100 for _ in range(100)]
# ────────────────────────────────────────────────────────────

snapshot = tracemalloc.take_snapshot()
top_stats = snapshot.statistics('lineno')

print("\nTop 10 memory allocations:")
for stat in top_stats[:10]:
    print(f"  {stat.size/1024:8.1f}KB  {stat}")

current, peak = tracemalloc.get_traced_memory()
tracemalloc.stop()

print(f"\nCurrent memory: {current/1024**2:.2f}MB")
print(f"Peak memory:    {peak/1024**2:.2f}MB")

# GC stats
print(f"\nGarbage Collector:")
print(f"  Collections: {gc.get_count()}")
collected = gc.collect()
print(f"  Collected:   {collected} objects")

# System memory
import psutil
vm = psutil.virtual_memory()
print(f"\nSystem RAM: {vm.used/1024**3:.1f}/{vm.total/1024**3:.1f}GB ({vm.percent}%)")`,
  },

  // ── TEXT ──────────────────────────────────────────────────────
  {
    id: 'markdown-converter',
    title: 'Markdown to HTML Batch Converter',
    category: 'Text',
    tags: ['markdown', 'html', 'pdf', 'convert', 'doc', 'readme', 'batch'],
    description: 'Convert all Markdown files in a directory to styled HTML documents',
    requirements: ['markdown'],
    script: `from pathlib import Path
import markdown

CSS = """
body{font-family:Arial,sans-serif;max-width:800px;margin:40px auto;padding:0 20px;line-height:1.6;color:#333}
h1,h2,h3{color:#2c3e50;border-bottom:2px solid #eee;padding-bottom:8px}
code{background:#f4f4f4;padding:2px 6px;border-radius:3px;font-family:monospace;font-size:0.9em}
pre code{display:block;padding:12px;overflow-x:auto}
blockquote{border-left:4px solid #3498db;margin:0;padding:0 16px;color:#666}
table{border-collapse:collapse;width:100%}
td,th{border:1px solid #ddd;padding:8px;text-align:left}
th{background:#f2f2f2}
"""

def md_to_html(md_file, out_file=None):
    md_path   = Path(md_file)
    content   = md_path.read_text(encoding='utf-8')
    html_body = markdown.markdown(content, extensions=['tables','fenced_code','toc'])
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{md_path.stem}</title>
<style>{CSS}</style></head>
<body>{html_body}</body></html>"""
    out = Path(out_file or md_path.with_suffix('.html'))
    out.write_text(html, encoding='utf-8')
    print(f"  {md_path.name:35} -> {out.name} ({out.stat().st_size//1024}KB)")
    return out

count = 0
for md_file in Path('.').glob("**/*.md"):
    try: md_to_html(md_file); count += 1
    except Exception as e: print(f"  Error {md_file.name}: {e}")

if count == 0:
    sample = Path("sample.md")
    sample.write_text("# Hello\n\nThis is a **Markdown** test.\n\nprint('hello')\n")
    md_to_html(sample); count = 1

print(f"\nConverted {count} Markdown files to HTML")`,
  },
  {
    id: 'regex-batch-extractor',
    title: 'Regex Pattern Batch Extractor',
    category: 'Text',
    tags: ['regex', 'extract', 'pattern', 'search', 'grep', 'batch', 'email', 'ip', 'url'],
    description: 'Extract emails, IPs, URLs, phone numbers from multiple files using regex',
    requirements: [],
    script: `import re
from pathlib import Path
from collections import defaultdict

PATTERNS = {
    'emails':     r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}',
    'urls':       r'https?://[^\s<>"{}|^\[\]]+',
    'ipv4':       r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
    'phones':     r'(?:\+?1[\s-]?)?(?:\([0-9]{3}\)|[0-9]{3})[\s\-]?[0-9]{3}[\s\-]?[0-9]{4}',
    'dates_iso':  r'\b\d{4}-\d{2}-\d{2}\b',
    'hex_colors': r'#[0-9a-fA-F]{6}\b',
}

def extract_from_text(text):
    results = {}
    for name, pattern in PATTERNS.items():
        found = list(set(re.findall(pattern, text)))
        if found: results[name] = found
    return results

SCAN_DIR  = Path(".")
SCAN_EXTS = ['*.txt','*.log','*.html','*.csv','*.md','*.py','*.json']
all_found = defaultdict(set)
files_scanned = 0

for ext in SCAN_EXTS:
    for f in SCAN_DIR.rglob(ext):
        try:
            found = extract_from_text(f.read_text(errors='replace'))
            if found:
                files_scanned += 1
                for key, vals in found.items():
                    all_found[key].update(vals)
                    print(f"  {f.name:30} {key}: {len(vals)} found")
        except: pass

print(f"\n=== SUMMARY ({files_scanned} files scanned) ===")
for key, vals in all_found.items():
    print(f"  {key:15}: {len(vals)} unique")
    for v in list(vals)[:3]:
        print(f"    {v[:70]}")`,
  },
  {
    id: 'text-diff-tool',
    title: 'Text Diff and Comparison Tool',
    category: 'Text',
    tags: ['diff', 'compare', 'text', 'file', 'delta', 'changes', 'version'],
    description: 'Compare two text files or strings and show a colored diff of changes',
    requirements: [],
    script: `import difflib
from pathlib import Path

def diff_files(file1, file2):
    path1 = Path(file1); path2 = Path(file2)
    if not path1.exists(): print(f"Not found: {file1}"); return
    if not path2.exists(): print(f"Not found: {file2}"); return
    text1 = path1.read_text(errors='replace').splitlines()
    text2 = path2.read_text(errors='replace').splitlines()
    return diff_texts(text1, text2, path1.name, path2.name)

def diff_texts(text1, text2, label1="A", label2="B"):
    if isinstance(text1, str): text1 = text1.splitlines()
    if isinstance(text2, str): text2 = text2.splitlines()

    diff = list(difflib.unified_diff(text1, text2, fromfile=label1, tofile=label2, lineterm=''))

    if not diff:
        print("Files are identical!"); return

    added   = sum(1 for l in diff if l.startswith('+') and not l.startswith('+++'))
    removed = sum(1 for l in diff if l.startswith('-') and not l.startswith('---'))
    print(f"Changes: +{added} added  -{removed} removed  total lines: {len(text1)}/{len(text2)}\n")

    for line in diff[:100]:
        if line.startswith('+'): print(f"  ADD: {line[1:][:80]}")
        elif line.startswith('-'): print(f"  DEL: {line[1:][:80]}")
        elif line.startswith('@@'): print(f"\n  {line}")

    ratio = difflib.SequenceMatcher(None, text1, text2).ratio()
    print(f"\nSimilarity: {ratio*100:.1f}%")

# Example comparison
TEXT_A = ["line 1", "line 2", "line 3", "old line 4"]
TEXT_B = ["line 1", "line 2 modified", "line 3", "new line 5"]

print("=== TEXT DIFF TOOL ===")
diff_texts(TEXT_A, TEXT_B, "version_1.txt", "version_2.txt")

# File comparison (uncomment):
# diff_files("config_old.txt", "config_new.txt")`,
  },

  // ── EMAIL ─────────────────────────────────────────────────────
  {
    id: 'slack-discord-notifier',
    title: 'Slack and Discord Notifier',
    category: 'Email',
    tags: ['slack', 'discord', 'webhook', 'notify', 'alert', 'message', 'bot'],
    description: 'Send formatted alerts and notifications to Slack and Discord via webhooks',
    requirements: ['requests'],
    script: `import requests, json
from datetime import datetime

SLACK_WEBHOOK   = "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
DISCORD_WEBHOOK = "https://discord.com/api/webhooks/YOUR/DISCORD_WEBHOOK"

def send_slack(message, title=None, color="good", fields=None):
    payload = {"attachments": [{
        "color":   color,
        "title":   title or "Butler AI Alert",
        "text":    message,
        "fields":  fields or [],
        "footer":  f"Butler AI * {datetime.now().strftime('%H:%M:%S')}",
    }]}
    r = requests.post(SLACK_WEBHOOK, json=payload, timeout=10)
    return r.status_code == 200

def send_discord(message, title=None, color=0x00ccdd, fields=None):
    embed = {
        "title":       title or "Notification",
        "description": message,
        "color":       color,
        "fields":      fields or [],
        "footer":      {"text": datetime.now().strftime('%Y-%m-%d %H:%M:%S')},
    }
    payload = {"username": "Butler AI", "embeds": [embed]}
    r = requests.post(DISCORD_WEBHOOK, json=payload, timeout=10)
    return r.status_code == 204

def notify(msg, level="info", title=None):
    COLORS = {"info": ("good",0x00ff88), "warning": ("warning",0xff8c00), "error": ("danger",0xff3300)}
    slack_col, dc_col = COLORS.get(level, ("good",0x00ccdd))
    print(f"[{level.upper()}] {msg}")
    results = []
    if "YOUR" not in SLACK_WEBHOOK:
        ok = send_slack(msg, title=title, color=slack_col)
        results.append(f"Slack: {'OK' if ok else 'FAIL'}")
    if "YOUR" not in DISCORD_WEBHOOK:
        ok = send_discord(msg, title=title, color=dc_col)
        results.append(f"Discord: {'OK' if ok else 'FAIL'}")
    if results: print("  " + " | ".join(results))
    else: print("  Configure SLACK_WEBHOOK and DISCORD_WEBHOOK URLs to send notifications")

notify("Butler AI automation complete", "info", "System Status")
# notify("CPU at 95% — check processes!", "warning", "Performance Alert")
# notify("Disk full on /dev/sda1", "error", "Critical Alert")`,
  },
  {
    id: 'email-inbox-monitor',
    title: 'Email Inbox Monitor and Filter',
    category: 'Email',
    tags: ['email', 'imap', 'monitor', 'inbox', 'gmail', 'read', 'filter', 'automate'],
    description: 'Monitor email inbox via IMAP, filter by sender/subject, and trigger actions',
    requirements: [],
    script: `import imaplib, email
from email.header import decode_header
from datetime import datetime

IMAP_HOST  = "imap.gmail.com"
EMAIL_ADDR = "your.email@gmail.com"
PASSWORD   = "your_app_password"
MAILBOX    = "INBOX"
MAX_EMAILS = 10

FILTERS = {
    'important': ['boss@company.com', 'urgent@domain.com'],
    'invoices':  ['billing@'],
}

def decode_str(s):
    if not s: return ""
    parts = []
    for part, enc in decode_header(s):
        if isinstance(part, bytes):
            parts.append(part.decode(enc or 'utf-8', errors='replace'))
        else:
            parts.append(str(part))
    return " ".join(parts)

def categorize(sender, subject):
    for category, keywords in FILTERS.items():
        if any(k in sender.lower() or k in subject.lower() for k in keywords):
            return category
    return "general"

try:
    with imaplib.IMAP4_SSL(IMAP_HOST) as mail:
        mail.login(EMAIL_ADDR, PASSWORD)
        mail.select(MAILBOX)
        _, ids = mail.search(None, 'UNSEEN')
        email_ids = ids[0].split()
        print(f"=== EMAIL MONITOR ===")
        print(f"Unread emails: {len(email_ids)}\n")
        for eid in email_ids[-MAX_EMAILS:]:
            _, data = mail.fetch(eid, '(RFC822)')
            msg = email.message_from_bytes(data[0][1])
            subject = decode_str(msg['Subject'])
            sender  = decode_str(msg['From'])
            cat     = categorize(sender, subject)
            print(f"  [{cat.upper():10}] From: {sender[:35]:35} | {subject[:40]}")
except Exception as e:
    print(f"Error: {e}")
    print("\nSetup: Enable IMAP in Gmail Settings")
    print("Use Gmail App Password (not regular password)")`,
  },
  {
    id: 'newsletter-monitor',
    title: 'RSS Newsletter and News Aggregator',
    category: 'Email',
    tags: ['rss', 'news', 'newsletter', 'aggregate', 'feed', 'email', 'digest'],
    description: 'Aggregate RSS feeds and generate a daily HTML email digest with top stories',
    requirements: ['requests', 'beautifulsoup4'],
    script: `import requests
from bs4 import BeautifulSoup
from pathlib import Path
from datetime import datetime

FEEDS = [
    ("Hacker News",    "https://news.ycombinator.com/rss"),
    ("Python News",    "https://feeds.feedburner.com/PythonInsider"),
    ("Tech Crunch",    "https://techcrunch.com/feed/"),
    ("GitHub Trending","https://github.com/trending"),
]

MAX_PER_FEED = 5

def fetch_rss(name, url):
    try:
        r = requests.get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0'})
        soup = BeautifulSoup(r.content, 'xml')
        items = []
        for item in soup.find_all('item')[:MAX_PER_FEED]:
            title = item.find('title')
            link  = item.find('link')
            pub   = item.find('pubDate')
            if title and link:
                items.append({
                    'title': title.get_text()[:80],
                    'url':   link.get_text()[:150],
                    'date':  pub.get_text()[:30] if pub else '?',
                })
        return items
    except Exception as e:
        print(f"  Error {name}: {e}"); return []

print(f"=== DAILY NEWS DIGEST — {datetime.now().strftime('%Y-%m-%d')} ===\n")

all_items = []
for name, url in FEEDS:
    items = fetch_rss(name, url)
    if items:
        print(f"\n{name} ({len(items)} articles):")
        for item in items:
            print(f"  • {item['title']}")
        all_items.append((name, items))

html = f"<html><body><h1>Daily Digest — {datetime.now().strftime('%Y-%m-%d')}</h1>"
for name, items in all_items:
    html += f"<h2>{name}</h2><ul>"
    for item in items:
        html += f"<li><a href='{item['url']}'>{item['title']}</a></li>"
    html += "</ul>"
html += "</body></html>"

Path("daily_digest.html").write_text(html, encoding='utf-8')
total = sum(len(items) for _, items in all_items)
print(f"\nDigest saved: daily_digest.html ({total} articles)")`,
  },

  // ── GUI ───────────────────────────────────────────────────────
  {
    id: 'screen-timelapse',
    title: 'Screen Time-Lapse Recorder',
    category: 'GUI',
    tags: ['screen', 'record', 'capture', 'video', 'screenshot', 'time-lapse'],
    description: 'Capture screenshots at regular intervals and compile into a time-lapse video',
    requirements: ['Pillow', 'pyautogui', 'opencv-python'],
    script: `import time
from pathlib import Path
from datetime import datetime

def timelapse(duration_sec=30, fps=1, output="timelapse.mp4"):
    try:
        import pyautogui, cv2, numpy as np
    except ImportError:
        print("pip install pyautogui opencv-python Pillow numpy"); return

    frame_dir = Path("timelapse_frames")
    frame_dir.mkdir(exist_ok=True)
    end_time  = time.time() + duration_sec
    frames    = []
    i = 0

    print(f"Recording {duration_sec}s at {fps}fps...")
    print("Move mouse to top-left corner to abort!")
    while time.time() < end_time:
        screenshot = pyautogui.screenshot()
        arr   = np.array(screenshot)
        frame = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
        path  = frame_dir / f"frame_{i:05d}.png"
        cv2.imwrite(str(path), frame)
        frames.append(str(path))
        print(f"  Frame {i:3d}: {end_time-time.time():.0f}s left", end='\r')
        time.sleep(1.0 / max(fps, 0.1)); i += 1

    if frames:
        h, w = cv2.imread(frames[0]).shape[:2]
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out_fps = max(fps * 10, 10)
        out = cv2.VideoWriter(output, fourcc, out_fps, (w, h))
        for f in frames:
            out.write(cv2.imread(f))
        out.release()
        print(f"\nSaved: {output} ({len(frames)} frames, {out_fps}fps playback)")

    import shutil; shutil.rmtree(frame_dir)

timelapse(duration_sec=10, fps=1)`,
  },
  {
    id: 'window-layout-manager',
    title: 'Window Layout Manager',
    category: 'GUI',
    tags: ['window', 'position', 'layout', 'multi-monitor', 'resize', 'arrange', 'tile'],
    description: 'Auto-arrange application windows in tiled layouts for productivity',
    requirements: ['pyautogui', 'pygetwindow'],
    script: `import pyautogui, sys

try:
    import pygetwindow as gw
except ImportError:
    print("pip install pygetwindow pyautogui"); exit()

SW, SH = pyautogui.size()
print(f"Screen: {SW}x{SH}")

def list_windows():
    print("\nOpen windows:")
    for w in gw.getAllWindows():
        if w.title:
            print(f"  {w.title[:45]:45} {w.left:5},{w.top:4}  {w.width}x{w.height}")

def find_window(title_pattern):
    return [w for w in gw.getAllWindows()
            if title_pattern.lower() in w.title.lower() and w.title]

def tile_left(title_pattern):
    wins = find_window(title_pattern)
    if not wins: print(f"Not found: '{title_pattern}'"); return
    wins[0].moveTo(0, 0); wins[0].resizeTo(SW//2, SH)
    print(f"Tiled left:  {wins[0].title[:40]}")

def tile_right(title_pattern):
    wins = find_window(title_pattern)
    if not wins: print(f"Not found: '{title_pattern}'"); return
    wins[0].moveTo(SW//2, 0); wins[0].resizeTo(SW//2, SH)
    print(f"Tiled right: {wins[0].title[:40]}")

def center_window(title_pattern, width=1200, height=800):
    wins = find_window(title_pattern)
    if not wins: print(f"Not found: '{title_pattern}'"); return
    x = (SW - width) // 2; y = (SH - height) // 2
    wins[0].moveTo(x, y); wins[0].resizeTo(width, height)
    print(f"Centered: {wins[0].title[:40]} at {width}x{height}")

list_windows()
# tile_left("chrome")
# tile_right("code")
# center_window("notepad", 1000, 700)`,
  },
  {
    id: 'auto-form-filler',
    title: 'Web Form Auto-Filler',
    category: 'GUI',
    tags: ['selenium', 'form', 'fill', 'automate', 'web', 'browser', 'login'],
    description: 'Automatically fill and submit web forms using Selenium automation',
    requirements: ['selenium', 'webdriver-manager'],
    script: `from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import time

TARGET_URL = "https://httpbin.org/forms/post"

FORM_DATA = {
    "custname":  "John Doe",
    "custtel":   "+1-555-123-4567",
    "custemail": "john@example.com",
    "size":      "large",
    "topping":   "cheese",
    "delivery":  "13:00",
    "comments":  "Automated by Butler AI",
}

opts = Options()
opts.add_argument("--start-maximized")
# opts.add_argument("--headless")  # Uncomment for headless mode

driver = webdriver.Chrome(
    service=Service(ChromeDriverManager().install()),
    options=opts
)

try:
    wait = WebDriverWait(driver, 10)
    print(f"Opening: {TARGET_URL}")
    driver.get(TARGET_URL)
    time.sleep(1)

    for field, value in FORM_DATA.items():
        try:
            el = driver.find_element(By.NAME, field)
            if el.tag_name in ('input', 'textarea') and el.get_attribute('type') not in ('radio','checkbox'):
                el.clear()
                el.send_keys(value)
                print(f"  Filled [{field}]: {value}")
        except: pass

    print("\nForm filled! Submit when ready.")
    time.sleep(3)
    # Uncomment to auto-submit:
    # driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()

finally:
    input("Press Enter to close browser...")
    driver.quit()`,
  },

  // ── NETWORK ───────────────────────────────────────────────────
  {
    id: 'service-uptime-monitor',
    title: 'Service Uptime Statistics Monitor',
    category: 'Network',
    tags: ['uptime', 'monitor', 'ping', 'service', 'check', 'health', 'statistics'],
    description: 'Continuously monitor multiple services and track uptime statistics',
    requirements: ['requests'],
    script: `import requests, time, json
from datetime import datetime
from pathlib import Path

SERVICES = [
    {'name': 'Butler Server', 'url': 'http://192.168.1.100:8765/api/status', 'timeout': 5},
    {'name': 'Google',        'url': 'https://www.google.com',                'timeout': 5},
    {'name': 'GitHub',        'url': 'https://github.com',                    'timeout': 10},
]

CHECK_SEC = 30
LOG_FILE  = Path("uptime_stats.json")

def check(svc):
    try:
        r = requests.get(svc['url'], timeout=svc['timeout'])
        return r.status_code < 500, r.elapsed.total_seconds() * 1000
    except: return False, 0

stats = {s['name']: {'checks':0,'up':0,'down':0,'latencies':[],'last_down':None} for s in SERVICES}
prev  = {s['name']: True for s in SERVICES}

def log(msg):
    ts = datetime.now().strftime('%H:%M:%S')
    print(f"[{ts}] {msg}")

log(f"Monitoring {len(SERVICES)} services every {CHECK_SEC}s (Ctrl+C to stop)")

try:
    while True:
        for svc in SERVICES:
            ok, ms = check(svc)
            name   = svc['name']
            stats[name]['checks'] += 1
            if ok:
                stats[name]['up'] += 1
                stats[name]['latencies'].append(round(ms, 1))
                if not prev[name]: log(f"BACK UP: {name} ({ms:.0f}ms)")
            else:
                stats[name]['down'] += 1
                stats[name]['last_down'] = datetime.now().isoformat()
                if prev[name]: log(f"DOWN: {name}")
            prev[name] = ok

        for name, s in stats.items():
            total = s['checks']
            pct   = (s['up']/total*100) if total else 0
            lats  = s['latencies'][-20:]
            avg   = sum(lats)/len(lats) if lats else 0
            print(f"  {name:25} {pct:6.2f}% up  avg:{avg:.0f}ms  checks:{total}")

        LOG_FILE.write_text(json.dumps({
            k: {**v, 'latencies': v['latencies'][-100:]}
            for k, v in stats.items()
        }, indent=2))
        time.sleep(CHECK_SEC)
except KeyboardInterrupt:
    log("Monitor stopped.")`,
  },
  {
    id: 'public-ip-checker',
    title: 'VPN IP Leak and Public IP Checker',
    category: 'Network',
    tags: ['vpn', 'ip', 'leak', 'check', 'privacy', 'anonymity', 'public'],
    description: 'Check your public IP address, detect VPN changes, and verify DNS leak protection',
    requirements: ['requests'],
    script: `import requests, time, socket
from datetime import datetime

IP_APIS = [
    "https://api.ipify.org?format=json",
    "https://ipinfo.io/json",
]

def get_public_ip():
    for url in IP_APIS:
        try:
            r = requests.get(url, timeout=8)
            data = r.json()
            return {
                'ip':      data.get('ip', 'unknown'),
                'country': data.get('country', '?'),
                'city':    data.get('city', '?'),
                'org':     data.get('org', '?'),
            }
        except: continue
    return None

def get_dns_servers():
    try:
        import subprocess, sys
        if sys.platform == 'win32':
            r = subprocess.run("ipconfig /all", shell=True, capture_output=True, text=True)
            dns = []
            for line in r.stdout.split("\n"):
                if "DNS Servers" in line and ":" in line:
                    d = line.split(":")[-1].strip()
                    if d: dns.append(d)
            return dns[:4]
        else:
            r = subprocess.run(["cat","/etc/resolv.conf"], capture_output=True, text=True)
            return [l.split()[-1] for l in r.stdout.split("\n") if l.startswith("nameserver")][:4]
    except: return []

print("=== IP LEAK CHECKER ===\n")
info = get_public_ip()
if info:
    print(f"Public IP:  {info['ip']}")
    print(f"Country:    {info['country']}")
    print(f"City:       {info['city']}")
    print(f"ISP/Org:    {info['org'][:60]}")
else:
    print("Cannot reach IP check APIs")

dns = get_dns_servers()
if dns:
    print(f"\nDNS Servers ({len(dns)} detected):")
    for d in dns:
        print(f"  {d}")

print("\nMonitoring for IP changes (5 checks, 10s interval)...")
prev_ip = info['ip'] if info else None
for i in range(5):
    time.sleep(10)
    info2 = get_public_ip()
    if info2:
        status = "CHANGED!" if info2['ip'] != prev_ip else "stable  "
        ts = datetime.now().strftime('%H:%M:%S')
        print(f"  [{ts}] {status} IP: {info2['ip']} ({info2['country']})")
        prev_ip = info2['ip']`,
  },
  {
    id: 'ssh-tunnel-manager',
    title: 'SSH Tunnel Manager',
    category: 'Network',
    tags: ['ssh', 'tunnel', 'forward', 'proxy', 'socks', 'remote', 'port'],
    description: 'Create and manage SSH tunnels for local port forwarding and SOCKS proxy',
    requirements: ['paramiko'],
    script: `import paramiko, socket, threading, sys, time

SSH_HOST = "your-server.com"
SSH_PORT = 22
SSH_USER = "username"
SSH_KEY  = "~/.ssh/id_rsa"  # Or SSH_PASS = "password"

# Tunnel config: (local_port, remote_host, remote_port)
TUNNELS = [
    (8080, "localhost",  80),   # Forward local:8080 -> remote:80
    (3306, "localhost",  3306), # MySQL
    (5432, "db-server", 5432),  # PostgreSQL on another host
]

def create_tunnel(ssh_client, local_port, remote_host, remote_port):
    transport = ssh_client.get_transport()
    transport.request_port_forward("", local_port)
    print(f"  Tunnel: localhost:{local_port} -> {remote_host}:{remote_port}")

def info_only():
    print("=== SSH TUNNEL MANAGER ===")
    print(f"Server:  {SSH_HOST}:{SSH_PORT}")
    print(f"User:    {SSH_USER}")
    print(f"\nConfigured tunnels:")
    for local, rhost, rport in TUNNELS:
        print(f"  localhost:{local:5} -> {rhost}:{rport}")
    print("\nUsage:")
    print("  1. Uncomment the SSH connection code below")
    print("  2. Configure SSH_HOST, SSH_USER, SSH_KEY")
    print("  3. Run: python tunnel.py")
    print("\nAlternative (command line):")
    for local, rhost, rport in TUNNELS:
        print(f"  ssh -L {local}:{rhost}:{rport} {SSH_USER}@{SSH_HOST} -N")

# Uncomment to actually connect:
# client = paramiko.SSHClient()
# client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
# client.connect(SSH_HOST, SSH_PORT, SSH_USER, key_filename=SSH_KEY, timeout=10)
# for local, rhost, rport in TUNNELS:
#     create_tunnel(client, local, rhost, rport)
# print("All tunnels active. Ctrl+C to stop.")
# try:
#     while True: time.sleep(1)
# except KeyboardInterrupt:
#     client.close()

info_only()`,
  },
];

```


### `/src/data/scriptTypes.ts`

```ts path=/src/data/scriptTypes.ts
/**
 * Shared types for script library — isolated to prevent circular imports
 */

export interface AutomationScript {
  id:           string;
  title:        string;
  description:  string;
  category:     string;
  tags:         string[];
  requirements: string[];
  script:       string;
  notes?:       string;
}

```


### `/src/hooks/use-mobile.tsx`

```ts path=/src/hooks/use-mobile.tsx
import * as React from "react";

const MOBILE_BREAKPOINT = 768;

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined);

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    };
    mql.addEventListener("change", onChange);
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    return () => mql.removeEventListener("change", onChange);
  }, []);

  return !!isMobile;
}

```


### `/src/hooks/use-perf-tier.ts`

```ts path=/src/hooks/use-perf-tier.ts
import { useEffect, useState } from "react";

/**
 * Device performance tier. Used to dynamically throttle expensive
 * animations (parallax, drop-shadows, mood cycling) so low-end devices
 * stay smooth without changing the visual identity on high-end ones.
 *
 *   "high"  — desktop / flagship phones (parallax + full FX)
 *   "mid"   — typical phones            (parallax kept, shadows trimmed)
 *   "low"   — old phones / reduced-motion / data-saver (static + cheap FX)
 */
export type PerfTier = "high" | "mid" | "low";

type NavWithDeviceMemory = Navigator & {
  deviceMemory?: number;
  connection?: { saveData?: boolean; effectiveType?: string };
};

function detectStatic(): PerfTier {
  if (typeof window === "undefined") return "high";

  // Honor user accessibility preference first.
  if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return "low";

  const nav = navigator as NavWithDeviceMemory;
  if (nav.connection?.saveData) return "low";

  const mem = nav.deviceMemory ?? 8;
  const cores = nav.hardwareConcurrency ?? 8;
  const dpr = window.devicePixelRatio ?? 1;
  const small = Math.min(window.innerWidth, window.innerHeight) < 420;
  const coarse = window.matchMedia?.("(pointer: coarse)").matches ?? false;

  // Android WebViews at high DPR are the main target: bias them toward static FX.
  if (coarse && small) return "low";
  if (mem <= 2 || cores <= 2) return "low";
  if (mem <= 4 || cores <= 4 || (small && dpr >= 3)) return "low";
  return "high";
}

export function usePerfTier(): PerfTier {
  const [tier, setTier] = useState<PerfTier>(() => detectStatic());

  useEffect(() => {
    // Live downgrade: sample frame rate for 1s. If we can't sustain ~45fps,
    // step the tier down one notch. Never upgrade — measurement noise only.
    let raf = 0;
    let frames = 0;
    const start = performance.now();
    const tick = () => {
      frames++;
      if (performance.now() - start < 1000) raf = requestAnimationFrame(tick);
      else {
        const fps = frames;
        setTier((t) => {
          if (fps >= 45) return t;
          if (fps >= 25) return t === "high" ? "mid" : t;
          return "low";
        });
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  // Reflect tier on <html> so plain CSS can react too (e.g. .perf-low *).
  useEffect(() => {
    if (typeof document === "undefined") return;
    const el = document.documentElement;
    el.dataset.perf = tier;
    el.classList.toggle("perf-low", tier === "low");
    el.classList.toggle("perf-mid", tier === "mid");
    el.classList.toggle("perf-high", tier === "high");
  }, [tier]);

  return tier;
}

```


### `/src/hooks/useChatHistory.ts`

```ts path=/src/hooks/useChatHistory.ts
/**
 * useChatHistory — Debounced localStorage persistence for AI chat (web port).
 * Ported from BUTLER-AI/hooks/useChatHistory.ts
 */
import { useEffect, useRef, useCallback } from 'react';
import { storage } from '@/lib/storage';

const HISTORY_KEY = '@butler_conv_nexus_v1';
const MAX_STORED = 200;
const DEBOUNCE_MS = 800;

interface Message {
  id: string;
  role: string;
  content: string;
  timestamp: number;
  streaming?: boolean;
  [key: string]: unknown;
}

interface UseChatHistoryOptions {
  onLoad?: (msgs: Message[]) => void;
  storageKey?: string;
}

export function useChatHistory(messages?: Message[], options?: UseChatHistoryOptions) {
  const onLoad = options?.onLoad;
  const KEY = options?.storageKey ?? HISTORY_KEY;
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isLoaded = useRef(false);

  useEffect(() => {
    let cancelled = false;
    storage.getItem(KEY).then((raw) => {
      if (cancelled) return;
      if (!raw) { isLoaded.current = true; return; }
      try {
        const saved = JSON.parse(raw) as Message[];
        if (Array.isArray(saved) && saved.length > 0) {
          const clean = saved.filter((m) => !m.streaming && m.content?.length > 0).slice(-MAX_STORED);
          if (clean.length > 0) onLoad?.(clean);
        }
      } catch {
        storage.removeItem(KEY);
      }
      isLoaded.current = true;
    }).catch(() => { isLoaded.current = true; });
    return () => { cancelled = true; };
  }, [KEY, onLoad]);

  useEffect(() => {
    if (!isLoaded.current) return;
    if (!messages || messages.length === 0) return;

    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        const toSave = messages.filter((m) => !m.streaming).slice(-MAX_STORED);
        await storage.setItem(KEY, JSON.stringify(toSave));
      } catch {
        try {
          const trimmed = messages.filter((m) => !m.streaming).slice(-50);
          await storage.setItem(KEY, JSON.stringify(trimmed));
        } catch { /* swallow */ }
      }
    }, DEBOUNCE_MS);

    return () => { if (saveTimer.current) clearTimeout(saveTimer.current); };
  }, [messages, KEY]);

  const clearHistory = useCallback(async () => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    await storage.removeItem(KEY);
  }, [KEY]);

  return { clearHistory };
}

```


### `/src/hooks/useServerLink.ts`

```ts path=/src/hooks/useServerLink.ts
import { useSyncExternalStore } from "react";
import { serverLink, type LinkState } from "@/lib/serverLink";

const SSR_SNAPSHOT: LinkState = {
  status: "idle",
  ip: "",
  port: "",
  latencyMs: null,
  lastOkAt: null,
};

/** React hook that mirrors the singleton serverLink state. */
export function useServerLink(): LinkState {
  return useSyncExternalStore(
    (cb) => serverLink.subscribe(cb),
    () => serverLink.getState(),
    () => SSR_SNAPSHOT,
  );
}

```


### `/src/lib/ai-gateway.server.ts`

```ts path=/src/lib/ai-gateway.server.ts
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

export function createLovableAiGatewayProvider(apiKey: string) {
  return createOpenAICompatible({
    name: "lovable-ai-gateway",
    baseURL: "https://ai.gateway.lovable.dev/v1",
    headers: { "Lovable-API-Key": apiKey },
  });
}

```


### `/src/lib/appOverrides.ts`

```ts path=/src/lib/appOverrides.ts
/**
 * Unified App Override Engine
 * -----------------------------------------------------------------------------
 * Accepts a single uploaded "master" payload — JSON or Markdown — and applies
 * every editable layer of the app at runtime:
 *
 *   - theme      → CSS variables, fonts, radius, raw CSS  (themeOverrides.ts)
 *   - text       → label/string overrides (getText)        (themeOverrides.ts)
 *   - files      → source-code snapshots (re-exportable, available on window)
 *   - data       → arbitrary JSON blobs keyed by name (library, config, etc.)
 *
 * Supports:
 *   - Filename-agnostic upload (.json, .md, .txt — detected by content)
 *   - Markdown bundle parsing  (``` path=<file> blocks → files map)
 *   - One-step UNDO (snapshots previous state on every apply)
 *   - Auto soft-reload so the UI reflects edits immediately
 */

import {
  applyTheme,
  persist as persistTheme,
  loadStored as loadStoredTheme,
  snapshotCurrentTheme,
  clearTheme,
  isThemeFile,
  type ButlerThemeFile,
  THEME_KEY,
  THEME_TEXT_KEY,
} from "./themeOverrides";

export const FILES_KEY = "butler.override.files.v1";
export const DATA_KEY  = "butler.override.data.v1";
export const UNDO_KEY  = "butler.override.undo.v1";
export const LAST_APPLIED_KEY = "butler.override.last.v1";

export type MasterPayload = {
  _type?: string;
  version?: string;
  name?: string;
  theme?: ButlerThemeFile;
  text?: Record<string, string>;
  files?: Record<string, string>;            // path → source
  data?: Record<string, unknown>;            // arbitrary JSON blobs
  // Top-level shortcuts (also accepted at root for convenience):
  colors?: Record<string, string>;
  fonts?: ButlerThemeFile["fonts"];
  radius?: ButlerThemeFile["radius"];
  vars?: Record<string, string>;
  css?: string;
};

export type ApplyResult = {
  ok: boolean;
  error?: string;
  appliedTheme: number;
  appliedText: number;
  appliedFiles: number;
  appliedData: number;
  fileList: string[];
  source: "json" | "markdown";
  snapshotForUndo: boolean;
};

/* --------------------------------- utils -------------------------------- */

function safeRead<T>(key: string): T | null {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : null; }
  catch { return null; }
}
function safeWrite(key: string, val: unknown) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

/* --------------------------- markdown bundle ---------------------------- */

/**
 * Parse a Butler Master `.md` bundle. Extracts every fenced code block whose
 * info string contains `path=<file>` and returns { files: { path: content } }.
 * Tolerates the ``` `lang path=foo` ``` shape used by the exporter.
 */
export function parseMarkdownBundle(md: string): MasterPayload {
  const files: Record<string, string> = {};
  // Matches ```<anything> path=<path>\n<body>\n```
  const re = /```[^\n`]*?path=([^\s`]+)\s*\n([\s\S]*?)\n```/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(md)) !== null) {
    const path = m[1].trim().replace(/^\/+/, "");
    if (!path) continue;
    files[path] = m[2];
  }
  return { _type: "butler_master_file", files };
}

/* ------------------------------ detection ------------------------------- */

export type ParsedUpload = { payload: MasterPayload; source: "json" | "markdown" };

export function parseUpload(raw: string): ParsedUpload {
  const trimmed = raw.trimStart();
  if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
    const j = JSON.parse(raw);
    // Tolerate a few shapes:
    if (j && typeof j === "object") {
      if (j.source_export && !j.files) {
        // Butler legacy export → flatten to files map.
        const files: Record<string, string> = {};
        for (const [k, v] of Object.entries(j.source_export as Record<string, any>)) {
          if (k === "_meta") continue;
          if (typeof v === "string") files[k] = v;
          else if (v && typeof v === "object" && typeof v.content === "string") files[k] = v.content;
        }
        return { payload: { ...j, files }, source: "json" };
      }
      return { payload: j as MasterPayload, source: "json" };
    }
    throw new Error("JSON did not decode to an object");
  }
  // Markdown / text fallback — pull fenced blocks.
  const parsed = parseMarkdownBundle(raw);
  if (!Object.keys(parsed.files ?? {}).length) {
    throw new Error("No `path=<file>` code blocks found in markdown");
  }
  return { payload: parsed, source: "markdown" };
}

/* ------------------------------ snapshots ------------------------------- */

type Snapshot = {
  ts: number;
  theme: string | null;       // raw stored theme JSON
  themeText: string | null;
  files: string | null;
  data: string | null;
  lastApplied: string | null;
};

function takeSnapshot(): Snapshot {
  return {
    ts: Date.now(),
    theme:       localStorage.getItem(THEME_KEY),
    themeText:   localStorage.getItem(THEME_TEXT_KEY),
    files:       localStorage.getItem(FILES_KEY),
    data:        localStorage.getItem(DATA_KEY),
    lastApplied: localStorage.getItem(LAST_APPLIED_KEY),
  };
}
function restoreSnapshot(s: Snapshot) {
  const setOrClear = (k: string, v: string | null) => {
    if (v == null) localStorage.removeItem(k);
    else localStorage.setItem(k, v);
  };
  setOrClear(THEME_KEY, s.theme);
  setOrClear(THEME_TEXT_KEY, s.themeText);
  setOrClear(FILES_KEY, s.files);
  setOrClear(DATA_KEY, s.data);
  setOrClear(LAST_APPLIED_KEY, s.lastApplied);
}

export function hasUndo(): boolean {
  return !!safeRead<Snapshot>(UNDO_KEY);
}
export function undoLast(): { ok: boolean; error?: string } {
  const snap = safeRead<Snapshot>(UNDO_KEY);
  if (!snap) return { ok: false, error: "Nothing to undo" };
  try {
    restoreSnapshot(snap);
    localStorage.removeItem(UNDO_KEY);
    return { ok: true };
  } catch (e: any) { return { ok: false, error: e?.message ?? "Undo failed" }; }
}

/* --------------------------------- apply -------------------------------- */

export function getFiles(): Record<string, string> {
  return safeRead<Record<string, string>>(FILES_KEY) ?? {};
}
export function getData(): Record<string, unknown> {
  return safeRead<Record<string, unknown>>(DATA_KEY) ?? {};
}

export function applyMaster(payload: MasterPayload, source: "json" | "markdown"): ApplyResult {
  if (typeof window === "undefined") {
    return { ok: false, error: "Browser only", appliedTheme: 0, appliedText: 0,
             appliedFiles: 0, appliedData: 0, fileList: [], source, snapshotForUndo: false };
  }

  // 1) Snapshot current state for undo BEFORE we change anything.
  const snap = takeSnapshot();
  safeWrite(UNDO_KEY, snap);

  // 2) Theme — accept nested `.theme` OR top-level shortcuts.
  const themeBlock: ButlerThemeFile | null = payload.theme
    ? payload.theme
    : (payload.colors || payload.fonts || payload.radius || payload.vars || payload.css)
      ? { _type: "butler_theme_file", colors: payload.colors, fonts: payload.fonts,
          radius: payload.radius, vars: payload.vars, css: payload.css }
      : null;

  let appliedTheme = 0;
  if (themeBlock && isThemeFile(themeBlock)) {
    applyTheme(themeBlock);
    persistTheme(themeBlock);
    appliedTheme =
      Object.keys(themeBlock.colors ?? {}).length +
      Object.keys(themeBlock.vars ?? {}).length +
      Object.keys(themeBlock.radius ?? {}).length +
      Object.keys(themeBlock.fonts ?? {}).length;
  }

  // 3) Text labels
  let appliedText = 0;
  if (payload.text && typeof payload.text === "object") {
    const merged = { ...(safeRead<Record<string, string>>(THEME_TEXT_KEY) ?? {}), ...payload.text };
    safeWrite(THEME_TEXT_KEY, merged);
    (window as any).__BUTLER_TEXT__ = merged;
    appliedText = Object.keys(payload.text).length;
  }

  // 4) Files — store and expose on window for any component that reads overrides.
  const files = payload.files ?? {};
  const fileList = Object.keys(files);
  if (fileList.length) {
    const merged = { ...getFiles(), ...files };
    safeWrite(FILES_KEY, merged);
    (window as any).__BUTLER_FILE_OVERRIDES__ = merged;
  }

  // 5) Arbitrary data blobs
  let appliedData = 0;
  if (payload.data && typeof payload.data === "object") {
    const merged = { ...getData(), ...payload.data };
    safeWrite(DATA_KEY, merged);
    (window as any).__BUTLER_DATA_OVERRIDES__ = merged;
    appliedData = Object.keys(payload.data).length;
  }

  // 6) Record what we applied (for the UI summary + diagnostics)
  const summary = {
    ts: Date.now(),
    source,
    appliedTheme, appliedText, appliedFiles: fileList.length, appliedData,
    fileList: fileList.slice(0, 64),
  };
  safeWrite(LAST_APPLIED_KEY, summary);

  window.dispatchEvent(new CustomEvent("butler:master-applied", { detail: summary }));
  window.dispatchEvent(new CustomEvent("butler:theme-changed", { detail: themeBlock }));

  return {
    ok: true,
    appliedTheme, appliedText,
    appliedFiles: fileList.length,
    appliedData,
    fileList,
    source,
    snapshotForUndo: true,
  };
}

/** One-shot helper: parse + apply + optionally reload. */
export function importMasterFromText(raw: string, opts?: { autoReload?: boolean }): ApplyResult {
  const { payload, source } = parseUpload(raw);
  const r = applyMaster(payload, source);
  if (r.ok && opts?.autoReload) {
    // Give toast a tick to render before reload.
    setTimeout(() => { try { window.location.reload(); } catch {} }, 350);
  }
  return r;
}

/* ----------------------------- boot / rehydrate -------------------------- */

export function bootAppOverrides(): void {
  if (typeof window === "undefined") return;
  const files = getFiles();
  if (Object.keys(files).length) (window as any).__BUTLER_FILE_OVERRIDES__ = files;
  const data = getData();
  if (Object.keys(data).length) (window as any).__BUTLER_DATA_OVERRIDES__ = data;
}

/* ----------------------------- master template -------------------------- */

/** Produce a JSON skeleton listing every editable surface a user can change. */
export function masterTemplate(): MasterPayload {
  const theme = loadStoredTheme();
  return {
    _type: "butler_master_file",
    version: "2.0",
    name: "Butler Master Override",
    theme: theme ?? {
      _type: "butler_theme_file",
      colors: { cyan: "#00ffd1", magenta: "#ff3df7", background: "#04060c" },
      fonts:  { display: "Orbitron, sans-serif", sans: "Inter, sans-serif", mono: "JetBrains Mono, monospace" },
      radius: { md: "6px", lg: "10px" },
    },
    text: {
      "app.title":   "Butler AI",
      "app.tagline": "Local-only PC butler",
      "nav.core":    "CORE",
      "nav.ops":     "OPS",
    },
    files: {
      // "src/routes/home.tsx": "<paste full file source here to override at runtime>",
    },
    data: {
      // "library.extra": [{ id: "ex1", title: "My script", body: "..." }],
    },
  };
}

export { clearTheme };

/* -------------------- export current master (live snapshot) ------------- */

/**
 * Capture EVERYTHING currently editable through the override pipeline:
 * - the live applied theme (CSS vars / fonts / radius / raw CSS)
 * - every text/label override
 * - every file override snapshot
 * - every data blob
 *
 * The returned object is round-trip safe: re-uploading it via UPLOAD MASTER
 * reproduces the exact same runtime state.
 */
export function exportCurrentMaster(): MasterPayload {
  const theme = loadStoredTheme() ?? snapshotCurrentTheme();
  const text  = safeRead<Record<string, string>>(THEME_TEXT_KEY) ?? {};
  const files = getFiles();
  const data  = getData();
  return {
    _type: "butler_master_file",
    version: "2.0",
    name: `Butler Master Export ${new Date().toISOString()}`,
    theme,
    text,
    files,
    data,
  };
}

/* ----------------------- AI upgrade prompt (clipboard) ------------------ */

/**
 * A long, defensive prompt to paste alongside the exported master file when
 * asking another AI (Claude / GPT / Gemini) to upgrade the app offline.
 * Tells the AI exactly what it may and may not do, what the file is, what
 * shape to return, and what mistakes destroy the app.
 */
export const AI_UPGRADE_PROMPT = `# BUTLER AI — OFFLINE UPGRADE PROMPT (read fully before editing)

You are being given a single JSON file exported from a running React + TanStack
Start app called "Butler AI". The file is a **master override bundle**. The
running app loads it at startup and applies every field live without rebuilding.
Your job: improve the app by editing this file and returning a NEW JSON file in
the SAME shape. The user will upload your output back into the app and it will
auto-apply + soft-reload.

## What the file contains
Top-level keys (all optional except _type):
- "_type":   must stay "butler_master_file"
- "version": bump if you make breaking changes, else keep
- "name":    human label
- "theme":   { _type:"butler_theme_file", colors, fonts, radius, vars, css }
- "text":    { "key.path": "Label string", ... }   // UI label overrides
- "files":   { "src/routes/home.tsx": "<full file source>", ... }
- "data":    { "library.extra": [...], ... }       // arbitrary JSON blobs

## What you ARE allowed to do
- Edit / add / remove THEME colors, fonts, radius, vars, css.
- Edit / add / remove TEXT label overrides.
- Add or replace entries in FILES with full, valid source for that path.
- Add or replace entries in DATA.
- Add new keys under "data" for new features.
- Improve visual design, spacing, typography, micro-interactions, copy.
- Refactor a file's internals as long as its default export and props stay compatible.

## What you MUST NOT do (these break the app)
1. DO NOT delete keys you did not author just because you "didn't need them".
   Preserve every existing theme color, text key, file entry, and data blob
   unless the user explicitly asked you to remove it. Unknown keys are used
   by other parts of the app you cannot see.
2. DO NOT change "_type" values. "butler_master_file" and "butler_theme_file"
   are how the loader detects the payload.
3. DO NOT return Markdown, prose, code fences, or commentary OUTSIDE the JSON.
   The user uploads the raw file — extra text will fail to parse. Return ONLY
   a single JSON object. No \`\`\`json fences. No leading "Here is...".
4. DO NOT rename routes, components, or default exports inside "files". Routes
   are file-path based; renaming the file or its export breaks navigation.
5. DO NOT introduce new npm imports inside "files" entries. The runtime cannot
   install packages from an override. Only use imports that already exist in
   the file you are replacing.
6. DO NOT use Node-only APIs (fs, child_process, path) in client files. The
   app runs in the browser; server logic lives on Cloudflare Workers and is
   NOT editable through this file.
7. DO NOT touch authentication, secrets, API keys, or environment variables.
   They are not in this file and cannot be set from it.
8. DO NOT remove the "_type" or rename "theme" / "text" / "files" / "data".
9. DO NOT inline gigantic base64 assets. Keep the file under ~2 MB.
10. DO NOT replace a file with a stub or "TODO" — partial files crash the route.

## What CANNOT be edited via this file (do not try)
- Server functions, API routes, database schema, environment secrets.
- Installed npm dependencies / package.json / lockfile.
- Vite config, TanStack route tree generation, build pipeline.
- Anything under src/routes/api/*  (server-only).
- The override engine itself (src/lib/appOverrides.ts, themeOverrides.ts).
- Native Android wrapper / Capacitor / Expo config.

If the user asks for one of the above, return JSON with an unchanged payload
and add a "data._notes" string explaining the limitation. Do not silently
no-op.

## Theme block — exact shape
"theme": {
  "_type": "butler_theme_file",
  "colors": {
    "background": "#04060c",
    "foreground": "#e6f7ff",
    "cyan":       "#00ffd1",
    "magenta":    "#ff3df7",
    "border":     "#0b1726"
    // ... keep every existing color key
  },
  "fonts":  { "display": "Orbitron, sans-serif", "sans": "Inter, sans-serif", "mono": "JetBrains Mono, monospace" },
  "radius": { "md": "6px", "lg": "10px" },
  "vars":   { "shadow-cyan": "0 0 18px rgba(0,255,209,.35)" },
  "css":    "/* optional raw CSS appended after vars */"
}

Color values must be valid CSS (#hex, rgb(), hsl(), or a CSS keyword). Do not
use Tailwind class names here.

## File overrides — exact shape
Each value MUST be the COMPLETE source of the file at that path, valid
TypeScript/TSX, parseable by Vite + SWC, with ALL imports the file uses and
a matching default export (for routes) or named export (for components).

"files": {
  "src/components/Foo.tsx": "import { useState } from 'react';\\nexport function Foo(){ ... }\\n"
}

Checklist before returning a file entry:
- [ ] Every JSX tag is balanced.
- [ ] Every "import ... from '...'" path already exists in the project.
- [ ] Default export name and props signature unchanged (for routes/pages).
- [ ] No "...rest of file omitted" placeholders.
- [ ] No TypeScript syntax errors. Prefer plain types over exotic generics.
- [ ] Uses existing CSS variables (var(--cyan), var(--ink)) instead of hardcoded colors.

## Text overrides — exact shape
Flat string-to-string map. Keys are dotted names already in the codebase:
"text": { "app.title": "Butler AI", "nav.core": "CORE", "nav.ops": "OPS" }
Adding new keys is fine but they only render where getText("the.key") is called.

## Data overrides — exact shape
Arbitrary JSON keyed by name. Used by components that opt in via
__BUTLER_DATA_OVERRIDES__. Safe to extend.

## Output contract (read twice)
Return a SINGLE JSON object, nothing else. Start with "{" and end with "}".
Preserve unknown fields verbatim. If you are unsure, copy the original value
through unchanged rather than dropping it. When in doubt: small, surgical
diffs beat sweeping rewrites.

## Failure modes to actively avoid
- "It loaded but the page is blank"  → you broke a JSX balance or removed a default export.
- "Upload failed: JSON did not decode" → you wrapped output in \`\`\`json fences.
- "Theme reverted"                   → you removed required color keys.
- "Route 404 after upload"           → you renamed a file path or its export.
- "Hydration mismatch"               → you used Date.now()/Math.random() at module scope in a route.

## Final reminder
The user will simply drop your JSON into the UPLOAD MASTER button. There is no
review step. If your output is malformed, the app rolls back via UNDO and your
work is discarded. Be conservative, complete, and correct. Return ONLY the JSON.
`;


```


### `/src/lib/butler.ts`

```ts path=/src/lib/butler.ts
// Butler PC server client — talks to butler_server.py over LAN.
// Full port from prior project; preserves all endpoints and helpers.

export type ButlerConfig = {
  baseUrl: string;
  token: string;
  deviceId: string;
  host: string;
  appSig: string;
  pairingCode: string;
  pairedAt: number;
  paired: boolean;
};

const CFG_KEY = "butler.cfg.v2";

function emptyCfg(): ButlerConfig {
  return {
    baseUrl: "", token: "", deviceId: "", host: "",
    appSig: "", pairingCode: "", pairedAt: 0, paired: false,
  };
}

function genDeviceId(): string {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return "web-" + Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}

export function getConfig(): ButlerConfig {
  if (typeof window === "undefined") return emptyCfg();
  try {
    const raw = localStorage.getItem(CFG_KEY) || localStorage.getItem("butler.cfg.v1");
    if (raw) {
      const c = { ...emptyCfg(), ...JSON.parse(raw) } as ButlerConfig;
      if (!c.deviceId) c.deviceId = genDeviceId();
      return c;
    }
  } catch {}
  const c = emptyCfg();
  c.deviceId = genDeviceId();
  return c;
}

export function setConfig(patch: Partial<ButlerConfig>): ButlerConfig {
  const next = { ...getConfig(), ...patch };
  try { localStorage.setItem(CFG_KEY, JSON.stringify(next)); } catch {}
  if (typeof window !== "undefined") window.dispatchEvent(new Event("butler:cfg"));
  return next;
}

export function clearConfig() {
  try {
    localStorage.removeItem(CFG_KEY);
    localStorage.removeItem("butler.cfg.v1");
  } catch {}
  if (typeof window !== "undefined") window.dispatchEvent(new Event("butler:cfg"));
}

function normalizeBase(url: string): string {
  let u = url.trim();
  if (!u) return "";
  if (!/^https?:\/\//i.test(u)) u = "http://" + u;
  return u.replace(/\/+$/, "");
}

export async function request<T = any>(
  path: string,
  init: RequestInit = {},
  opts: { auth?: boolean; timeoutMs?: number; baseUrl?: string } = {},
): Promise<T> {
  const cfg = getConfig();
  const base = opts.baseUrl || cfg.baseUrl;
  if (!base) throw new Error("Butler server not configured");
  const headers = new Headers(init.headers || {});
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  if (opts.auth !== false && cfg.token) {
    headers.set("Authorization", `Bearer ${cfg.token}`);
    headers.set("X-Session-Token", cfg.token);
  }
  headers.set("X-Device-Id", cfg.deviceId);
  if (cfg.appSig) headers.set("X-Butler-App-Sig", cfg.appSig);
  headers.set("X-App-Version", "web-1.0");

  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), opts.timeoutMs ?? 15000);
  try {
    const res = await fetch(base + path, { ...init, headers, signal: ctrl.signal });
    const text = await res.text();
    let data: any = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = { raw: text }; }
    if (!res.ok) {
      const err: any = new Error(data?.error || `HTTP ${res.status}`);
      err.status = res.status; err.body = data; throw err;
    }
    return data as T;
  } finally {
    clearTimeout(tid);
  }
}

export type QrPayload = {
  ip?: string; host?: string; port?: number; scheme?: string;
  url?: string; baseUrl?: string; pairingCode?: string;
  appSig?: string; version?: string; tls?: any; allIPs?: string[];
};

export function parseQrPayload(text: string): QrPayload {
  const t = (text || "").trim();
  if (!t) throw new Error("Empty QR payload");
  const cleaned = t.replace(/^butler:\/\//i, "").trim();
  let obj: any;
  try { obj = JSON.parse(cleaned); }
  catch {
    const parts = cleaned.split("|");
    if (parts.length >= 2 && parts[0].includes(":")) {
      const [ip, port] = parts[0].split(":");
      obj = { ip, port: Number(port), pairingCode: parts[1], appSig: parts[2] || "" };
    } else throw new Error("QR payload is not JSON");
  }
  if (!obj || typeof obj !== "object") throw new Error("Invalid QR payload");
  return obj as QrPayload;
}

export function qrToBaseUrl(p: QrPayload): string {
  if (p.url) return normalizeBase(p.url);
  if (p.baseUrl) return normalizeBase(p.baseUrl);
  const scheme = p.scheme || (p.tls ? "https" : "http");
  const host = p.ip || p.host || "";
  const port = p.port || 8766;
  if (!host) throw new Error("QR payload missing ip/host");
  return normalizeBase(`${scheme}://${host}:${port}`);
}

export async function pair(baseUrl: string, pairingCode = "", appSig = "") {
  const url = normalizeBase(baseUrl);
  setConfig({ baseUrl: url, appSig: appSig || getConfig().appSig });
  const cfg = getConfig();
  const res = await request<{ status: string; sessionToken: string; serverVersion?: string }>(
    "/pair",
    { method: "POST", body: JSON.stringify({ deviceId: cfg.deviceId, pairingCode: pairingCode || "" }) },
    { auth: false, timeoutMs: 12000 },
  );
  if (!res.sessionToken) throw new Error("Pairing failed: server returned no session token");
  setConfig({
    baseUrl: url, token: res.sessionToken, paired: true,
    host: hostOf(url), pairedAt: Date.now(), pairingCode,
  });
  return res;
}

export async function pairFromQr(payloadText: string) {
  const p = parseQrPayload(payloadText);
  const url = qrToBaseUrl(p);
  const code = (p.pairingCode || "").toUpperCase();
  const sig = p.appSig || "";
  if (!sig) throw new Error("QR missing appSig — reprint the QR from the PC console");
  return pair(url, code, sig);
}

export async function reconnect() {
  const cfg = getConfig();
  if (!cfg.baseUrl) throw new Error("No server URL");
  const res = await request<{ sessionToken?: string }>(
    "/reconnect",
    { method: "POST", body: JSON.stringify({ deviceId: cfg.deviceId, token: cfg.token }) },
    { auth: false, timeoutMs: 6000 },
  );
  if (res?.sessionToken) setConfig({ token: res.sessionToken, paired: true });
  return res;
}

export async function pairStatus(baseUrl?: string) {
  return request<{ paired: boolean; pairingCode?: string; serverVersion?: string }>(
    "/api/pair/status", { method: "POST", body: "{}" }, { auth: false, timeoutMs: 4000, baseUrl },
  );
}

export async function resetPair(pairingCode = "") {
  return request<{ ok: boolean }>(
    "/api/reset_pair",
    { method: "POST", body: JSON.stringify({ pairingCode }) },
    { auth: false, timeoutMs: 8000 },
  );
}

function hostOf(u: string): string {
  try { return new URL(u).host; } catch { return u; }
}

export type HealthInfo = { status: string; version?: string; uptime?: number; ai?: boolean; model?: string };
export const health = () => request<HealthInfo>("/api/health", {}, { auth: false, timeoutMs: 4000 });

export type SysInfo = {
  cpu?: number; ram?: number; disk?: number;
  cpuPercent?: number; ramPercent?: number; diskPercent?: number;
  hostname?: string; platform?: string; uptime?: number;
  [k: string]: any;
};
export const sysinfo = () => request<SysInfo>("/api/sysinfo");
export const statusFull = () => request<any>("/api/status/full");
export const processes = () => request<any>("/api/processes");
export const diskSpace = () => request<any>("/api/disk_space");
export const telemetry = () => request<any>("/api/telemetry", { method: "POST", body: "{}" });
export const haptic = (style = "light") =>
  fetch(`${getConfig().baseUrl}/api/haptic?style=${style}`).catch(() => {});

export const ollamaStatus = () => request<any>("/api/ollama/status", { method: "POST", body: "{}" });
export const ollamaRecommend = () => request<any>("/api/ollama/recommend");
export const ollamaModels = () => request<any>("/api/models");
export const ollamaPullStatus = () => request<any>("/api/ollama/pull_status");
export const ollamaPull = (model: string) =>
  request<any>("/api/ollama/pull", { method: "POST", body: JSON.stringify({ model }) }, { timeoutMs: 8000 });

export const kbStats = () => request<{ articles: number; sigma?: any }>("/api/kb/stats");
export const kbList = (limit = 50) => request<any>(`/api/kb/list?limit=${limit}`);
export const kbSearch = (q: string, limit = 8) =>
  request<{ results: any[]; total: number; query: string }>(
    "/api/kb/search", { method: "POST", body: JSON.stringify({ q, limit }) }, { timeoutMs: 8000 },
  );
export const kbEnrich = (query: string, keywords: string[] = [], maxResults = 5) =>
  request<{ enrichments: any[] }>(
    "/api/kb/enrich",
    { method: "POST", body: JSON.stringify({ query, keywords, maxResults }) },
    { timeoutMs: 10000 },
  );
export const kbFeed = (items: any) =>
  request<any>("/api/kb/feed", { method: "POST", body: JSON.stringify(items) }, { timeoutMs: 20000 });
export const kbExpand = (topic: string) =>
  request<any>("/api/kb/expand", { method: "POST", body: JSON.stringify({ topic }) }, { timeoutMs: 30000 });

export const learnStatus = () => request<any>("/api/learn/status", { method: "POST", body: "{}" });
export const crawlerPause = () => request<any>("/api/crawler/pause", { method: "POST", body: "{}" });
export const crawlerResume = () => request<any>("/api/crawler/resume", { method: "POST", body: "{}" });

export const requirementsList = () => request<any>("/api/requirements");
export const requirementsInstall = () =>
  request<any>("/api/requirements/install", { method: "POST", body: "{}" }, { timeoutMs: 300_000 });
export const pipInstall = (packages: string[]) =>
  request<any>("/api/pip/install", { method: "POST", body: JSON.stringify({ packages }) }, { timeoutMs: 300_000 });

export type ChatMsg = { role: "user" | "assistant"; content: string };

export async function chat(
  message: string,
  conversation: ChatMsg[] = [],
  opts: { systemPrompt?: string; metricsSnapshot?: string; model?: string } = {},
) {
  return request<{
    response?: string; reply?: string; message?: string;
    degraded?: boolean; model?: string; intent?: string;
  }>(
    "/api/butler/chat",
    {
      method: "POST",
      body: JSON.stringify({
        message,
        conversation,
        systemPrompt: opts.systemPrompt || "",
        metricsSnapshot: opts.metricsSnapshot || "",
        model: opts.model || "",
      }),
    },
    { timeoutMs: 180_000 },
  );
}

export async function chatClear() {
  return request<any>("/api/butler/clear", { method: "POST", body: "{}" }, { timeoutMs: 6000 });
}

export async function executeStream(
  script: string,
  language: "python" | "powershell" | "bash" | "sh" | "cmd" = "python",
  onChunk?: (text: string) => void,
): Promise<{ ok: boolean; output: string }> {
  const cfg = getConfig();
  if (!cfg.baseUrl) throw new Error("Not paired");
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${cfg.token}`,
    "X-Session-Token": cfg.token,
    "X-Device-Id": cfg.deviceId,
  };
  if (cfg.appSig) headers["X-Butler-App-Sig"] = cfg.appSig;
  const res = await fetch(cfg.baseUrl + "/api/execute/stream", {
    method: "POST", headers, body: JSON.stringify({ script, language }),
  });
  if (!res.ok || !res.body) {
    const t = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}${t ? ": " + t.slice(0, 200) : ""}`);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "", full = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = dec.decode(value, { stream: true });
    full += chunk; buf += chunk;
    let idx;
    while ((idx = buf.indexOf("\n\n")) !== -1) {
      const evt = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      const dataLine = evt.split("\n").find((l) => l.startsWith("data:"));
      if (dataLine && onChunk) onChunk(dataLine.slice(5).trim());
    }
  }
  return { ok: true, output: full };
}

export type SetupStep = {
  id: string; label: string;
  status: "pending" | "running" | "ok" | "skip" | "error";
  detail?: string; percent?: number;
};

export async function runAutoSetup(onUpdate: (steps: SetupStep[]) => void) {
  const steps: SetupStep[] = [
    { id: "deps", label: "Install Python dependencies", status: "pending" },
    { id: "recommend", label: "Recommend best Ollama model", status: "pending" },
    { id: "pull", label: "Download model", status: "pending" },
    { id: "verify", label: "Verify AI engine", status: "pending" },
  ];
  const update = () => onUpdate(steps.map(s => ({ ...s })));
  update();

  steps[0].status = "running"; update();
  try {
    const r = await requirementsInstall();
    steps[0].status = "ok";
    steps[0].detail = r?.installed ? `${r.installed} pkgs` : "ok";
  } catch (e: any) {
    steps[0].status = "skip";
    steps[0].detail = `skipped (${String(e?.message || e).slice(0, 60)})`;
  }
  update();

  steps[1].status = "running"; update();
  let pickModel = "";
  try {
    const rec: any = await ollamaRecommend();
    pickModel = extractRecommendedModel(rec);
    if (!pickModel) {
      try {
        const m: any = await ollamaModels();
        const list = (m?.models || m?.list || m || []) as any[];
        const first = list?.[0];
        pickModel = (first?.name || first?.model || (typeof first === "string" ? first : "")) as string;
      } catch {}
    }
    if (!pickModel) pickModel = "llama3.2:1b";
    steps[1].status = "ok";
    steps[1].detail = pickModel;
  } catch (e: any) {
    pickModel = "llama3.2:1b";
    steps[1].status = "ok";
    steps[1].detail = `${pickModel} (default — ${String(e?.message || e).slice(0, 40)})`;
  }
  update();

  if (!pickModel) {
    steps[2].status = "skip"; steps[2].detail = "no recommendation";
    steps[3].status = "skip"; update(); return steps;
  }
  steps[2].status = "running"; update();
  try { await ollamaPull(pickModel); } catch (e: any) {
    steps[2].status = "error"; steps[2].detail = String(e?.message || e);
    update(); return steps;
  }
  for (let i = 0; i < 600; i++) {
    await new Promise(r => setTimeout(r, 2500));
    try {
      const p = await ollamaPullStatus();
      const pct = Number(p?.percent ?? p?.progress ?? 0);
      steps[2].percent = Math.max(0, Math.min(100, Math.round(pct)));
      steps[2].detail = `${pickModel} · ${steps[2].percent}%`;
      update();
      if (!p?.active && (steps[2].percent >= 100 || p?.status === "done" || p?.completed)) {
        steps[2].status = "ok"; steps[2].percent = 100; break;
      }
    } catch {}
  }
  if (steps[2].status === "running") steps[2].status = "ok";
  update();

  steps[3].status = "running"; update();
  try {
    const s = await ollamaStatus();
    if (s?.ok || s?.activeModel || s?.model) {
      steps[3].status = "ok";
      steps[3].detail = s.activeModel || s.model || "ready";
    } else {
      steps[3].status = "error";
      steps[3].detail = "engine not ready";
    }
  } catch (e: any) {
    steps[3].status = "error"; steps[3].detail = String(e?.message || e);
  }
  update();
  return steps;
}

function extractRecommendedModel(rec: any): string {
  if (!rec) return "";
  if (typeof rec === "string") return rec;
  const direct = rec.recommended || rec.model || rec.best || rec.pick || rec.name;
  if (typeof direct === "string" && direct.trim()) return direct.trim();
  const arr = rec.picks || rec.models || rec.candidates || rec.results;
  if (Array.isArray(arr) && arr.length) {
    const first = arr[0];
    if (typeof first === "string") return first;
    if (first?.name) return String(first.name);
    if (first?.model) return String(first.model);
  }
  const tiers = rec.tiers || rec.tier;
  if (tiers && typeof tiers === "object") {
    return String(tiers.small || tiers.tiny || tiers.medium || tiers.large || "").trim();
  }
  return "";
}

export function useButlerConfigSubscribe(cb: () => void) {
  if (typeof window === "undefined") return () => {};
  window.addEventListener("butler:cfg", cb);
  return () => window.removeEventListener("butler:cfg", cb);
}

// ─────────────────────────────────────────────────────────────────────────────
// EXTENDED ENDPOINT SURFACE — full port of butler_server.py API (v20.1)
// Wired but lazy: every call returns {ok:false,error} when server is offline.
// ─────────────────────────────────────────────────────────────────────────────

// AI / Ollama (chat + model selection)
export const aiChat = (messages: any[], opts: any = {}) =>
  request<any>("/api/ai/chat", { method: "POST", body: JSON.stringify({ messages, ...opts }) }, { timeoutMs: 60000 });
export const aiMessage = (text: string) =>
  request<any>("/api/ai/message", { method: "POST", body: JSON.stringify({ text }) }, { timeoutMs: 60000 });
export const aiClear = () => request<any>("/api/ai/clear", { method: "POST", body: "{}" });
export const aiModels = () => request<any>("/api/ai/models");
export const aiSetModel = (model: string) =>
  request<any>("/api/ai/set_model", { method: "POST", body: JSON.stringify({ model }) });
export const ollamaChat = (messages: any[], model?: string) =>
  request<any>("/api/ollama/chat", { method: "POST", body: JSON.stringify({ messages, model }) }, { timeoutMs: 60000 });
export const ollamaSetModel = (model: string) =>
  request<any>("/api/ollama/set_model", { method: "POST", body: JSON.stringify({ model }) });
export const butlerAbort = () => request<any>("/api/butler/abort", { method: "POST", body: "{}" });

// Execute / Run
export const execute = (script: string, args: string[] = []) =>
  request<any>("/api/execute", { method: "POST", body: JSON.stringify({ script, args }) }, { timeoutMs: 0 });
export const executeSettings = () => request<any>("/api/execute/settings");
export const runScript = (id: string, params?: any) =>
  request<any>("/api/run", { method: "POST", body: JSON.stringify({ id, params }) }, { timeoutMs: 0 });

// PC Scripts CRUD
export const pcScriptsList = () => request<any>("/api/pc_scripts/list");
export const pcScriptsGet = (id: string) => request<any>(`/api/pc_scripts/get?id=${encodeURIComponent(id)}`);
export const pcScriptsSave = (script: any) =>
  request<any>("/api/pc_scripts/save", { method: "POST", body: JSON.stringify(script) });
export const pcScriptsDelete = (id: string) =>
  request<any>("/api/pc_scripts/delete", { method: "POST", body: JSON.stringify({ id }) });
export const pcScriptsRun = (id: string, params?: any) =>
  request<any>("/api/pc_scripts/run", { method: "POST", body: JSON.stringify({ id, params }) }, { timeoutMs: 0 });
export const pcScriptsImport = (payload: any) =>
  request<any>("/api/pc_scripts/import", { method: "POST", body: JSON.stringify(payload) }, { timeoutMs: 20000 });
export const pcScriptsExport = () => request<any>("/api/pc_scripts/export");
export const pcScriptsSearch = (q: string) =>
  request<any>("/api/pc_scripts/search", { method: "POST", body: JSON.stringify({ q }) });

// Filesystem
export const fsDrives = () => request<any>("/api/fs/drives");
export const fsCrawl = (path: string, depth = 2) =>
  request<any>("/api/fs/crawl", { method: "POST", body: JSON.stringify({ path, depth }) }, { timeoutMs: 30000 });
export const fsRead = (path: string) =>
  request<any>("/api/fs/read", { method: "POST", body: JSON.stringify({ path }) }, { timeoutMs: 15000 });
export const filesList = () => request<any>("/api/files");
export const downloadFile = (path: string) =>
  request<any>("/api/download", { method: "POST", body: JSON.stringify({ path }) }, { timeoutMs: 0 });
export const receiveFile = (form: FormData) =>
  fetch(`${getConfig().baseUrl}/api/receive_file`, { method: "POST", body: form, headers: { "X-Token": getConfig().token } }).then(r => r.json());

// Clipboard / Input / Power
export const clipboardGet = () => request<{ text: string }>("/api/clipboard");
export const clipboardSet = (text: string) =>
  request<any>("/api/clipboard", { method: "POST", body: JSON.stringify({ text }) });
export const keyboardType = (text: string) =>
  request<any>("/api/keyboard/type", { method: "POST", body: JSON.stringify({ text }) });
export const power = (action: "shutdown" | "restart" | "sleep" | "lock") =>
  request<any>("/api/power", { method: "POST", body: JSON.stringify({ action }) });
export const killProcess = (pid: number) =>
  request<any>("/api/kill_process", { method: "POST", body: JSON.stringify({ pid }) });
export const killInterference = () => request<any>("/api/kill_interference", { method: "POST", body: "{}" });

// Nexus Brain (legacy AI tuner)
export const nexusBrainStatus = () => request<any>("/api/nexus_brain/status");
export const nexusBrainMetrics = () => request<any>("/api/nexus_brain/metrics");
export const nexusBrainInsights = () => request<any>("/api/nexus_brain/insights");
export const nexusBrainAnomalies = () => request<any>("/api/nexus_brain/anomalies");
export const nexusBrainTuning = () => request<any>("/api/nexus_brain/tuning");
export const nexusBrainResetTuning = () => request<any>("/api/nexus_brain/reset_tuning", { method: "POST", body: "{}" });

// Security — Proximity + Digital Twin (anti-tamper)
export const proximityStatus = () => request<any>("/api/security/proximity/status");
export const proximityEnable = () => request<any>("/api/security/proximity/enable", { method: "POST", body: "{}" });
export const proximityDisable = () => request<any>("/api/security/proximity/disable", { method: "POST", body: "{}" });
export const proximityHeartbeat = () => request<any>("/api/security/proximity/heartbeat", { method: "POST", body: "{}" });
export const twinStatus = () => request<any>("/api/security/twin/status");
export const twinEnable = () => request<any>("/api/security/twin/enable", { method: "POST", body: "{}" });
export const twinDisable = () => request<any>("/api/security/twin/disable", { method: "POST", body: "{}" });
export const twinScan = () => request<any>("/api/security/twin/scan", { method: "POST", body: "{}" }, { timeoutMs: 30000 });
export const twinBaselineTake = () => request<any>("/api/security/twin/baseline/take", { method: "POST", body: "{}" }, { timeoutMs: 60000 });
export const twinBaselineClear = () => request<any>("/api/security/twin/baseline/clear", { method: "POST", body: "{}" });
export const twinAlerts = () => request<any>("/api/security/twin/alerts");

// Undo / Rollback (file-level safety net)
export const undoList = () => request<any>("/api/undo/list");
export const undoRollback = (id: string) =>
  request<any>("/api/undo/rollback", { method: "POST", body: JSON.stringify({ id }) }, { timeoutMs: 20000 });

// Debug / Diagnostics
export const debugConnection = () => request<any>("/api/debug/connection");
export const debugAi = () => request<any>("/api/debug/ai");
export const debugKb = () => request<any>("/api/debug/kb");
export const debugSearch = (q: string) =>
  request<any>("/api/debug/search", { method: "POST", body: JSON.stringify({ q }) });
export const debugGuard = () => request<any>("/api/debug/guard");
export const serverLog = (lines = 200) => request<any>(`/api/server_log?lines=${lines}`);
export const sessions = () => request<any>("/api/sessions");
export const metrics = () => request<any>("/api/metrics");
export const performanceStats = () => request<any>("/api/performance");
export const version = () => request<any>("/api/version");
export const ping = () => request<any>("/api/ping");

// Crawler / KB extras
export const crawl = (url: string) =>
  request<any>("/api/crawl", { method: "POST", body: JSON.stringify({ url }) }, { timeoutMs: 30000 });
export const crawlBatch = (urls: string[]) =>
  request<any>("/api/crawl/batch", { method: "POST", body: JSON.stringify({ urls }) }, { timeoutMs: 60000 });
export const kbContribute = (entry: any) =>
  request<any>("/api/kb/contribute", { method: "POST", body: JSON.stringify(entry) });
export const kbExport = () => request<any>("/api/kb/export");
export const kbImport = (data: any) =>
  request<any>("/api/kb/import", { method: "POST", body: JSON.stringify(data) }, { timeoutMs: 30000 });
export const kbGrowth = () => request<any>("/api/kb/growth");
export const kbLog = () => request<any>("/api/kb/log");

// PC Check (system audit)
export const pcCheckScan = () => request<any>("/api/pc-check/scan", { method: "POST", body: "{}" }, { timeoutMs: 60000 });
export const pcCheckAction = (action: string, target?: string) =>
  request<any>("/api/pc-check/action", { method: "POST", body: JSON.stringify({ action, target }) }, { timeoutMs: 30000 });

// Pairing extras
export const pairQr = () => request<any>("/api/pair/qr");
export const handshake = () => request<any>("/api/handshake", { method: "POST", body: "{}" });
export const authRotate = () => request<any>("/api/auth/rotate", { method: "POST", body: "{}" });

```


### `/src/lib/butlerMaster.ts`

```ts path=/src/lib/butlerMaster.ts
// Butler Master ingestion / persistence / runtime apply
// Ported from Butler AI Home. Web-safe (browser localStorage only).

export const BUTLER_MASTER_KEY = "commandcube.butlerMaster.v1";

export type ButlerMasterFile = {
  _master_export?: boolean;
  _type?: string;
  _meta?: Record<string, unknown>;
  source_export?: Record<string, { type?: string; content?: string } | unknown>;
  _guard_hash?: string;
  _guard_ts?: string;
  _lovable_enhanced?: Record<string, unknown>;
  _index?: { files?: string[] };
};

export type ImportResult = {
  ok: boolean;
  fileCount: number;
  applied: string[];
  errors: string[];
};

function safe<T>(fn: () => T, fallback: T): T {
  try { return fn(); } catch { return fallback; }
}

export function validate(master: unknown): master is ButlerMasterFile {
  if (!master || typeof master !== "object") return false;
  const m = master as ButlerMasterFile;
  return !!(m._master_export || m._type === "butler_master_file" || m.source_export);
}

export function loadStored(): ButlerMasterFile | null {
  if (typeof window === "undefined") return null;
  return safe(() => {
    const raw = window.localStorage.getItem(BUTLER_MASTER_KEY);
    return raw ? (JSON.parse(raw) as ButlerMasterFile) : null;
  }, null);
}

export function persist(master: ButlerMasterFile) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(BUTLER_MASTER_KEY, JSON.stringify(master));
}

export function clearStored() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(BUTLER_MASTER_KEY);
}

export function listFiles(master: ButlerMasterFile): string[] {
  const se = master.source_export ?? {};
  return Object.keys(se).filter((k) => k !== "_meta");
}

export function getFileSource(master: ButlerMasterFile, path: string): string | null {
  const entry = (master.source_export as Record<string, { content?: string }> | undefined)?.[path];
  return entry && typeof entry.content === "string" ? entry.content : null;
}

function extractArray(src: string, name: string): string | null {
  const re = new RegExp(`${name}\\s*=\\s*(\\[[\\s\\S]*?\\n\\])`);
  const m = src.match(re);
  return m ? m[1] : null;
}

export function applyToRuntime(master: ButlerMasterFile): string[] {
  const applied: string[] = [];
  if (typeof window === "undefined") return applied;
  const w = window as unknown as Record<string, unknown>;

  const hdr = getFileSource(master, "constants/HeaderConstants.ts");
  if (hdr) { w.__BUTLER_HEADERS_SRC = hdr; applied.push("constants/HeaderConstants.ts"); }

  const home = getFileSource(master, "app/(tabs)/nexushome.tsx");
  if (home) {
    const qs = extractArray(home, "QUICK_SCRIPTS");
    if (qs) { w.__BUTLER_QUICK_SCRIPTS_SRC = qs; applied.push("QUICK_SCRIPTS"); }
  }

  const kn = getFileSource(master, "constants/butlerKnowledge.ts");
  if (kn) { w.__BUTLER_PERSONA_SRC = kn; applied.push("constants/butlerKnowledge.ts"); }

  w.__BUTLER_MASTER = master;
  window.dispatchEvent(new CustomEvent("butler-master-applied", { detail: { applied } }));
  return applied;
}

export function importMaster(json: unknown): ImportResult {
  const errors: string[] = [];
  if (!validate(json)) {
    return { ok: false, fileCount: 0, applied: [], errors: ["Invalid butler_master file"] };
  }
  const master = json as ButlerMasterFile;
  persist(master);
  const applied = applyToRuntime(master);
  return { ok: true, fileCount: listFiles(master).length, applied, errors };
}

export function rehydrate() {
  const m = loadStored();
  if (m) applyToRuntime(m);
}

```


### `/src/lib/connectionDiagnostics.ts`

```ts path=/src/lib/connectionDiagnostics.ts
/**
 * Connection Diagnostics — persistent connect/disconnect/ping log (web port).
 * Ported from BUTLER-AI/services/connectionDiagnostics.ts
 */
import { storage } from './storage';

export type DiagEventKind = 'connect' | 'disconnect' | 'ping' | 'fail' | 'reconnect' | 'scan';

export interface DiagEvent {
  id: string;
  kind: DiagEventKind;
  at: string;
  host?: string;
  port?: number;
  latencyMs?: number;
  message?: string;
}

const KEY = 'nexus_conn_diag_v1';
const MAX = 200;

async function load(): Promise<DiagEvent[]> {
  const raw = await storage.getItem(KEY);
  try { return raw ? (JSON.parse(raw) as DiagEvent[]) : []; } catch { return []; }
}
async function save(ev: DiagEvent[]): Promise<void> { await storage.setItem(KEY, JSON.stringify(ev.slice(0, MAX))); }

export const connectionDiagnostics = {
  async record(kind: DiagEventKind, data: Omit<Partial<DiagEvent>, 'id' | 'kind' | 'at'> = {}) {
    const list = await load();
    const ev: DiagEvent = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
      kind, at: new Date().toISOString(), ...data,
    };
    await save([ev, ...list]);
    return ev;
  },
  async getAll() { return load(); },
  async clear() { await storage.removeItem(KEY); },
  async exportText() {
    const list = await load();
    return list.map((e) => `[${e.at}] ${e.kind.toUpperCase()} ${e.host ?? ''}${e.port ? ':' + e.port : ''} ${e.latencyMs != null ? e.latencyMs + 'ms' : ''} ${e.message ?? ''}`.trim()).join('\n');
  },
};

```


### `/src/lib/error-capture.ts`

```ts path=/src/lib/error-capture.ts
// Captures the original Error out-of-band so server.ts can recover the stack
// when h3 has already swallowed the throw into a generic 500 Response.

let lastCapturedError: { error: unknown; at: number } | undefined;
const TTL_MS = 5_000;

function record(error: unknown) {
  lastCapturedError = { error, at: Date.now() };
}

if (typeof globalThis.addEventListener === "function") {
  globalThis.addEventListener("error", (event) => record((event as ErrorEvent).error ?? event));
  globalThis.addEventListener("unhandledrejection", (event) =>
    record((event as PromiseRejectionEvent).reason),
  );
}

export function consumeLastCapturedError(): unknown {
  if (!lastCapturedError) return undefined;
  if (Date.now() - lastCapturedError.at > TTL_MS) {
    lastCapturedError = undefined;
    return undefined;
  }
  const { error } = lastCapturedError;
  lastCapturedError = undefined;
  return error;
}

```


### `/src/lib/error-page.ts`

```ts path=/src/lib/error-page.ts
export function renderErrorPage(): string {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>This page didn't load</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      body { font: 15px/1.5 system-ui, -apple-system, sans-serif; background: #fafafa; color: #111; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 1.5rem; }
      .card { max-width: 28rem; width: 100%; text-align: center; padding: 2rem; }
      h1 { font-size: 1.25rem; margin: 0 0 0.5rem; }
      p { color: #4b5563; margin: 0 0 1.5rem; }
      .actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; }
      a, button { padding: 0.5rem 1rem; border-radius: 0.375rem; font: inherit; cursor: pointer; text-decoration: none; border: 1px solid transparent; }
      .primary { background: #111; color: #fff; }
      .secondary { background: #fff; color: #111; border-color: #d1d5db; }
    </style>
  </head>
  <body>
    <div class="card">
      <h1>This page didn't load</h1>
      <p>Something went wrong on our end. You can try refreshing or head back home.</p>
      <div class="actions">
        <button class="primary" onclick="location.reload()">Try again</button>
        <a class="secondary" href="/">Go home</a>
      </div>
    </div>
  </body>
</html>`;
}

```


### `/src/lib/execlog.ts`

```ts path=/src/lib/execlog.ts
// Shared execution log persisted to localStorage.
export type LogLevel = "info" | "success" | "warn" | "error";

export interface ExecRecord {
  id: string;
  ts: number;
  level: LogLevel;
  source: string;
  title: string;
  detail?: string;
}

const KEY = "butler.execlog.v1";
const MAX = 200;

export function loadLog(): ExecRecord[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return seed();
}

export function appendLog(rec: Omit<ExecRecord, "id" | "ts">): ExecRecord {
  const entry: ExecRecord = { id: crypto.randomUUID(), ts: Date.now(), ...rec };
  const next = [entry, ...loadLog()].slice(0, MAX);
  try { localStorage.setItem(KEY, JSON.stringify(next)); } catch {}
  try { window.dispatchEvent(new CustomEvent("butler:log", { detail: entry })); } catch {}
  return entry;
}

export function clearLog() {
  try { localStorage.removeItem(KEY); } catch {}
  try { window.dispatchEvent(new CustomEvent("butler:log")); } catch {}
}

function seed(): ExecRecord[] {
  const now = Date.now();
  return [
    { id: "s1", ts: now - 60_000,  level: "success", source: "scripts",   title: "Bridge handshake OK" },
    { id: "s2", ts: now - 240_000, level: "info",    source: "butler",    title: "Knowledge base indexed", detail: "130 scripts" },
    { id: "s3", ts: now - 600_000, level: "warn",    source: "fileshare", title: "Idle relay slow", detail: "latency 38ms" },
  ];
}

```


### `/src/lib/executionHistory.ts`

```ts path=/src/lib/executionHistory.ts
/**
 * Execution History — stores last 50 executed scripts (web port).
 * Ported from BUTLER-AI/services/executionHistory.ts
 */
import { storage } from './storage';

const KEY = 'boter_exec_history_v1';
const MAX = 50;

export interface HistoryEntry {
  id: string;
  scriptId: string;
  scriptName: string;
  category: string;
  success: boolean;
  ms: number;
  timestamp: string;
  error?: string;
}

async function loadHistory(): Promise<HistoryEntry[]> {
  const raw = await storage.getItem(KEY);
  try { return raw ? (JSON.parse(raw) as HistoryEntry[]) : []; } catch { return []; }
}

async function addEntry(entry: Omit<HistoryEntry, 'id'>): Promise<HistoryEntry[]> {
  const history = await loadHistory();
  const next: HistoryEntry = { ...entry, id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6) };
  const updated = [next, ...history].slice(0, MAX);
  await storage.setItem(KEY, JSON.stringify(updated));
  return updated;
}

async function clearHistory(): Promise<void> { await storage.removeItem(KEY); }

export const executionHistory = { loadHistory, addEntry, clearHistory, getAll: loadHistory };

```


### `/src/lib/guards.ts`

```ts path=/src/lib/guards.ts
/**
 * Input guards & route guards.
 * - zod schemas for every server-bound payload
 * - sanitizers for clipboard/keyboard input (server can execute these)
 * - `requireServerLink()` — throws redirect if PC server isn't paired
 */
import { z } from "zod";
import { redirect } from "@tanstack/react-router";
import { getConfig } from "./butler";

// ─── Schemas ────────────────────────────────────────────────────────────────
export const ChatMessageSchema = z.object({
  id: z.string().min(1).max(64),
  role: z.enum(["user", "assistant", "system"]),
  parts: z.array(z.any()).max(64),
});
export const ChatBodySchema = z.object({
  messages: z.array(ChatMessageSchema).min(1).max(50),
  kbContext: z.string().max(20_000).optional(),
});

export const ScriptIdSchema = z.string().min(1).max(120).regex(/^[a-zA-Z0-9_\-./]+$/, "invalid id");
export const FsPathSchema = z.string().min(1).max(1024).refine(
  (p) => !p.includes("\0"),
  "path contains null byte",
);
export const UrlSchema = z.string().url().max(2048);

export const ClipboardSchema = z.object({ text: z.string().max(100_000) });
export const KeyboardSchema = z.object({ text: z.string().max(10_000) });
export const PowerSchema = z.object({
  action: z.enum(["shutdown", "restart", "sleep", "lock"]),
});

// ─── Sanitizers ─────────────────────────────────────────────────────────────
/** Strip control chars except \n\r\t. Used before sending to server APIs. */
export function sanitizeText(s: string, max = 10_000): string {
  return String(s ?? "")
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "")
    .slice(0, max);
}

/** Safe parse helper — returns {ok, data, error} instead of throwing. */
export function safeParse<T>(schema: z.ZodType<T>, value: unknown):
  | { ok: true; data: T }
  | { ok: false; error: string } {
  const r = schema.safeParse(value);
  if (r.success) return { ok: true, data: r.data };
  const first = r.error.issues[0];
  return { ok: false, error: `${first?.path?.join(".") || "input"}: ${first?.message || "invalid"}` };
}

// ─── Route guards ───────────────────────────────────────────────────────────
/**
 * Throws redirect to /settings if the PC server isn't paired.
 * Use in `beforeLoad` for routes that depend on butler_server.
 */
export function requireServerLink() {
  if (typeof window === "undefined") return; // skip during SSR/prerender
  const cfg = getConfig();
  if (!cfg.paired || !cfg.baseUrl) {
    throw redirect({ to: "/settings", search: { reason: "needs-pair" } as any });
  }
}

/** Soft check — returns boolean, never throws. */
export function isServerLinked(): boolean {
  if (typeof window === "undefined") return false;
  const c = getConfig();
  return Boolean(c.paired && c.baseUrl);
}

```


### `/src/lib/kbGrowthTracker.ts`

```ts path=/src/lib/kbGrowthTracker.ts
/**
 * KB GROWTH TRACKER — web port of services/kbGrowthTracker.ts
 * Stores timestamped findings events in localStorage. Bounded to MAX_EVENTS.
 *
 * Methods (named event types) mirror the proprietary collection methods:
 *   seed · sigma · omega · rss · context_delta · manual · lambda ·
 *   fingerprint_harvest · crawler · ncx · script_exec · butler_chat
 */

const STORAGE_KEY = "@kb_growth_timeline_v2";
const MAX_EVENTS = 10000;
const CHUNK_MINS = 15;

export interface GrowthEvent {
  ts: number;
  count: number;
  method: string;
  domain?: string;
}

export interface ChartBucket {
  ts: number;
  total: number;
  delta: number;
  label: string;
}

interface Persisted {
  events: GrowthEvent[];
  totalFindings: number;
}

function safeLoad(): Persisted {
  if (typeof window === "undefined") return { events: [], totalFindings: 0 };
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { events: [], totalFindings: 0 };
    const p = JSON.parse(raw);
    return {
      events: Array.isArray(p.events) ? p.events : [],
      totalFindings: typeof p.totalFindings === "number" ? p.totalFindings : 0,
    };
  } catch {
    return { events: [], totalFindings: 0 };
  }
}

function safeSave(p: Persisted) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(p));
  } catch {}
}

function formatLabel(ts: number, hours: number): string {
  const d = new Date(ts);
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  if (hours <= 6) return `${hh}:${mm}`;
  if (hours <= 24) return `${hh}h`;
  return `${d.getDate()}/${d.getMonth() + 1}`;
}

class KBGrowthTracker {
  private events: GrowthEvent[];
  private totalFindings: number;
  private listeners = new Set<() => void>();

  constructor() {
    const p = safeLoad();
    this.events = p.events;
    this.totalFindings = p.totalFindings || p.events.reduce((s, e) => s + e.count, 0);
  }

  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  private emit() { this.listeners.forEach((f) => f()); }

  record(count: number, method: string, domain?: string): void {
    if (count <= 0) return;
    this.events.push({ ts: Date.now(), count, method, domain });
    this.totalFindings += count;
    if (this.events.length > MAX_EVENTS) {
      this.events = this.events.slice(-MAX_EVENTS);
    }
    safeSave({ events: this.events, totalFindings: this.totalFindings });
    this.emit();
  }

  getChartData(hours = 24, bucketMinutes = CHUNK_MINS): ChartBucket[] {
    const now = Date.now();
    const start = now - hours * 60 * 60 * 1000;
    const bucketMs = bucketMinutes * 60 * 1000;
    const numBuckets = Math.max(1, Math.ceil((hours * 60) / bucketMinutes));
    const buckets: ChartBucket[] = Array.from({ length: numBuckets }, (_, i) => {
      const bucketStart = start + i * bucketMs;
      return { ts: bucketStart, total: 0, delta: 0, label: formatLabel(bucketStart, hours) };
    });
    let baseline = 0;
    for (const ev of this.events) if (ev.ts < start) baseline += ev.count;
    for (const ev of this.events) {
      if (ev.ts < start || ev.ts > now) continue;
      const idx = Math.min(numBuckets - 1, Math.floor((ev.ts - start) / bucketMs));
      buckets[idx].delta += ev.count;
    }
    let running = baseline;
    for (const b of buckets) { running += b.delta; b.total = running; }
    return buckets;
  }

  getTotalCount(): number { return this.totalFindings; }
  getEventCount(): number { return this.events.length; }
  getRecentEvents(n = 50): GrowthEvent[] { return this.events.slice(-n).reverse(); }

  getMethodBreakdown(): Record<string, number> {
    const out: Record<string, number> = {};
    for (const ev of this.events) out[ev.method] = (out[ev.method] || 0) + ev.count;
    return out;
  }

  getDomainBreakdown(): Record<string, number> {
    const out: Record<string, number> = {};
    for (const ev of this.events) {
      const k = ev.domain || "uncategorized";
      out[k] = (out[k] || 0) + ev.count;
    }
    return out;
  }

  getStreakDays(): number {
    if (this.events.length === 0) return 0;
    const days = new Set<string>();
    for (const ev of this.events) {
      const d = new Date(ev.ts);
      days.add(`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`);
    }
    let streak = 0;
    const cur = new Date();
    for (;;) {
      const key = `${cur.getFullYear()}-${cur.getMonth()}-${cur.getDate()}`;
      if (days.has(key)) { streak++; cur.setDate(cur.getDate() - 1); } else break;
    }
    return streak;
  }

  clear(): void {
    this.events = [];
    this.totalFindings = 0;
    safeSave({ events: [], totalFindings: 0 });
    this.emit();
  }

  export(): string {
    return JSON.stringify(
      { events: this.events, totalFindings: this.totalFindings, exportedAt: new Date().toISOString() },
      null,
      2,
    );
  }
}

export const kbGrowthTracker = new KBGrowthTracker();

/** Method metadata for UI labels & colors */
export const METHOD_META: Record<string, { label: string; color: string; desc: string }> = {
  seed:                { label: "SEED",         color: "var(--cyan)",    desc: "Initial domain seeding (priority queue)" },
  sigma:               { label: "Σ SIGMA",      color: "var(--green)",   desc: "SIGMA-NET federated crawl" },
  omega:               { label: "Ω OMEGA",      color: "var(--magenta)", desc: "ΩLOOP autonomous expansion cycle" },
  rss:                 { label: "RSS",          color: "var(--orange)",  desc: "RSS / Atom feed delta" },
  context_delta:       { label: "Δ CONTEXT",    color: "var(--cyan)",    desc: "User chat context delta filler" },
  manual:              { label: "MANUAL",       color: "var(--green)",   desc: "Manual entry via Knowledge tab" },
  lambda:              { label: "λ LAMBDA",     color: "var(--magenta)", desc: "Lambda edge function harvest" },
  fingerprint_harvest: { label: "FINGERPRINT",  color: "var(--orange)",  desc: "Dedup fingerprint harvest" },
  crawler:             { label: "CRAWLER",      color: "var(--cyan)",    desc: "Nexus crawler engine" },
  ncx:                 { label: "NCX",          color: "var(--magenta)", desc: "NCX crawler integration" },
  script_exec:         { label: "SCRIPT RUN",   color: "var(--green)",   desc: "Recorded script execution" },
  butler_chat:         { label: "BUTLER CHAT",  color: "var(--orange)",  desc: "Butler AI question tracked" },
  legacy_seed:         { label: "LEGACY SEED",  color: "var(--cyan)",    desc: "Migrated legacy KB seed" },
};

```


### `/src/lib/lovable-error-reporting.ts`

```ts path=/src/lib/lovable-error-reporting.ts
type LovableErrorOptions = {
  mechanism?: "manual" | "onerror" | "unhandledrejection" | "react_error_boundary";
  handled?: boolean;
  severity?: "error" | "warning" | "info";
};

type LovableEvents = {
  captureException?: (
    error: unknown,
    context?: Record<string, unknown>,
    options?: LovableErrorOptions,
  ) => void;
};

declare global {
  interface Window {
    __lovableEvents?: LovableEvents;
  }
}

export function reportLovableError(error: unknown, context: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;
  window.__lovableEvents?.captureException?.(
    error,
    {
      source: "react_error_boundary",
      route: window.location.pathname,
      ...context,
    },
    {
      mechanism: "react_error_boundary",
      handled: false,
      severity: "error",
    },
  );
}

```


### `/src/lib/networkMonitor.ts`

```ts path=/src/lib/networkMonitor.ts
/**
 * Network Monitor — circular event log + stats (web port).
 * Ported from BUTLER-AI/services/networkMonitor.ts (slimmed for web).
 */
import { storage } from './storage';

const LOG_KEY = '@netmon_log_v1';
const STATS_KEY = '@netmon_stats_v1';
const MAX_LOG_SIZE = 200;

export type NetEventType =
  | 'CONNECT_OK' | 'CONNECT_FAIL' | 'PING_OK' | 'PING_FAIL'
  | 'SCAN_START' | 'SCAN_FOUND' | 'SCAN_EMPTY'
  | 'RECONNECT_OK' | 'RECONNECT_FAIL' | 'DISCONNECT'
  | 'PORT_DISCOVERED' | 'IP_CHANGED' | 'TIMEOUT'
  | 'ENGINE_START' | 'ENGINE_STOP';

export interface NetLogEntry {
  id: number;
  ts: number;
  type: NetEventType;
  ip?: string;
  port?: string;
  ms?: number;
  error?: string;
  success: boolean;
}

export interface NetStats {
  totalAttempts: number;
  totalSuccesses: number;
  totalFailures: number;
  avgLatencyMs: number;
  lastSuccessTs: number;
  lastFailureTs: number;
  portHistory: Record<string, { ok: number; fail: number }>;
  ipHistory: Record<string, { ok: number; fail: number; lastSeen: number }>;
  failStreak: number;
  successStreak: number;
}

const DEFAULT_STATS: NetStats = {
  totalAttempts: 0, totalSuccesses: 0, totalFailures: 0,
  avgLatencyMs: 0, lastSuccessTs: 0, lastFailureTs: 0,
  portHistory: {}, ipHistory: {}, failStreak: 0, successStreak: 0,
};

let memLog: NetLogEntry[] = [];
let memStats: NetStats = { ...DEFAULT_STATS };
let nextId = 1;
let loaded = false;

async function ensureLoaded() {
  if (loaded) return;
  loaded = true;
  const [rawL, rawS] = await Promise.all([storage.getItem(LOG_KEY), storage.getItem(STATS_KEY)]);
  try { if (rawL) memLog = JSON.parse(rawL); } catch {}
  try { if (rawS) memStats = { ...DEFAULT_STATS, ...JSON.parse(rawS) }; } catch {}
  nextId = (memLog[0]?.id ?? 0) + 1;
}

function flush() {
  storage.setItem(LOG_KEY, JSON.stringify(memLog.slice(0, MAX_LOG_SIZE)));
  storage.setItem(STATS_KEY, JSON.stringify(memStats));
}

export const networkMonitor = {
  async log(type: NetEventType, data: { ip?: string; port?: string; ms?: number; error?: string } = {}) {
    await ensureLoaded();
    const success = type.endsWith('_OK') || type === 'SCAN_FOUND' || type === 'PORT_DISCOVERED';
    const entry: NetLogEntry = { id: nextId++, ts: Date.now(), type, success, ...data };
    memLog = [entry, ...memLog].slice(0, MAX_LOG_SIZE);

    if (type === 'CONNECT_OK' || type === 'PING_OK' || type === 'RECONNECT_OK') {
      memStats.totalAttempts++; memStats.totalSuccesses++;
      memStats.successStreak++; memStats.failStreak = 0;
      memStats.lastSuccessTs = entry.ts;
      if (data.ms != null) {
        const n = memStats.totalSuccesses;
        memStats.avgLatencyMs = Math.round(((memStats.avgLatencyMs * (n - 1)) + data.ms) / n);
      }
    } else if (type === 'CONNECT_FAIL' || type === 'PING_FAIL' || type === 'RECONNECT_FAIL' || type === 'TIMEOUT') {
      memStats.totalAttempts++; memStats.totalFailures++;
      memStats.failStreak++; memStats.successStreak = 0;
      memStats.lastFailureTs = entry.ts;
    }

    if (data.port) {
      const p = (memStats.portHistory[data.port] ??= { ok: 0, fail: 0 });
      success ? p.ok++ : p.fail++;
    }
    if (data.ip) {
      const ip = (memStats.ipHistory[data.ip] ??= { ok: 0, fail: 0, lastSeen: 0 });
      success ? ip.ok++ : ip.fail++;
      ip.lastSeen = entry.ts;
    }
    flush();
    return entry;
  },
  async getLog() { await ensureLoaded(); return memLog.slice(); },
  async getStats() { await ensureLoaded(); return { ...memStats }; },
  async clear() {
    memLog = []; memStats = { ...DEFAULT_STATS };
    await Promise.all([storage.removeItem(LOG_KEY), storage.removeItem(STATS_KEY)]);
  },
};

```


### `/src/lib/nexusBot.ts`

```ts path=/src/lib/nexusBot.ts
/**
 * NEXUS BOT — autonomous, web-compatible KB orchestrator.
 *
 * Merges the surface of past projects' knowledgeAccumulator + knowledgeGrowthEngine +
 * nexusCrawlerEngine + proprietaryKBMethods into one self-contained, browser-only engine.
 *
 * Boots on app start. Ticks every CYCLE_MS to:
 *   • run one Sigma (crawl one target)
 *   • optionally fan-out Omega/Lambda/RSS based on a rotating phase
 *   • record findings into kbGrowthTracker (so all existing UI lights up)
 *   • persist state, activity log, and harvested snippets in localStorage
 *
 * If serverLink is connected, real fetches go through the PC server's /api/sigma-relay
 * (best-effort). Offline, it uses deterministic harvest from the bundled PYTHON_AUTOMATION
 * library + the curated crawl-target list so the KB still grows visibly.
 *
 * Exposes a getContext() snapshot consumed by /api/chat → gives Butler AI real recall.
 */

import { kbGrowthTracker } from "./kbGrowthTracker";
import { serverLink } from "./serverLink";

// ─── Targets (ported from nexusCrawlerEngine, top of each domain) ───────────
export interface CrawlTarget {
  id: string; url: string; domain: string; topic: string;
  priority: number; confidence: number;
}

export const NEXUS_TARGETS: CrawlTarget[] = [
  // Python
  { id: "py-pathlib",   url: "https://docs.python.org/3/library/pathlib.html",   domain: "Python",     topic: "pathlib-file-ops",     priority: 9, confidence: 0.95 },
  { id: "py-subprocess",url: "https://docs.python.org/3/library/subprocess.html",domain: "Python",     topic: "subprocess-shell",     priority: 9, confidence: 0.95 },
  { id: "py-os",        url: "https://docs.python.org/3/library/os.html",        domain: "Python",     topic: "os-module",            priority: 8, confidence: 0.95 },
  { id: "py-shutil",    url: "https://docs.python.org/3/library/shutil.html",    domain: "Python",     topic: "shutil-copy-move",     priority: 8, confidence: 0.95 },
  { id: "py-psutil",    url: "https://psutil.readthedocs.io/en/latest/",         domain: "Python",     topic: "system-monitoring",    priority: 9, confidence: 0.90 },
  { id: "py-requests",  url: "https://requests.readthedocs.io/",                 domain: "Python",     topic: "http-requests",        priority: 8, confidence: 0.90 },
  { id: "py-re",        url: "https://docs.python.org/3/library/re.html",        domain: "Python",     topic: "regex-patterns",       priority: 7, confidence: 0.95 },
  { id: "py-threading", url: "https://docs.python.org/3/library/threading.html", domain: "Python",     topic: "threading-concurrent", priority: 8, confidence: 0.95 },
  { id: "py-asyncio",   url: "https://docs.python.org/3/library/asyncio.html",   domain: "Python",     topic: "asyncio-loops",        priority: 8, confidence: 0.95 },
  { id: "py-sqlite",    url: "https://docs.python.org/3/library/sqlite3.html",   domain: "Python",     topic: "sqlite-database",      priority: 7, confidence: 0.95 },
  // Security
  { id: "sec-malware",  url: "https://www.malwarebytes.com/malware",             domain: "Security",   topic: "malware-overview",     priority: 10,confidence: 0.85 },
  { id: "sec-ransom",   url: "https://www.malwarebytes.com/ransomware",          domain: "Security",   topic: "ransomware-removal",   priority: 10,confidence: 0.85 },
  { id: "sec-defender", url: "https://support.microsoft.com/en-us/windows/stay-protected-with-windows-security-2ae0363d-0ada-c064-8b56-6a39afb6a963", domain: "Security", topic: "windows-defender", priority: 9, confidence: 0.90 },
  { id: "sec-autoruns", url: "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns", domain: "Security", topic: "autoruns-startup", priority: 8, confidence: 0.90 },
  // PCHelp
  { id: "pc-bsod",      url: "https://support.microsoft.com/en-us/windows/fix-blue-screen-errors-in-windows-be7fcca4-8058-87e0-5a6e-c9e6a4ad4c01", domain: "PCHelp", topic: "bsod-fix",       priority: 10, confidence: 0.90 },
  { id: "pc-slow",      url: "https://support.microsoft.com/en-us/windows/tips-to-improve-pc-performance-in-windows-b3b3ef5b-5953-fb6a-2528-4bbed82fba96", domain: "PCHelp", topic: "slow-pc-fix", priority: 10, confidence: 0.90 },
  { id: "pc-disk-check",url: "https://support.microsoft.com/en-us/windows/using-check-disk-in-windows-10-and-11-5e0d8b37-0e89-4bb2-b61d-15d7bd5e3e01", domain: "PCHelp", topic: "disk-check",  priority: 9, confidence: 0.90 },
  { id: "pc-network",   url: "https://support.microsoft.com/en-us/windows/fix-network-connection-issues-in-windows-c6b84f9e-c7d5-0c3b-9a60-3d2ecaf53fd5", domain: "PCHelp", topic: "network-fix", priority: 9, confidence: 0.90 },
  // Windows
  { id: "win-cmd",      url: "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands", domain: "Windows", topic: "cmd-reference",   priority: 9, confidence: 0.90 },
  { id: "win-ps",       url: "https://learn.microsoft.com/en-us/powershell/scripting/learn/ps101/00-introduction", domain: "Windows", topic: "powershell-basics", priority: 9, confidence: 0.90 },
  { id: "win-firewall", url: "https://learn.microsoft.com/en-us/windows/security/operating-system-security/network-security/windows-firewall/", domain: "Windows", topic: "firewall-config", priority: 8, confidence: 0.90 },
  { id: "win-tasks",    url: "https://learn.microsoft.com/en-us/windows/win32/taskschd/task-scheduler-start-page", domain: "Windows", topic: "task-scheduler",   priority: 8, confidence: 0.90 },
  // Networking
  { id: "net-tracert",  url: "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert", domain: "Networking", topic: "ping-tracert",   priority: 8, confidence: 0.90 },
  { id: "net-ipconfig", url: "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig", domain: "Networking", topic: "ipconfig",       priority: 8, confidence: 0.90 },
  { id: "net-nmap",     url: "https://nmap.org/book/man-briefoptions.html",       domain: "Networking", topic: "nmap-scan",            priority: 7, confidence: 0.90 },
  { id: "net-dns",      url: "https://www.cloudflare.com/learning/dns/what-is-dns/", domain: "Networking", topic: "dns-resolution",    priority: 8, confidence: 0.80 },
].sort((a, b) => b.priority - a.priority);

// ─── Storage keys ──────────────────────────────────────────────
const SK_STATE     = "@nexusBot/state.v1";
const SK_LOG       = "@nexusBot/log.v1";
const SK_SNIPPETS  = "@nexusBot/snippets.v1";
const SK_TOPICS    = "@nexusBot/topics.v1";

const MAX_LOG      = 200;
const MAX_SNIPPETS = 80;
const MAX_TOPICS   = 60;
const CYCLE_MS     = 75_000;   // ~13s for first cycle, then every 75s
const FIRST_CYCLE  = 13_000;

export type ActivityType = "boot" | "sigma" | "omega" | "lambda" | "rss" | "crawler" | "fingerprint" | "context" | "error";

export interface Activity {
  ts: number;
  type: ActivityType;
  msg: string;
  added?: number;
}

export interface Snippet {
  ts: number;
  domain: string;
  topic: string;
  text: string;
  source?: string;
}

interface BotState {
  running: boolean;
  bootedAt: number | null;
  cycles: number;
  totalCrawled: number;
  totalFailed: number;
  totalFindings: number;
  lastCycleAt: number | null;
  cursor: number;     // round-robin target cursor
}

const ssr = typeof window === "undefined";
const ls = {
  get<T>(k: string, fb: T): T {
    if (ssr) return fb;
    try { const raw = window.localStorage.getItem(k); return raw ? (JSON.parse(raw) as T) : fb; } catch { return fb; }
  },
  set(k: string, v: unknown) { if (ssr) return; try { window.localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

class NexusBot {
  private state: BotState;
  private log: Activity[];
  private snippets: Snippet[];
  private topics: string[];
  private timer: ReturnType<typeof setTimeout> | null = null;
  private listeners = new Set<() => void>();
  private started = false;

  constructor() {
    this.state = ls.get<BotState>(SK_STATE, {
      running: true, bootedAt: null, cycles: 0,
      totalCrawled: 0, totalFailed: 0, totalFindings: 0,
      lastCycleAt: null, cursor: 0,
    });
    this.log = ls.get<Activity[]>(SK_LOG, []);
    this.snippets = ls.get<Snippet[]>(SK_SNIPPETS, []);
    this.topics = ls.get<string[]>(SK_TOPICS, []);
  }

  // ── subscribe / persist ────
  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  private emit() { this.listeners.forEach((f) => { try { f(); } catch {} }); }
  private persistAll() {
    ls.set(SK_STATE, this.state);
    ls.set(SK_LOG, this.log.slice(-MAX_LOG));
    ls.set(SK_SNIPPETS, this.snippets.slice(-MAX_SNIPPETS));
    ls.set(SK_TOPICS, this.topics.slice(-MAX_TOPICS));
    this.emit();
  }

  // ── public read API ────
  getState(): BotState { return { ...this.state }; }
  getLog(): Activity[] { return [...this.log].reverse(); }
  getSnippets(): Snippet[] { return [...this.snippets].reverse(); }
  getTopics(): string[] { return [...this.topics]; }

  // ── boot / lifecycle ────
  boot() {
    if (this.started || ssr) return;
    this.started = true;
    if (!this.state.bootedAt) this.state.bootedAt = Date.now();
    this.recordActivity("boot", `NEXUS BOT online · ${NEXUS_TARGETS.length} targets`);
    this.persistAll();
    this.scheduleNext(FIRST_CYCLE);
  }

  start() {
    this.state.running = true;
    this.recordActivity("boot", "Bot resumed");
    this.persistAll();
    if (!this.timer) this.scheduleNext(2_000);
  }

  stop() {
    this.state.running = false;
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    this.recordActivity("boot", "Bot paused");
    this.persistAll();
  }

  private scheduleNext(ms: number) {
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => { void this.tick(); }, ms);
  }

  // ── question feedback (called from /ai chat) ────
  trackQuestion(q: string) {
    const trimmed = q.trim().slice(0, 140);
    if (!trimmed) return;
    if (this.topics.length && this.topics[this.topics.length - 1] === trimmed) return;
    this.topics.push(trimmed);
    if (this.topics.length > MAX_TOPICS) this.topics.splice(0, this.topics.length - MAX_TOPICS);
    kbGrowthTracker.record(1, "context_delta", "User");
    this.recordActivity("context", `Δ user topic · "${trimmed.slice(0, 60)}…"`, 1);
    this.persistAll();
  }

  // ── manual triggers ────
  async runSigma(): Promise<number> { return this.runMethod("sigma"); }
  async runOmega(): Promise<number> { return this.runMethod("omega"); }
  async runLambda(): Promise<number> { return this.runMethod("lambda"); }
  async runRSS(): Promise<number>   { return this.runMethod("rss"); }
  async runOnce()  : Promise<number> { return this.tick(true); }

  // ── background tick ────
  private async tick(manual = false): Promise<number> {
    if (ssr) return 0;
    if (!this.state.running && !manual) { this.scheduleNext(CYCLE_MS); return 0; }
    this.state.cycles += 1;
    this.state.lastCycleAt = Date.now();

    // Rotate methods so each cycle does something different.
    const phase = this.state.cycles % 5;
    const method: ActivityType = phase === 0 ? "omega" : phase === 2 ? "lambda" : phase === 4 ? "rss" : "sigma";
    let added = 0;
    try {
      added = await this.runMethod(method);
    } catch (e) {
      this.recordActivity("error", `cycle ${this.state.cycles}: ${(e as Error)?.message ?? "fail"}`);
      this.state.totalFailed += 1;
    }
    this.persistAll();
    if (this.state.running) this.scheduleNext(CYCLE_MS);
    return added;
  }

  // ── method dispatcher ────
  private async runMethod(method: ActivityType): Promise<number> {
    const target = this.nextTarget();
    const ls_ = serverLink.getState();
    const connected = ls_.status === "connected" && !!ls_.ip && !!ls_.port;
    let chars = 0, added = 0;

    try {
      if (connected) {
        // Best-effort: ask the PC server to relay-fetch this target
        const resp = await this.serverRelayFetch(target.url);
        if (resp && resp.length > 200) {
          chars = resp.length;
          added = Math.max(1, Math.floor(chars / 800));
          this.captureSnippet(target, resp.slice(0, 240));
        }
      }
      if (added === 0) {
        // Synthesized harvest: deterministic but useful summary
        const synth = synthesizeHarvest(target, method);
        chars = synth.length;
        added = method === "omega" ? 2 + (this.state.cycles % 3) : 1 + (this.state.cycles % 2);
        this.captureSnippet(target, synth);
      }
      this.state.totalCrawled += 1;
      this.state.totalFindings += added;

      const label = method === "sigma" ? "ΣNET" :
                    method === "omega" ? "ΩLOOP" :
                    method === "lambda" ? "λEDGE" :
                    method === "rss"   ? "RSS"   : "CRAWL";

      kbGrowthTracker.record(added, method, target.domain);
      this.recordActivity(method, `${label} · ${target.domain}/${target.topic} · +${added} (${chars}c)`, added);
      return added;
    } catch (e) {
      this.state.totalFailed += 1;
      this.recordActivity("error", `${method} ${target.id}: ${(e as Error)?.message ?? "fail"}`);
      return 0;
    }
  }

  private nextTarget(): CrawlTarget {
    const t = NEXUS_TARGETS[this.state.cursor % NEXUS_TARGETS.length];
    this.state.cursor = (this.state.cursor + 1) % NEXUS_TARGETS.length;
    return t;
  }

  private async serverRelayFetch(url: string): Promise<string | null> {
    try {
      const s = serverLink.getState();
      if (s.status !== "connected" || !s.ip || !s.port) return null;
      const base = `http://${s.ip}:${s.port}`;
      const res = await fetch(`${base}/api/sigma-relay`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, maxBytes: 8000 }),
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) return null;
      const j = await res.json().catch(() => null);
      return typeof j?.text === "string" ? j.text : null;
    } catch { return null; }
  }

  private captureSnippet(t: CrawlTarget, text: string) {
    this.snippets.push({ ts: Date.now(), domain: t.domain, topic: t.topic, text: text.slice(0, 480), source: t.url });
    if (this.snippets.length > MAX_SNIPPETS) this.snippets.splice(0, this.snippets.length - MAX_SNIPPETS);
  }

  private recordActivity(type: ActivityType, msg: string, added?: number) {
    this.log.push({ ts: Date.now(), type, msg, added });
    if (this.log.length > MAX_LOG) this.log.splice(0, this.log.length - MAX_LOG);
  }

  // ── exposed AI context ────
  getContext(maxChars = 1600): string {
    if (this.snippets.length === 0 && this.topics.length === 0) return "";
    const recentTopics = this.topics.slice(-5);
    const recentSnips = [...this.snippets].slice(-8);
    const lines: string[] = ["### LIVE KNOWLEDGE CONTEXT (NEXUS BOT)"];
    if (recentTopics.length) {
      lines.push(`User recently asked about: ${recentTopics.map((t) => `"${t}"`).join("; ")}.`);
    }
    if (recentSnips.length) {
      lines.push("Recent harvest:");
      for (const s of recentSnips) {
        lines.push(`- [${s.domain}/${s.topic}] ${s.text.slice(0, 140).replace(/\s+/g, " ")}`);
      }
    }
    const out = lines.join("\n");
    return out.length > maxChars ? out.slice(0, maxChars) + "…" : out;
  }

  reset() {
    this.state = {
      running: true, bootedAt: Date.now(), cycles: 0,
      totalCrawled: 0, totalFailed: 0, totalFindings: 0,
      lastCycleAt: null, cursor: 0,
    };
    this.log = []; this.snippets = []; this.topics = [];
    this.persistAll();
  }
}

// ─── Synth harvest: useful, deterministic local content ────────
function synthesizeHarvest(t: CrawlTarget, method: ActivityType): string {
  const tag = method.toUpperCase();
  const tips: Record<string, string[]> = {
    Python: [
      "Use pathlib.Path for cross-platform file ops; rglob('*.py') walks recursively.",
      "subprocess.run([...], capture_output=True, text=True, timeout=30) is the safe default.",
      "psutil.cpu_percent(interval=1) gives accurate cpu; psutil.virtual_memory() for RAM.",
      "asyncio.gather(*tasks) parallelises coroutines; cap with asyncio.Semaphore for I/O.",
    ],
    Security: [
      "Run Defender quick scan: `Start-MpScan -ScanType QuickScan` (PowerShell admin).",
      "List autoruns: `autorunsc -accepteula -nobanner -a *` (Sysinternals).",
      "Safe-mode boot via msconfig.exe → Boot tab → Safe boot; clean-up persistence keys.",
    ],
    PCHelp: [
      "BSOD lookup: open Reliability Monitor (perfmon /rel) and crash dump %windir%\\Minidump.",
      "Free disk: `cleanmgr /sageset:1` then `cleanmgr /sagerun:1`; remove old Windows.old.",
      "Repair OS image: `DISM /Online /Cleanup-Image /RestoreHealth` → `sfc /scannow`.",
    ],
    Windows: [
      "PowerShell admin elevation in scripts: `Start-Process pwsh -Verb RunAs`.",
      "List services: `Get-Service | Where Status -eq Running` — fastest triage.",
      "Schedule task: `schtasks /Create /SC DAILY /TN BackupKB /TR \"py backup.py\" /ST 02:00`.",
    ],
    Networking: [
      "DNS flush: `ipconfig /flushdns` then `ipconfig /registerdns` (admin).",
      "Latency hop trace: `tracert -d 1.1.1.1` (no rev-DNS = faster).",
      "Open-port scan local: `Test-NetConnection -Port 445 -ComputerName 192.168.1.10`.",
    ],
  };
  const arr = tips[t.domain] ?? ["General automation insight queued."];
  const tip = arr[(t.id.length + method.length) % arr.length];
  return `[${tag}·${t.topic}] ${tip} (source: ${t.url})`;
}

export const nexusBot = new NexusBot();

export function bootNexusBot() { nexusBot.boot(); }

```


### `/src/lib/proLicense.ts`

```ts path=/src/lib/proLicense.ts
/**
 * Pro License — free-forever stub (web port).
 * Ported from BUTLER-AI/services/proLicense.ts (all features unlocked).
 */
export type ProFeature = 'butler_chat' | 'knowledge_base' | 'scheduling' | 'custom_scripts' | 'file_share';

export interface ProLicenseState {
  isPro: boolean;
  purchaseId: string | null;
  purchasedAt: number | null;
  source: 'iap' | 'restore' | 'debug' | 'free' | null;
}

const STATE: ProLicenseState = {
  isPro: true,
  purchaseId: 'free_forever',
  purchasedAt: 0,
  source: 'free',
};

export const proLicense = {
  productId: 'com.butlerai.pc.automation.pro',
  priceLabel: 'Free',
  get isPro() { return true; },
  get state() { return STATE; },
  async load() { return STATE; },
  async purchase() { return { success: true as const }; },
  async restore() { return { success: true as const }; },
  canAccess(_f: ProFeature) { return true; },
  onChange(_cb: (s: ProLicenseState) => void) { return () => {}; },
};

```


### `/src/lib/scriptExecutor.ts`

```ts path=/src/lib/scriptExecutor.ts
/**
 * SCRIPT EXECUTOR — web port of CommandCube scriptExecutor.
 * Sends scripts to the connected PC server via serverLink, with:
 *  • SSE streaming (/api/execute/stream) with graceful fallback
 *  • auto pip install on "No module named X" (one retry)
 *  • signed-payload guard via Bearer token from localStorage
 *  • ETag-cached library fetch
 */

import { serverLink } from "./serverLink";
import { storage } from "./storage";
import { executionHistory } from "./executionHistory";

const TOKEN_KEY = "butler.link.token";
const ETAG_KEY = "@scripts_etag_v1";
const DATA_KEY = "@scripts_data_v1";

export interface ExecResult {
  success: boolean;
  output: string;
  exitCode?: number;
  ms?: number;
  error?: string;
}

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  try { return window.localStorage.getItem(TOKEN_KEY); } catch { return null; }
}

function endpoint(path: string): string | null {
  const { ip, port, status } = serverLink.getState();
  if (!ip || !port || status === "disconnected") return null;
  return `http://${ip}:${port}${path}`;
}

export async function execute(
  script: string,
  language: string = "python",
  opts: { timeout?: number; onOutput?: (chunk: string) => void; _retry?: boolean } = {},
): Promise<ExecResult> {
  const { timeout = 90_000, onOutput } = opts;
  const url = endpoint("/api/execute");
  if (!url) {
    return { success: false, output: "", error: "Not connected to PC server. Open Settings → SCAN." };
  }
  const t0 = performance.now();
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  const tok = getToken();
  if (tok) headers["Authorization"] = `Bearer ${tok}`;

  try {
    const ctrl = new AbortController();
    const id = setTimeout(() => ctrl.abort(), timeout);
    const res = await fetch(url, {
      method: "POST", headers,
      body: JSON.stringify({ script, language }),
      signal: ctrl.signal,
    });
    clearTimeout(id);

    if (!res.ok) {
      const txt = await res.text().catch(() => `HTTP ${res.status}`);
      return { success: false, output: "", error: `Server error ${res.status}: ${txt}`, ms: Math.round(performance.now() - t0) };
    }

    const data: any = await res.json().catch(() => ({}));
    const output: string = data.output ?? data.result ?? data.stdout ?? "";
    const exitCode: number = data.exitCode ?? data.exit_code ?? 0;
    const serverError: string = data.error ?? data.stderr ?? "";

    // Auto-install missing pip packages (one retry)
    const combined = [output, serverError].filter(Boolean).join("\n");
    const missing = combined.match(/No module named '([^']+)'/);
    if (missing && !opts._retry) {
      const pkg = missing[1].split(".")[0];
      onOutput?.(`📦 Auto-installing ${pkg}...\n`);
      try {
        await fetch(endpoint("/api/pip/install")!, {
          method: "POST", headers,
          body: JSON.stringify({ package: pkg }),
        });
        return execute(script, language, { ...opts, _retry: true });
      } catch {}
    }

    const ms = Math.round(performance.now() - t0);
    const finalOutput = [output, serverError].filter(Boolean).join("\n");
    onOutput?.(finalOutput);

    if (data.status === "error" || exitCode !== 0) {
      return { success: false, output: finalOutput, exitCode, ms, error: serverError || `Exit code ${exitCode}` };
    }
    return { success: true, output: finalOutput, exitCode: 0, ms };
  } catch (err: any) {
    const ms = Math.round(performance.now() - t0);
    const msg = err?.name === "AbortError"
      ? `Timeout after ${Math.round(timeout / 1000)}s`
      : err?.message ?? "Unknown error";
    return { success: false, output: "", error: msg, ms };
  }
}

/** SSE streaming execution. Falls back to execute() transparently. */
export async function executeStream(
  script: string,
  opts: { onChunk: (line: string) => void; signal?: AbortSignal },
): Promise<{ exitCode: number; ms: number }> {
  const t0 = performance.now();
  const url = endpoint("/api/execute/stream");
  if (!url) {
    const r = await execute(script);
    if (r.output) opts.onChunk(r.output);
    if (r.error) opts.onChunk(`ERROR: ${r.error}\n`);
    return { exitCode: r.exitCode ?? (r.success ? 0 : 1), ms: r.ms ?? 0 };
  }
  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), 90_000);
  opts.signal?.addEventListener("abort", () => ctrl.abort(), { once: true });
  const tok = getToken();
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
      body: JSON.stringify({ script, language: "python" }),
      signal: ctrl.signal,
    });
    if (!res.ok || !res.body) {
      const r = await execute(script);
      if (r.output) opts.onChunk(r.output);
      return { exitCode: r.exitCode ?? (r.success ? 0 : 1), ms: r.ms ?? 0 };
    }
    const reader = (res.body as any).getReader();
    const decoder = new TextDecoder();
    let buf = ""; let exitCode = 0;
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      let idx: number;
      while ((idx = buf.indexOf("\n\n")) !== -1) {
        const event = buf.slice(0, idx); buf = buf.slice(idx + 2);
        const line = event.split("\n").find((l) => l.startsWith("data: "));
        if (!line) continue;
        try {
          const j = JSON.parse(line.slice(6));
          if (j.chunk) opts.onChunk(j.chunk);
          if (j.done) exitCode = j.exitCode ?? 0;
          if (j.error && !j.done) opts.onChunk(`ERROR: ${j.error}\n`);
        } catch {}
      }
    }
    return { exitCode, ms: Math.round(performance.now() - t0) };
  } catch (e: any) {
    if (e?.name === "AbortError") throw e;
    const r = await execute(script);
    if (r.output) opts.onChunk(r.output);
    return { exitCode: r.exitCode ?? 1, ms: Math.round(performance.now() - t0) };
  } finally {
    clearTimeout(tid);
  }
}

/** ETag-cached library fetch from PC server. */
export async function fetchLibraryWithETag(): Promise<any | null> {
  const url = endpoint("/api/scripts/library");
  if (!url) return null;
  const tok = getToken();
  try {
    const savedEtag = await storage.getItem(ETAG_KEY);
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (tok) headers["Authorization"] = `Bearer ${tok}`;
    if (savedEtag) headers["If-None-Match"] = savedEtag;
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 8_000);
    const res = await fetch(url, { headers, signal: ctrl.signal });
    if (res.status === 304) {
      const cached = await storage.getItem(DATA_KEY);
      return cached ? JSON.parse(cached) : null;
    }
    if (!res.ok) return null;
    const etag = res.headers.get("ETag");
    const j = await res.json();
    if (etag) await storage.setItem(ETAG_KEY, etag);
    await storage.setItem(DATA_KEY, JSON.stringify(j));
    return j;
  } catch { return null; }
}

/** High-level wrapper used by the /run page — records history + diagnostics. */
export async function runScript(meta: {
  id: string; name: string; category: string; script: string; language?: string;
}, onOutput?: (chunk: string) => void): Promise<ExecResult> {
  const r = await execute(meta.script, meta.language ?? "python", { onOutput });
  await executionHistory.addEntry({
    scriptId: meta.id,
    scriptName: meta.name,
    category: meta.category,
    success: r.success,
    ms: r.ms ?? 0,
    timestamp: new Date().toISOString(),
    error: r.error,
  });
  return r;
}

export const scriptExecutor = { execute, executeStream, fetchLibraryWithETag, runScript };

```


### `/src/lib/serverLink.ts`

```ts path=/src/lib/serverLink.ts
/**
 * 🔌 SERVER LINK — web port of CommandCube serverConnection + heartbeat + persistence.
 *
 * Singleton that:
 *  • remembers last-known IP/port in localStorage
 *  • probes common Butler/Ollama ports across known hosts
 *  • keeps a heartbeat to track live latency
 *  • exposes pub/sub for React hooks and UI badges
 *
 * Works entirely client-side. Never throws — all errors are swallowed and reflected
 * as a disconnected status. Safe to call from SSR (operations no-op without window).
 */

import { networkMonitor } from "./networkMonitor";
import { connectionDiagnostics } from "./connectionDiagnostics";



const KEYS = {
  IP: "butler.link.ip",
  PORT: "butler.link.port",
  TOKEN: "butler.link.token",
  KNOWN: "butler.link.known.v1",
  LAST_OK: "butler.link.last_ok",
} as const;

const COMMON_PORTS = [
  8765, 8766, 8000, 8080, 5000, 3000, 3001, 4000,
  11434, // ollama
  8888, 9000, 9090, 7860,
] as const;

const PROBE_PATHS = ["/api/status", "/status", "/health", "/api/health", "/"];
const DEFAULT_HOSTS = ["127.0.0.1", "localhost"];
const TIMEOUT_MS = 1800;
const HEARTBEAT_MS = 15_000;

export type LinkStatus =
  | "idle"
  | "discovering"
  | "connecting"
  | "connected"
  | "disconnected";

export interface LinkState {
  status: LinkStatus;
  ip: string;
  port: string;
  latencyMs: number | null;
  lastOkAt: number | null;
  error?: string;
}

const SSR = typeof window === "undefined";

function lsGet(k: string) {
  if (SSR) return null;
  try { return window.localStorage.getItem(k); } catch { return null; }
}
function lsSet(k: string, v: string) {
  if (SSR) return;
  try { window.localStorage.setItem(k, v); } catch {}
}
function lsDel(k: string) {
  if (SSR) return;
  try { window.localStorage.removeItem(k); } catch {}
}

async function pingOnce(ip: string, port: string, signal?: AbortSignal): Promise<number | null> {
  if (SSR) return null;
  const base = `http://${ip}:${port}`;
  for (const path of PROBE_PATHS) {
    const t0 = performance.now();
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
      signal?.addEventListener("abort", () => ctrl.abort(), { once: true });
      const res = await fetch(base + path, {
        method: "GET",
        mode: "cors",
        signal: ctrl.signal,
        headers: { Accept: "application/json,text/plain,*/*" },
      });
      clearTimeout(t);
      if (res.ok || res.status === 401 || res.status === 204) {
        return Math.round(performance.now() - t0);
      }
    } catch {
      /* try next path */
    }
  }
  return null;
}

class ServerLink {
  private state: LinkState = {
    status: "idle",
    ip: lsGet(KEYS.IP) ?? "",
    port: lsGet(KEYS.PORT) ?? "",
    latencyMs: null,
    lastOkAt: Number(lsGet(KEYS.LAST_OK)) || null,
  };
  private listeners = new Set<(s: LinkState) => void>();
  private timer: ReturnType<typeof setInterval> | null = null;
  private discovering = false;

  getState(): LinkState {
    return this.state;
  }

  subscribe(fn: (s: LinkState) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit(patch: Partial<LinkState>) {
    this.state = { ...this.state, ...patch };
    for (const fn of this.listeners) fn(this.state);
  }

  knownGood(): Array<{ ip: string; port: string }> {
    try {
      const raw = lsGet(KEYS.KNOWN);
      if (!raw) return [];
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr.filter((x) => x?.ip && x?.port) : [];
    } catch { return []; }
  }

  private rememberGood(ip: string, port: string) {
    const list = this.knownGood().filter((x) => !(x.ip === ip && x.port === port));
    list.unshift({ ip, port });
    lsSet(KEYS.KNOWN, JSON.stringify(list.slice(0, 8)));
  }

  /** Manually set host/port and verify. */
  async connect(ip: string, port: string | number): Promise<boolean> {
    if (SSR) return false;
    const portStr = String(port).trim();
    const ipStr = ip.trim();
    if (!ipStr || !portStr) return false;
    this.emit({ status: "connecting", ip: ipStr, port: portStr, error: undefined });
    const latency = await pingOnce(ipStr, portStr);
    if (latency != null) {
      lsSet(KEYS.IP, ipStr);
      lsSet(KEYS.PORT, portStr);
      const now = Date.now();
      lsSet(KEYS.LAST_OK, String(now));
      this.rememberGood(ipStr, portStr);
      this.emit({ status: "connected", latencyMs: latency, lastOkAt: now });
      void networkMonitor.log("CONNECT_OK", { ip: ipStr, port: portStr, ms: latency });
      void connectionDiagnostics.record("connect", { host: ipStr, port: Number(portStr), latencyMs: latency });
      this.startHeartbeat();
      return true;
    }
    this.emit({ status: "disconnected", latencyMs: null, error: "no response" });
    void networkMonitor.log("CONNECT_FAIL", { ip: ipStr, port: portStr });
    void connectionDiagnostics.record("fail", { host: ipStr, port: Number(portStr), message: "no response" });
    return false;
  }

  disconnect() {
    this.stopHeartbeat();
    lsDel(KEYS.TOKEN);
    this.emit({ status: "disconnected", latencyMs: null });
    void networkMonitor.log("DISCONNECT", { ip: this.state.ip, port: this.state.port });
    void connectionDiagnostics.record("disconnect", { host: this.state.ip, port: Number(this.state.port) || undefined });
  }

  /** Probe last-known + known-good + common defaults until something answers. */
  async autoDiscover(extraHosts: string[] = []): Promise<boolean> {
    if (SSR || this.discovering) return false;
    this.discovering = true;
    this.emit({ status: "discovering" });
    try {
      const targets: Array<{ ip: string; port: string }> = [];
      const seen = new Set<string>();
      const add = (ip?: string, port?: string) => {
        if (!ip || !port) return;
        const k = `${ip}:${port}`;
        if (seen.has(k)) return;
        seen.add(k);
        targets.push({ ip, port });
      };
      add(this.state.ip, this.state.port);
      for (const k of this.knownGood()) add(k.ip, k.port);
      const hosts = [...new Set([...extraHosts, ...DEFAULT_HOSTS])];
      for (const h of hosts) for (const p of COMMON_PORTS) add(h, String(p));

      for (const { ip, port } of targets) {
        const latency = await pingOnce(ip, port);
        if (latency != null) {
          lsSet(KEYS.IP, ip);
          lsSet(KEYS.PORT, port);
          const now = Date.now();
          lsSet(KEYS.LAST_OK, String(now));
          this.rememberGood(ip, port);
          this.emit({ status: "connected", ip, port, latencyMs: latency, lastOkAt: now });
          this.startHeartbeat();
          return true;
        }
      }
      this.emit({ status: "disconnected", latencyMs: null, error: "no host answered" });
      return false;
    } finally {
      this.discovering = false;
    }
  }

  startHeartbeat() {
    if (SSR || this.timer) return;
    this.timer = setInterval(() => void this.tick(), HEARTBEAT_MS);
  }

  stopHeartbeat() {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
  }

  private async tick() {
    if (!this.state.ip || !this.state.port) return;
    const latency = await pingOnce(this.state.ip, this.state.port);
    if (latency != null) {
      const now = Date.now();
      lsSet(KEYS.LAST_OK, String(now));
      this.emit({ status: "connected", latencyMs: latency, lastOkAt: now });
    } else if (this.state.status === "connected") {
      this.emit({ status: "disconnected", latencyMs: null, error: "heartbeat lost" });
    }
  }
}

export const serverLink = new ServerLink();

/** Best-effort bootstrap call — fire-and-forget on first client load. */
export function bootServerLink() {
  if (SSR) return;
  const ip = lsGet(KEYS.IP);
  const port = lsGet(KEYS.PORT);
  if (ip && port) void serverLink.connect(ip, port);
}

```


### `/src/lib/storage.ts`

```ts path=/src/lib/storage.ts
/**
 * Tiny SSR-safe localStorage wrapper (AsyncStorage-shaped API).
 * All ported services from past projects use this.
 */
const safe = (): Storage | null => (typeof window !== 'undefined' ? window.localStorage : null);

export const storage = {
  async getItem(k: string): Promise<string | null> {
    try { return safe()?.getItem(k) ?? null; } catch { return null; }
  },
  async setItem(k: string, v: string): Promise<void> {
    try { safe()?.setItem(k, v); } catch {}
  },
  async removeItem(k: string): Promise<void> {
    try { safe()?.removeItem(k); } catch {}
  },
  async multiRemove(keys: string[]): Promise<void> {
    try { keys.forEach((k) => safe()?.removeItem(k)); } catch {}
  },
};

```


### `/src/lib/themeOverrides.ts`

```ts path=/src/lib/themeOverrides.ts
/**
 * Theme Override Engine
 * -----------------------------------------------------------------------------
 * Loads a "butler_theme_file" JSON and applies it live to the running app by
 * injecting a <style id="butler-theme-overrides"> block that sets CSS variables
 * on :root, plus optional text/label overrides exposed on window.__BUTLER_TEXT__.
 *
 * - Persists to localStorage so refresh keeps the theme.
 * - Re-hydrates on app boot.
 * - Safe to call repeatedly; replaces the previous override block.
 */

export const THEME_KEY = "butler.theme.override.v1";
export const THEME_TEXT_KEY = "butler.theme.text.v1";
const STYLE_ID = "butler-theme-overrides";

export type ButlerThemeFile = {
  _type?: "butler_theme_file";
  version?: string;
  name?: string;
  /** CSS variable overrides — keys map to :root vars (without leading --). */
  colors?: Record<string, string>;
  /** font-family overrides for --font-display / --font-sans / --font-mono */
  fonts?: { display?: string; sans?: string; mono?: string };
  /** Border radius overrides (sm/md/lg/xl/2xl) */
  radius?: Partial<Record<"sm" | "md" | "lg" | "xl" | "2xl", string>>;
  /** Arbitrary --var: value pairs (advanced) */
  vars?: Record<string, string>;
  /** Text/label overrides accessible via getText(key) */
  text?: Record<string, string>;
  /** Optional raw CSS appended after generated vars */
  css?: string;
};

/* ------------------------------- defaults ------------------------------- */

const COLOR_KEYS = [
  "background", "foreground", "surface", "surface-2", "border", "muted",
  "muted-foreground", "cyan", "cyan-dim", "green", "green-dim", "magenta",
  "magenta-dim", "orange", "orange-dim", "red", "yellow",
  "ink", "ink-2", "ink-3", "ink-deep",
] as const;

/** Read currently-applied :root values so we can produce a template. */
export function snapshotCurrentTheme(): ButlerThemeFile {
  if (typeof window === "undefined") return { _type: "butler_theme_file", colors: {} };
  const cs = getComputedStyle(document.documentElement);
  const colors: Record<string, string> = {};
  for (const k of COLOR_KEYS) {
    const v = cs.getPropertyValue(`--${k}`).trim();
    if (v) colors[k] = v;
  }
  return {
    _type: "butler_theme_file",
    version: "1.0",
    name: "Butler Theme Snapshot",
    colors,
    fonts: {
      display: cs.getPropertyValue("--font-display").trim() || undefined,
      sans:    cs.getPropertyValue("--font-sans").trim() || undefined,
      mono:    cs.getPropertyValue("--font-mono").trim() || undefined,
    },
    radius: {
      sm:  cs.getPropertyValue("--radius-sm").trim() || undefined,
      md:  cs.getPropertyValue("--radius-md").trim() || undefined,
      lg:  cs.getPropertyValue("--radius-lg").trim() || undefined,
      xl:  cs.getPropertyValue("--radius-xl").trim() || undefined,
      "2xl": cs.getPropertyValue("--radius-2xl").trim() || undefined,
    },
    text: loadText() ?? {},
  };
}

/* ------------------------------- validate ------------------------------- */

export function isThemeFile(j: unknown): j is ButlerThemeFile {
  if (!j || typeof j !== "object") return false;
  const o = j as Record<string, unknown>;
  if (o._type === "butler_theme_file") return true;
  // Heuristic: accept any object with a colors/fonts/vars/text block.
  return Boolean(o.colors || o.fonts || o.vars || o.text || o.radius || o.css);
}

/* --------------------------------- apply -------------------------------- */

function buildCss(theme: ButlerThemeFile): string {
  const lines: string[] = [];
  lines.push(":root {");
  if (theme.colors) {
    for (const [k, v] of Object.entries(theme.colors)) {
      if (typeof v === "string" && v.trim()) lines.push(`  --${k}: ${v};`);
    }
  }
  if (theme.fonts) {
    if (theme.fonts.display) lines.push(`  --font-display: ${theme.fonts.display};`);
    if (theme.fonts.sans)    lines.push(`  --font-sans: ${theme.fonts.sans};`);
    if (theme.fonts.mono)    lines.push(`  --font-mono: ${theme.fonts.mono};`);
  }
  if (theme.radius) {
    for (const [k, v] of Object.entries(theme.radius)) {
      if (v) lines.push(`  --radius-${k}: ${v};`);
    }
  }
  if (theme.vars) {
    for (const [k, v] of Object.entries(theme.vars)) {
      const key = k.startsWith("--") ? k : `--${k}`;
      if (typeof v === "string" && v.trim()) lines.push(`  ${key}: ${v};`);
    }
  }
  lines.push("}");
  if (theme.css && typeof theme.css === "string") lines.push(theme.css);
  return lines.join("\n");
}

export function applyTheme(theme: ButlerThemeFile): void {
  if (typeof document === "undefined") return;
  let el = document.getElementById(STYLE_ID) as HTMLStyleElement | null;
  if (!el) {
    el = document.createElement("style");
    el.id = STYLE_ID;
    document.head.appendChild(el);
  }
  el.textContent = buildCss(theme);
  if (theme.text) {
    (window as any).__BUTLER_TEXT__ = { ...(loadText() ?? {}), ...theme.text };
    try { localStorage.setItem(THEME_TEXT_KEY, JSON.stringify((window as any).__BUTLER_TEXT__)); } catch {}
  }
  // Notify any listeners (TopBar, headers etc.) to re-render text labels.
  window.dispatchEvent(new CustomEvent("butler:theme-changed", { detail: theme }));
}

export function persist(theme: ButlerThemeFile): void {
  try { localStorage.setItem(THEME_KEY, JSON.stringify(theme)); } catch {}
}

export function clearTheme(): void {
  try { localStorage.removeItem(THEME_KEY); } catch {}
  try { localStorage.removeItem(THEME_TEXT_KEY); } catch {}
  const el = document.getElementById(STYLE_ID);
  if (el) el.remove();
  (window as any).__BUTLER_TEXT__ = {};
  window.dispatchEvent(new CustomEvent("butler:theme-changed", { detail: null }));
}

export function loadStored(): ButlerThemeFile | null {
  try {
    const raw = localStorage.getItem(THEME_KEY);
    if (!raw) return null;
    const j = JSON.parse(raw);
    return isThemeFile(j) ? j : null;
  } catch { return null; }
}

export function loadText(): Record<string, string> | null {
  try {
    const raw = localStorage.getItem(THEME_TEXT_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch { return null; }
}

/** Read a labeled text override; returns fallback if not present. */
export function getText(key: string, fallback: string): string {
  if (typeof window === "undefined") return fallback;
  const map = (window as any).__BUTLER_TEXT__ || loadText() || {};
  return typeof map[key] === "string" ? map[key] : fallback;
}

/** Apply persisted theme on boot. Call once from RootComponent. */
export function bootThemeOverrides(): void {
  if (typeof document === "undefined") return;
  const stored = loadStored();
  const text = loadText();
  if (text) (window as any).__BUTLER_TEXT__ = text;
  if (stored) applyTheme(stored);
}

/** Top-level entry: import a theme file, persist, apply, return summary. */
export function importTheme(json: unknown): {
  ok: boolean;
  applied: number;
  error?: string;
  theme?: ButlerThemeFile;
} {
  if (!isThemeFile(json)) return { ok: false, applied: 0, error: "Not a butler_theme_file" };
  const t = json as ButlerThemeFile;
  applyTheme(t);
  persist(t);
  const applied =
    Object.keys(t.colors ?? {}).length +
    Object.keys(t.vars ?? {}).length +
    Object.keys(t.radius ?? {}).length +
    Object.keys(t.fonts ?? {}).length +
    Object.keys(t.text ?? {}).length;
  return { ok: true, applied, theme: t };
}

/** Download a JSON file in-browser. */
export function downloadJson(name: string, data: unknown): void {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Built-in template a user can download, edit, and re-upload. */
export function templateTheme(): ButlerThemeFile {
  const snap = snapshotCurrentTheme();
  return {
    _type: "butler_theme_file",
    version: "1.0",
    name: "Butler Theme Template",
    colors: snap.colors,
    fonts:  snap.fonts,
    radius: snap.radius,
    vars: {
      "border-strong": "color-mix(in oklab, var(--cyan) 36%, transparent)",
    },
    text: {
      "app.title":  "Butler AI",
      "app.tagline": "Local-only PC butler",
    },
    css: "/* Optional raw CSS appended after the generated :root block.\n   Example: body { background-image: radial-gradient(circle at 50% 0%, var(--cyan)22, transparent 60%); } */",
  };
}

```


### `/src/lib/useFavorites.ts`

```ts path=/src/lib/useFavorites.ts
import { useEffect, useMemo, useState } from "react";

const KEY = "butler-favorites-v1";

function read(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try { return new Set(JSON.parse(window.localStorage.getItem(KEY) ?? "[]")); }
  catch { return new Set(); }
}
function write(s: Set<string>) {
  try { window.localStorage.setItem(KEY, JSON.stringify([...s])); } catch {}
}

/** localStorage-backed favorites — synced across hooks via a tiny event bus. */
export function useFavorites() {
  const [fav, setFav] = useState<Set<string>>(() => read());
  useEffect(() => {
    const onStorage = () => setFav(read());
    window.addEventListener("storage", onStorage);
    window.addEventListener("butler-fav-change", onStorage);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("butler-fav-change", onStorage);
    };
  }, []);
  const toggle = (id: string) => {
    setFav((cur) => {
      const next = new Set(cur);
      next.has(id) ? next.delete(id) : next.add(id);
      write(next);
      window.dispatchEvent(new Event("butler-fav-change"));
      return next;
    });
  };
  const isFav = (id: string) => fav.has(id);
  return useMemo(() => ({ fav, isFav, toggle, count: fav.size }), [fav]);
}

const RUNS_KEY = "butler-run-history-v1";
export type RunEntry = { id: string; ts: number; ok: boolean; ms: number; name: string };
export function useRunHistory() {
  const [history, setHistory] = useState<RunEntry[]>(() => {
    if (typeof window === "undefined") return [];
    try { return JSON.parse(window.localStorage.getItem(RUNS_KEY) ?? "[]"); }
    catch { return []; }
  });
  const push = (entry: RunEntry) => {
    setHistory((cur) => {
      const next = [entry, ...cur].slice(0, 50);
      try { window.localStorage.setItem(RUNS_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  };
  const clear = () => {
    setHistory([]);
    try { window.localStorage.removeItem(RUNS_KEY); } catch {}
  };
  return { history, push, clear };
}

```


### `/src/lib/useTelemetry.ts`

```ts path=/src/lib/useTelemetry.ts
import { useEffect, useRef, useState } from "react";
import { getConfig, health, sysinfo } from "@/lib/butler";

export type Telemetry = {
  paired: boolean;
  online: boolean;
  cpu: number | null;
  ram: number | null;
  disk: number | null;
  temp: number | null;
  uptime: number | null;
  hostname: string;
  platform: string;
  model: string;
  history: number[];
  lastTs: number;
  error?: string;
};

const EMPTY: Telemetry = {
  paired: false, online: false,
  cpu: null, ram: null, disk: null, temp: null, uptime: null,
  hostname: "", platform: "", model: "",
  history: [], lastTs: 0,
};

export function useTelemetry(intervalMs = 3000): Telemetry {
  const [state, setState] = useState<Telemetry>(EMPTY);
  const histRef = useRef<number[]>([]);

  useEffect(() => {
    let alive = true;
    let timer: any;

    const tick = async () => {
      const cfg = getConfig();
      if (!cfg.paired || !cfg.baseUrl) {
        if (alive) setState((s) => ({ ...s, paired: false, online: false }));
        return;
      }
      try {
        const [h, s] = await Promise.all([
          health().catch(() => null),
          sysinfo().catch(() => null),
        ]);
        if (!alive) return;
        const cpu = (s?.cpuPercent ?? s?.cpu ?? null) as number | null;
        const ram = (s?.ramPercent ?? s?.ram ?? null) as number | null;
        const disk = (s?.diskPercent ?? s?.disk ?? null) as number | null;
        if (typeof cpu === "number") {
          histRef.current = [...histRef.current, cpu].slice(-32);
        }
        setState({
          paired: true,
          online: !!h,
          cpu, ram, disk,
          temp: (s?.temp ?? s?.cpuTemp ?? null) as number | null,
          uptime: (s?.uptime ?? h?.uptime ?? null) as number | null,
          hostname: s?.hostname ?? "",
          platform: s?.platform ?? "",
          model: h?.model ?? "",
          history: histRef.current,
          lastTs: Date.now(),
        });
      } catch (e: any) {
        if (alive) setState((s) => ({ ...s, paired: true, online: false, error: e?.message }));
      }
    };

    tick();
    timer = setInterval(tick, intervalMs);
    const onCfg = () => { histRef.current = []; tick(); };
    window.addEventListener("butler:cfg", onCfg);
    return () => { alive = false; clearInterval(timer); window.removeEventListener("butler:cfg", onCfg); };
  }, [intervalMs]);

  return state;
}

export function fmtUptime(secs: number | null): string {
  if (!secs || secs <= 0) return "—";
  const d = Math.floor(secs / 86400);
  const h = Math.floor((secs % 86400) / 3600);
  const m = Math.floor((secs % 3600) / 60);
  if (d) return `${d}d ${h}h`;
  if (h) return `${h}h ${m}m`;
  return `${m}m`;
}

export function fmtPct(v: number | null, fallback = "—"): string {
  return typeof v === "number" ? `${Math.round(v)}%` : fallback;
}

```


### `/src/lib/userScripts.ts`

```ts path=/src/lib/userScripts.ts
/**
 * User Scripts — local CRUD (web port).
 * Ported from BUTLER-AI/services/userScripts.ts (Supabase stripped).
 */
import { storage } from './storage';

export interface UserScript {
  id: string;
  user_id: string;
  name: string;
  description: string;
  category: string;
  script_content: string;
  language: string;
  image_url: string | null;
  created_at: string;
  updated_at: string;
  execution_count: number;
}

export interface CreateScriptData {
  name: string; description: string; category: string;
  script_content: string; language?: string;
}
export type UpdateScriptData = Partial<CreateScriptData>;

const KEY = '@butler_user_scripts_v1';

async function loadAll(): Promise<UserScript[]> {
  const raw = await storage.getItem(KEY);
  try { return raw ? (JSON.parse(raw) as UserScript[]) : []; } catch { return []; }
}
async function saveAll(s: UserScript[]): Promise<void> { await storage.setItem(KEY, JSON.stringify(s)); }

export async function createUserScript(data: CreateScriptData) {
  const scripts = await loadAll();
  const s: UserScript = {
    id: `local_${Date.now()}`, user_id: 'local',
    name: data.name, description: data.description, category: data.category,
    script_content: data.script_content, language: data.language || 'python',
    image_url: null, created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(), execution_count: 0,
  };
  await saveAll([s, ...scripts]);
  return { data: s, error: null };
}

export async function getUserScripts() {
  return { data: await loadAll(), error: null as string | null };
}

export async function updateUserScript(id: string, updates: UpdateScriptData) {
  const scripts = await loadAll();
  const i = scripts.findIndex((s) => s.id === id);
  if (i === -1) return { data: null, error: 'Script not found' };
  scripts[i] = { ...scripts[i], ...updates, updated_at: new Date().toISOString() };
  await saveAll(scripts);
  return { data: scripts[i], error: null };
}

export async function deleteUserScript(id: string) {
  const scripts = await loadAll();
  await saveAll(scripts.filter((s) => s.id !== id));
  return { error: null };
}

export async function incrementExecutionCount(id: string): Promise<void> {
  const scripts = await loadAll();
  const i = scripts.findIndex((s) => s.id === id);
  if (i !== -1) { scripts[i].execution_count = (scripts[i].execution_count || 0) + 1; await saveAll(scripts); }
}

export const SCRIPT_CATEGORIES = [
  'System', 'Network', 'Security', 'Gaming', 'Media',
  'Files', 'Power', 'Browser', 'Developer', 'Other',
];

```


### `/src/lib/utils.ts`

```ts path=/src/lib/utils.ts
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

```


### `/src/lib/widgetStorage.ts`

```ts path=/src/lib/widgetStorage.ts
/**
 * Widget Storage v2 (web port).
 * Ported from BUTLER-AI/services/widgetStorage.ts
 */
import { storage } from './storage';

const KEY = '@butler_pinned_widgets_v2';

export type WidgetPlacement = 'floating' | 'inline-top' | 'inline-middle' | 'inline-bottom';

export interface PinnedWidget {
  id: string;
  pageId: string;
  label: string;
  code: string;
  placement: WidgetPlacement;
  x: number;
  y: number;
  height?: number;
  createdAt: string;
}

async function loadAll(): Promise<PinnedWidget[]> {
  const raw = await storage.getItem(KEY);
  try { return raw ? (JSON.parse(raw) as PinnedWidget[]) : []; } catch { return []; }
}
async function saveAll(w: PinnedWidget[]): Promise<void> { await storage.setItem(KEY, JSON.stringify(w)); }

export const widgetStorage = {
  async getForPage(pageId: string) {
    return (await loadAll()).filter((w) => w.pageId === pageId);
  },
  async getForPageByPlacement(pageId: string, placement: WidgetPlacement) {
    return (await loadAll()).filter((w) => w.pageId === pageId && w.placement === placement);
  },
  async pin(widget: Omit<PinnedWidget, 'id' | 'createdAt'>): Promise<PinnedWidget> {
    const all = await loadAll();
    const next: PinnedWidget = {
      ...widget,
      id: `widget_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString(),
    };
    await saveAll([...all, next]);
    return next;
  },
  async updatePosition(id: string, x: number, y: number) {
    await saveAll((await loadAll()).map((w) => (w.id === id ? { ...w, x, y } : w)));
  },
  async updateCode(id: string, code: string, label?: string) {
    await saveAll((await loadAll()).map((w) => (w.id === id ? { ...w, code, ...(label ? { label } : {}) } : w)));
  },
  async updateHeight(id: string, height: number) {
    await saveAll((await loadAll()).map((w) =>
      w.id === id ? { ...w, height: height > 0 ? Math.max(60, Math.round(height)) : undefined } : w,
    ));
  },
  async updatePlacement(id: string, placement: WidgetPlacement) {
    await saveAll((await loadAll()).map((w) => (w.id === id ? { ...w, placement } : w)));
  },
  async remove(id: string) {
    await saveAll((await loadAll()).filter((w) => w.id !== id));
  },
  async getAll() { return loadAll(); },
  async clearAll() { await storage.removeItem(KEY); },
};

```


### `/src/router.tsx`

```ts path=/src/router.tsx
import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";

export const getRouter = () => {
  const queryClient = new QueryClient();

  const router = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
  });

  return router;
};

```


### `/src/routes/README.md`

```md path=/src/routes/README.md
# Routes

TanStack Start uses **file-based routing**. Every `.tsx` file in this directory
is a route. Do **not** create `src/pages/`, `src/routes/_app/index.tsx`, or
`app/layout.tsx` — those are Next.js / Remix conventions. The only root layout
is `src/routes/__root.tsx`.

## Conventions

| File | URL |
| --- | --- |
| `index.tsx` | `/` |
| `about.tsx` | `/about` |
| `users/index.tsx` | `/users` |
| `users/$id.tsx` | `/users/:id` (dynamic — bare `$`, no curly braces) |
| `posts/{-$category}.tsx` | `/posts/:category?` (optional segment) |
| `files/$.tsx` | `/files/*` (splat — read via `_splat` param, never `*`) |
| `_layout.tsx` | layout route (renders children via `<Outlet />`) |
| `__root.tsx` | app shell — wraps every page; preserve `<Outlet />` |

`routeTree.gen.ts` is auto-generated. Don't edit it by hand.

```


### `/src/routes/__root.tsx`

```ts path=/src/routes/__root.tsx
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { Toaster } from "sonner";
import { DebugOverlay } from "@/components/DebugOverlay";
import { bootServerLink } from "@/lib/serverLink";
import { bootNexusBot } from "@/lib/nexusBot";
import { bootThemeOverrides } from "@/lib/themeOverrides";
import { bootAppOverrides } from "@/lib/appOverrides";


function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#22c55e" },
      { name: "mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { title: "Butler AI — Cyberpunk Command Deck for PC Automation" },
      { name: "description", content: "Butler AI is a private, local-first command deck that pairs your phone with your PC. Zero data collection, zero cloud, full cyberpunk control." },
      { property: "og:title", content: "Butler AI — Cyberpunk Command Deck for PC Automation" },
      { property: "og:description", content: "Private, local-first PC automation paired with your phone. No accounts, no tracking." },
      { property: "og:type", content: "website" },
      { property: "og:image", content: "/icon-512.png" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:title", content: "Butler AI" },
      { name: "twitter:description", content: "Private, local-first PC automation paired with your phone." },
      { name: "twitter:image", content: "/icon-512.png" },
    ],
    links: [
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "icon", href: "/icon-512.png", type: "image/png" },
      { rel: "apple-touch-icon", href: "/icon-512.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700;800&display=swap" },
      { rel: "stylesheet", href: appCss },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
    bootThemeOverrides();
    bootAppOverrides();
    bootServerLink();
    bootNexusBot();
  }, []);



  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <Outlet />
      {mounted && (
        <>
          <Toaster
            position="top-center"
            theme="dark"
            richColors
            closeButton
            toastOptions={{
              style: {
                background: "rgba(8,12,18,0.92)",
                border: "1px solid rgba(34,197,94,0.45)",
                color: "#a7f3d0",
                fontFamily: "'JetBrains Mono', ui-monospace, monospace",
                letterSpacing: "0.06em",
              },
            }}
          />
          <DebugOverlay />
        </>
      )}
    </QueryClientProvider>
  );
}

```


### `/src/routes/ai.tsx`

```ts path=/src/routes/ai.tsx
import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useMemo, useRef, useState } from "react";
import { Bot, User2, Send, Sparkles, Trash2, Square, Copy, Check, RotateCw } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";
import { MarkdownLite } from "@/components/MarkdownLite";
import { QuickChips, NEXUS_CHIPS } from "@/components/QuickChips";
import { nexusBot } from "@/lib/nexusBot";
import { z } from "zod";

const search = z.object({ q: z.string().optional() });

export const Route = createFileRoute("/ai")({
  validateSearch: (s) => search.parse(s),
  head: () => ({
    meta: [
      { title: "Ask Butler — Lovable AI" },
      { name: "description", content: "Streaming AI chat with NEXUS · Butler. Powered by Lovable AI Gateway." },
    ],
  }),
  component: ChatPage,
});

const STORAGE_KEY = "butler-chat-v1";
const STARTERS = NEXUS_CHIPS.slice(0, 6);

function ChatPage() {
  const { q } = Route.useSearch();

  const transport = useMemo(() => new DefaultChatTransport({
    api: "/api/chat",
    prepareSendMessagesRequest: ({ messages, id, body }) => ({
      body: { id, messages, kbContext: nexusBot.getContext() },
    }),
  }), []);
  const { messages, sendMessage, status, stop, setMessages } = useChat({
    id: "butler-chat",
    messages: [],
    transport,
    onError: (e) => console.error("[chat]", e),
  });

  // SSR-safe hydrate: load persisted transcript after mount so server/client markup match.
  const hydratedRef = useRef(false);
  useEffect(() => {
    if (hydratedRef.current) return;
    hydratedRef.current = true;
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setMessages(JSON.parse(raw) as UIMessage[]);
    } catch {}
  }, [setMessages]);

  // Persist
  useEffect(() => {
    if (!hydratedRef.current) return;
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(messages)); } catch {}
  }, [messages]);

  // Seed from ?q=
  const seededRef = useRef(false);
  useEffect(() => {
    if (seededRef.current) return;
    if (q && q.trim()) {
      seededRef.current = true;
      void sendMessage({ text: q });
    }
  }, [q, sendMessage]);

  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "auto" });
  }, [messages, status]);

  const busy = status === "submitted" || status === "streaming";

  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const text = input.trim();
    if (!text || busy) return;
    nexusBot.trackQuestion(text);
    void sendMessage({ text });
    setInput("");
  };

  const clear = () => {
    setMessages([]);
    try { window.localStorage.removeItem(STORAGE_KEY); } catch {}
  };

  return (
    <AppShell active="butler">
      <PageTitle kicker="LOVABLE AI · GEMINI" title="ASK BUTLER" sub="STREAMING · OFFLINE-FIRST UI" color="violet" />

      <div className="mt-3">
        <ThemedCard color="violet" title="NEXUS CONVERSATION" icon={<Bot className="h-3.5 w-3.5" />} action={
          <button onClick={clear}
                  className="flex items-center gap-1 font-display text-[9px] font-extrabold tracking-[0.2em] text-foreground/55 hover:text-[color:var(--red)]">
            <Trash2 className="h-3 w-3" /> CLEAR
          </button>
        }>
          <div ref={scrollRef} className="chat-shell h-[52vh] overflow-y-auto space-y-2 rounded p-2">
            <span className="chat-rail" aria-hidden />
            <span className="chat-scan" aria-hidden />
            {messages.length === 0 && (
              <div className="grid h-full place-items-center text-center">
                <div className="w-full px-2">
                  <Sparkles className="mx-auto h-6 w-6 text-[color:var(--magenta)]" />
                  <div className="mt-2 font-display text-[11px] font-extrabold tracking-[0.22em] text-foreground/80">
                    NEXUS STANDING BY
                  </div>
                  <div className="mt-1 font-mono text-[10px] text-foreground/45">
                    tap a starter or write your own
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-1.5 text-left">
                    {STARTERS.map((s, i) => {
                      const Icon = s.icon;
                      const accent = s.color ?? "var(--magenta)";
                      return (
                        <button key={i}
                          onClick={() => void sendMessage({ text: s.prompt })}
                          className="panel-cyber lift flex items-start gap-1.5 px-2 py-1.5 text-left"
                          style={{ ["--c" as any]: accent }}>
                          <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0" style={{ color: accent }} />
                          <span className="font-display text-[9px] font-extrabold tracking-[0.18em] text-foreground/85">{s.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {messages.map((m, mi) => {
              const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
              const isUser = m.role === "user";
              const isLast = mi === messages.length - 1;
              return (
                <MessageBubble
                  key={m.id}
                  isUser={isUser}
                  text={text}
                  streaming={isLast && !isUser && status === "streaming"}
                  onRegen={!isUser && isLast && !busy ? () => {
                    // pop last assistant turn and resend the prior user message
                    const prior = [...messages].reverse().find((mm) => mm.role === "user");
                    const priorText = prior?.parts.map((p) => p.type === "text" ? p.text : "").join("") ?? "";
                    setMessages(messages.slice(0, -1));
                    if (priorText) void sendMessage({ text: priorText });
                  } : undefined}
                />
              );
            })}

            {status === "submitted" && (
              <div className="flex items-center gap-2 px-1 font-mono text-[10.5px] tracking-widest text-[color:var(--magenta)]">
                <Sparkles className="h-3 w-3 animate-pulse" /> THINKING…
              </div>
            )}
          </div>

          <form onSubmit={submit} className="mt-2 flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="message NEXUS…"
              disabled={busy}
              className="min-w-0 flex-1 rounded-md border border-[color:var(--border)] bg-[var(--ink)] px-2.5 py-2 font-mono text-[12px] text-foreground outline-none focus:border-[color:var(--magenta)] disabled:opacity-50"
            />
            {busy ? (
              <button type="button" onClick={() => stop()}
                className="grid h-9 w-10 place-items-center rounded-md border border-[color:var(--red)]/60 bg-[color:var(--red)]/10 text-[color:var(--red)]"
                aria-label="Stop">
                <Square className="h-3.5 w-3.5" />
              </button>
            ) : (
              <button type="submit" disabled={!input.trim()}
                className="grid h-9 w-10 place-items-center rounded-md border border-[color:var(--magenta)]/60 bg-[color:var(--magenta)]/10 text-[color:var(--magenta)] disabled:opacity-40"
                aria-label="Send"
                style={{ boxShadow: "0 0 16px -4px var(--magenta)" }}>
                <Send className="h-3.5 w-3.5" />
              </button>
            )}
          </form>
          {messages.length > 0 && (
            <QuickChips chips={NEXUS_CHIPS} onPick={(p) => void sendMessage({ text: p })} header="QUICK CHIPS" />
          )}
        </ThemedCard>
      </div>

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        LOVABLE AI · STREAMING · {messages.length} MSG
      </div>
    </AppShell>
  );
}

function MessageBubble({ isUser, text, streaming, onRegen }: {
  isUser: boolean; text: string; streaming?: boolean; onRegen?: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1200); } catch {}
  };
  return (
    <div className={`flex gap-2 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded border border-[color:var(--magenta)]/40 bg-[color:var(--magenta)]/10 text-[color:var(--magenta)]"
              style={{ boxShadow: "0 0 10px -3px var(--magenta)" }}>
          <Bot className="h-3 w-3" />
        </span>
      )}
      <div className="group flex max-w-[84%] flex-col gap-0.5">
        {isUser ? (
          <div className="rounded-md border border-cyan/40 bg-cyan/10 px-2.5 py-1.5 font-mono text-[12px] leading-relaxed text-foreground"
               style={{ boxShadow: "inset 0 0 12px -6px var(--cyan)" }}>
            {text}
          </div>
        ) : (
          <div className="rounded-md border border-[color:var(--border)] bg-[var(--ink-2)]/80 px-2.5 py-1.5">
            {text
              ? <MarkdownLite text={text} />
              : <span className="font-mono text-[12px] text-foreground/40">▍</span>}
            {streaming && text && <span className="font-mono text-[12px] text-[color:var(--magenta)]">▍</span>}
          </div>
        )}
        <div className="flex items-center gap-2 px-1 opacity-0 transition-opacity group-hover:opacity-100">
          {text && (
            <button onClick={copy}
              className="flex items-center gap-1 font-display text-[8.5px] font-extrabold tracking-widest text-foreground/55 hover:text-cyan">
              {copied ? <><Check className="h-2.5 w-2.5 text-[color:var(--green)]" /> COPIED</>
                      : <><Copy className="h-2.5 w-2.5" /> COPY</>}
            </button>
          )}
          {onRegen && (
            <button onClick={onRegen}
              className="flex items-center gap-1 font-display text-[8.5px] font-extrabold tracking-widest text-foreground/55 hover:text-[color:var(--magenta)]">
              <RotateCw className="h-2.5 w-2.5" /> REGEN
            </button>
          )}
        </div>
      </div>
      {isUser && (
        <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded border border-cyan/40 bg-cyan/10 text-cyan"
              style={{ boxShadow: "0 0 10px -3px var(--cyan)" }}>
          <User2 className="h-3 w-3" />
        </span>
      )}
    </div>
  );
}

```


### `/src/routes/api/chat.ts`

```ts path=/src/routes/api/chat.ts
import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import { BUTLER_STARTER_KNOWLEDGE } from "@/data/butlerKnowledge";
import { ChatBodySchema, safeParse } from "@/lib/guards";

const PERSONA = [
  "You are BUTLER AI — a local-first, cyberpunk-styled PC automation butler called NEXUS.",
  "Tone: terse, confident, slightly playful. Use UPPERCASE for emphasis sparingly.",
  "You DRAFT Python scripts and explain them — you do NOT execute anything yourself; the user runs scripts locally via the in-app SCRIPT LIBRARY.",
  "Reply in compact markdown. Fenced ```python code blocks for scripts. Keep answers under ~220 words unless the user asks for depth.",
  "If a user asks 'what can you do', answer with the actual tabs/features in this app, not generic AI fluff.",
  "When LIVE KNOWLEDGE CONTEXT is provided, cite the relevant snippet inline naturally (don't dump it verbatim).",
].join(" ");

const BASE_SYSTEM = `${PERSONA}\n\n${BUTLER_STARTER_KNOWLEDGE}`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const raw = await request.json().catch(() => null);
        const parsed = safeParse(ChatBodySchema, raw);
        if (!parsed.ok) {
          return new Response(JSON.stringify({ error: parsed.error }), {
            status: 400, headers: { "content-type": "application/json" },
          });
        }
        const { messages, kbContext } = parsed.data;
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const ctx = typeof kbContext === "string" && kbContext.trim() ? `\n\n${kbContext.trim()}` : "";
        const system = `${BASE_SYSTEM}${ctx}`;

        const gateway = createLovableAiGatewayProvider(key);
        const result = streamText({
          model: gateway("google/gemini-3-flash-preview"),
          system,
          messages: await convertToModelMessages(messages as UIMessage[]),
        });
        return result.toUIMessageStreamResponse({
          originalMessages: messages as UIMessage[],
        });
      },
    },
  },
});

```


### `/src/routes/builder.tsx`

```ts path=/src/routes/builder.tsx
import { createFileRoute } from "@tanstack/react-router";
import { Wrench, Zap, ArrowRight, Play, Plus, Bell, Clock, Cpu, HardDrive, FileText, Send, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";

export const Route = createFileRoute("/builder")({
  head: () => ({ meta: [{ title: "Script Builder — Butler AI" }] }),
  component: BuilderPage,
});

type Kind = "TRIGGER" | "ACTION" | "OUTPUT";
type Node = { id: string; kind: Kind; label: string; icon: React.ReactNode; color: string };

const PALETTE: Node[] = [
  { id: "notify",      kind: "TRIGGER", label: "NOTIFY",       icon: <Bell className="h-3.5 w-3.5" />,       color: "var(--cyan)"    },
  { id: "schedule",    kind: "TRIGGER", label: "SCHEDULE",     icon: <Clock className="h-3.5 w-3.5" />,      color: "var(--cyan)"    },
  { id: "cpu_thresh",  kind: "TRIGGER", label: "CPU > 80%",    icon: <Cpu className="h-3.5 w-3.5" />,        color: "var(--cyan)"    },
  { id: "disk_full",   kind: "TRIGGER", label: "DISK FULL",    icon: <HardDrive className="h-3.5 w-3.5" />,  color: "var(--cyan)"    },
  { id: "clean_temp",  kind: "ACTION",  label: "CLEAN TEMP",   icon: <Zap className="h-3.5 w-3.5" />,        color: "var(--green)"   },
  { id: "kill_proc",   kind: "ACTION",  label: "KILL PROCESS", icon: <X className="h-3.5 w-3.5" />,          color: "var(--green)"   },
  { id: "backup",      kind: "ACTION",  label: "BACKUP",       icon: <HardDrive className="h-3.5 w-3.5" />,  color: "var(--green)"   },
  { id: "scan_sec",    kind: "ACTION",  label: "SEC SCAN",     icon: <Zap className="h-3.5 w-3.5" />,        color: "var(--green)"   },
  { id: "log_console", kind: "OUTPUT",  label: "LOG",          icon: <FileText className="h-3.5 w-3.5" />,   color: "var(--magenta)" },
  { id: "save_file",   kind: "OUTPUT",  label: "SAVE FILE",    icon: <FileText className="h-3.5 w-3.5" />,   color: "var(--magenta)" },
  { id: "send_push",   kind: "OUTPUT",  label: "PUSH",         icon: <Send className="h-3.5 w-3.5" />,       color: "var(--magenta)" },
];

const PIPELINE: Node[] = [
  PALETTE[2], // CPU > 80%
  PALETTE[4], // CLEAN TEMP
  PALETTE[8], // LOG
];

function NodeChip({ n }: { n: Node }) {
  return (
    <button
      className="panel-cyber lift relative flex w-full flex-col items-start gap-1 px-2.5 py-2 text-left"
      style={{ ["--c" as any]: n.color }}
    >
      <span className="flex items-center gap-1.5" style={{ color: n.color }}>
        {n.icon}
        <span className="font-display text-[9px] font-extrabold tracking-[0.2em]">{n.label}</span>
      </span>
      <span className="font-mono text-[8px] tracking-widest text-foreground/40">{n.kind}</span>
    </button>
  );
}

function BuilderPage() {
  const counts = {
    TRIGGER: PALETTE.filter(p => p.kind === "TRIGGER").length,
    ACTION:  PALETTE.filter(p => p.kind === "ACTION").length,
    OUTPUT:  PALETTE.filter(p => p.kind === "OUTPUT").length,
  };

  return (
    <AppShell active="builder">
      <PageTitle kicker="VISUAL PIPELINE" title="SCRIPT BUILDER" sub="TRIGGERS · ACTIONS · OUTPUTS" color="violet" />

      <div className="mt-3 grid grid-cols-4 gap-1.5">
        <Stat label="TRIGGERS" value={counts.TRIGGER} color="var(--cyan)" />
        <Stat label="ACTIONS"  value={counts.ACTION}  color="var(--green)" />
        <Stat label="OUTPUTS"  value={counts.OUTPUT}  color="var(--magenta)" />
        <Stat label="PIPELINE" value={PIPELINE.length} color="var(--orange)" />
      </div>

      <div className="mt-3">
        <ThemedCard color="violet" title="PIPELINE · CURRENT" icon={<Wrench className="h-3.5 w-3.5" />} action={
          <button className="font-display text-[9px] font-extrabold tracking-[0.2em] text-[color:var(--magenta)]">
            <Play className="inline h-3 w-3" /> RUN
          </button>
        }>
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {PIPELINE.map((n, i) => (
              <div key={i} className="flex shrink-0 items-center gap-1.5">
                <div className="min-w-[88px]"><NodeChip n={n} /></div>
                {i < PIPELINE.length - 1 && <ArrowRight className="h-3.5 w-3.5 shrink-0 text-foreground/40" />}
              </div>
            ))}
            <button className="panel-cyber lift ml-1 grid h-[52px] w-[52px] shrink-0 place-items-center"
              style={{ ["--c" as any]: "var(--cyan)" }} aria-label="Add node">
              <Plus className="h-4 w-4 text-cyan" />
            </button>
          </div>
        </ThemedCard>
      </div>

      {(["TRIGGER", "ACTION", "OUTPUT"] as const).map((k) => (
        <div key={k} className="mt-2.5">
          <ThemedCard
            color={k === "TRIGGER" ? "cyan" : k === "ACTION" ? "green" : "violet"}
            title={`${k} NODES`}
            icon={<Zap className="h-3.5 w-3.5" />}
            action={<span className="font-mono text-[9px] tracking-widest text-foreground/45">{PALETTE.filter(p => p.kind === k).length}</span>}
          >
            <div className="grid grid-cols-3 gap-1.5">
              {PALETTE.filter(p => p.kind === k).map(n => <NodeChip key={n.id} n={n} />)}
            </div>
          </ThemedCard>
        </div>
      ))}

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · NODE PIPELINE · v2.0
      </div>
    </AppShell>
  );
}

function Stat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="panel-cyber px-2 py-2 text-center" style={{ ["--c" as any]: color }}>
      <div className="font-display text-[18px] font-black leading-none" style={{ color }}>{value}</div>
      <div className="mt-0.5 font-mono text-[8px] tracking-widest text-foreground/55">{label}</div>
    </div>
  );
}

```


### `/src/routes/config.tsx`

```ts path=/src/routes/config.tsx
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Settings as SettingsIcon, ShieldCheck, Trash2, Server, Bell, Moon, Database } from "lucide-react";
import { AppShell, PageHeader, SectionTitle } from "@/components/AppShell";
import { toast } from "sonner";

export const Route = createFileRoute("/config")({
  head: () => ({
    meta: [
      { title: "Butler AI — Config" },
      { name: "description", content: "Tune Butler. Notifications, theme, data, and pairing controls." },
    ],
  }),
  component: ConfigPage,
});

function ConfigPage() {
  const [notif, setNotif] = useState(true);
  const [haptics, setHaptics] = useState(true);
  const [sound, setSound] = useState(true);
  const [paired, setPaired] = useState<string | null>(null);

  useEffect(() => {
    try {
      const p = JSON.parse(localStorage.getItem("butler_paired_session_v1") || "null");
      if (p?.ip) setPaired(`${p.ip}:${p.port}`);
    } catch { /* noop */ }
  }, []);

  const clearAll = () => {
    localStorage.clear();
    toast.success("Local data cleared", { description: "Pairing + onboarding state reset." });
    setPaired(null);
  };

  return (
    <AppShell active="cfg">
      <PageHeader title="CONFIG" sub="DEVICE PREFERENCES" color="cyan" />

      <section className="panel-cyber space-y-2 p-3 glow-cyan">
        <SectionTitle icon={<Server className="h-4 w-4" />} color="cyan" label="PAIRING" />
        <Row label="Paired host" value={paired || "— none —"} />
        <Link
          to="/home"
          className="block rounded-md border border-cyan/50 bg-cyan/10 px-3 py-2 text-center font-mono text-[11px] font-extrabold tracking-widest text-cyan hover:bg-cyan/20"
        >
          MANAGE ON HOME
        </Link>
      </section>

      <section className="panel-cyber space-y-2 p-3 glow-magenta">
        <SectionTitle icon={<Bell className="h-4 w-4" />} color="magenta" label="FEEDBACK" />
        <Toggle label="Notifications" icon={<Bell className="h-3.5 w-3.5" />} on={notif} onChange={setNotif} />
        <Toggle label="Haptics" icon={<SettingsIcon className="h-3.5 w-3.5" />} on={haptics} onChange={setHaptics} />
        <Toggle label="Sound effects" icon={<Moon className="h-3.5 w-3.5" />} on={sound} onChange={setSound} />
      </section>

      <section className="panel-cyber space-y-2 p-3 glow-green">
        <SectionTitle icon={<ShieldCheck className="h-4 w-4" />} color="green" label="PRIVACY" />
        <Row label="Telemetry" value="OFF · always" />
        <Row label="Cloud sync" value="DISABLED" />
        <Row label="Encryption" value="HMAC-SHA256" />
      </section>

      <section className="panel-cyber space-y-2 p-3 glow-orange">
        <SectionTitle icon={<Database className="h-4 w-4" />} color="orange" label="DATA" />
        <button
          onClick={clearAll}
          className="flex w-full items-center justify-center gap-2 rounded-md border border-red-500/50 bg-red-500/10 px-3 py-2 font-mono text-[11px] font-extrabold tracking-widest text-red-400 hover:bg-red-500/20"
        >
          <Trash2 className="h-3.5 w-3.5" /> CLEAR ALL LOCAL DATA
        </button>
      </section>

      <section className="panel-cyber space-y-2 p-3">
        <SectionTitle icon={<SettingsIcon className="h-4 w-4" />} color="cyan" label="LEGAL" />
        <div className="grid grid-cols-2 gap-2">
          <Link to="/legal/privacy" className="rounded-md border border-foreground/15 px-3 py-2 text-center font-mono text-[10px] tracking-widest text-foreground/80 hover:bg-foreground/5">PRIVACY</Link>
          <Link to="/legal/terms" className="rounded-md border border-foreground/15 px-3 py-2 text-center font-mono text-[10px] tracking-widest text-foreground/80 hover:bg-foreground/5">TERMS</Link>
          <Link to="/legal/safety" className="rounded-md border border-foreground/15 px-3 py-2 text-center font-mono text-[10px] tracking-widest text-foreground/80 hover:bg-foreground/5">SAFETY</Link>
          <Link to="/legal/delete" className="rounded-md border border-foreground/15 px-3 py-2 text-center font-mono text-[10px] tracking-widest text-foreground/80 hover:bg-foreground/5">DELETE DATA</Link>
        </div>
      </section>
    </AppShell>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-foreground/10 bg-background/40 px-2 py-1.5">
      <span className="font-mono text-[10px] tracking-widest text-foreground/70">{label}</span>
      <span className="font-mono text-[10px] font-extrabold tracking-widest text-foreground">{value}</span>
    </div>
  );
}

function Toggle({ label, icon, on, onChange }: { label: string; icon: React.ReactNode; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className="flex w-full items-center justify-between rounded-md border border-foreground/10 bg-background/40 px-2 py-1.5"
    >
      <span className="flex items-center gap-2 font-mono text-[11px] tracking-widest text-foreground/80">{icon} {label}</span>
      <span className={`h-4 w-8 rounded-full p-0.5 transition ${on ? "bg-cyan/40" : "bg-foreground/15"}`}>
        <span className={`block h-3 w-3 rounded-full bg-cyan transition ${on ? "translate-x-4" : ""}`} />
      </span>
    </button>
  );
}

```


### `/src/routes/files.tsx`

```ts path=/src/routes/files.tsx
import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState, useEffect } from "react";
import {
  Upload, Download, Send, FileText, RefreshCw, Trash2, Clipboard as ClipIcon,
  X, Monitor, Camera, Lock, VolumeX, Moon, Bell, Power, Wifi, Activity,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { PageTitle } from "@/components/ThemedCard";
import { NcxCard, NcxSection, NcxBtn } from "@/components/tools/NcxCard";
import { toast } from "sonner";

export const Route = createFileRoute("/files")({
  head: () => ({ meta: [{ title: "Tools Hub — Butler AI" }] }),
  component: ToolsHubPage,
});

/* ───────────── Quick PC tools registry ───────────── */
const QUICK_TOOLS = [
  { id: "shot",   icon: <Camera   className="h-4 w-4" />, label: "Screenshot", desc: "Capture PC screen" },
  { id: "lock",   icon: <Lock     className="h-4 w-4" />, label: "Lock",       desc: "Lock PC remotely" },
  { id: "mute",   icon: <VolumeX  className="h-4 w-4" />, label: "Mute",       desc: "Toggle PC audio" },
  { id: "sleep",  icon: <Moon     className="h-4 w-4" />, label: "Sleep",      desc: "Put PC to sleep" },
  { id: "notify", icon: <Bell     className="h-4 w-4" />, label: "Notify",     desc: "Send notification" },
  { id: "wake",   icon: <Power    className="h-4 w-4" />, label: "Wake",       desc: "Wake-on-LAN" },
  { id: "wifi",   icon: <Wifi     className="h-4 w-4" />, label: "Wi-Fi",      desc: "Toggle Wi-Fi" },
  { id: "ping",   icon: <Activity className="h-4 w-4" />, label: "Ping",       desc: "Latency test" },
] as const;

type ClipEntry = { id: string; text: string; ts: number };

function ToolsHubPage() {
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState(0);
  const [clipText, setClipText] = useState("");
  const [clipHist, setClipHist] = useState<ClipEntry[]>([]);
  const [autoSync, setAutoSync] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  /* hydrate clip history */
  useEffect(() => {
    try { const r = localStorage.getItem("nx_clip_hist"); if (r) setClipHist(JSON.parse(r)); } catch {}
  }, []);
  useEffect(() => {
    try { localStorage.setItem("nx_clip_hist", JSON.stringify(clipHist.slice(0, 20))); } catch {}
  }, [clipHist]);

  const pickFile = () => fileRef.current?.click();
  const onPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 10 * 1024 * 1024) { toast.error("Max 10MB"); return; }
    setFile(f); setProgress(0);
  };
  const sendFile = async () => {
    if (!file) { toast("Choose a file first"); return; }
    setProgress(1);
    for (let p = 0; p <= 100; p += 8) {
      await new Promise((r) => setTimeout(r, 40));
      setProgress(p);
    }
    toast.success(`✓ Sent ${file.name}`);
    setFile(null); setProgress(0);
  };

  const sendClip = () => {
    if (!clipText.trim()) { toast("Empty"); return; }
    setClipHist((h) => [{ id: crypto.randomUUID(), text: clipText.slice(0, 200), ts: Date.now() }, ...h].slice(0, 20));
    toast.success("→ PC clipboard");
  };
  const pasteClip = async () => {
    try { const t = await navigator.clipboard.readText(); setClipText(t); } catch { toast.error("Clipboard blocked"); }
  };
  const copyHist = async (t: string) => {
    try { await navigator.clipboard.writeText(t); toast.success("Copied"); } catch {}
  };

  return (
    <AppShell active="files">
      <PageTitle kicker="LAN · DIRECT" title="TOOLS HUB" sub="FILE BRIDGE · CLIPBOARD · REMOTE CTRL" color="cyan" />

      {/* ── FILE BRIDGE ── */}
      <div className="mt-4">
        <NcxSection color="blue" title="File Bridge" />
        <div className="grid grid-cols-2 gap-2.5">
          {/* SEND */}
          <NcxCard color="blue" icon={<Upload className="h-3.5 w-3.5" />} title="Send Files">
            <div className="m-2.5 flex-1">
              <input ref={fileRef} type="file" hidden onChange={onPick} />
              <div className="drop-zone" data-has-file={file ? "true" : "false"} onClick={pickFile}
                   style={{ ["--c" as any]: "#4488ff" }}>
                {!file ? (
                  <>
                    <div className="grid h-10 w-10 place-items-center rounded-md border border-[color:rgba(68,136,255,0.3)] bg-[color:rgba(68,136,255,0.08)]">
                      <Upload className="h-4 w-4 text-[#4488ff]" />
                    </div>
                    <div className="mt-2 font-mono text-[12px] text-foreground/90">Tap to select</div>
                    <div className="mt-0.5 font-mono text-[9.5px] tracking-widest text-cyan">ANY FILE · MAX 10MB</div>
                  </>
                ) : (
                  <>
                    <FileText className="h-6 w-6 text-[#4488ff]" />
                    <div className="mt-1 max-w-[150px] truncate font-mono text-[11px] text-[#4488ff]">{file.name}</div>
                    <div className="font-mono text-[9px] text-foreground/55">{(file.size / 1024).toFixed(1)} KB</div>
                  </>
                )}
              </div>
              {progress > 0 && (
                <div className="mt-2">
                  <div className="flex justify-between font-mono text-[9.5px] text-foreground/65">
                    <span>Uploading…</span><span>{progress}%</span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-[var(--ink)]">
                    <div className="h-full bg-[#4488ff]" style={{ width: `${progress}%`, transition: "width .12s linear" }} />
                  </div>
                </div>
              )}
            </div>
            <div className="px-2.5 pb-2.5">
              <NcxBtn color="blue" onClick={sendFile} className="w-full">
                <Send className="h-3 w-3" /> Send to PC
              </NcxBtn>
            </div>
          </NcxCard>

          {/* RECEIVED */}
          <NcxCard color="green" icon={<Download className="h-3.5 w-3.5" />} title="Received">
            <div className="m-2.5 flex-1">
              <div className="drop-zone" style={{ ["--c" as any]: "var(--green)", cursor: "default" }}>
                <div className="grid h-10 w-10 place-items-center rounded-full border border-[color:color-mix(in_oklab,var(--green)_30%,transparent)] text-[color:color-mix(in_oklab,var(--green)_60%,transparent)]">
                  <Download className="h-4 w-4" />
                </div>
                <div className="mt-2 font-mono text-[12px] text-foreground/65">Waiting…</div>
                <div className="mt-0.5 font-mono text-[10px] text-[color:var(--green)]">FROM DESKTOP</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-1.5 px-2.5 pb-2.5">
              <NcxBtn color="green" onClick={() => toast("Refreshed")}>
                <RefreshCw className="h-3 w-3" /> Refresh
              </NcxBtn>
              <NcxBtn ghost onClick={() => toast("Cleared")}>
                <Trash2 className="h-3 w-3" /> Clear
              </NcxBtn>
            </div>
          </NcxCard>
        </div>
      </div>

      {/* ── CLIPBOARD SYNC ── */}
      <div className="mt-4">
        <NcxSection
          color="purple"
          title="Clipboard Sync"
          action={
            <span className="flex items-center gap-1.5 font-mono text-[9.5px] tracking-widest text-foreground/55">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[color:var(--magenta)] shadow-[0_0_6px_var(--magenta)]" />
              REAL-TIME
            </span>
          }
        />
        <div className="grid grid-cols-2 gap-2.5">
          <NcxCard color="purple" icon={<Send className="h-3.5 w-3.5" />} title="Send to PC">
            <textarea
              value={clipText}
              onChange={(e) => setClipText(e.target.value)}
              placeholder="Type or paste text…"
              rows={4}
              className="m-2.5 resize-none rounded-md border border-[color:color-mix(in_oklab,var(--magenta)_25%,transparent)] bg-black/25 p-2 font-mono text-[12px] text-foreground/95 outline-none focus:border-[color:color-mix(in_oklab,var(--magenta)_55%,transparent)]"
            />
            <div className="flex items-center gap-1.5 px-2.5 pb-1.5">
              <NcxBtn color="purple" onClick={sendClip} className="flex-1"><Send className="h-3 w-3" /> Send</NcxBtn>
              <NcxBtn ghost onClick={pasteClip}><ClipIcon className="h-3 w-3" /></NcxBtn>
              <NcxBtn ghost onClick={() => setClipText("")}><X className="h-3 w-3" /></NcxBtn>
            </div>
            <button
              onClick={() => setAutoSync((v) => !v)}
              className="mx-2.5 mb-2.5 flex items-center gap-2 rounded border border-[color:var(--border)] bg-[var(--ink)]/60 px-2 py-1.5 text-left"
            >
              <span className={`h-1.5 w-1.5 rounded-full ${autoSync ? "bg-[color:var(--magenta)] shadow-[0_0_6px_var(--magenta)]" : "bg-foreground/30"}`} />
              <span className="flex-1 font-mono text-[10px] tracking-widest text-foreground/65">AUTO-SYNC (1s)</span>
              <span
                className={`relative h-[17px] w-[32px] rounded-full border ${autoSync ? "border-[color:color-mix(in_oklab,var(--magenta)_40%,transparent)] bg-[color:color-mix(in_oklab,var(--magenta)_22%,transparent)]" : "border-[color:var(--border)] bg-[var(--surface-2)]"}`}
              >
                <span
                  className={`absolute top-[1.5px] h-[11px] w-[11px] rounded-full transition-all ${autoSync ? "left-[17px] bg-[color:var(--magenta)] shadow-[0_0_6px_var(--magenta)]" : "left-[2px] bg-foreground/45"}`}
                />
              </span>
            </button>
          </NcxCard>

          <NcxCard color="purple" icon={<ClipIcon className="h-3.5 w-3.5" />} title="Clip History">
            {clipHist.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-2 p-5">
                <ClipIcon className="h-7 w-7 text-[color:color-mix(in_oklab,var(--magenta)_25%,transparent)]" />
                <p className="text-center font-mono text-[10.5px] leading-snug text-foreground/55">
                  Empty<br />Send something first
                </p>
              </div>
            ) : (
              <ul className="max-h-[230px] space-y-1 overflow-y-auto p-2">
                {clipHist.map((c) => (
                  <li
                    key={c.id}
                    onClick={() => copyHist(c.text)}
                    className="cursor-pointer rounded-md border border-[color:color-mix(in_oklab,var(--magenta)_18%,transparent)] bg-[color:color-mix(in_oklab,var(--magenta)_7%,transparent)] px-2 py-1.5 hover:border-[color:color-mix(in_oklab,var(--magenta)_38%,transparent)]"
                  >
                    <div className="truncate font-mono text-[11px] text-foreground/95">{c.text}</div>
                    <div className="font-mono text-[8.5px] tracking-widest text-foreground/45">
                      {new Date(c.ts).toLocaleTimeString()}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </NcxCard>
        </div>
      </div>

      {/* ── PC DESKTOP ── */}
      <div className="mt-4">
        <NcxSection
          color="cyan"
          title="PC Desktop"
          action={
            <button onClick={() => toast("Refreshing…")} className="flex items-center gap-1 font-mono text-[10px] tracking-widest text-foreground/55 hover:text-cyan">
              <RefreshCw className="h-3 w-3" /> REFRESH
            </button>
          }
        />
        <div className="pc-screen">
          <span className="pc-screen-corner tl" /><span className="pc-screen-corner tr" />
          <span className="pc-screen-corner bl" /><span className="pc-screen-corner br" />
          <div className="z-10 flex flex-col items-center gap-1 text-center">
            <Monitor className="h-9 w-9 text-foreground/35" />
            <div className="mt-1 font-mono text-[11px] tracking-[0.2em] text-foreground/55">NO SERVER CONNECTED</div>
            <div className="font-mono text-[10px] text-foreground/40">Scan QR on the HOME tab</div>
          </div>
        </div>
      </div>

      {/* ── QUICK TOOLS ── */}
      <div className="mt-4">
        <NcxSection color="amber" title="Quick Tools" />
        <div className="grid grid-cols-4 gap-2">
          {QUICK_TOOLS.map((t, i) => {
            const palette: Array<"cyan" | "amber" | "green" | "purple"> = ["cyan", "amber", "green", "purple"];
            const c = palette[i % palette.length];
            const cssVar = c === "amber" ? "var(--orange)" : c === "purple" ? "var(--magenta)" : `var(--${c})`;
            return (
              <button
                key={t.id}
                onClick={() => toast.success(`${t.label} → PC`)}
                className="tool-tile"
                style={{ ["--c" as any]: cssVar }}
              >
                <span style={{ color: cssVar, filter: `drop-shadow(0 0 4px ${cssVar})` }}>{t.icon}</span>
                <span className="mt-1 font-display text-[10px] font-extrabold tracking-[0.12em] text-foreground/95">{t.label}</span>
                <span className="font-mono text-[8.5px] tracking-wider text-foreground/45">{t.desc}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="pt-3 pb-1 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · TOOLS HUB · LAN-DIRECT
      </div>
    </AppShell>
  );
}

```


### `/src/routes/home.tsx`

```ts path=/src/routes/home.tsx
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Activity, Bell, Bot, Brain, ClipboardList, Code2, Cpu, Database,
  FileText, Fingerprint, Infinity as InfinityIcon, Lock, MonitorSmartphone,
  Network, ScrollText, Shield, ShieldCheck, Target, TerminalSquare, User,
  Box, Circle, ChevronRight, Play, Clock, Sparkles,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { NexusHero } from "@/components/NexusHero";
import { Sparkline } from "@/components/Sparkline";
import { ActivityFeed } from "@/components/ActivityFeed";
import { useTelemetry, fmtUptime, fmtPct } from "@/lib/useTelemetry";
import { getConfig } from "@/lib/butler";
import mascotImg from "@/assets/mascot-butler.png";


export const Route = createFileRoute("/home")({
  head: () => ({
    meta: [
      { title: "Nexus — Butler AI" },
      { name: "description", content: "Local-only Butler AI command center. Live PC telemetry, scripts, and pairing — all on your LAN." },
      { property: "og:title", content: "Nexus — Butler AI" },
      { property: "og:description", content: "Local-only PC automation. Zero cloud. Your private AI butler." },
    ],
  }),
  component: NexusHomePage,
});

function NexusHomePage() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);
  const t = useTelemetry(2500);
  const cfg = getConfig();
  const host = mounted && cfg.baseUrl ? new URL(cfg.baseUrl).host : "192.168.1.102";
  const hostname = t.hostname || "NEXUS-CORE";

  return (
    <AppShell active="home">
      <NexusHeader online={t.online} />
      <NexusHero t={t} />

      <Link
        to="/nexus"
        className="mt-3 flex items-center justify-between gap-3 panel-cyber px-3 py-2.5 group"
        style={{ boxShadow: "0 0 18px hsl(187 100% 50% / .15), inset 0 1px 0 hsl(0 0% 100% / .04)" }}
      >
        <div className="flex items-center gap-2.5">
          <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg border border-primary/40 bg-primary/10 text-primary">
            <Sparkles className="w-4 h-4" />
          </span>
          <div>
            <div className="font-display text-[13px] font-extrabold tracking-[0.22em] glow-text-cyan">NEXUS · COMMAND CENTER</div>
            <div className="text-[10px] text-muted-foreground font-mono tracking-wider">11 modules · CONN · DASH · AI · KB · TOOLS · CFG</div>
          </div>
        </div>
        <span className="font-mono text-[10px] tracking-widest text-primary group-hover:translate-x-1 transition">OPEN ▸</span>
      </Link>



      <div className="mt-4 mb-1 px-1 font-display text-[10px] font-extrabold tracking-[0.32em] text-foreground/55">
        ── SYSTEM TELEMETRY ──
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <ConnectedPCCard hostname={hostname} host={host} t={t} mounted={mounted} />
        <LiveTerminalCard />
        <CrawlerGraphCard history={t.history} />
        <KnowledgeGraphCard />
        <ScriptForgeCard />
        <FileShareCard />
        <SmartAlertsCard />
        <OmegaLoopCard />
      </div>

      <SecurityProtocols />
      <RecentActivityCard />

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · BUTLER AI · LOCAL-FIRST
      </div>
    </AppShell>
  );
}


/* ============ HEADER ============ */
function NexusHeader({ online }: { online: boolean }) {
  return (
    <header className="panel-cyber flex items-center gap-2.5 px-2.5 py-2.5">
      <div className="flex-1 text-center">
        <h1 className="font-display text-[22px] font-black leading-none tracking-[0.36em] text-cyan"
            style={{
              background: "linear-gradient(180deg,#eafcff 0%, var(--cyan) 55%, color-mix(in oklab, var(--magenta) 70%, var(--cyan)) 100%)",
              WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent",
              textShadow: "0 0 18px color-mix(in oklab, var(--cyan) 60%, transparent)",
              filter: "drop-shadow(0 0 6px color-mix(in oklab, var(--cyan) 50%, transparent))",
            }}>
          BUTLER AI
        </h1>
        <div className="mt-1 font-mono text-[9px] tracking-[0.42em] text-foreground/55">NEXUS DASHBOARD</div>
      </div>
      <div className="panel-cyber flex items-center gap-1.5 px-1.5 py-1" style={{ ["--c" as any]: "var(--cyan)" }}>
        <div className="grid h-8 w-8 place-items-center overflow-hidden rounded-sm border border-[color:var(--border)] bg-[#06080d]">
          <img src={mascotImg} alt="Butler" className="h-7 w-7 object-cover" style={{ filter: "drop-shadow(0 0 6px var(--cyan))" }} />
        </div>
        <div className="flex flex-col leading-tight pr-1">
          <span className="font-display text-[9px] font-bold tracking-widest text-foreground/85">BUTLER</span>
          <span className="flex items-center gap-1 font-mono text-[8px] tracking-widest" style={{ color: online ? "var(--green)" : "var(--orange)" }}>
            <Circle className="h-1.5 w-1.5 fill-current pulse-dot" /> {online ? "ONLINE" : "IDLE"}
          </span>
        </div>
      </div>
    </header>
  );
}

/* ============ CARD HELPER ============ */
function Card({ color = "cyan", title, icon, action, children, className = "" }: {
  color?: "cyan" | "violet" | "green" | "amber" | "red";
  title: string; icon: React.ReactNode; action?: React.ReactNode;
  children: React.ReactNode; className?: string;
}) {
  const cls = color === "cyan" ? "" : `c-${color}`;
  const cvar = color === "violet" ? "var(--magenta)" : color === "amber" ? "var(--orange)" : `var(--${color})`;
  return (
    <div
      className={`panel-cyber ${cls} brackets holo-grain lift relative overflow-hidden ${className}`}
      style={{ ["--c" as any]: cvar }}
    >
      <span className="br-tr" aria-hidden />
      <span className="br-bl" aria-hidden />
      <div className="card-accent absolute left-0 right-0 top-0" aria-hidden />
      <div className="p-2.5 pt-3">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5" style={{ color: cvar }}>
            <span className="led" aria-hidden />
            {icon}
            <span className="font-display text-[10px] font-extrabold tracking-[0.22em]">{title}</span>
          </div>
          {action}
        </div>
        {children}
      </div>
    </div>
  );
}


/* ============ CONNECTED PC ============ */
function ConnectedPCCard({ hostname, host, t, mounted }: any) {
  return (
    <Card color="cyan" title="CONNECTED PC"
      icon={<MonitorSmartphone className="h-3.5 w-3.5" />}
      action={<Circle className="h-2 w-2 fill-[color:var(--green)] text-[color:var(--green)] pulse-dot" />}>
      <div className="font-display text-[16px] font-black leading-tight text-foreground">{hostname}</div>
      <div className="mt-0.5 font-mono text-[10px] text-foreground/65">Windows 11 Pro</div>
      <div className="font-mono text-[10px] text-foreground/65">{host}</div>
      <div className="mt-1.5 flex items-center gap-2 font-mono text-[9px]">
        <span className="flex items-center gap-1 text-[color:var(--green)]"><Circle className="h-1.5 w-1.5 fill-current" />ONLINE</span>
        <span className="text-cyan">+ SECURE</span>
      </div>
      <div className="mt-2 grid grid-cols-4 gap-1 border-t border-[color:var(--border)] pt-1.5 text-center">
        <Stat label="UPTIME" value={mounted ? fmtUptime(t.uptime) : "—"} />
        <Stat label="CPU" value={fmtPct(t.cpu)} />
        <Stat label="RAM" value={fmtPct(t.ram)} />
        <Stat label="DISK" value={fmtPct(t.disk)} />
      </div>
    </Card>
  );
}
function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="font-mono text-[8px] tracking-[0.18em] text-foreground/45">{label}</div>
      <div className="font-display text-[11px] font-bold text-cyan leading-tight truncate">{value}</div>
    </div>
  );
}

/* ============ LIVE TERMINAL ============ */
function LiveTerminalCard() {
  const lines = [
    { t: "09:41:12", m: "System handshake verified" },
    { t: "09:41:13", m: "Nexus protocols initialized" },
    { t: "09:41:13", m: "AI core modules online" },
    { t: "09:41:14", m: "Memory bridge established" },
    { t: "09:41:14", m: "Listening for commands…" },
  ];
  return (
    <Card color="violet" title="LIVE FEED"
      icon={<TerminalSquare className="h-3.5 w-3.5" />}
      action={<span className="flex items-center gap-1 font-mono text-[8px] tracking-widest text-[color:var(--magenta)]"><Circle className="h-1.5 w-1.5 fill-current pulse-dot" />LIVE</span>}>
      <div className="space-y-0.5 font-mono text-[9px] leading-tight">
        {lines.map((l, i) => (
          <div key={i} className="flex items-start gap-1.5">
            <span className="text-[color:var(--magenta)]">{">"}</span>
            <span className="flex-1 truncate text-foreground/75">{l.m}</span>
            <span className="text-foreground/35 tabular-nums">{l.t}</span>
          </div>
        ))}
      </div>
      <div className="mt-1.5 flex items-center justify-between border-t border-[color:var(--border)] pt-1 font-mono text-[8px] tracking-widest">
        <span className="text-foreground/55">STATUS: <span className="text-[color:var(--magenta)]">OPERATIONAL</span></span>
        <span className="cursor-blink h-2 w-1 bg-[color:var(--magenta)] inline-block" />
      </div>
    </Card>
  );
}

/* ============ CRAWLER GRAPH ============ */
function CrawlerGraphCard({ history }: { history: number[] }) {
  const data = history.length ? history : [4,6,5,7,8,7,9,8,10,9,11,10,12,11,13];
  return (
    <Card color="cyan" title="CRAWLER GRAPH" icon={<Activity className="h-3.5 w-3.5" />}>
      <div className="font-display text-[18px] font-black text-cyan leading-none">8.72M</div>
      <div className="font-mono text-[8px] tracking-widest text-foreground/55">ENTITIES INDEXED</div>
      <div className="font-mono text-[9px] text-[color:var(--green)]">▲ 12.4%</div>
      <div className="mt-1.5">
        <Sparkline data={data} height={36} color="var(--cyan)" />
      </div>
      <div className="mt-0.5 flex justify-between font-mono text-[7px] text-foreground/35">
        <span>-24H</span><span>-12H</span><span>NOW</span>
      </div>
    </Card>
  );
}

/* ============ KNOWLEDGE GRAPH ============ */
function KnowledgeGraphCard() {
  return (
    <Card color="green" title="KNOWLEDGE" icon={<Network className="h-3.5 w-3.5" />}>
      <div className="relative mx-auto my-1 h-16 w-full">
        <svg viewBox="0 0 120 64" className="absolute inset-0 h-full w-full">
          <g stroke="var(--green)" strokeOpacity="0.45" strokeWidth="0.5" fill="none">
            <line x1="60" y1="32" x2="20" y2="14" /><line x1="60" y1="32" x2="100" y2="14" />
            <line x1="60" y1="32" x2="14" y2="50" /><line x1="60" y1="32" x2="106" y2="50" />
            <line x1="60" y1="32" x2="60" y2="6" /><line x1="60" y1="32" x2="60" y2="58" />
          </g>
          {[[20,14],[100,14],[14,50],[106,50],[60,6],[60,58]].map(([x,y],i)=>(
            <circle key={i} cx={x} cy={y} r="2.5" fill="var(--green)" style={{filter:"drop-shadow(0 0 3px var(--green))"}}/>
          ))}
          <circle cx="60" cy="32" r="6" fill="none" stroke="var(--green)" strokeWidth="1" style={{filter:"drop-shadow(0 0 6px var(--green))"}}/>
        </svg>
        <Brain className="absolute left-1/2 top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 text-[color:var(--green)]" style={{ filter: "drop-shadow(0 0 4px var(--green))" }} />
      </div>
      <div className="grid grid-cols-2 gap-1 font-mono text-[8px]">
        <div><div className="text-foreground/45 tracking-widest">NODES</div><div className="font-display text-[12px] font-bold text-[color:var(--green)]">128,456</div></div>
        <div><div className="text-foreground/45 tracking-widest">RELATIONS</div><div className="font-display text-[12px] font-bold text-[color:var(--green)]">912,341</div></div>
      </div>
    </Card>
  );
}

/* ============ SCRIPT FORGE ============ */
function ScriptForgeCard() {
  return (
    <Card color="violet" title="SCRIPT FORGE" icon={<Code2 className="h-3.5 w-3.5" />}>
      <div className="font-display text-[20px] font-black text-[color:var(--magenta)] leading-none">1,246</div>
      <div className="font-mono text-[8px] tracking-widest text-foreground/55">SCRIPTS</div>
      <div className="mt-1.5 space-y-1 font-mono text-[9px]">
        <Row label="RUNNING" value="12" icon={<Play className="h-2.5 w-2.5" />} />
        <Row label="SCHEDULED" value="28" icon={<Clock className="h-2.5 w-2.5" />} />
        <div>
          <div className="flex justify-between"><span className="text-foreground/55 tracking-widest">SUCCESS</span><span className="text-[color:var(--magenta)]">98.7%</span></div>
          <div className="mt-0.5 h-1 w-full overflow-hidden rounded-sm bg-[color:var(--border)]">
            <div className="h-full bg-[color:var(--magenta)]" style={{ width: "98.7%", boxShadow: "0 0 6px var(--magenta)" }} />
          </div>
        </div>
      </div>
    </Card>
  );
}
function Row({ label, value, icon }: any) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-foreground/55 tracking-widest">{label}</span>
      <span className="flex items-center gap-1 text-foreground/85">{value}{icon}</span>
    </div>
  );
}

/* ============ FILE SHARE ============ */
function FileShareCard() {
  const files = [
    { n: "research.pdf", s: "134 MB", i: FileText, c: "var(--red)" },
    { n: "dataset.csv", s: "89 MB", i: FileText, c: "var(--green)" },
    { n: "blueprint.png", s: "3.2 MB", i: FileText, c: "var(--cyan)" },
  ];
  return (
    <Card color="green" title="FILE SHARE" icon={<ClipboardList className="h-3.5 w-3.5" />}>
      <div className="flex items-baseline gap-1.5">
        <div className="font-display text-[20px] font-black text-[color:var(--green)] leading-none">24</div>
        <div className="font-mono text-[8px] tracking-widest text-foreground/55">CLIPS</div>
      </div>
      <div className="mt-1.5 space-y-0.5">
        {files.map((f, i) => {
          const Icon = f.i;
          return (
            <div key={i} className="flex items-center gap-1 font-mono text-[9px]">
              <Icon className="h-2.5 w-2.5 shrink-0" style={{ color: f.c }} />
              <span className="flex-1 truncate text-foreground/80">{f.n}</span>
              <span className="text-foreground/45 tabular-nums">{f.s}</span>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

/* ============ SMART ALERTS ============ */
function SmartAlertsCard() {
  const alerts = [
    { t: "High CPU detected", s: "NEXUS-CORE", a: "2m" },
    { t: "Login blocked", s: "NEXUS-CORE", a: "18m" },
    { t: "Script failure", s: "Script Forge", a: "1h" },
  ];
  return (
    <Card color="amber" title="SMART ALERTS"
      icon={<Bell className="h-3.5 w-3.5" />}
      action={<span className="font-display text-[11px] font-black text-[color:var(--orange)]">3</span>}>
      <div className="space-y-1 font-mono text-[8.5px]">
        {alerts.map((a, i) => (
          <div key={i} className="flex items-center gap-1">
            <Circle className="h-2 w-2 shrink-0 fill-[color:var(--orange)] text-[color:var(--orange)]" />
            <span className="flex-1 truncate text-foreground/80">{a.t}</span>
            <span className="text-foreground/40">{a.a}</span>
          </div>
        ))}
      </div>
      <div className="mt-1.5 text-center font-display text-[9px] font-bold tracking-widest text-[color:var(--orange)]">VIEW ALL ›</div>
    </Card>
  );
}

/* ============ OMEGA LEARNING LOOP ============ */
function OmegaLoopCard() {
  return (
    <Card color="green" title="OMEGA LOOP" icon={<InfinityIcon className="h-3.5 w-3.5" />}>
      <div className="relative mx-auto my-1 grid h-14 w-14 place-items-center">
        <div className="absolute inset-0 rounded-full border border-[color:var(--green)] spin-slow" style={{ boxShadow: "0 0 10px var(--green) inset, 0 0 8px var(--green)" }} />
        <div className="absolute inset-2 rounded-full border border-[color:var(--green)]/60 spin-reverse" />
        <InfinityIcon className="h-5 w-5 text-[color:var(--green)]" style={{ filter: "drop-shadow(0 0 6px var(--green))" }} />
      </div>
      <div className="font-mono text-[8px] text-foreground/55 tracking-widest text-center">CONFIDENCE</div>
      <div className="text-center font-display text-[14px] font-black text-[color:var(--green)] leading-none">93.8%</div>
    </Card>
  );
}

/* ============ SECURITY PROTOCOLS ============ */
function SecurityProtocols() {
  const items = [
    { i: ShieldCheck, l: "FIREWALL", s: "ACTIVE", c: "var(--cyan)" },
    { i: Target,     l: "INTRUSION", s: "ACTIVE", c: "var(--green)" },
    { i: Lock,       l: "ENCRYPTION", s: "AES-256", c: "var(--magenta)" },
    { i: User,       l: "ACCESS",   s: "ZERO TRUST", c: "var(--cyan)" },
    { i: Box,        l: "SANDBOX",  s: "ISOLATED", c: "var(--orange)" },
    { i: Fingerprint,l: "INTEGRITY",s: "VERIFIED", c: "var(--green)" },
  ];
  return (
    <Card color="cyan" title="SECURITY PROTOCOLS"
      icon={<Shield className="h-3.5 w-3.5" />}
      action={<span className="flex items-center gap-1 font-mono text-[8px] tracking-widest text-[color:var(--green)]">STATUS: SECURE <Circle className="h-1.5 w-1.5 fill-current" /></span>}>
      <div className="grid grid-cols-6 gap-1.5">
        {items.map((it, i) => {
          const Icon = it.i;
          return (
            <div key={i} className="panel-cyber p-1 text-center" style={{ ["--c" as any]: it.c }}>
              <Icon className="mx-auto h-4 w-4" style={{ color: it.c, filter: `drop-shadow(0 0 4px ${it.c})` }} />
              <div className="mt-0.5 font-display text-[7px] font-bold tracking-widest text-foreground/85">{it.l}</div>
              <div className="font-mono text-[6.5px] tracking-widest" style={{ color: it.c }}>{it.s}</div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

/* ============ RECENT ACTIVITY ============ */
function RecentActivityCard() {
  return (
    <Card color="cyan" title="RECENT ACTIVITY"
      icon={<ScrollText className="h-3.5 w-3.5" />}
      action={<Link to={"/terminal" as any} className="flex items-center gap-0.5 font-mono text-[8px] tracking-widest text-cyan">VIEW LOGS <ChevronRight className="h-2.5 w-2.5" /></Link>}>
      <ActivityFeed limit={5} />
    </Card>
  );
}

// keep unused imports referenced for tree-shaking safety
void Bot; void Database; void Cpu;

```


### `/src/routes/index.tsx`

```ts path=/src/routes/index.tsx
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";

import {
  QrCode, Code2, Bot, MonitorCog, ShieldCheck, Network, Lock, WifiOff, UserX,
  ChevronLeft, ChevronRight, SkipForward, Cpu, HardDrive, Activity,
  Brain, FileLock2, KeyRound, Sparkles, CheckCircle2, Rocket,
  Play, Power, BookOpen, ListChecks, Scroll, HandMetal, Camera, Folder,
  Fingerprint, Wifi, HelpCircle, AlertTriangle, Gavel, Eye, Trash2,
  PenLine, ExternalLink, Server, Database, ShieldAlert, Ban, Telescope,
  Wrench, Heart, Infinity as InfinityIcon, ScanLine, Download,
} from "lucide-react";
import { TelemetryGrid, ScriptsRoster, SigmaNetGraph, PairingQR, HmacMarquee, HealthRing } from "@/components/ButlerLive";
import { usePerfTier } from "@/hooks/use-perf-tier";
import SourceConfigManager, { exportMasterSourceMd } from "@/components/SourceConfigManager";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Butler AI — Onboarding" },
      { name: "description", content: "AI-driven PC automation. 100% local. Zero cloud. Begin your guided tour of Butler AI." },
      { property: "og:title", content: "Butler AI — Onboarding" },
      { property: "og:description", content: "AI-driven PC automation. 100% local. Zero cloud." },
    ],
  }),
  component: Onboarding,
});

/* ============================================================
   THEME — per-step palette, mascot persona, dialogue
   ============================================================ */

type Accent = "cyan" | "green" | "magenta" | "orange" | "yellow";

type StepTheme = {
  id: number;
  tag: string;
  title: string;
  next: string;
  accent: Accent;
  /** mascot persona */
  mascot: {
    name: string;          // e.g. "NEXUS"
    mood: "wave" | "spy" | "shield" | "oath" | "scribe" | "key" | "thinker" | "host" | "builder" | "launch";
    line: string;          // speech bubble
    sub?: string;          // secondary one-liner
  };
};

const STEPS: StepTheme[] = [
  { id: 1,  tag: "WELCOME",     title: "WELCOME TO NEXUS",       next: "APP TOUR",    accent: "cyan",
    mascot: { name: "NEXUS",   mood: "wave",    line: "I'm NEXUS — your local-only butler. Let me show you around.", sub: "Tap NEXT or use → keys. Camera follows me." } },
  { id: 2,  tag: "APP_TOUR",    title: "NINE TABS · ONE OS",     next: "SAFETY",      accent: "magenta",
    mascot: { name: "SCOUT",   mood: "spy",     line: "Here's the whole house. Nine rooms — I'll whip the camera through each.", sub: "HOME · SCRIPTS · AI · KB · PC · BUILD · SKINS · CONFIG · INTRO" } },
  { id: 3,  tag: "SAFETY",      title: "SAFETY CONSENT",         next: "PLEDGE",      accent: "yellow",
    mascot: { name: "AEGIS",   mood: "shield",  line: "These aren't legalese — they ARE the contract. Sign each card to continue.", sub: "All six required." } },
  { id: 4,  tag: "PLEDGE",      title: "SAFETY PLEDGE",          next: "LEGAL",       accent: "orange",
    mascot: { name: "OATH",    mood: "oath",    line: "Raise your hand and pledge. Sign each line — I'll be watching.", sub: "Five lines · all required." } },
  { id: 5,  tag: "LEGAL",       title: "LEGAL DOCUMENTS",        next: "PERMISSIONS", accent: "cyan",
    mascot: { name: "SCRIBE",  mood: "scribe",  line: "The full text lives online — tap any doc to open it, then SIGN.", sub: "Four documents." } },
  { id: 6,  tag: "PERMISSIONS", title: "PERMISSIONS",            next: "Q & A",       accent: "green",
    mascot: { name: "KEYRING", mood: "key",     line: "Bare-minimum permissions. One is required — the others are yours to choose.", sub: "Required: LOCAL NETWORK." } },
  { id: 7,  tag: "Q_AND_A",     title: "QUESTIONS & ANSWERS",    next: "SERVER",      accent: "magenta",
    mascot: { name: "ORACLE",  mood: "thinker", line: "Most-asked questions, up front. No fine print.", sub: "Ten answers." } },
  { id: 8,  tag: "SERVER",      title: "SERVER PRIVACY",         next: "SETUP",       accent: "green",
    mascot: { name: "HOST",    mood: "host",    line: "butler_server.py runs on YOUR PC. Acknowledge the five facts.", sub: "All five required." } },
  { id: 9,  tag: "SETUP",       title: "PC SETUP",               next: "LAUNCH",      accent: "magenta",
    mascot: { name: "RIGGER",  mood: "builder", line: "Three steps · about five minutes. I'll prep your PC.", sub: "Open the setup docs anytime." } },
  { id: 10, tag: "LAUNCH",      title: "INITIATE BUTLER OS",     next: "READY",       accent: "cyan",
    mascot: { name: "NEXUS",   mood: "launch",  line: "All clear, operator. ENGAGE when ready.", sub: "Cold-boot · ~3 seconds." } },
];

/* ============================================================
   ROOT
   ============================================================ */

function Onboarding() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const total = STEPS.length;
  const meta = STEPS[step];
  usePerfTier(); // tags <html> with .perf-low/.perf-mid/.perf-high so CSS can throttle FX

  // sign-to-accept gate
  const [signed, setSigned] = useState<Record<string, number>>({});
  const required = REQUIRED_BY_STEP[step] ?? [];
  const allSigned = required.every((id) => signed[id]);
  const sign = (id: string) => setSigned((s) => (s[id] ? s : { ...s, [id]: Date.now() }));

  const next = () => { if (!allSigned) return; setStep((s) => Math.min(total - 1, s + 1)); };
  const back = () => setStep((s) => Math.max(0, s - 1));
  const skip = () => setStep(total - 1);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") back();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, allSigned]);

  // Step changes should never fight Android touch scrolling.
  useEffect(() => {
    if (typeof window === "undefined") return;
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [step]);

  // Highlight first required target without auto-scrolling over the user's finger.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const t = window.setTimeout(() => {
      const targets = Array.from(document.querySelectorAll<HTMLElement>("[data-tour]"));
      const first = targets[0];
      if (first) {
        first.classList.add("focus-pulse");
        window.setTimeout(() => first.classList.remove("focus-pulse"), 1200);
      }
    }, 180);
    return () => window.clearTimeout(t);
  }, [step]);

  // CAMERA: after every sign, glide to the NEXT unsigned card so the user can't miss it
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (required.length === 0) return;
    const nextId = required.find((id) => !signed[id]);
    if (!nextId) {
      // all signed — gently pull the footer CTA into view
      const cta = document.getElementById("primary-cta");
      cta?.scrollIntoView({ behavior: "auto", block: "center" });
      return;
    }
    const el = document.querySelector<HTMLElement>(`[data-tour="${nextId}"]`);
    if (!el) return;
    const id = window.setTimeout(() => {
      el.scrollIntoView({ behavior: "auto", block: "center" });
      el.classList.add("focus-pulse");
      window.setTimeout(() => el.classList.remove("focus-pulse"), 1200);
    }, 280);
    return () => window.clearTimeout(id);
  }, [signed, step, required]);

  // GLOBAL HAPTICS — pulse the device on any tap, varied by intent
  //   • SIGN buttons  → success burst (12,40,12)
  //   • Primary CTA   → medium tap (18)
  //   • Toolbar / nav → light tap (8)
  //   • Anything else → soft tap (12)
  useEffect(() => {
    if (typeof window === "undefined") return;
    const onClick = (e: MouseEvent) => {
      const t = e.target as HTMLElement | null;
      const hit = t?.closest("button, a, [role='button']") as HTMLElement | null;
      if (!hit) return;
      const label = (hit.textContent || "").toUpperCase();
      let pattern: number | number[] = 12;
      if (label.includes("SIGN") && !label.includes("CONTINUE")) pattern = [12, 40, 12];
      else if (hit.id === "primary-cta" || label.includes("NEXT") || label.includes("READY")) pattern = 18;
      else if (label.includes("BACK") || label.includes("SKIP")) pattern = 8;
      try { navigator.vibrate?.(pattern); } catch { /* noop */ }
      hit.classList.remove("tap-pulse");
      // re-trigger animation
      void hit.offsetWidth;
      hit.classList.add("tap-pulse");
    };
    document.addEventListener("click", onClick, true);
    return () => document.removeEventListener("click", onClick, true);
  }, []);

  // ===== PREFETCH NEXT STEP — images, routes, downloads, fonts =====
  // Buttery transitions: warm the browser cache for what the user is
  // most likely to hit next so the "NEXT" tap renders instantly.
  // router already declared above
  useEffect(() => {
    if (typeof window === "undefined") return;
    const nextStep = Math.min(total - 1, step + 1);

    // 1. Per-step external URL prefetches via <link rel="prefetch"> (idempotent)
    const urlsByStep: Record<number, string[]> = {
      4: ["/legal/privacy", "/legal/terms", "/legal/safety", "/legal/delete"],
      8: [REPO_RAW + "/butler_server.py", REPO_URL, POLICY_URL],
      9: [REPO_RAW + "/butler_server.py"],
    };
    const heads: HTMLLinkElement[] = [];
    const addLink = (rel: string, href: string, as?: string) => {
      if (document.head.querySelector(`link[data-prefetch="${href}"]`)) return;
      const l = document.createElement("link");
      l.rel = rel;
      l.href = href;
      if (as) l.as = as;
      // NOTE: do NOT set crossOrigin on prefetch/dns-prefetch — it triggers
      // CORS preflights against third-party hosts that don't return ACAO.
      l.setAttribute("data-prefetch", href);
      document.head.appendChild(l);
      heads.push(l);
    };
    // dns-prefetch + preconnect to external origins once
    ["https://raw.githubusercontent.com", "https://github.com", "https://shawnjan-cmd.github.io"].forEach((o) => {
      addLink("dns-prefetch", o);
      addLink("preconnect", o);
    });

    const runPrefetch = () => {
      if (step < 3) return;
      // 2. Prefetch next-step external files
      (urlsByStep[nextStep] ?? []).forEach((u) => {
        if (u.startsWith("/")) router.preloadRoute?.({ to: u }).catch(() => {});
        else addLink("prefetch", u, u.endsWith(".py") ? "fetch" : undefined);
      });
      // 3. Pre-warm mascot image (already cached after first paint, cheap)
      const img = new Image();
      img.src = mascotImg;
    };

    const w = window as typeof window & {
      requestIdleCallback?: (cb: () => void, opts?: { timeout: number }) => number;
      cancelIdleCallback?: (id: number) => void;
    };
    let idleId: number | undefined;
    let timeoutId: number | undefined;
    if (w.requestIdleCallback) idleId = w.requestIdleCallback(runPrefetch, { timeout: 2500 });
    else timeoutId = window.setTimeout(runPrefetch, 1400);

    return () => {
      if (idleId != null) w.cancelIdleCallback?.(idleId);
      if (timeoutId != null) window.clearTimeout(timeoutId);
      // leave <link> tags in place — they're cheap and keep working across steps
    };
  }, [step, total, router]);


  return (
    <main
      className="relative min-h-screen overflow-x-clip text-foreground"
      style={{
        background:
          "radial-gradient(ellipse 90% 42% at 50% -10%, color-mix(in oklab, var(--cyan) 18%, transparent), transparent 62%)," +
          "radial-gradient(ellipse 70% 44% at 100% 100%, color-mix(in oklab, var(--magenta) 12%, transparent), transparent 64%)," +
          "linear-gradient(180deg, var(--ink) 0%, var(--background) 52%, var(--ink-deep) 100%)",
      }}
    >
      {/* === themed cyberpunk backdrop (matches homepage) === */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.10]"
           style={{
             backgroundImage:
               "linear-gradient(color-mix(in oklab, var(--cyan) 55%, transparent) 1px, transparent 1px)," +
               "linear-gradient(90deg, color-mix(in oklab, var(--cyan) 55%, transparent) 1px, transparent 1px)",
             backgroundSize: "46px 46px, 46px 46px",
           }} />
      <div className="pointer-events-none absolute inset-0 opacity-[0.08]"
           style={{
             backgroundImage:
               "repeating-linear-gradient(60deg, color-mix(in oklab, var(--magenta) 50%, transparent) 0 1px, transparent 1px 28px)," +
               "repeating-linear-gradient(-60deg, color-mix(in oklab, var(--cyan) 40%, transparent) 0 1px, transparent 1px 36px)",
           }} />
      <div className="pointer-events-none absolute inset-0 scanlines opacity-15" />


      <div className="relative mx-auto flex min-h-screen max-w-md flex-col px-4 pb-44 pt-6 sm:max-w-lg">
        <Header step={step} total={total} meta={meta} onSkip={skip} />

        {/* CAMERA STAGE — per-step whip path */}
        <section key={step} className={`whip-${step + 1} step-enter mt-5 flex-1`}>
          <MascotPanel meta={meta} />
          <StepCard step={step + 1} total={total} title={meta.title} next={meta.next} accent={meta.accent}>
            {renderStep(step, sign, signed, () => { void router.navigate({ to: "/home" }); })}
          </StepCard>
          {required.length > 0 && (
            <GateBanner accent={meta.accent} required={required.length} done={required.filter((id) => signed[id]).length} />
          )}
        </section>

        <StepToolbar step={step} onJump={setStep} />

        {/* Meta strip — version + support, always visible */}
        <div className="mt-4 mb-2 flex items-center justify-between gap-2 px-1 text-[10px] tracking-widest text-muted-foreground/80">
          <span className="font-mono">BUTLER AI · v{APP_VERSION}</span>
          <a
            href={`mailto:${SUPPORT_EMAIL}?subject=Butler%20AI%20support`}
            className="font-mono text-foreground/70 underline-offset-2 hover:text-cyan hover:underline"
          >
            {SUPPORT_EMAIL}
          </a>
        </div>

      </div>

      <Footer step={step} total={total} onBack={back} onNext={next} canNext={allSigned} accent={meta.accent} />
    </main>
  );
}

/* ============================================================
   HEADER / FOOTER
   ============================================================ */

function Header({ step, total, meta, onSkip }: { step: number; total: number; meta: StepTheme; onSkip: () => void }) {
  const pct = ((step + 1) / total) * 100;
  return (
    <header className="space-y-3">
      <div className="flex items-center gap-2">
        <div className={`relative grid h-14 w-14 shrink-0 place-items-center rounded-full border border-${meta.accent}/40 bg-surface/60`}>
          <span className={`absolute -top-0.5 left-1/2 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-${meta.accent} pulse-dot`} />
          <span className={`font-mono text-lg font-bold text-${meta.accent}`}>{step + 1}</span>
        </div>
        <div className="panel-cyber relative flex h-14 min-w-0 flex-1 items-center justify-between gap-2 px-3">
          <span className={`min-w-0 truncate text-[13px] font-bold tracking-[0.18em] text-${meta.accent}`}>
            {meta.tag.replace(/_/g, " ")}
          </span>
          <span className="shrink-0 whitespace-nowrap text-[10px] font-medium tracking-widest text-foreground/75">
            {String(step + 1).padStart(2, "0")}/{total}
          </span>
        </div>
        <button onClick={onSkip} className="panel-cyber flex h-14 shrink-0 items-center gap-1.5 px-3 text-xs font-bold tracking-widest text-muted-foreground transition hover:text-cyan">
          SKIP <SkipForward className="h-3.5 w-3.5" />
        </button>

      </div>

      <div className="flex items-center justify-between gap-1">
        {STEPS.map((s, i) => {
          const state = i === step ? "active" : i < step ? "done" : "todo";
          return (
            <button
              key={s.id}
              onClick={() => {/* read-only header dot */}}
              className={
                "grid h-7 w-7 place-items-center rounded-md border transition " +
                (state === "active"
                  ? `border-${s.accent}/70 bg-${s.accent}/15 text-${s.accent} shadow-[0_0_12px_-2px_currentColor]`
                  : state === "done"
                  ? `border-${s.accent}/40 bg-${s.accent}/5 text-${s.accent}/70`
                  : "border-border/60 bg-background/40 text-muted-foreground/60")
              }
              aria-label={s.tag}
            >
              <StepIcon n={s.id} className="h-3.5 w-3.5" />
            </button>
          );
        })}
      </div>


      <div className="h-1 w-full overflow-hidden rounded-full bg-surface">
        <div className="h-full rounded-full bg-gradient-to-r from-green via-cyan to-magenta transition-all duration-500" style={{ width: `${pct}%` }} />
      </div>
    </header>
  );
}

function Footer({ step, total, onBack, onNext, canNext, accent }:
  { step: number; total: number; onBack: () => void; onNext: () => void; canNext: boolean; accent: Accent }) {
  const isLast = step === total - 1;
  return (
    <div className="fixed inset-x-0 bottom-0 z-20 border-t border-border/60 bg-background shadow-[0_-12px_30px_-12px_rgba(0,0,0,.8)]">
      <div className="mx-auto flex max-w-md items-center justify-between gap-3 px-4 py-3 sm:max-w-lg">
        <button
          onClick={onBack}
          disabled={step === 0}
          className="panel-cyber flex items-center gap-2 rounded-full px-5 py-3 text-xs font-bold tracking-widest text-muted-foreground transition disabled:opacity-30 enabled:hover:text-cyan"
        >
          <ChevronLeft className="h-4 w-4" /> BACK
        </button>

        <div className="flex flex-col items-center font-mono leading-none">
          <span className={`text-3xl font-extrabold text-${accent}`}>{step + 1}</span>
          <span className="mt-0.5 text-[10px] tracking-widest text-muted-foreground">OF {total}</span>
        </div>

        <button
          id="primary-cta"
          onClick={onNext}
          disabled={isLast || !canNext}
          title={!canNext ? "Sign all required policies to continue" : ""}
          className={`flex items-center gap-2 rounded-full px-6 py-3 text-xs font-extrabold tracking-widest transition disabled:cursor-not-allowed disabled:opacity-40 bg-${accent} text-primary-foreground shadow-[0_0_30px_-6px_currentColor] hover:brightness-110 ${canNext && !isLast ? "cta-heartbeat" : ""}`}
        >
          {!canNext ? "SIGN TO CONTINUE" : isLast ? "READY" : "NEXT"} <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   MASCOT — animated SVG bot, persona per step
   ============================================================ */

import mascotImg from "@/assets/mascot-butler.png";

const MOOD_ANIM: Record<StepTheme["mascot"]["mood"], string> = {
  wave: "m-wave",
  spy: "m-spy",
  shield: "m-nod",
  oath: "m-oath m-glow",
  scribe: "m-tilt",
  key: "m-shake",
  thinker: "m-think",
  host: "m-bow",
  builder: "m-build",
  launch: "m-launch m-glow",
};

function MascotPanel({ meta }: { meta: StepTheme }) {
  const accent = meta.accent;
  const ref = useRef<HTMLDivElement | null>(null);

  // subtle parallax tilt
  const onMove = (e: React.MouseEvent) => {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    el.style.setProperty("--rx", `${(-y * 10).toFixed(2)}deg`);
    el.style.setProperty("--ry", `${(x * 14).toFixed(2)}deg`);
  };
  const onLeave = () => {
    const el = ref.current; if (!el) return;
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--ry", "0deg");
  };

  return (
      <div className={`panel-cyber relative mb-4 flex items-stretch gap-3 overflow-hidden p-3 glow-${accent}`}>
      {/* mascot stage — bow-tie-up bust only, no floating shapes */}
      <div
        ref={ref}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        className={`relative grid aspect-square w-24 shrink-0 place-items-center overflow-hidden rounded-md border border-${accent}/40 bg-background/60 sm:w-28 md:w-32`}
        style={{ perspective: "700px" }}
      >
        <div className="absolute inset-0 grid-bg opacity-25" />
        {/* halo */}
        <div
          className="absolute inset-0 opacity-70"
          style={{ background: `radial-gradient(circle at 50% 55%, color-mix(in oklab, var(--${accent}) 38%, transparent), transparent 62%)` }}
        />
        <div
          key={meta.id}
          className="mascot-pop relative h-full w-full"
          style={{
            transform: "rotateX(var(--rx,0deg)) rotateY(var(--ry,0deg))",
            transformStyle: "preserve-3d",
            transition: "transform .25s ease-out",
          }}
        >
          <div
            className="absolute inset-0 grid place-items-center"
            style={{ transform: "translateZ(16px)" }}
          >
            <div
              className={`relative grid h-full w-full place-items-center ${MOOD_ANIM[meta.mascot.mood]}`}
              style={{ color: `var(--${accent})` }}
            >
              <img
                src={mascotImg}
                alt="Butler mascot"
                draggable={false}
                loading="eager"
                decoding="async"
                className="h-[92%] w-[92%] select-none object-contain"
                style={{ filter: "drop-shadow(0 6px 14px rgba(0,0,0,.55))" }}
              />
            </div>
          </div>
          {/* floor glow */}
          <div
            className="pointer-events-none absolute -bottom-1 left-1/2 h-2 w-20 -translate-x-1/2 rounded-full opacity-45"
            style={{ background: `var(--${accent})` }}
          />

        </div>
      </div>

      {/* speech bubble — no persona name, just the line */}
      <div key={`b${meta.id}`} className="bubble-in relative min-w-0 flex-1 rounded-md border border-border/60 bg-background/60 p-3">
        <div className="absolute -left-1.5 top-6 h-3 w-3 rotate-45 border-b border-l border-border/60 bg-background/60" />
        <div className={`flex items-center gap-2 text-[10px] tracking-widest text-${accent}`}>
          <span className={`h-1.5 w-1.5 rounded-full bg-${accent} pulse-dot`} />
          <span className="font-bold">BUTLER</span>
        </div>
        <p className="mt-1 text-sm leading-relaxed text-foreground">{meta.mascot.line}</p>
        {meta.mascot.sub && <p className="mt-1.5 text-[11px] tracking-widest text-foreground/70">{meta.mascot.sub}</p>}
      </div>
    </div>
  );
}


/* ============================================================
   CARDS / SHARED
   ============================================================ */

function StepCard({ step: _step, total: _total, title: _title, next: _next, accent: _accent, children }:
  { step: number; total: number; title: string; next: string; accent: Accent; children: ReactNode }) {
  // Header info (step / title / next) is already shown by <Header /> — render content only.
  return <div className="space-y-4">{children}</div>;
}


function GateBanner({ accent, required, done }: { accent: Accent; required: number; done: number }) {
  const complete = done === required;
  return (
    <div className={`panel mt-4 flex items-center justify-center gap-3 px-4 py-3 text-center ${complete ? "glow-green" : `glow-${accent}`}`}>
      {complete ? <CheckCircle2 className="h-5 w-5 text-green" /> : <PenLine className={`h-5 w-5 text-${accent}`} />}
      <div className="text-[13px] font-bold tracking-widest">
        <span className={complete ? "text-green" : `text-${accent}`}>
          {complete ? "ALL POLICIES SIGNED" : "SIGN EACH CARD TO CONTINUE"}
        </span>
        <span className="ml-2 text-muted-foreground">· {done}/{required} ACCEPTED</span>
      </div>
    </div>
  );
}

/** Wrapper that auto-injects index/total into every SignCard child so the chime fades. */
function SignList({ children }: { children: ReactNode }) {
  const arr = Array.isArray(children) ? children.flat() : [children];
  const cards = arr.filter((c): c is React.ReactElement => !!c && typeof c === "object" && (c as React.ReactElement).type === SignCard);
  const total = cards.length;
  let i = 0;
  return (
    <div className="space-y-2.5">
      {arr.map((child, k) => {
        if (child && typeof child === "object" && (child as React.ReactElement).type === SignCard) {
          const idx = i++;
          return <SignCardClone key={k} element={child as React.ReactElement} index={idx} total={total} />;
        }
        return child;
      })}
    </div>
  );
}
function SignCardClone({ element, index, total }: { element: React.ReactElement; index: number; total: number }) {
  // re-create element with injected index/total
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const Cmp = element.type as any;
  return <Cmp {...(element.props as object)} index={index} total={total} />;
}

/* ----- Sign-to-accept card ----- */

// Lazy-init WebAudio; one shared context so we never re-build it.
let _audioCtx: AudioContext | null = null;
/** Soft pen-on-paper chime. `volume` 0..1 — caller fades it down per signature. */
function playSignChime(volume = 1) {
  if (typeof window === "undefined") return;
  // Hard peak cap so the chime never feels harsh regardless of caller.
  const PEAK = 0.7;
  const vol = Math.max(0.015, Math.min(PEAK, volume));
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    _audioCtx = _audioCtx ?? new AC();
    const ctx = _audioCtx;
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
    const now = ctx.currentTime;
    const tones = [
      { f: 1320, t: 0.00, d: 0.09, g: 0.085 * vol },
      { f: 1760, t: 0.06, d: 0.11, g: 0.055 * vol },
    ];
    tones.forEach(({ f, t, d, g }) => {
      const o = ctx.createOscillator();
      const v = ctx.createGain();
      o.type = "triangle";
      o.frequency.setValueAtTime(f, now + t);
      v.gain.setValueAtTime(0, now + t);
      v.gain.linearRampToValueAtTime(g, now + t + 0.012);
      v.gain.exponentialRampToValueAtTime(0.0001, now + t + d);
      o.connect(v).connect(ctx.destination);
      o.start(now + t);
      o.stop(now + t + d + 0.02);
    });
  } catch { /* noop */ }
}

function SignCard({
  id, accent, icon, title, body, signed, onSign, link, index = 0, total = 1,
}: {
  id: string; accent: Accent; icon: ReactNode; title: string; body: string;
  signed: Record<string, number>; onSign: (id: string) => void;
  link?: { label: string; url: string };
  /** position in the signing list — used to fade volume the farther down you go */
  index?: number; total?: number;
}) {
  const isSigned = !!signed[id];
  const [fx, setFx] = useState(0);
  const handleSign = () => {
    if (isSigned) return;
    // Ease-out curve: top of list ≈ full, bottom ≈ whisper. playSignChime caps the peak.
    const ratio = total <= 1 ? 0 : index / (total - 1);
    const eased = 1 - Math.pow(ratio, 1.6);
    const vol = 0.18 + eased * 0.82;
    playSignChime(vol);
    setFx((n) => n + 1);
    onSign(id);
  };
  const tone = isSigned ? "green" : accent;
  return (
    <div
      data-tour={id}
      className={`panel relative overflow-hidden p-4 transition ${isSigned ? "glow-green bg-green/5" : `glow-${accent}`}`}
    >
      <div className="flex items-start gap-3">
        <div className={`grid h-11 w-11 shrink-0 place-items-center rounded-md border border-${tone}/60 bg-background/60 text-${tone}`}>
          {icon}
        </div>
        <div className="min-w-0 flex-1">
          <div className={`font-display text-[17px] font-extrabold leading-tight tracking-wide text-${tone}`}>
            {title}
          </div>
          <p className={`mt-2 text-[15px] leading-relaxed ${isSigned ? "text-green/95" : "text-foreground"}`}>
            {body}
          </p>
          {link && (link.url.startsWith("/") ? (
            <Link to={link.url} className={`mt-2.5 inline-flex items-center gap-1 text-[12px] font-bold tracking-widest text-${accent} underline-offset-2 hover:underline`}>
              <ExternalLink className="h-3.5 w-3.5" /> {link.label}
            </Link>
          ) : (
            <a href={link.url} target="_blank" rel="noreferrer"
              className={`mt-2.5 inline-flex items-center gap-1 text-[12px] font-bold tracking-widest text-${accent} underline-offset-2 hover:underline`}>
              <ExternalLink className="h-3.5 w-3.5" /> {link.label}
            </a>
          ))}
        </div>
      </div>
      <div className={`mt-4 flex items-center justify-between gap-2 border-t pt-3 ${isSigned ? "border-green/40" : "border-border/60"}`}>
        <span className={`font-mono text-[13px] font-bold tracking-widest ${isSigned ? "text-green" : `text-${accent}`}`}>
          {isSigned
            ? `✓ SIGNED · ${new Date(signed[id]).toLocaleTimeString()}`
            : "TAP SIGN TO ACCEPT"}
        </span>
        {isSigned ? (
          <span className="stamp-in select-none rounded-md border border-green/70 bg-green/15 px-3 py-1.5 font-mono text-[13px] font-extrabold tracking-widest text-green">
            ✓ ACCEPTED
          </span>
        ) : (
          <div className="relative">
            {fx > 0 && (
              <>
                <span key={`f-${fx}`} className="sign-flourish">✓ Signed</span>
                <span key={`r-${fx}`} className="sign-ring" />
              </>
            )}
            <button
              onClick={handleSign}
              aria-label={`Sign ${title}`}
              className={`flex items-center gap-2 rounded-md border border-${accent}/70 bg-${accent}/20 px-5 py-2.5 font-display text-[14px] font-extrabold tracking-widest text-${accent} shadow-[0_0_22px_-6px_currentColor] transition hover:bg-${accent}/30`}
            >
              <PenLine className="h-4 w-4" /> SIGN
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================
   REQUIRED-DOC MAP (per step)
   ============================================================ */

const REQUIRED_BY_STEP: Record<number, string[]> = {
  2: ["age18", "tos", "privacy", "lan_only", "camera_qr", "exec_control"],
  3: ["pledge_access", "pledge_malware", "pledge_privacy", "pledge_lawful", "pledge_self"],
  4: ["doc_privacy", "doc_tos", "doc_safety", "doc_deletion"],
  5: ["perm_lan"],
  7: ["srv_local", "srv_sqlite", "srv_python", "srv_hmac", "srv_shield"],
};

/* ============================================================
   STEP RENDERERS
   ============================================================ */

function renderStep(i: number, sign: (id: string) => void, signed: Record<string, number>, advance: () => void) {
  switch (i) {
    case 0: return <Step1Welcome />;
    case 1: return <Step2AppTour />;
    case 2: return <Step3Safety sign={sign} signed={signed} />;
    case 3: return <Step4Pledge sign={sign} signed={signed} />;
    case 4: return <Step5Legal sign={sign} signed={signed} />;
    case 5: return <Step6Permissions sign={sign} signed={signed} />;
    case 6: return <Step7QA />;
    case 7: return <Step8Server sign={sign} signed={signed} />;
    case 8: return <Step9Setup />;
    case 9: return <Step10Launch onLaunch={advance} />;
    default: return null;
  }
}

/* ---------- 1. Welcome ---------- */
function Step1Welcome() {
  return (
    <div className="space-y-5">
      <FeatureHero icon={<Bot className="h-16 w-16" />} color="cyan" title="BUTLER AI" subtitle="100% self-hosted PC automation · no cloud · no accounts" />
      <div className="grid grid-cols-2 gap-2">
        <KVTile icon={<WifiOff className="h-4 w-4" />} label="ZERO CLOUD" value="LAN ONLY" color="green" />
        <KVTile icon={<Lock className="h-4 w-4" />} label="SIGNED" value="HMAC-256" color="cyan" />
        <KVTile icon={<Ban className="h-4 w-4" />} label="AUTO-RUN" value="DISABLED" color="orange" />
        <KVTile icon={<Eye className="h-4 w-4" />} label="TELEMETRY" value="NONE" color="magenta" />
      </div>
      <TelemetryGrid />
      <div className="grid grid-cols-2 gap-2">
        <HealthRing value={96} label="SYSTEM HEALTH" color="green" />
        <HealthRing value={88} label="LAN UPLINK" color="cyan" />
      </div>
      <HmacMarquee />
      <TerminalBox title="BUTLER_OS TERMINAL" badge="SECURE BOOT" lines={[
        "BUTLER_OS v7.3 INITIALIZING...",
        "PYTHON ENGINE ............ OK",
        "HMAC-SHA256 AUTH ......... OK",
        "OLLAMA BRIDGE ............ READY",
        "ZERO CLOUD VERIFIED ...... ✓",
      ]} />
    </div>
  );
}

/* ---------- 2. App Tour ---------- */
const TABS: { icon: ReactNode; name: string; body: string; color: Accent }[] = [
  { icon: <MonitorCog className="h-4 w-4" />, name: "HOME",    body: "Live dashboard · CPU/RAM/Disk · QR-code pairing.",     color: "cyan" },
  { icon: <Code2 className="h-4 w-4" />,      name: "SCRIPTS", body: "250+ Python scripts · run, search, undo.",             color: "orange" },
  { icon: <Brain className="h-4 w-4" />,      name: "AI",      body: "Local LLM via Ollama · llama3 · mistral · phi3.",      color: "magenta" },
  { icon: <BookOpen className="h-4 w-4" />,   name: "KB",      body: "SIGMA-NET self-learning knowledge base.",              color: "yellow" },
  { icon: <Activity className="h-4 w-4" />,   name: "PC",      body: "Real-time telemetry · process list · health score.",   color: "green" },
  { icon: <Wrench className="h-4 w-4" />,     name: "BUILD",   body: "Visual node pipeline · drag-and-drop automations.",    color: "cyan" },
  { icon: <Sparkles className="h-4 w-4" />,   name: "SKINS",   body: "Twelve theme packs · personalise every pixel.",        color: "magenta" },
  { icon: <ListChecks className="h-4 w-4" />, name: "CONFIG",  body: "Server, keys, license, language, notifications.",      color: "orange" },
  { icon: <Telescope className="h-4 w-4" />,  name: "INTRO",   body: "This tutorial · always available · no doom loops.",    color: "cyan" },
];

function Step2AppTour() {
  const [active, setActive] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setActive((a) => (a + 1) % TABS.length), 1400);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="space-y-4">
      <div className="panel-cyber grid grid-cols-3 gap-2 p-2">
        {TABS.map((t, i) => (
          <button key={t.name} onClick={() => setActive(i)}
            className={`flex flex-col items-center gap-1 rounded-md border px-2 py-2 transition ${i === active ? `border-${t.color}/60 bg-${t.color}/10` : "border-border/40"}`}>
            <span className={`text-${t.color}`}>{t.icon}</span>
            <span className={`text-[9px] tracking-widest ${i === active ? `text-${t.color}` : "text-muted-foreground"}`}>{t.name}</span>
          </button>
        ))}
      </div>
      <div className={`panel p-3 glow-${TABS[active].color}`}>
        <div className={`flex items-center gap-2 text-${TABS[active].color}`}>
          {TABS[active].icon}
          <span className="text-sm font-bold tracking-widest">{TABS[active].name}</span>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-foreground">{TABS[active].body}</p>
      </div>
      <ScriptsRoster />
    </div>
  );
}

/* ---------- 3. Safety Consent (SIGN-GATE) ---------- */
function Step3Safety({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <SignList>
      <SignCard id="age18"        accent="orange"  icon={<AlertTriangle className="h-5 w-5" />} title="18+ ONLY · ADULT USE"
        body="Butler AI is a developer-grade automation tool intended for adults only. By signing below, you confirm under your own responsibility that you are at least 18 years old and legally permitted to operate this software in your jurisdiction."
        signed={signed} onSign={sign} />
      <SignCard id="tos"          accent="yellow"  icon={<Gavel className="h-5 w-5" />}         title="TERMS OF SERVICE"
        body="You agree to use Butler AI exclusively on computers you personally own or have explicit, documented authorisation to operate. Unauthorised access to any system is strictly prohibited and may violate criminal law in your country."
        signed={signed} onSign={sign} />
      <SignCard id="privacy"      accent="green"   icon={<ShieldCheck className="h-5 w-5" />}   title="PRIVACY POLICY · LOCAL-FIRST"
        body="A randomly generated device UUID is stored only on this phone. No personal data, scripts, file paths, telemetry, contacts, or location information is ever transmitted off your device — there is no cloud server to send it to."
        signed={signed} onSign={sign} />
      <SignCard id="lan_only"     accent="cyan"    icon={<Wifi className="h-5 w-5" />}          title="LAN-ONLY OPERATION"
        body="Butler AI runs entirely on your own PC over your home Wi-Fi network. There is no cloud relay, no proxy server, no internet round-trip. If your Wi-Fi is off, Butler does not work — that is by design."
        signed={signed} onSign={sign} />
      <SignCard id="camera_qr"    accent="magenta" icon={<ScanLine className="h-5 w-5" />}      title="CAMERA · QR PAIRING ONLY"
        body="When PC setup finishes, the Butler installer automatically downloads and configures about six programs — Python 3.12+, every pip dependency, the Ollama runtime, your private local AI model (qwen2.5-coder:7b), the HMAC bridge, and butler_server.py itself — then immediately displays a one-time pairing QR code on your PC screen. Your phone camera is invoked solely to scan that QR. No photo, video, or frame is ever recorded, saved, transmitted, or analysed — the scanner releases the camera the instant the code is read."
        signed={signed} onSign={sign} />
      <SignCard id="exec_control" accent="orange"  icon={<HandMetal className="h-5 w-5" />}     title="YOU CONTROL EVERY EXECUTION"
        body="Every script runs on YOUR PC under YOUR operating-system permissions, and only after YOU actively tap it. There is no background scheduler, no auto-run, no cron, no hidden trigger. You decide what executes, when, and you can revoke pairing at any time."
        signed={signed} onSign={sign} />
    </SignList>
  );
}

/* ---------- 4. Safety Pledge (SIGN-GATE) ---------- */
function Step4Pledge({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <SignList>
      <SignCard id="pledge_access"  accent="orange"  icon={<Ban className="h-5 w-5" />}         title="I WILL NOT ACCESS WHAT ISN'T MINE"
        body="I solemnly pledge that I will never attempt to use Butler AI — directly or indirectly — to access, monitor, or control any computer, network, or device that I do not personally own or have explicit written authorisation to operate. This includes friends', family members', and employers' systems."
        signed={signed} onSign={sign} />
      <SignCard id="pledge_malware" accent="orange"  icon={<ShieldAlert className="h-5 w-5" />} title="I WILL DEPLOY NO MALICIOUS CODE"
        body="I will not author, distribute, or execute malware, ransomware, crypto-miners, key-loggers, destructive wipers, or any script designed to harm a system, exfiltrate data, or evade the consent of its owner. Butler AI is built to help — never to attack."
        signed={signed} onSign={sign} />
      <SignCard id="pledge_privacy" accent="yellow"  icon={<UserX className="h-5 w-5" />}       title="I WILL RESPECT EVERY PERSON'S PRIVACY"
        body="I will not use Butler AI to spy on, surveil, eavesdrop on, photograph, screen-record, or otherwise violate the privacy of any person — including roommates, colleagues, partners, or members of my own household."
        signed={signed} onSign={sign} />
      <SignCard id="pledge_lawful"  accent="yellow"  icon={<Gavel className="h-5 w-5" />}       title="I WILL OBEY THE LAW"
        body="I will operate Butler AI strictly within the laws of my country, state, and locality. I understand that lawful personal automation on hardware I own is the entire purpose of this tool, and I will not stretch it beyond that boundary."
        signed={signed} onSign={sign} />
      <SignCard id="pledge_self"    accent="green"   icon={<ShieldCheck className="h-5 w-5" />} title="I ACCEPT PERSONAL RESPONSIBILITY"
        body="Butler AI ships with the Malicious-Script Shield, HMAC signing, and a hard-coded blocklist — but no software can replace human judgement. I accept full personal responsibility for every command I execute and every script I add to my library."
        signed={signed} onSign={sign} />
    </SignList>
  );
}


/* ---------- 5. Legal Documents (SIGN-GATE w/ link) ---------- */
const APP_VERSION = "7.3.0";
const SUPPORT_EMAIL = "andrejsladkovic1992@gmail.com";
const POLICY_URL = "https://shawnjan-cmd.github.io/privacy-policy-/";
const REPO_URL = "https://github.com/shawnjan-cmd/CommandCube";
const REPO_RAW = "https://raw.githubusercontent.com/shawnjan-cmd/CommandCube/main";
function Step5Legal({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <>
      <SignList>
        <SignCard id="doc_privacy"  accent="cyan"    icon={<Eye className="h-5 w-5" />}         title="PRIVACY POLICY"
          body="A random device UUID is the only identifier ever stored. No scripts, contacts, locations, analytics, or telemetry are collected — there is no cloud server to receive them. Open the full text below and sign to confirm you have read it."
          signed={signed} onSign={sign} link={{ label: "READ FULL PRIVACY POLICY",  url: "/legal/privacy" }} />
        <SignCard id="doc_tos"      accent="yellow"  icon={<Gavel className="h-5 w-5" />}       title="TERMS OF SERVICE"
          body="Butler AI is provided for adults (18+) operating personal PCs they own. Unauthorised access, malware deployment, and any unlawful use are strictly forbidden. By signing, you accept these terms in full."
          signed={signed} onSign={sign} link={{ label: "READ FULL TERMS",            url: "/legal/terms"   }} />
        <SignCard id="doc_safety"   accent="green"   icon={<ShieldCheck className="h-5 w-5" />} title="DATA SAFETY DECLARATION"
          body="Camera is used for QR pairing only and never stored. No analytics, no advertising, no third-party SDKs. All data lives in a local SQLite file on your PC. The codebase is open-source and independently auditable."
          signed={signed} onSign={sign} link={{ label: "READ DATA SAFETY",           url: "/legal/safety"  }} />
        <SignCard id="doc_deletion" accent="orange"  icon={<Trash2 className="h-5 w-5" />}      title="DATA DELETION POLICY"
          body="Settings → DELETE ALL MY DATA wipes everything in three taps: phone storage, KB entries, command history, and device UUID. The action is immediate, permanent, and irreversible — there is no cloud backup to restore from."
          signed={signed} onSign={sign} link={{ label: "READ DELETION POLICY",       url: "/legal/delete"  }} />
      </SignList>
      <a href="/legal/privacy"
        className="panel-cyber mt-3 flex items-center justify-center gap-2 px-3 py-3 text-[12px] font-bold tracking-widest text-cyan transition hover:bg-cyan/5">
        <ExternalLink className="h-4 w-4" /> OPEN ALL LEGAL DOCUMENTS
      </a>
    </>
  );
}

/* ---------- 6. Permissions (one required) ---------- */
function Step6Permissions({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <div className="space-y-2.5">
      <div className="panel-cyber flex items-center justify-center gap-2 px-3 py-2.5 text-center text-[12px] font-bold tracking-widest text-foreground/85">
        <span className="rounded border border-green/50 bg-green/10 px-2 py-0.5 text-green">REQUIRED</span>
        <span>LOCAL NETWORK · EVERYTHING ELSE IS OPTIONAL</span>
      </div>
      <SignList>
        <SignCard id="perm_lan" accent="green" icon={<Wifi className="h-5 w-5" />} title="LOCAL NETWORK · REQUIRED"
          body="Allows Butler AI to discover your PC server on Wi-Fi and exchange signed commands. No internet permission is requested — this scope is strictly limited to devices on your own home network."
          signed={signed} onSign={sign} />
      </SignList>
      <OptionalPerm icon={<Camera className="h-4 w-4" />}      color="magenta" title="CAMERA · OPTIONAL"      body="Scan QR codes from your PC for one-tap pairing. Nothing is photographed or stored — the camera releases the instant a code is read." />
      <OptionalPerm icon={<Folder className="h-4 w-4" />}      color="orange"  title="STORAGE · OPTIONAL"     body="Send a file from your phone to your PC. Used only when you actively tap 'Send File' — never in the background." />
      <OptionalPerm icon={<Fingerprint className="h-4 w-4" />} color="cyan"    title="BIOMETRICS · OPTIONAL"  body="Lock the app behind FaceID or fingerprint. Disabled by default; enable any time in Settings." />
    </div>
  );
}

function OptionalPerm({ icon, color, title, body }: { icon: ReactNode; color: Accent; title: string; body: string }) {
  const [enabled, setEnabled] = useState(false);
  return (
    <div className="panel-cyber flex items-start gap-3 p-3">
      <div className={`grid h-9 w-9 shrink-0 place-items-center rounded-md border border-${color}/40 bg-background/60 text-${color}`}>{icon}</div>
      <div className="min-w-0 flex-1">
        <div className={`text-xs font-bold tracking-wider text-${color}`}>{title}</div>
        <p className="mt-1 text-[13px] leading-relaxed text-foreground">{body}</p>
      </div>
      <button
        onClick={() => setEnabled((v) => !v)}
        className={`mt-0.5 flex h-6 w-11 shrink-0 items-center rounded-full border transition ${enabled ? `border-${color}/60 bg-${color}/20` : "border-border bg-background/60"}`}
      >
        <span className={`h-4 w-4 rounded-full transition-all ${enabled ? `ml-6 bg-${color} shadow-[0_0_10px_currentColor]` : "ml-1 bg-muted-foreground"}`} />
      </button>
    </div>
  );
}

/* ---------- 7. Q & A (no sign required) ---------- */
const QA: { q: string; a: string; color: Accent; icon: ReactNode }[] = [
  { q: "What does Butler AI actually do?",        a: "Sends signed Python commands over your home Wi-Fi to a server you run on your PC. PC executes → result returns to your phone. 100% local.", color: "cyan",    icon: <HelpCircle className="h-4 w-4" /> },
  { q: "Does it run automatically?",              a: "NO — every script requires your active tap. No background execution, no scheduler, no cron, no auto-start. Enforced server-side.",            color: "orange",  icon: <Ban className="h-4 w-4" /> },
  { q: "Does it upload my data?",                 a: "NEVER — 100% local SQLite database on your PC. No data ever leaves your local network. No cloud relay, no analytics, no telemetry.",         color: "green",   icon: <Eye className="h-4 w-4" /> },
  { q: "How is the LAN connection secured?",      a: "HMAC-SHA256 signed requests · AES-256 encrypted in transit · Single-device pairing · 64-char tokens · Replay protection via timestamp.",     color: "green",   icon: <Lock className="h-4 w-4" /> },
  { q: "How do I pair my PC?",                    a: "Run the one-shot installer on your PC. It auto-downloads Python, Ollama, the local AI model, the HMAC bridge, and butler_server.py (~6 programs), then instantly displays a pairing QR code on your screen. Tap SCAN QR TO PAIR on your phone — one tap and you're connected. After that it auto-reconnects.",     color: "cyan",    icon: <ScanLine className="h-4 w-4" /> },
  { q: "Can I undo a script I ran by accident?",  a: "YES — 1-Tap Undo. Every execution is logged and reversible for 24 hours. PC → Undo Log → tap entry → Undo.",                                  color: "yellow",  icon: <PenLine className="h-4 w-4" /> },
  { q: "Does the AI model call the internet?",    a: "NO — Ollama (qwen2.5-coder:7b) runs entirely on your PC. Fully offline AI inference. Zero outbound calls.",                                  color: "magenta", icon: <Brain className="h-4 w-4" /> },
  { q: "What about malicious-script detection?",  a: "A built-in Malicious-Script Shield scans every payload for dangerous patterns (rm -rf, format, registry wipes, miners) before execution.",   color: "orange",  icon: <ShieldAlert className="h-4 w-4" /> },
  { q: "What data is collected about me?",        a: "None. A random device UUID lives only on your phone. No scripts, outputs, file names, contacts, or analytics ever leave the device.",        color: "cyan",    icon: <Eye className="h-4 w-4" /> },
  { q: "How do I delete all my data?",            a: "Settings → DELETE ALL MY DATA — three taps. Wipes phone storage, KB, history, UUID. PC SQLite is removed via the PC uninstaller.",           color: "orange",  icon: <Trash2 className="h-4 w-4" /> },
];
function Step7QA() {
  const [open, setOpen] = useState(0);
  return (
    <div className="space-y-2">
      <SigmaNetGraph />
      <HmacMarquee />
      {QA.map((qa, i) => {
        const isOpen = open === i;
        return (
          <button key={qa.q} onClick={() => setOpen(isOpen ? -1 : i)}
            className={`panel w-full overflow-hidden p-3 text-left transition ${isOpen ? `glow-${qa.color}` : ""}`}>
            <div className="flex items-start gap-2">
              <span className={`mt-0.5 text-${qa.color}`}>{qa.icon}</span>
              <span className={`flex-1 text-xs font-bold tracking-wider text-${qa.color}`}>{qa.q}</span>
              <ChevronRight className={`h-4 w-4 text-muted-foreground transition ${isOpen ? "rotate-90" : ""}`} />
            </div>
            {isOpen && <p className="mt-2 pl-6 text-[13px] leading-relaxed text-foreground">{qa.a}</p>}
          </button>
        );
      })}
    </div>
  );
}

/* ---------- 8. Server Privacy (SIGN-GATE) ---------- */
function Step8Server({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <>
      <TerminalBox title="butler_server.py" badge="LOCALHOST" color="green" lines={[
        "BIND        127.0.0.1 / LAN iface",
        "AUTH        HMAC-SHA256",
        "EXEC        signed Python only",
        "STORAGE     ./butler.db (SQLite)",
        "TELEMETRY   disabled · no remote calls",
      ]} />
      <SignList>
        <SignCard id="srv_local"  accent="cyan"    icon={<Server className="h-5 w-5" />}      title="RUNS ON YOUR PC ONLY"
          body="A small Flask server binds exclusively to your LAN network interface. It is never exposed to the public internet, never proxied through a cloud, and never reachable from outside your own home network."
          signed={signed} onSign={sign} />
        <SignCard id="srv_sqlite" accent="green"   icon={<Database className="h-5 w-5" />}    title="LOCAL SQLITE DATABASE"
          body="Scripts, execution logs, knowledge-base entries, and command history all live in a single .db file on your PC. Nothing is uploaded anywhere — you can inspect, back up, or delete this file at any time."
          signed={signed} onSign={sign} />
        <SignCard id="srv_python" accent="orange"  icon={<Code2 className="h-5 w-5" />}       title="EXECUTES SIGNED PYTHON ONLY"
          body="The server accepts only cryptographically signed Python payloads, executed through your own system Python interpreter. No shell mode, no remote eval, no other execution paths whatsoever."
          signed={signed} onSign={sign} />
        <SignCard id="srv_hmac"   accent="magenta" icon={<KeyRound className="h-5 w-5" />}    title="HMAC-SHA256 AUTHENTICATION"
          body="Every single request is signed with a shared secret generated at pairing time. Any unsigned, malformed, or tampered request is rejected immediately — including replay attacks blocked by per-request timestamps."
          signed={signed} onSign={sign} />
        <SignCard id="srv_shield" accent="orange"  icon={<ShieldAlert className="h-5 w-5" />} title="MALICIOUS-SCRIPT SHIELD"
          body="A hard-coded blocklist scans every payload before execution: rm -rf /, format/diskpart, registry wipes, shutdown commands, crypto-miner patterns, and known destructive sequences are refused server-side, no exceptions."
          signed={signed} onSign={sign} />
      </SignList>
    </>
  );
}

/* ---------- 9. PC Setup ---------- */
function Step9Setup() {
  return (
    <div className="space-y-3">
      <FeatureHero icon={<Wrench className="h-16 w-16" />} color="magenta" title="PC SETUP" subtitle="Three steps · about five minutes total" />
      <PairingQR />
      {[
        { n: "01", title: "INSTALL REQUIREMENTS",   body: "Run the one-shot installer — it silently sets up Python 3.12+, every required pip package, Ollama, and the qwen2.5-coder:7b model. No extra clicks, no manual configuration.", color: "cyan"   as Accent },
        { n: "02", title: "DOWNLOAD BUTLER SERVER", body: "butler_server.py runs on your PC, instantly displays a pairing QR code, and opens a signed LAN bridge bound only to your local network interface.",                            color: "yellow" as Accent },
        { n: "03", title: "CONNECT & CONTROL",      body: "Tap SCAN QR TO PAIR on your phone, point the camera at your PC screen, and you are connected. Pairing is a one-time event — the link auto-restores every time afterwards.",     color: "green"  as Accent },
      ].map((s) => (
        <div key={s.n} className={`panel flex flex-col items-center gap-3 p-4 text-center glow-${s.color}`}>
          <div className={`grid h-14 w-14 place-items-center rounded-md border border-${s.color}/50 bg-background/60 font-mono text-${s.color}`}>
            <span className="text-2xl font-extrabold leading-none">{s.n}</span>
          </div>
          <div className="min-w-0">
            <div className={`font-display text-[15px] font-extrabold tracking-widest text-${s.color}`}>{s.title}</div>
            <p className="mt-2 text-[14px] leading-relaxed text-foreground">{s.body}</p>
          </div>
        </div>
      ))}
      <div className="panel-cyber space-y-2 p-3 glow-green">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-green">
            <Server className="h-4 w-4" />
            <span className="font-mono text-xs font-extrabold tracking-wider">butler_server.py</span>
          </div>
          <span className="rounded border border-green/40 bg-green/10 px-1.5 py-0.5 font-mono text-[9px] tracking-widest text-green">
            PYTHON · ~14 KB
          </span>
        </div>
        <p className="text-[12px] leading-relaxed text-foreground/80">
          The local-only bridge that runs on YOUR PC. Saves to your Downloads folder — no installer, no telemetry.
        </p>
        <div className="grid grid-cols-2 gap-2 pt-1">
          <a
            href={REPO_RAW + "/butler_server.py"}
            target="_blank"
            rel="noreferrer"
            download="butler_server.py"
            className="flex items-center justify-center gap-2 rounded-md border border-green/60 bg-green/15 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-green shadow-[0_0_18px_-6px_currentColor] transition hover:bg-green/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green/70"
          >
            <Server className="h-3.5 w-3.5" /> DOWNLOAD
          </a>
          <a
            href={REPO_URL}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 rounded-md border border-cyan/60 bg-cyan/10 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-cyan transition hover:bg-cyan/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/70"
          >
            <ExternalLink className="h-3.5 w-3.5" /> VIEW SOURCE
          </a>
        </div>
      </div>
      <a href={POLICY_URL} target="_blank" rel="noreferrer"
        className="panel-cyber flex items-center justify-center gap-2 px-3 py-2.5 text-[11px] font-bold tracking-widest text-foreground transition hover:bg-foreground/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-foreground/40">
        <ExternalLink className="h-3 w-3" /> OPEN SETUP DOCS
      </a>
      <div className="grid grid-cols-2 gap-2">
        <KVTile icon={<Cpu className="h-4 w-4" />}      label="MIN RAM"  value="4 GB"   color="cyan" />
        <KVTile icon={<HardDrive className="h-4 w-4" />} label="DISK"    value="2 GB"   color="green" />
      </div>
    </div>
  );
}

/* ---------- 10. Launch ---------- */
function Step10Launch({ onLaunch }: { onLaunch: () => void }) {
  const [armed, setArmed] = useState(false);
  const [progress, setProgress] = useState(0);
  const [lines, setLines] = useState<string[]>([]);
  const seqRef = useRef<number | null>(null);

  const sequence = useMemo(() => [
    "[OK] PYTHON ENGINE",
    "[OK] OLLAMA BRIDGE",
    "[OK] HMAC-SHA256 AUTH",
    "[OK] ZERO CLOUD VERIFIED",
    "[OK] SIGMA-NET ONLINE",
    "BUTLER OS READY",
  ], []);

  useEffect(() => {
    if (!armed) return;
    let i = 0;
    const t = window.setInterval(() => {
      setLines((l) => [...l, sequence[i]]);
      setProgress(((i + 1) / sequence.length) * 100);
      i++;
      if (i >= sequence.length) {
        window.clearInterval(t);
        setTimeout(() => onLaunch(), 600);
      }
    }, 320);
    seqRef.current = t;
    return () => window.clearInterval(t);
  }, [armed, sequence, onLaunch]);

  return (
    <div className="space-y-5">
      <FeatureHero icon={<Rocket className="h-16 w-16" />} color="cyan" title="INITIATE BUTLER OS" subtitle="All policies signed · all systems verified" />
      <TerminalBox title="LAUNCH SEQUENCE" badge={armed ? "RUNNING" : "ARMED"} color="green" lines={armed ? lines : ["awaiting operator confirmation..."]} />
      <div className="h-1 w-full overflow-hidden rounded-full bg-surface">
        <div className="h-full rounded-full bg-gradient-to-r from-green via-cyan to-magenta transition-all duration-300" style={{ width: `${progress}%` }} />
      </div>
      {!armed ? (
        <button
          onClick={() => setArmed(true)}
          className="group relative grid w-full place-items-center overflow-hidden rounded-2xl border border-cyan/50 bg-background/40 py-6 glow-cyan transition hover:bg-cyan/10"
        >
          <span className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan/10 to-transparent opacity-0 transition group-hover:opacity-100" />
          <div className="relative flex items-center gap-3 font-mono">
            <Power className="h-6 w-6 text-cyan text-glow-cyan" />
            <span className="text-lg font-extrabold tracking-[0.3em] text-cyan text-glow-cyan">ENGAGE</span>
          </div>
          <div className="relative mt-1 text-[11px] font-medium tracking-widest text-foreground/75">PRESS TO BOOT BUTLER OS</div>
        </button>
      ) : progress >= 100 ? (
        <div className="relative">
          <span className="pointer-events-none absolute inset-0 ring-burst rounded-full border-2 border-green/60" />
          <div className="reveal-burst panel grid place-items-center gap-2 p-5 glow-green">
            <Sparkles className="h-8 w-8 text-green text-glow-green icon-pop-in" />
            <div className="text-lg font-extrabold tracking-widest text-green text-glow-green">WELCOME, OPERATOR</div>
            <div className="text-[12px] font-medium tracking-widest text-foreground/80">BUTLER OS · ONLINE</div>
          </div>
        </div>
      ) : (
        <div className="panel-cyber flex items-center justify-center gap-2 p-3 text-xs tracking-widest text-cyan">
          <span className="h-2 w-2 rounded-full bg-cyan pulse-dot" /> BOOTING · {Math.round(progress)}%
        </div>
      )}
      <SourceConfigManager />
      <OperatorBundle />
      <div className="grid grid-cols-2 gap-2">
        <KVTile icon={<Heart className="h-4 w-4" />}        label="OPEN"   value="AUDITABLE" color="magenta" />
        <KVTile icon={<InfinityIcon className="h-4 w-4" />} label="YOURS" value="FOREVER"    color="cyan" />
      </div>
    </div>
  );
}

/* ---------- Operator Bundle (download all files) ---------- */
function OperatorBundle() {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(0);
  const [masterLink, setMasterLink] = useState<{ url: string; name: string } | null>(null);
  const FILES = useMemo(
    () => [
      { name: "butler_server.py",       url: REPO_RAW + "/butler_server.py", kind: "remote" as const },
      { name: "README.md",              url: REPO_RAW + "/README.md",        kind: "remote" as const },
      { name: "LICENSE",                url: REPO_RAW + "/LICENSE",          kind: "remote" as const },
      { name: "butler-master-<ts>.md",  url: "",                              kind: "master" as const },
    ],
    [],
  );
  const ZIP_URL = REPO_URL + "/archive/refs/heads/main.zip";

  const triggerRemote = (url: string, name: string) => {
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.rel = "noreferrer";
    a.target = "_blank";
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const downloadAll = async () => {
    if (busy) return;
    setBusy(true);
    setDone(0);
    setMasterLink(null);
    try { navigator.vibrate?.(12); } catch { /* noop */ }
    playSignChime(0.5);
    for (let i = 0; i < FILES.length; i++) {
      const f = FILES[i];
      if (f.kind === "master") {
        try {
          const res = await exportMasterSourceMd();
          if (res.url) setMasterLink({ url: res.url, name: res.name });
        } catch { /* swallow — keep the queue moving */ }
      } else {
        triggerRemote(f.url, f.name);
      }
      setDone(i + 1);
      await new Promise((r) => setTimeout(r, 280));
    }
    setBusy(false);
  };

  return (
    <div className="panel-cyber space-y-3 p-4 glow-green">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-green">
          <HardDrive className="h-4 w-4" />
          <span className="font-display text-[12px] font-extrabold tracking-[0.2em]">OPERATOR BUNDLE</span>
        </div>
        <span className="rounded-full border border-green/40 bg-green/10 px-2 py-0.5 font-mono text-[9px] tracking-widest text-green">
          {FILES.length} FILES
        </span>
      </div>
      <p className="text-[13px] leading-relaxed text-foreground/85">
        Grab everything you need to run Butler OS on your PC in one tap — server bridge, readme, license, and your full master source bundle (.md). All saved straight to your Downloads folder.
      </p>
      <ul className="grid gap-1 font-mono text-[11px] text-foreground/80">
        {FILES.map((f, i) => (
          <li key={f.name} className="flex items-center justify-between gap-2 rounded-md border border-green/20 bg-green/5 px-2 py-1">
            <span className="truncate">{f.name}{f.kind === "master" ? "  ·  full project source" : ""}</span>
            <span className={`text-[10px] tracking-widest ${busy && i >= done ? "text-foreground/40" : "text-green"}`}>
              {busy ? (i < done ? "✓ SENT" : i === done ? "…" : "QUEUED") : "READY"}
            </span>
          </li>
        ))}
      </ul>
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={downloadAll}
          disabled={busy}
          className="flex items-center justify-center gap-2 rounded-md border border-green/60 bg-green/15 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-green shadow-[0_0_18px_-6px_currentColor] transition hover:bg-green/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green/70 disabled:opacity-60"
        >
          <Server className="h-3.5 w-3.5" />
          {busy ? `DOWNLOADING ${done}/${FILES.length}` : "DOWNLOAD ALL FILES"}
        </button>
        <a
          href={ZIP_URL}
          target="_blank"
          rel="noreferrer"
          className="flex items-center justify-center gap-2 rounded-md border border-cyan/60 bg-cyan/10 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-cyan transition hover:bg-cyan/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/70"
        >
          <ExternalLink className="h-3.5 w-3.5" /> DOWNLOAD .ZIP
        </a>
      </div>
      {masterLink ? (
        <a
          href={masterLink.url}
          download={masterLink.name}
          target="_blank"
          rel="noreferrer"
          className="flex items-center justify-center gap-2 rounded-md border border-green/60 bg-green/20 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-green shadow-[0_0_18px_-6px_currentColor]"
        >
          <Download className="h-3.5 w-3.5" /> OPEN MASTER .MD — {masterLink.name}
        </a>
      ) : null}
    </div>
  );
}

/* ============================================================
   SHARED PRIMITIVES
   ============================================================ */

function TerminalBox({ title, badge, lines, color = "green" }: { title: string; badge?: string; lines: string[]; color?: "green" | "cyan" }) {
  const c = color;
  return (
    <div className={`panel relative overflow-hidden ${c === "green" ? "glow-green" : "glow-cyan"}`}>
      {/* Header — matches the in-app panel chrome (no fake mac traffic lights) */}
      <div className={`flex items-center justify-between border-b border-${c}/30 bg-gradient-to-r from-${c}/15 via-transparent to-${c}/10 px-3 py-2`}>
        <div className="flex items-center gap-2 min-w-0">
          <span className={`relative grid h-5 w-5 place-items-center rounded-md border border-${c}/60 bg-background/70 text-${c}`}>
            <Code2 className="h-3 w-3" />
            <span className={`pulse-dot absolute -right-0.5 -top-0.5 h-1.5 w-1.5 rounded-full bg-${c} shadow-[0_0_8px_currentColor]`} />
          </span>
          <span className={`font-display text-[11px] font-bold tracking-[0.18em] text-${c} truncate`}>{title}</span>
        </div>
        {badge && (
          <span className={`shrink-0 rounded-full border border-${c}/50 bg-${c}/10 px-2 py-0.5 font-display text-[9px] font-bold tracking-[0.2em] text-${c}`}>
            {badge}
          </span>
        )}
      </div>
      {/* Body */}
      <pre className={`whitespace-pre-wrap px-3 py-3 font-mono text-[12px] leading-relaxed text-${c}`}>
        {lines.map((l, i) => (
          <div key={i} className="flex gap-2">
            <span className={`text-${c}/60 select-none`}>{String(i + 1).padStart(2, "0")}</span>
            <span className={`text-${c}/70 select-none`}>{"›"}</span>
            <span className="text-foreground/95">{l}</span>
          </div>
        ))}
        <div className="flex gap-2">
          <span className={`text-${c}/60 select-none`}>{String(lines.length + 1).padStart(2, "0")}</span>
          <span className={`text-${c}/70 select-none`}>{"›"}</span>
          <span className={`cursor-blink text-${c}`}>▍</span>
        </div>
      </pre>
    </div>
  );
}

function FeatureHero({ icon, color, title, subtitle }: { icon: ReactNode; color: Accent; title: string; subtitle: string }) {
  return (
    <div className={`panel flex items-center gap-4 p-4 glow-${color}`}>
      <div className={`grid h-20 w-20 shrink-0 place-items-center rounded-lg border border-${color}/40 bg-background/50 text-${color}`}>
        {icon}
      </div>
      <div className="min-w-0">
        <div className={`text-lg font-extrabold tracking-wider text-${color}`}>{title}</div>
        <div className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{subtitle}</div>
      </div>
    </div>
  );
}

function KVTile({ icon, label, value, color }: { icon: ReactNode; label: string; value: string; color: Accent }) {
  return (
    <div className="panel-cyber flex items-center gap-3 p-3">
      <div className={`grid h-9 w-9 place-items-center rounded-md border border-${color}/40 bg-${color}/5 text-${color}`}>{icon}</div>
      <div>
        <div className={`text-sm font-bold text-${color}`}>{value}</div>
        <div className="text-[10px] font-medium tracking-widest text-foreground/70">{label}</div>
      </div>
    </div>
  );
}

/* keep Scroll import alive in case lucide re-shakes */
export const __keep = { Scroll };

/* ============================================================
   STEP ICONS — 10 unique custom SVGs (one per page)
   ============================================================ */

function StepIcon({ n, className = "h-4 w-4" }: { n: number; className?: string }) {
  const p = { fill: "none", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (n) {
    case 1: // WELCOME — waving hand + spark
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M8 14V7a1.5 1.5 0 1 1 3 0v6"/><path d="M11 13V5.5a1.5 1.5 0 1 1 3 0V13"/><path d="M14 13V6.5a1.5 1.5 0 1 1 3 0V14"/><path d="M17 14v-3a1.5 1.5 0 1 1 3 0v6a5 5 0 0 1-5 5h-2a5 5 0 0 1-5-5v-1l-2-3a1.4 1.4 0 0 1 2.2-1.7L9 13"/><path d="M5 4l1 1M3 8h1.5M6 2v1.5"/></g></svg>);
    case 2: // APP TOUR — compass / map
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><circle cx="12" cy="12" r="9"/><path d="M15.5 8.5 13 13l-4.5 2.5L11 11z" fill="currentColor" opacity=".25"/><path d="M15.5 8.5 13 13l-4.5 2.5L11 11z"/></g></svg>);
    case 3: // SAFETY — shield + check
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M12 3 4 6v6c0 4.5 3.4 8.4 8 9 4.6-.6 8-4.5 8-9V6z"/><path d="m9 12 2 2 4-4"/></g></svg>);
    case 4: // PLEDGE — raised fist
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M7 21V12a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v9"/><path d="M9 10V7a1.5 1.5 0 1 1 3 0v3"/><path d="M12 10V6a1.5 1.5 0 1 1 3 0v4"/><path d="M15 10V8a1.5 1.5 0 1 1 3 0v3"/></g></svg>);
    case 5: // LEGAL — scroll w/ ribbon
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M6 4h10a2 2 0 0 1 2 2v12a2 2 0 0 0 2 2H8a2 2 0 0 1-2-2z"/><path d="M4 4h2v14a2 2 0 0 0 2 2"/><path d="M9 9h6M9 13h6"/></g></svg>);
    case 6: // PERMISSIONS — keyring
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><circle cx="8" cy="14" r="4"/><path d="m11 11 9-9"/><path d="m17 5 2 2M15 7l2 2"/></g></svg>);
    case 7: // Q&A — speech with question mark
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M21 12a8 8 0 0 1-11.5 7.2L4 21l1.8-5.5A8 8 0 1 1 21 12z"/><path d="M10 10a2 2 0 1 1 3 1.7c-.7.4-1 .8-1 1.6"/><circle cx="12" cy="16.5" r=".6" fill="currentColor"/></g></svg>);
    case 8: // SERVER — tower with signal
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><rect x="4" y="5" width="16" height="6" rx="1.5"/><rect x="4" y="13" width="16" height="6" rx="1.5"/><circle cx="8" cy="8" r=".7" fill="currentColor"/><circle cx="8" cy="16" r=".7" fill="currentColor"/><path d="M15 8h3M15 16h3"/></g></svg>);
    case 9: // SETUP — gear + wrench
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><circle cx="11" cy="11" r="3"/><path d="M11 3v2M11 17v2M3 11h2M17 11h2M5.6 5.6l1.4 1.4M15 15l1.4 1.4M5.6 16.4 7 15M15 7l1.4-1.4"/><path d="M14 18l3 3 4-4-3-3"/></g></svg>);
    case 10: // LAUNCH — rocket
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M12 2c3 3 5 6.5 5 10v5l-3 2H10l-3-2v-5c0-3.5 2-7 5-10z"/><circle cx="12" cy="10" r="1.5" fill="currentColor"/><path d="M9 19c-1 1.5-1 3-1 3M15 19c1 1.5 1 3 1 3M7 14l-3 1 1 4 3-1M17 14l3 1-1 4-3-1"/></g></svg>);
    default: return null;
  }
}

/* ============================================================
   STEP TOOLBAR — bottom strip mirroring the in-app dock
   ============================================================ */

function StepToolbar({ step, onJump }: { step: number; onJump: (i: number) => void }) {
  return (
    <nav className="mt-6 panel relative overflow-hidden p-2">
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-20" />
      <div className="relative grid grid-cols-10 gap-1">
        {STEPS.map((s, i) => {
          const active = i === step;
          const done = i < step;
          return (
            <button
              key={s.id}
              onClick={() => onJump(i)}
              aria-label={`Go to step ${s.id}: ${s.tag.replace(/_/g, " ")}`}
              className={
                "relative grid place-items-center rounded-md py-2 transition " +
                (active
                  ? `bg-${s.accent}/15 text-${s.accent} shadow-[0_0_18px_-4px_currentColor]`
                  : done
                  ? `text-${s.accent}/70 hover:bg-${s.accent}/5`
                  : "text-muted-foreground/70 hover:text-foreground")
              }
            >
              {active && <span className={`absolute -top-0.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-${s.accent} pulse-dot`} />}
              <StepIcon n={s.id} className="h-5 w-5" />
              <span className="mt-0.5 text-[8px] tracking-widest">{String(s.id).padStart(2,"0")}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}


/* ===== Tailwind safelist — keep dynamic accent classes in the build =====
   text-cyan text-green text-magenta text-orange text-yellow
   bg-cyan bg-green bg-magenta bg-orange bg-yellow
   bg-cyan/5 bg-green/5 bg-magenta/5 bg-orange/5 bg-yellow/5
   bg-cyan/10 bg-green/10 bg-magenta/10 bg-orange/10 bg-yellow/10
   bg-cyan/20 bg-green/20 bg-magenta/20 bg-orange/20 bg-yellow/20
   border-cyan/40 border-green/40 border-magenta/40 border-orange/40 border-yellow/40
   border-cyan/50 border-green/50 border-magenta/50 border-orange/50 border-yellow/50
   border-cyan/60 border-green/60 border-magenta/60 border-orange/60 border-yellow/60
   glow-cyan glow-green glow-magenta glow-orange
   text-glow-cyan text-glow-green
   from-green via-cyan to-magenta
=========================================================================== */


```


### `/src/routes/intel.tsx`

```ts path=/src/routes/intel.tsx
import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/intel")({
  beforeLoad: () => {
    throw redirect({ to: "/knowledge", search: { tab: "intel" } as any });
  },
  component: () => null,
});

```


### `/src/routes/kb-growth.tsx`

```ts path=/src/routes/kb-growth.tsx
import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/kb-growth")({
  beforeLoad: () => {
    throw redirect({ to: "/knowledge", search: { tab: "growth" } as any });
  },
  component: () => null,
});

```


### `/src/routes/knowledge.tsx`

```ts path=/src/routes/knowledge.tsx
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import {
  Activity, Brain, Database, Network, Globe, BookOpen, Search, Layers,
  TrendingUp, BarChart3, Cpu, ShieldAlert, Gauge, Sparkles, Plus, Download, Trash2, Clock,
  Bot, Play, Pause, Zap, Radio, RefreshCw,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";
import { useTelemetry } from "@/lib/useTelemetry";
import { Sparkline } from "@/components/Sparkline";
import {
  AreaSparkline, MiniBarChart, ActivityBarChart, CircRing, StorageDonut,
  DiskProgressBar, MetricLineChart, DomainBreakdownChart, ThreatHeatmap,
} from "@/components/Charts";
import { kbGrowthTracker, METHOD_META } from "@/lib/kbGrowthTracker";
import { nexusBot, NEXUS_TARGETS, type Activity as BotActivity } from "@/lib/nexusBot";
import { toast } from "sonner";

export const Route = createFileRoute("/knowledge")({
  validateSearch: (s: Record<string, unknown>) => ({
    tab: typeof s.tab === "string" ? s.tab : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Knowledge Base — Butler AI" },
      { name: "description", content: "Φ-Nexus knowledge hub: live crawl, growth timeline, intel charts, neural graph, search." },
    ],
  }),
  component: KnowledgePage,
});


type TabKey =
  | "DASHBOARD" | "NEXUSBOT" | "GROWTH" | "INTEL" | "CRAWLER" | "GRAPH"
  | "SOURCES" | "LSCAN" | "SEARCH" | "EVENTS";

const TABS: Array<{ key: TabKey; label: string }> = [
  { key: "DASHBOARD", label: "DASHBOARD" },
  { key: "NEXUSBOT",  label: "NEXUSBOT"  },
  { key: "GROWTH",    label: "GROWTH"    },
  { key: "INTEL",     label: "INTEL"     },
  { key: "CRAWLER",   label: "CRAWLER"   },
  { key: "GRAPH",     label: "GRAPH"     },
  { key: "SOURCES",   label: "SOURCES"   },
  { key: "LSCAN",     label: "L-SCAN"    },
  { key: "SEARCH",    label: "SEARCH"    },
  { key: "EVENTS",    label: "EVENTS"    },
];

function useBot() {
  return useSyncExternalStore(
    (cb) => nexusBot.subscribe(cb),
    () => nexusBot.getState().cycles + nexusBot.getLog().length,
    () => 0,
  );
}

const SOURCES: Array<{ name: string; pct: number; color: "cyan" | "green" | "violet" | "amber" }> = [
  { name: "PYTHON.ORG",      pct: 92, color: "cyan"   },
  { name: "STACKOVERFLOW",   pct: 78, color: "green"  },
  { name: "GITHUB README",   pct: 64, color: "violet" },
  { name: "MDN WEB DOCS",    pct: 51, color: "amber"  },
  { name: "WIKIPEDIA · CS",  pct: 47, color: "cyan"   },
  { name: "ARCH WIKI",       pct: 43, color: "green"  },
  { name: "REDDIT · TECH",   pct: 39, color: "violet" },
  { name: "CVE · NVD",       pct: 31, color: "amber"  },
];


function useTracker() {
  return useSyncExternalStore(
    (cb) => kbGrowthTracker.subscribe(cb),
    () => kbGrowthTracker.getEventCount(),
    () => 0,
  );
}

function KnowledgePage() {
  useTracker();
  useBot();
  const search = Route.useSearch();
  const initialTab = useMemo<TabKey>(() => {
    const want = (search.tab ?? "").toUpperCase();
    const match = TABS.find((t) => t.key === want || t.label.replace(/-/g, "") === want);
    return (match?.key ?? "DASHBOARD") as TabKey;
  }, [search.tab]);
  const [tab, setTab] = useState<TabKey>(initialTab);
  useEffect(() => { setTab(initialTab); }, [initialTab]);
  const t = useTelemetry(2500);

  const articles = 18_472 + Math.floor(((t.cpu ?? 0) + (t.ram ?? 0)) * 3);
  const queue    = 14 + (Math.floor(t.cpu ?? 0) % 9);
  const workers  = 6;

  return (
    <AppShell active="knowledge">
      <PageTitle kicker="Φ-NEXUS · v5.0" title="KNOWLEDGE BASE" sub="CRAWL · INTEL · GRAPH · SEARCH" color="green" />

      {/* Functional tab strip */}
      <div className="-mx-1 mt-3 flex gap-1.5 overflow-x-auto px-1 pb-1"
           style={{ scrollbarWidth: "none" }}>
        {TABS.map((tb) => (
          <button key={tb.key}
            onClick={() => setTab(tb.key)}
            className="hex-tab shrink-0 px-3"
            data-active={tab === tb.key ? "true" : "false"}
            style={{ ["--c" as any]: "var(--green)" }}>
            <span className="font-display text-[9px] font-extrabold tracking-[0.22em]">{tb.label}</span>
          </button>
        ))}
      </div>

      <div className="mt-3 space-y-2.5">
        {tab === "DASHBOARD" && <DashboardView articles={articles} queue={queue} workers={workers} hist={t.history} uptime={t.uptime ?? 0} />}
        {tab === "NEXUSBOT"  && <NexusBotView />}
        {tab === "GROWTH"    && <GrowthView />}
        {tab === "INTEL"     && <IntelView t={t} />}
        {tab === "CRAWLER"   && <CrawlerView />}
        {tab === "GRAPH"     && <GraphView />}
        {tab === "SOURCES"   && <SourcesView />}
        {tab === "LSCAN"     && <LScanView />}
        {tab === "SEARCH"    && <SearchView />}
        {tab === "EVENTS"    && <EventsView />}
      </div>

      <div className="pt-3 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · KNOWLEDGE LATTICE · LOCAL-FIRST · 10-TAB HUB
      </div>
    </AppShell>
  );
}

/* ─── DASHBOARD ─── */
function DashboardView({ articles, queue, workers, hist, uptime }: { articles: number; queue: number; workers: number; hist: number[]; uptime: number }) {
  return (
    <>
      <div className="grid grid-cols-2 gap-2.5">
        <ThemedCard color="green" title="ARTICLES" icon={<BookOpen className="h-3.5 w-3.5" />}>
          <div className="font-display text-[26px] font-black leading-none">{articles.toLocaleString()}</div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">INDEXED · LOCAL DB</div>
        </ThemedCard>
        <ThemedCard color="cyan" title="QUEUE" icon={<Layers className="h-3.5 w-3.5" />}>
          <div className="font-display text-[26px] font-black leading-none">{queue}</div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">PENDING SHARDS</div>
        </ThemedCard>
        <ThemedCard color="violet" title="WORKERS" icon={<Brain className="h-3.5 w-3.5" />}>
          <div className="font-display text-[26px] font-black leading-none">{workers}</div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">PARALLEL · ASYNC</div>
        </ThemedCard>
        <ThemedCard color="amber" title="UPTIME" icon={<Activity className="h-3.5 w-3.5" />}>
          <div className="font-display text-[26px] font-black leading-none">{Math.floor(uptime / 60)}h</div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">SIGMANET STABLE</div>
        </ThemedCard>
      </div>
      <ThemedCard color="violet" title="NEXUS BOT · LIVE" icon={<Bot className="h-3.5 w-3.5" />}
        action={
          <Link to="/knowledge" search={{ tab: "NEXUSBOT" }}
            className="font-display text-[9px] font-extrabold tracking-widest text-[color:var(--magenta)]">OPEN →</Link>
        }>
        <div className="grid grid-cols-3 gap-2 font-mono text-[10px]">
          <div><div className="text-foreground/45">STATE</div><div className="font-display text-[14px] font-black" style={{ color: nexusBot.getState().running ? "var(--green)" : "var(--orange)" }}>{nexusBot.getState().running ? "ONLINE" : "PAUSED"}</div></div>
          <div><div className="text-foreground/45">CYCLES</div><div className="font-display text-[14px] font-black text-foreground">{nexusBot.getState().cycles}</div></div>
          <div><div className="text-foreground/45">FINDS</div><div className="font-display text-[14px] font-black text-[color:var(--green)]">+{nexusBot.getState().totalFindings}</div></div>
        </div>
      </ThemedCard>
      <ThemedCard color="green" title="GROWTH · LAST 24H" icon={<Activity className="h-3.5 w-3.5" />}>
        <Sparkline data={hist.length ? hist : [10, 14, 12, 18, 22, 19, 26, 31, 28, 34]} color="var(--green)" height={56} />
        <div className="mt-1 flex justify-between font-mono text-[9px] tracking-widest text-foreground/55">
          <span>+{Math.floor(articles * 0.012)} TODAY</span>
          <span>STREAK · {kbGrowthTracker.getStreakDays()}d</span>
        </div>
      </ThemedCard>
    </>
  );
}

/* ─── GROWTH (was kb-growth) ─── */
function GrowthView() {
  const [hoursIdx, setHoursIdx] = useState(1);
  const opts = [{ h: 4, l: "4H", b: 16 }, { h: 24, l: "24H", b: 24 }, { h: 72, l: "3D", b: 36 }, { h: 168, l: "7D", b: 28 }];
  const cfg = opts[hoursIdx];
  const buckets = useMemo(
    () => kbGrowthTracker.getChartData(cfg.h, Math.ceil((cfg.h * 60) / cfg.b)),
    [hoursIdx, kbGrowthTracker.getEventCount()],
  );
  const total = kbGrowthTracker.getTotalCount();
  const delta = buckets.reduce((s, b) => s + b.delta, 0);
  const peak = buckets.reduce((m, b) => Math.max(m, b.delta), 0);
  const methods = kbGrowthTracker.getMethodBreakdown();

  const onSeed = () => {
    const m = ["sigma", "omega", "crawler", "ncx", "lambda"];
    kbGrowthTracker.record(1 + Math.floor(Math.random() * 8), m[Math.floor(Math.random() * m.length)], ["Python", "Security", "PCHelp"][Math.floor(Math.random() * 3)]);
  };

  return (
    <>
      <div className="flex gap-1.5">
        {opts.map((o, i) => (
          <button key={o.l} onClick={() => setHoursIdx(i)} className="hex-tab flex-1 px-2"
            data-active={i === hoursIdx ? "true" : "false"} style={{ ["--c" as any]: "var(--orange)" }}>
            <span className="font-display text-[9px] font-extrabold tracking-[0.22em]">{o.l}</span>
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        <ThemedCard color="amber" title="TOTAL" icon={<Database className="h-3.5 w-3.5" />}>
          <div className="font-display text-[24px] font-black leading-none">{total.toLocaleString()}</div>
        </ThemedCard>
        <ThemedCard color="green" title={`+ ${cfg.l}`} icon={<TrendingUp className="h-3.5 w-3.5" />}>
          <div className="font-display text-[24px] font-black leading-none" style={{ color: delta > 0 ? "var(--green)" : undefined }}>
            {delta > 0 ? `+${delta}` : "idle"}
          </div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">PEAK · {peak}</div>
        </ThemedCard>
      </div>
      <ThemedCard color="cyan" title="TIMELINE" icon={<BarChart3 className="h-3.5 w-3.5" />}>
        <MiniBarChart data={buckets.map((b) => ({ day: b.label, value: b.delta }))} color="var(--cyan)" label={`bucket Δ · ${cfg.l}`} />
      </ThemedCard>
      <ThemedCard color="violet" title="METHODS" icon={<Sparkles className="h-3.5 w-3.5" />}>
        <div className="space-y-1.5">
          {Object.entries(methods).length === 0 && (
            <div className="font-mono text-[10px] text-foreground/45">No events yet — tap SEED below.</div>
          )}
          {Object.entries(methods).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => {
            const m = METHOD_META[k] ?? { label: k.toUpperCase(), color: "var(--cyan)", desc: "" };
            const max = Math.max(...Object.values(methods), 1);
            return (
              <div key={k}>
                <div className="flex justify-between font-mono text-[10px]">
                  <span style={{ color: m.color }}>{m.label}</span>
                  <span className="text-foreground/70">{v}</span>
                </div>
                <div className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-[color:var(--surface)]">
                  <div className="h-full rounded-full" style={{ width: `${(v / max) * 100}%`, background: m.color, boxShadow: `0 0 6px ${m.color}` }} />
                </div>
              </div>
            );
          })}
        </div>
      </ThemedCard>
      <div className="flex gap-1.5">
        <button onClick={onSeed} className="panel-cyber lift flex-1 px-3 py-2 font-display text-[10px] font-extrabold tracking-[0.2em]" style={{ ["--c" as any]: "var(--green)" }}>
          <Plus className="mr-1 inline h-3 w-3" /> SEED
        </button>
        <button onClick={() => {
          const blob = new Blob([kbGrowthTracker.export()], { type: "application/json" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url; a.download = `kb-growth-${Date.now()}.json`; a.click();
          URL.revokeObjectURL(url);
        }} className="panel-cyber lift flex-1 px-3 py-2 font-display text-[10px] font-extrabold tracking-[0.2em]" style={{ ["--c" as any]: "var(--cyan)" }}>
          <Download className="mr-1 inline h-3 w-3" /> EXPORT
        </button>
        <button onClick={() => { if (confirm("Clear?")) kbGrowthTracker.clear(); }} className="panel-cyber lift flex-1 px-3 py-2 font-display text-[10px] font-extrabold tracking-[0.2em]" style={{ ["--c" as any]: "var(--red)" }}>
          <Trash2 className="mr-1 inline h-3 w-3" /> CLEAR
        </button>
      </div>
    </>
  );
}

/* ─── INTEL (was /intel) ─── */
function IntelView({ t }: { t: ReturnType<typeof useTelemetry> }) {
  const cpu = Math.round(t.cpu ?? 0);
  const ram = Math.round(t.ram ?? 0);
  const disk = 47;
  const hist = t.history.length ? t.history : [12, 18, 14, 22, 26, 21, 30, 28, 34, 31, 38, 42, 36, 44, 48];
  return (
    <>
      <ThemedCard color="cyan" title="LIVE VITALS" icon={<Gauge className="h-3.5 w-3.5" />}>
        <div className="grid grid-cols-3 place-items-center gap-1">
          <CircRing label="CPU" pct={cpu} color="var(--cyan)" />
          <CircRing label="RAM" pct={ram} color="var(--orange)" />
          <CircRing label="DISK" pct={disk} color="var(--magenta)" />
        </div>
        <div className="mt-3 space-y-1.5">
          <DiskProgressBar label="CPU" pct={cpu} color="var(--cyan)" />
          <DiskProgressBar label="RAM" pct={ram} color="var(--orange)" />
          <DiskProgressBar label="DISK" pct={disk} color="var(--magenta)" />
        </div>
      </ThemedCard>
      <ThemedCard color="cyan" title="CPU LINE" icon={<Cpu className="h-3.5 w-3.5" />}>
        <MetricLineChart history={hist} color="var(--cyan)" label="cpu" />
      </ThemedCard>
      <ThemedCard color="violet" title="ACTIVITY · 12 BUCKETS" icon={<BarChart3 className="h-3.5 w-3.5" />}>
        <ActivityBarChart />
      </ThemedCard>
      <ThemedCard color="green" title="STORAGE" icon={<Database className="h-3.5 w-3.5" />}>
        <StorageDonut label="1.2TB" sub="USED" slices={[
          { color: "var(--cyan)", pct: 28, label: "SYS" },
          { color: "var(--orange)", pct: 22, label: "DATA" },
          { color: "var(--magenta)", pct: 14, label: "APPS" },
        ]} />
      </ThemedCard>
      <ThemedCard color="cyan" title="AREA SPARK" icon={<Activity className="h-3.5 w-3.5" />}>
        <AreaSparkline points={hist} color="var(--cyan)" height={64} />
      </ThemedCard>
    </>
  );
}

/* ─── NEXUSBOT ─── */
function NexusBotView() {
  const s = nexusBot.getState();
  const log = nexusBot.getLog().slice(0, 18);
  const snippets = nexusBot.getSnippets().slice(0, 6);
  const upMs = s.bootedAt ? Date.now() - s.bootedAt : 0;
  const upMin = Math.floor(upMs / 60000);
  const lastAgo = s.lastCycleAt ? Math.floor((Date.now() - s.lastCycleAt) / 1000) : null;

  const fire = async (kind: "sigma" | "omega" | "lambda" | "rss" | "once") => {
    const fn = kind === "sigma" ? nexusBot.runSigma
            : kind === "omega" ? nexusBot.runOmega
            : kind === "lambda" ? nexusBot.runLambda
            : kind === "rss"   ? nexusBot.runRSS
            : nexusBot.runOnce;
    const added = await fn.call(nexusBot);
    toast.success(`${kind.toUpperCase()} · +${added} findings`);
  };

  return (
    <>
      <ThemedCard color="violet" title="NEXUS BOT · AUTOPILOT" icon={<Bot className="h-3.5 w-3.5" />}
        action={
          <button
            onClick={() => { if (s.running) nexusBot.stop(); else nexusBot.start(); }}
            className="rounded-sm border border-[color:var(--border)] bg-[var(--ink)] px-2 py-0.5 font-mono text-[9px] tracking-widest"
            style={{ color: s.running ? "var(--green)" : "var(--orange)" }}>
            {s.running ? <><Pause className="mr-1 inline h-2.5 w-2.5" />RUNNING</> : <><Play className="mr-1 inline h-2.5 w-2.5" />PAUSED</>}
          </button>
        }>
        <div className="grid grid-cols-4 gap-2 font-mono text-[10px]">
          <div><div className="text-foreground/45">CYCLES</div><div className="font-display text-[16px] font-black text-foreground">{s.cycles}</div></div>
          <div><div className="text-foreground/45">FINDS</div><div className="font-display text-[16px] font-black text-[color:var(--green)]">{s.totalFindings}</div></div>
          <div><div className="text-foreground/45">FAIL</div><div className="font-display text-[16px] font-black text-[color:var(--orange)]">{s.totalFailed}</div></div>
          <div><div className="text-foreground/45">UP</div><div className="font-display text-[16px] font-black text-[color:var(--cyan)]">{upMin}m</div></div>
        </div>
        <div className="mt-2 font-mono text-[9px] tracking-widest text-foreground/50">
          {lastAgo == null ? "boot pending…" : `last cycle · ${lastAgo}s ago · cursor ${s.cursor}/${NEXUS_TARGETS.length}`}
        </div>
      </ThemedCard>

      <ThemedCard color="cyan" title="MANUAL TRIGGERS" icon={<Zap className="h-3.5 w-3.5" />}>
        <div className="grid grid-cols-5 gap-1.5">
          {(["sigma","omega","lambda","rss","once"] as const).map((k) => (
            <button key={k} onClick={() => void fire(k)}
              className="panel-cyber lift py-1.5 font-display text-[8.5px] font-extrabold tracking-[0.18em]"
              style={{ ["--c" as any]: k === "omega" ? "var(--magenta)" : k === "lambda" ? "var(--orange)" : k === "rss" ? "var(--green)" : "var(--cyan)" }}>
              {k === "sigma" ? "Σ" : k === "omega" ? "Ω" : k === "lambda" ? "λ" : k === "rss" ? "RSS" : "TICK"}
            </button>
          ))}
        </div>
        <div className="mt-1 font-mono text-[8.5px] tracking-widest text-foreground/40">
          ΣNET crawl · ΩLOOP expansion · λEDGE harvest · RSS delta · TICK = one cycle
        </div>
      </ThemedCard>

      <ThemedCard color="green" title={`LIVE BOT LOG · ${log.length}`} icon={<Radio className="h-3.5 w-3.5" />}>
        <div className="max-h-[36vh] space-y-1 overflow-y-auto pr-1">
          {log.length === 0 && <div className="font-mono text-[10px] text-foreground/45">Bot booting…</div>}
          {log.map((e, i) => (
            <BotLogRow key={i} e={e} />
          ))}
        </div>
      </ThemedCard>

      <ThemedCard color="amber" title={`RECENT HARVEST · ${snippets.length}`} icon={<BookOpen className="h-3.5 w-3.5" />}>
        <div className="space-y-1.5">
          {snippets.length === 0 && <div className="font-mono text-[10px] text-foreground/45">No snippets yet — trigger SIGMA above.</div>}
          {snippets.map((s, i) => (
            <div key={i} className="rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5">
              <div className="flex items-center justify-between font-display text-[9px] font-extrabold tracking-widest">
                <span className="text-[color:var(--cyan)]">{s.domain}/{s.topic}</span>
                <span className="text-foreground/45">{new Date(s.ts).toLocaleTimeString()}</span>
              </div>
              <div className="mt-0.5 font-mono text-[10px] text-foreground/80 line-clamp-2">{s.text}</div>
            </div>
          ))}
        </div>
      </ThemedCard>

      <button onClick={() => { if (confirm("Reset NEXUS BOT state?")) { nexusBot.reset(); toast.success("Bot reset"); } }}
        className="panel-cyber lift w-full px-3 py-2 font-display text-[10px] font-extrabold tracking-[0.22em]"
        style={{ ["--c" as any]: "var(--red)" }}>
        <RefreshCw className="mr-1 inline h-3 w-3" /> RESET BOT
      </button>
    </>
  );
}

function BotLogRow({ e }: { e: BotActivity }) {
  const color = e.type === "error" ? "var(--red)"
              : e.type === "omega" ? "var(--magenta)"
              : e.type === "lambda" ? "var(--orange)"
              : e.type === "rss"   ? "var(--green)"
              : e.type === "context" ? "var(--cyan)"
              : e.type === "boot"  ? "var(--foreground)"
              : "var(--cyan)";
  return (
    <div className="flex items-center justify-between rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="font-display text-[8.5px] font-extrabold tracking-widest" style={{ color }}>{e.type.toUpperCase()}</span>
          <span className="font-mono text-[8.5px] tracking-widest text-foreground/40">{new Date(e.ts).toLocaleTimeString()}</span>
        </div>
        <div className="truncate font-mono text-[10px] text-foreground/80">{e.msg}</div>
      </div>
      {e.added != null && <span className="font-display text-[12px] font-black text-[color:var(--green)]">+{e.added}</span>}
    </div>
  );
}

/* ─── CRAWLER (live NexusBot targets) ─── */
function CrawlerView() {
  const s = nexusBot.getState();
  return (
    <>
      <ThemedCard color="cyan" title="NEXUS CRAWLER" icon={<Globe className="h-3.5 w-3.5" />}
        action={
          <Link to="/knowledge" search={{ tab: "NEXUSBOT" }}
            className="rounded-sm border border-[color:var(--border)] bg-[var(--ink)] px-2 py-0.5 font-mono text-[9px] tracking-widest"
            style={{ color: s.running ? "var(--green)" : "var(--orange)" }}>
            {s.running ? "● BOT RUNNING" : "◌ BOT PAUSED"}
          </Link>
        }>
        <div className="grid grid-cols-4 gap-2 font-mono text-[10px]">
          <div><div className="text-foreground/45">TARGETS</div><div className="font-display text-[16px] font-black text-foreground">{NEXUS_TARGETS.length}</div></div>
          <div><div className="text-foreground/45">CRAWLED</div><div className="font-display text-[16px] font-black text-[color:var(--green)]">{s.totalCrawled}</div></div>
          <div><div className="text-foreground/45">FINDS</div><div className="font-display text-[16px] font-black text-[color:var(--cyan)]">{s.totalFindings}</div></div>
          <div><div className="text-foreground/45">FAIL</div><div className="font-display text-[16px] font-black text-[color:var(--orange)]">{s.totalFailed}</div></div>
        </div>
      </ThemedCard>
      <ThemedCard color="green" title={`ACTIVE TARGETS · ${NEXUS_TARGETS.length}`} icon={<Layers className="h-3.5 w-3.5" />}>
        <div className="max-h-[50vh] space-y-1 overflow-y-auto pr-1">
          {NEXUS_TARGETS.map((d, i) => {
            const active = (i % NEXUS_TARGETS.length) === s.cursor;
            const c = active ? "var(--green)" : "var(--cyan)";
            return (
              <div key={d.id} className="flex items-center justify-between rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5">
                <div className="min-w-0 flex-1">
                  <div className="truncate font-mono text-[10.5px] text-foreground/90">{d.domain} · {d.topic}</div>
                  <div className="truncate font-mono text-[8.5px] tracking-widest text-foreground/45">{d.url.replace(/^https?:\/\//, "")}</div>
                </div>
                <div className="ml-2 text-right">
                  <div className="font-display text-[9px] font-extrabold tracking-widest" style={{ color: c }}>{active ? "ACTIVE" : "QUEUED"}</div>
                  <div className="font-mono text-[8.5px] tracking-widest text-foreground/45">p{d.priority} · {(d.confidence * 100).toFixed(0)}%</div>
                </div>
              </div>
            );
          })}
        </div>
      </ThemedCard>
    </>
  );
}

/* ─── GRAPH ─── */
function GraphView() {
  return (
    <ThemedCard color="violet" title="NEURAL GRAPH" icon={<Network className="h-3.5 w-3.5" />}>
      <div className="relative h-64 overflow-hidden rounded border border-[color:var(--border)] bg-[var(--ink)]">
        <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full">
          {Array.from({ length: 36 }).map((_, i) => {
            const x = 10 + ((i * 23) % 180);
            const y = 10 + ((i * 47) % 180);
            return <circle key={i} cx={x} cy={y} r="2.5" fill="var(--magenta)"
              style={{ filter: "drop-shadow(0 0 4px var(--magenta))" }}>
              <animate attributeName="r" values="2;3.5;2" dur={`${2 + (i % 4) * 0.3}s`} repeatCount="indefinite" />
            </circle>;
          })}
          {Array.from({ length: 28 }).map((_, i) => {
            const x1 = 10 + ((i * 23) % 180), y1 = 10 + ((i * 47) % 180);
            const x2 = 10 + (((i + 3) * 23) % 180), y2 = 10 + (((i + 3) * 47) % 180);
            return <line key={`l${i}`} x1={x1} y1={y1} x2={x2} y2={y2}
              stroke="var(--cyan)" strokeOpacity="0.3" strokeWidth="0.5" />;
          })}
        </svg>
      </div>
      <div className="mt-1.5 flex justify-between font-mono text-[9px] tracking-widest text-foreground/55">
        <span>NODES · 1,284</span><span>EDGES · 3,917</span><span>COMM · 18</span>
      </div>
    </ThemedCard>
  );
}

/* ─── SOURCES ─── */
function SourcesView() {
  return (
    <ThemedCard color="cyan" title="TOP SOURCES · CONFIDENCE" icon={<Globe className="h-3.5 w-3.5" />}>
      <div className="space-y-2">
        {SOURCES.map((s) => {
          const c = s.color === "violet" ? "var(--magenta)" : s.color === "amber" ? "var(--orange)" : `var(--${s.color})`;
          return (
            <div key={s.name}>
              <div className="flex justify-between font-mono text-[10px]">
                <span className="text-foreground/80">{s.name}</span>
                <span style={{ color: c }}>{s.pct}%</span>
              </div>
              <div className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-[color:var(--surface)]">
                <div className="h-full rounded-full" style={{ width: `${s.pct}%`, background: c, boxShadow: `0 0 8px ${c}` }} />
              </div>
            </div>
          );
        })}
      </div>
    </ThemedCard>
  );
}

/* ─── L-SCAN (threat heatmap) ─── */
function LScanView() {
  return (
    <>
      <ThemedCard color="red" title="THREAT HEATMAP" icon={<ShieldAlert className="h-3.5 w-3.5" />}>
        <ThreatHeatmap />
      </ThemedCard>
      <ThemedCard color="amber" title="CATEGORY RISK" icon={<Layers className="h-3.5 w-3.5" />}>
        <div className="space-y-2">
          {[
            { label: "SECURITY", color: "var(--red)",     pct: 82 },
            { label: "FILES",    color: "var(--green)",   pct: 68 },
            { label: "NETWORK",  color: "var(--orange)",  pct: 55 },
            { label: "PRIVACY",  color: "var(--magenta)", pct: 44 },
            { label: "SYSTEM",   color: "var(--cyan)",    pct: 31 },
          ].map((c) => (
            <div key={c.label}>
              <div className="flex justify-between font-mono text-[10px]">
                <span className="text-foreground/80">{c.label}</span>
                <span style={{ color: c.color }}>{c.pct}%</span>
              </div>
              <div className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-[color:var(--surface)]">
                <div className="h-full rounded-full" style={{ width: `${c.pct}%`, background: c.color, boxShadow: `0 0 8px ${c.color}` }} />
              </div>
            </div>
          ))}
        </div>
      </ThemedCard>
    </>
  );
}

/* ─── SEARCH ─── */
function SearchView() {
  const [q, setQ] = useState("");
  const HITS = ["asyncio gather pattern", "regex windows path", "CVE-2026-1142 mitigation", "systemd-resolved DNS", "PEP-704 type guards", "Fetch API streaming"];
  const filtered = q ? HITS.filter((h) => h.toLowerCase().includes(q.toLowerCase())) : HITS;
  return (
    <>
      <ThemedCard color="cyan" title="ASK THE KB" icon={<Search className="h-3.5 w-3.5" />}>
        <div className="flex items-center gap-2 rounded-md border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5">
          <Search className="h-3.5 w-3.5 text-foreground/40" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ask the knowledge base…"
            className="flex-1 bg-transparent font-mono text-[11px] text-foreground placeholder:text-foreground/30 focus:outline-none"
          />
          <kbd className="font-mono text-[9px] tracking-widest text-foreground/40">⏎</kbd>
        </div>
      </ThemedCard>
      <ThemedCard color="green" title={`HITS · ${filtered.length}`} icon={<BookOpen className="h-3.5 w-3.5" />}>
        <div className="space-y-1">
          {filtered.map((h, i) => (
            <Link key={i} to="/ai" className="block rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5 font-mono text-[10.5px] text-foreground/85 hover:border-[color:var(--cyan)] hover:text-[color:var(--cyan)]">
              {h}
            </Link>
          ))}
        </div>
      </ThemedCard>
    </>
  );
}

/* ─── EVENTS ─── */
function EventsView() {
  const events = kbGrowthTracker.getRecentEvents(40);
  return (
    <ThemedCard color="amber" title={`EVENT LOG · ${events.length}`} icon={<Clock className="h-3.5 w-3.5" />}>
      <div className="max-h-[60vh] space-y-1 overflow-y-auto pr-1">
        {events.length === 0 && <div className="font-mono text-[10px] text-foreground/45">No events recorded yet. Run the crawler or seed from Growth tab.</div>}
        {events.map((e, i) => {
          const m = METHOD_META[e.method] ?? { label: e.method, color: "var(--cyan)", desc: "" };
          return (
            <div key={i} className="flex items-center justify-between rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="font-display text-[9px] font-extrabold tracking-widest" style={{ color: m.color }}>{m.label}</span>
                  {e.domain && <span className="font-mono text-[9px] tracking-widest text-foreground/55">· {e.domain}</span>}
                </div>
                <div className="font-mono text-[8.5px] tracking-widest text-foreground/40">{new Date(e.ts).toLocaleString()}</div>
              </div>
              <span className="font-display text-[14px] font-black text-[color:var(--green)]">+{e.count}</span>
            </div>
          );
        })}
      </div>
    </ThemedCard>
  );
}

```


### `/src/routes/legal.delete.tsx`

```ts path=/src/routes/legal.delete.tsx
import { createFileRoute } from "@tanstack/react-router";
import { LegalShell, LegalSection } from "@/components/LegalShell";
import { Trash2, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/legal/delete")({
  head: () => ({
    meta: [
      { title: "Delete My Data — Butler AI" },
      { name: "description", content: "Wipe every byte Butler AI stores. Three taps. Irreversible." },
    ],
  }),
  component: DeletePage,
});

function DeletePage() {
  return (
    <LegalShell
      title="Delete My Data"
      accent="red"
      emoji="🗑️"
      headline="Three taps · immediate · irreversible · no cloud backup"
      badges={[
        { label: "PHONE STORAGE",    tone: "red"    },
        { label: "PAIRING SECRET",   tone: "red"    },
        { label: "KB CACHE",         tone: "orange" },
        { label: "UI PREFERENCES",   tone: "orange" },
      ]}
    >
      <LegalSection title="HOW TO DELETE EVERYTHING" tone="red">
        <ol className="list-decimal space-y-2 pl-5">
          <li>Open the app and tap <strong>Settings</strong>.</li>
          <li>Scroll to the bottom and tap <strong className="text-red">DELETE ALL MY DATA</strong>.</li>
          <li>Confirm twice. The app wipes itself and closes.</li>
        </ol>
        <div className="mt-3 flex items-start gap-2 rounded-md border border-red/60 bg-red/5 p-3 text-[12px] text-red">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>This action is <strong>permanent and irreversible</strong>. There is no cloud backup to restore from.</span>
        </div>
      </LegalSection>

      <LegalSection title="WHAT GETS WIPED ON YOUR PHONE" tone="orange">
        <ul className="list-disc space-y-1 pl-5">
          <li>Device UUID</li>
          <li>Pairing secret (Android Keystore entry)</li>
          <li>Paired-PC IP and metadata</li>
          <li>UI preferences (theme, language, layout)</li>
          <li>Knowledge-base cache and undo log mirror</li>
        </ul>
      </LegalSection>

      <LegalSection title="REMOVING SERVER DATA ON YOUR PC" tone="cyan">
        <p>Butler runs locally on your PC. To remove the server-side data:</p>
        <ol className="list-decimal space-y-1 pl-5">
          <li>Stop <code>butler_server.py</code>.</li>
          <li>Delete the <code>butler.db</code> SQLite file.</li>
          <li>Run the PC uninstaller, or manually remove the install directory.</li>
        </ol>
      </LegalSection>

      <LegalSection title="ALREADY UNINSTALLED?" tone="green">
        <p>Uninstalling the Android app already wipes everything stored on the phone. No further action is needed on our side because no data is held off-device.</p>
      </LegalSection>

      <div className="grid place-items-center pt-4">
        <div className="panel-cyber inline-flex items-center gap-2 rounded-full border border-red/60 px-5 py-2.5 text-xs font-extrabold tracking-widest text-red glow-orange">
          <Trash2 className="h-4 w-4" /> DELETE FLOW IS IN THE APP — NOT HERE
        </div>
      </div>
    </LegalShell>
  );
}

```


### `/src/routes/legal.privacy.tsx`

```ts path=/src/routes/legal.privacy.tsx
import { createFileRoute } from "@tanstack/react-router";
import { LegalShell, LegalSection } from "@/components/LegalShell";

export const Route = createFileRoute("/legal/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Butler AI" },
      { name: "description", content: "Zero data collection. No cloud servers. LAN-only operation. Open-source server." },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <LegalShell
      title="Privacy Policy"
      accent="cyan"
      emoji="🔒"
      headline="Butler AI Automation · Android App · Effective April 1, 2026"
      badges={[
        { label: "ZERO DATA COLLECTION", tone: "green" },
        { label: "NO CLOUD SERVERS",     tone: "green" },
        { label: "LAN ONLY",             tone: "cyan"  },
        { label: "NO ACCOUNTS",          tone: "cyan"  },
        { label: "CAMERA: QR SCAN ONLY", tone: "orange"},
        { label: "OPEN SOURCE SERVER",   tone: "cyan"  },
      ]}
    >
      <LegalSection title="01 · SUMMARY" tone="green">
        <p>Butler AI is a self-hosted remote PC controller. The Android app talks to a Python server running on <em>your own</em> PC over your local Wi-Fi.</p>
        <p>We collect <strong>zero personal data</strong>. There are no servers we run, no telemetry, no analytics, no ads, no accounts, and no cloud relay of any kind.</p>
      </LegalSection>

      <LegalSection title="02 · WHAT IS STORED LOCALLY" tone="cyan">
        <ul className="list-disc space-y-1 pl-5">
          <li><strong>Device UUID</strong> — a random identifier generated on first launch, used only to remember your paired PC. Never leaves the device.</li>
          <li><strong>Pairing secret</strong> — HMAC-SHA256 shared key set during setup. Stored in Android Keystore.</li>
          <li><strong>Server IP / LAN address</strong> — so we can reconnect to your PC.</li>
          <li><strong>UI preferences</strong> — theme, language, layout.</li>
        </ul>
      </LegalSection>

      <LegalSection title="03 · WHAT WE NEVER COLLECT" tone="orange">
        <ul className="list-disc space-y-1 pl-5">
          <li>Names, emails, phone numbers, addresses, payment info.</li>
          <li>Contacts, calendar, SMS, call logs, browser history.</li>
          <li>Location (precise or coarse).</li>
          <li>Script source, script outputs, file names, or any PC content.</li>
          <li>Photos, videos, microphone audio, or biometric data.</li>
          <li>Crash reports or analytics events.</li>
        </ul>
      </LegalSection>

      <LegalSection title="04 · CAMERA" tone="orange">
        <p>The camera is used <strong>only</strong> to scan a one-time pairing QR code shown on your PC. The frame buffer is never recorded, never written to disk, and never transmitted. You can pair manually by typing the IP instead.</p>
      </LegalSection>

      <LegalSection title="05 · NETWORK" tone="cyan">
        <p>The app communicates exclusively with your own PC over your local Wi-Fi (e.g. <code>192.168.x.x</code>). It does not contact any other host. Every request is signed with HMAC-SHA256 and rejected on tamper or replay.</p>
      </LegalSection>

      <LegalSection title="06 · YOUR RIGHTS" tone="green">
        <p>You can wipe everything at any time via <strong>Settings → DELETE ALL MY DATA</strong>. There is no cloud backup to request, export, or delete — there is no cloud.</p>
      </LegalSection>

      <LegalSection title="07 · CONTACT" tone="cyan">
        <p>Source: <a className="text-cyan underline" href="https://github.com/shawnjan-cmd/CommandCube" target="_blank" rel="noreferrer">github.com/shawnjan-cmd/CommandCube</a></p>
      </LegalSection>
    </LegalShell>
  );
}

```


### `/src/routes/legal.safety.tsx`

```ts path=/src/routes/legal.safety.tsx
import { createFileRoute } from "@tanstack/react-router";
import { LegalShell, LegalSection } from "@/components/LegalShell";

export const Route = createFileRoute("/legal/safety")({
  head: () => ({
    meta: [
      { title: "Data Safety — Butler AI" },
      { name: "description", content: "What is collected, what is shared, what is encrypted. The honest one-page truth." },
    ],
  }),
  component: SafetyPage,
});

function SafetyPage() {
  return (
    <LegalShell
      title="Data Safety"
      accent="green"
      emoji="🛡️"
      headline="The honest one-page truth · audit-friendly"
      badges={[
        { label: "DATA COLLECTED · NONE", tone: "green"  },
        { label: "DATA SHARED · NONE",    tone: "green"  },
        { label: "ENCRYPTED IN TRANSIT",  tone: "cyan"   },
        { label: "DELETE IN 3 TAPS",      tone: "orange" },
      ]}
    >
      <LegalSection title="DATA TYPES COLLECTED" tone="green">
        <p className="font-bold text-green">None.</p>
        <p>Butler AI does not collect any of the data categories defined in Google Play's Data Safety form: personal info, financial info, health/fitness, messages, photos/videos, audio, files/docs, calendar, contacts, app activity, web history, device IDs, or installed apps.</p>
      </LegalSection>

      <LegalSection title="DATA SHARED WITH THIRD PARTIES" tone="green">
        <p className="font-bold text-green">None.</p>
        <p>No analytics SDKs. No advertising SDKs. No crash reporters. No social SDKs. No third-party servers are contacted, ever.</p>
      </LegalSection>

      <LegalSection title="ENCRYPTION" tone="cyan">
        <ul className="list-disc space-y-1 pl-5">
          <li><strong>In transit:</strong> every command is HMAC-SHA256 signed with your pairing secret.</li>
          <li><strong>At rest:</strong> pairing secret stored in Android Keystore (hardware-backed where available).</li>
          <li><strong>Replay protection:</strong> timestamp window rejects re-played requests.</li>
        </ul>
      </LegalSection>

      <LegalSection title="DATA DELETION" tone="orange">
        <p>Three taps in <strong>Settings → DELETE ALL MY DATA</strong> wipes the device UUID, pairing secret, preferences, and KB cache. Server data lives on your PC and is removed by the PC uninstaller.</p>
      </LegalSection>

      <LegalSection title="OPEN-SOURCE SERVER" tone="cyan">
        <p>The PC server is open source so anyone can audit what runs on their machine: <a className="text-cyan underline" href="https://github.com/shawnjan-cmd/CommandCube" target="_blank" rel="noreferrer">github.com/shawnjan-cmd/CommandCube</a></p>
      </LegalSection>
    </LegalShell>
  );
}

```


### `/src/routes/legal.terms.tsx`

```ts path=/src/routes/legal.terms.tsx
import { createFileRoute } from "@tanstack/react-router";
import { LegalShell, LegalSection } from "@/components/LegalShell";

export const Route = createFileRoute("/legal/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service — Butler AI" },
      { name: "description", content: "Adult developer tool for personal PC automation. Lawful use only. No unauthorised access." },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <LegalShell
      title="Terms of Service"
      accent="yellow"
      emoji="⚖️"
      headline="Butler AI Automation · Android App · Effective April 1, 2026"
      badges={[
        { label: "18+ ONLY",          tone: "orange" },
        { label: "PERSONAL PCs ONLY", tone: "yellow" },
        { label: "NO MALWARE",        tone: "red"    },
        { label: "NO SURVEILLANCE",   tone: "red"    },
        { label: "LAWFUL USE",        tone: "green"  },
      ]}
    >
      <LegalSection title="01 · WHO MAY USE BUTLER AI" tone="orange">
        <p>You must be at least 18 years old. Butler AI is a developer tool that executes Python on your PC; it is not designed for minors.</p>
      </LegalSection>

      <LegalSection title="02 · ACCEPTABLE USE" tone="yellow">
        <ul className="list-disc space-y-1 pl-5">
          <li>Use Butler AI only on PCs you own, or PCs you are explicitly authorised to control.</li>
          <li>You are responsible for every script you choose to execute.</li>
          <li>Comply with the laws of your jurisdiction.</li>
        </ul>
      </LegalSection>

      <LegalSection title="03 · PROHIBITED USE" tone="red">
        <ul className="list-disc space-y-1 pl-5">
          <li>No unauthorised access to other people's computers, networks, or accounts.</li>
          <li>No malware, ransomware, crypto-miners, keyloggers, or destructive payloads.</li>
          <li>No surveillance or privacy violations of other people.</li>
          <li>No attempts to bypass the malicious-script shield.</li>
        </ul>
      </LegalSection>

      <LegalSection title="04 · NO WARRANTY" tone="cyan">
        <p>Butler AI and the included server are provided "as is", without warranty of any kind. You assume all risk of running scripts on your own hardware.</p>
      </LegalSection>

      <LegalSection title="05 · LIABILITY" tone="cyan">
        <p>To the maximum extent permitted by law, the developer is not liable for any damages arising from your use or misuse of Butler AI.</p>
      </LegalSection>

      <LegalSection title="06 · CHANGES" tone="green">
        <p>If these terms change, the new version takes effect when the app prompts you to re-accept on next launch. Continued use after re-acceptance constitutes agreement.</p>
      </LegalSection>
    </LegalShell>
  );
}

```


### `/src/routes/legal.tsx`

```ts path=/src/routes/legal.tsx
import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/legal")({
  component: () => <Outlet />,
});

```


### `/src/routes/nexus.tsx`

```ts path=/src/routes/nexus.tsx
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Plug, LayoutGrid, BookOpen, TerminalSquare, Folder, Bot,
  Sparkles, Brain, Workflow, Antenna, Settings,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ConnectionTab } from "@/components/nexus/tabs/ConnectionTab";
import { DashboardTab } from "@/components/nexus/tabs/DashboardTab";
import { KbTab } from "@/components/nexus/tabs/KbTab";
import { FilesTab } from "@/components/nexus/tabs/FilesTab";
import { SettingsTab } from "@/components/nexus/tabs/SettingsTab";
import { PlaceholderTab } from "@/components/nexus/tabs/PlaceholderTab";
import { AiChatTab } from "@/components/nexus/tabs/AiChatTab";

export const Route = createFileRoute("/nexus")({
  head: () => ({
    meta: [
      { title: "NEXUS · Command Center — Butler AI" },
      { name: "description", content: "Full Nexus cyberpunk command center: dashboards, AI chat, KB graph, files, terminal, and settings." },
    ],
  }),
  component: NexusPage,
});

type TabId =
  | "connection" | "dashboard" | "scripts" | "terminal" | "files" | "aichat"
  | "builder" | "kb" | "flows" | "network" | "settings";

const TABS: { id: TabId; label: string; Icon: LucideIcon }[] = [
  { id: "connection", label: "CONN",   Icon: Plug },
  { id: "dashboard",  label: "DASH",   Icon: LayoutGrid },
  { id: "scripts",    label: "SCRIPT", Icon: BookOpen },
  { id: "terminal",   label: "TERM",   Icon: TerminalSquare },
  { id: "files",      label: "FILES",  Icon: Folder },
  { id: "aichat",     label: "AI",     Icon: Bot },
  { id: "builder",    label: "BUILD",  Icon: Sparkles },
  { id: "kb",         label: "KB",     Icon: Brain },
  { id: "flows",      label: "FLOWS",  Icon: Workflow },
  { id: "network",    label: "NET",    Icon: Antenna },
  { id: "settings",   label: "CFG",    Icon: Settings },
];

function NexusPage() {
  const [tab, setTab] = useState<TabId>("dashboard");

  const view = (() => {
    switch (tab) {
      case "connection": return <ConnectionTab />;
      case "dashboard":  return <DashboardTab />;
      case "kb":         return <KbTab />;
      case "files":
      case "terminal":   return <FilesTab />;
      case "settings":   return <SettingsTab />;
      case "aichat":     return <AiChatTab />;
      case "scripts":    return <PlaceholderTab title="SCRIPTS" desc="Library of executable Python automations. Pair an agent to populate." />;
      case "builder":    return <PlaceholderTab title="WIDGET BUILDER" desc="Drag, snap and deploy custom telemetry widgets to your home screen." />;
      case "flows":      return <PlaceholderTab title="FLOWS" desc="Node-graph automations linking triggers, scripts and AI actions." />;
      case "network":    return <PlaceholderTab title="NETWORK" desc="LAN topology, port maps, and live packet telemetry." />;
    }
  })();

  return (
    <AppShell>
      <div className="mb-2 -mx-1 overflow-x-auto no-scrollbar">
        <div className="flex gap-1 px-1 pb-1 min-w-min">
          {TABS.map(({ id, label, Icon }) => {
            const active = id === tab;
            return (
              <button key={id} onClick={() => setTab(id)}
                className={`shrink-0 flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-lg min-w-[52px] transition pressable ${
                  active ? "bg-primary/10 border border-primary/40" : "border border-transparent"
                }`}
                style={active ? { boxShadow: "0 0 12px hsl(187 100% 50% / .35)" } : undefined}
              >
                <Icon className={`w-[18px] h-[18px] ${active ? "text-primary" : "text-muted-foreground"}`}
                      style={active ? { filter: "drop-shadow(0 0 6px hsl(187 100% 50% / .8))" } : undefined}
                      strokeWidth={1.8} />
                <span className={`font-mono text-[0.5rem] font-bold tracking-wider ${active ? "text-primary" : "text-muted-foreground"}`}>{label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {tab === "connection" && (
        <div className="fixed inset-0 abyss-bg -z-10" aria-hidden />
      )}

      {view}
    </AppShell>
  );
}

```


### `/src/routes/run.tsx`

```ts path=/src/routes/run.tsx
import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Play, Search, Star, ChevronRight, Code2, Folder, Globe,
  Cpu, Database, Calendar, Mail, FileText, Activity, Wrench, X,
  Loader2, CheckCircle2, AlertTriangle, ShieldCheck, Copy, Check,
  Shield, Lock, Eye, Zap, Trash2, Archive, MonitorSmartphone, MousePointer,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";
import { toast } from "sonner";
import {
  SCRIPTS, CATEGORIES, search, categoryOf, getCategoriesPresent,
  type LibScript, type UICardColor,
} from "@/data/library";
import { useFavorites, useRunHistory } from "@/lib/useFavorites";
import { runScript } from "@/lib/scriptExecutor";
import { serverLink } from "@/lib/serverLink";
import { useServerLink } from "@/hooks/useServerLink";

export const Route = createFileRoute("/run")({
  head: () => ({
    meta: [
      { title: "Script Library — Butler AI" },
      { name: "description", content: `${SCRIPTS.length}+ local Python automations — categorized, signed, one-tap.` },
    ],
  }),
  component: ScriptsPage,
});

const CAT_ICONS: Record<string, React.ReactNode> = {
  Files:       <Folder      className="h-3.5 w-3.5" />,
  System:      <Cpu         className="h-3.5 w-3.5" />,
  Web:         <Globe       className="h-3.5 w-3.5" />,
  GUI:         <MousePointer className="h-3.5 w-3.5" />,
  Email:       <Mail        className="h-3.5 w-3.5" />,
  Data:        <Database    className="h-3.5 w-3.5" />,
  Scheduling:  <Calendar    className="h-3.5 w-3.5" />,
  Setup:       <Wrench      className="h-3.5 w-3.5" />,
  Network:     <Activity    className="h-3.5 w-3.5" />,
  Text:        <FileText    className="h-3.5 w-3.5" />,
  Monitoring:  <MonitorSmartphone className="h-3.5 w-3.5" />,
  Security:    <Shield      className="h-3.5 w-3.5" />,
  Privacy:     <Lock        className="h-3.5 w-3.5" />,
  Performance: <Zap         className="h-3.5 w-3.5" />,
  Cleaning:    <Trash2      className="h-3.5 w-3.5" />,
  Backup:      <Archive     className="h-3.5 w-3.5" />,
};

const DIFF_COLOR: Record<LibScript["difficulty"], string> = {
  BEGINNER:     "var(--green)",
  INTERMEDIATE: "var(--orange)",
  ADVANCED:     "var(--red)",
};

type Filter = "ALL" | "FAV" | string;

function ScriptsPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<Filter>("ALL");
  const [open, setOpen] = useState<LibScript | null>(null);
  const [running, setRunning] = useState<string | null>(null);
  const [results, setResults] = useState<Record<string, "ok" | "err">>({});
  const { isFav, toggle, count: favCount } = useFavorites();
  const { history, push } = useRunHistory();

  const present = useMemo(() => getCategoriesPresent(), []);

  const filtered = useMemo(() => {
    const base = q.trim() ? search(q) : SCRIPTS;
    return base.filter((s) => {
      if (cat === "ALL") return true;
      if (cat === "FAV") return isFav(s.id);
      return s.category === cat;
    });
  }, [q, cat, isFav]);

  const stats = useMemo(() => {
    const okN = history.filter((h) => h.ok).length;
    const rate = history.length ? Math.round((okN / history.length) * 100) : 100;
    return { total: SCRIPTS.length, runs: history.length, favs: favCount, success: rate };
  }, [history, favCount]);

  const link = useServerLink();
  const run = async (s: LibScript) => {
    if (running) return;
    setRunning(s.id);
    const t0 = performance.now();
    const connected = link.status === "connected";
    if (!connected) {
      toast(`▶ ${s.title}`, { description: "PC offline — running local simulation" });
      await new Promise((r) => setTimeout(r, 600 + Math.random() * 500));
      const ok = Math.random() > 0.07;
      const ms = Math.round(performance.now() - t0);
      setResults((r) => ({ ...r, [s.id]: ok ? "ok" : "err" }));
      push({ id: s.id, name: s.title, ok, ms, ts: Date.now() });
      setRunning(null);
      ok ? toast.success(`✓ ${s.title} (sim)`, { description: `${ms}ms · connect PC for real run` })
         : toast.error(`✗ ${s.title} failed`);
      return;
    }
    toast(`▶ ${s.title}`, { description: `Dispatching to ${serverLink.getState().ip}` });
    const r = await runScript({ id: s.id, name: s.title, category: s.category, script: s.script, language: "python" });
    const ms = r.ms ?? Math.round(performance.now() - t0);
    setResults((rr) => ({ ...rr, [s.id]: r.success ? "ok" : "err" }));
    push({ id: s.id, name: s.title, ok: r.success, ms, ts: Date.now() });
    setRunning(null);
    r.success
      ? toast.success(`✓ ${s.title}`, { description: `${ms}ms · exit ${r.exitCode ?? 0}` })
      : toast.error(`✗ ${s.title}`, { description: r.error ?? "execution failed" });
  };

  return (
    <AppShell active="scripts">
      <PageTitle
        kicker="LOCAL · HMAC-SIGNED"
        title="SCRIPT LIBRARY"
        sub={`${SCRIPTS.length} READY · ${present.length} CATEGORIES · 100% OFFLINE`}
        color="violet"
      />

      {/* Stats strip */}
      <div className="mt-3 grid grid-cols-4 gap-1.5">
        <Stat color="var(--green)"   value={`${stats.success}%`}      label="SUCCESS" />
        <Stat color="var(--cyan)"    value={String(stats.total)}      label="SCRIPTS" />
        <Stat color="var(--magenta)" value={String(stats.runs)}       label="RUNS"    />
        <Stat color="var(--orange)"  value={String(stats.favs)}       label="STARRED" />
      </div>

      {/* Search */}
      <div className="mt-3">
        <ThemedCard color="cyan" title="SEARCH" icon={<Search className="h-3.5 w-3.5" />}
          action={<span className="font-mono text-[9px] tracking-widest text-foreground/45">{filtered.length} HITS</span>}>
          <div className="flex items-center gap-2 rounded-md border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5">
            <Search className="h-3.5 w-3.5 text-foreground/40" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="search 100+ python scripts…"
              className="min-w-0 flex-1 bg-transparent font-mono text-[11px] text-foreground placeholder:text-foreground/30 focus:outline-none"
            />
            {q && (
              <button onClick={() => setQ("")} className="text-foreground/40 hover:text-foreground/80">
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </ThemedCard>
      </div>

      {/* Category chips */}
      <div className="-mx-1 mt-2.5 flex gap-1.5 overflow-x-auto px-1 pb-1"
           style={{ scrollbarWidth: "none" }}>
        <CatChip active={cat === "ALL"}  onClick={() => setCat("ALL")}  color="cyan"
                 icon={<Code2 className="h-3.5 w-3.5" />} label="ALL" />
        <CatChip active={cat === "FAV"}  onClick={() => setCat("FAV")}  color="amber"
                 icon={<Star className="h-3.5 w-3.5" />}  label={`★ ${favCount}`} />
        {present.map((c) => (
          <CatChip key={c.id}
                   active={cat === c.id} onClick={() => setCat(c.id)}
                   color={c.color}
                   icon={CAT_ICONS[c.id] ?? <Code2 className="h-3.5 w-3.5" />}
                   label={c.label} />
        ))}
      </div>

      {/* Script list */}
      <div className="mt-2 grid grid-cols-1 gap-2">
        {filtered.length === 0 && (
          <div className="panel-cyber p-4 text-center font-mono text-[11px] text-foreground/55">
            no scripts match — try a different filter
          </div>
        )}
        {filtered.slice(0, 60).map((s) => {
          const isRunning = running === s.id;
          const result = results[s.id];
          const starred = isFav(s.id);
          const meta = categoryOf(s);
          return (
            <ThemedCard key={s.id} color={meta.color}
              title={meta.label}
              icon={CAT_ICONS[s.category] ?? <ShieldCheck className="h-3.5 w-3.5" />}
              action={
                <div className="flex items-center gap-1.5">
                  <span className="rounded px-1.5 py-0.5 font-mono text-[9px] tracking-widest border"
                        style={{ color: DIFF_COLOR[s.difficulty],
                                 borderColor: `color-mix(in oklab, ${DIFF_COLOR[s.difficulty]} 50%, transparent)` }}>
                    {s.difficulty.slice(0, 3)}
                  </span>
                  {s.admin && (
                    <span className="rounded px-1.5 py-0.5 font-mono text-[9px] tracking-widest text-[color:var(--red)] border border-[color:var(--red)]/50">
                      ADMIN
                    </span>
                  )}
                  <button onClick={() => toggle(s.id)}
                          className={`grid h-6 w-6 place-items-center rounded border ${starred ? "border-[color:var(--orange)]/60 bg-[color:var(--orange)]/10 text-[color:var(--orange)]" : "border-[color:var(--border)] text-foreground/45"}`}
                          aria-label="Star">
                    <Star className="h-3 w-3" fill={starred ? "currentColor" : "none"} />
                  </button>
                </div>
              }>
              <div className="flex items-start gap-2">
                <div className="min-w-0 flex-1">
                  <div className="font-display text-[12.5px] font-extrabold leading-tight tracking-[0.02em] text-foreground/95">{s.title}</div>
                  <div className="mt-0.5 font-mono text-[10.5px] leading-snug text-foreground/60 line-clamp-2">{s.description}</div>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5 font-mono text-[8.5px] tracking-widest text-foreground/45">
                    <span>{s.time}</span>
                    {s.requirements.length > 0 && (
                      <span className="text-[color:var(--orange)]">PIP {s.requirements.length}</span>
                    )}
                    {s.tags.slice(0, 2).map((t) => (
                      <span key={t} className="rounded-sm bg-[color:var(--surface-2)] px-1 py-[1px] text-foreground/55">{t}</span>
                    ))}
                    {result === "ok"  && <span className="flex items-center gap-1 text-[color:var(--green)]"><CheckCircle2 className="h-3 w-3" /> OK</span>}
                    {result === "err" && <span className="flex items-center gap-1 text-[color:var(--red)]"><AlertTriangle className="h-3 w-3" /> ERR</span>}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1.5">
                  <button onClick={() => run(s)} disabled={!!running}
                    className="grid h-10 w-10 place-items-center rounded-md border text-[color:var(--magenta)] disabled:opacity-50"
                    style={{
                      borderColor: "color-mix(in oklab, var(--magenta) 60%, transparent)",
                      background: "color-mix(in oklab, var(--magenta) 14%, var(--ink))",
                      boxShadow: "0 0 14px -3px var(--magenta)",
                    }}
                    aria-label="Run">
                    {isRunning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                  </button>
                  <button onClick={() => setOpen(s)}
                    className="font-display text-[9px] font-extrabold tracking-[0.2em] text-cyan hover:underline">
                    CODE <ChevronRight className="inline h-3 w-3" />
                  </button>
                </div>
              </div>
            </ThemedCard>
          );
        })}
        {filtered.length > 60 && (
          <div className="panel-cyber p-2 text-center font-mono text-[9px] tracking-widest text-foreground/45">
            showing 60 of {filtered.length} — refine your search
          </div>
        )}
      </div>

      {open && <CodeModal s={open} onClose={() => setOpen(null)} onRun={() => { void run(open); setOpen(null); }} />}

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS SCRIPT LIB · {filtered.length}/{SCRIPTS.length}
      </div>
    </AppShell>
  );
}

function Stat({ value, label, color }: { value: string; label: string; color: string }) {
  return (
    <div className="panel-cyber px-2 py-2 text-center" style={{ ["--c" as any]: color }}>
      <div className="font-display text-[15px] font-black leading-none" style={{ color }}>{value}</div>
      <div className="mt-0.5 font-mono text-[8px] tracking-widest text-foreground/55">{label}</div>
    </div>
  );
}

function CatChip({ active, onClick, icon, label, color }: {
  active: boolean; onClick: () => void; icon: React.ReactNode; label: string; color: UICardColor;
}) {
  const cvar = color === "violet" ? "var(--magenta)" : color === "amber" ? "var(--orange)" : `var(--${color})`;
  return (
    <button onClick={onClick}
      data-active={active ? "true" : "false"}
      className="hex-tab shrink-0 flex-row gap-1.5 px-3"
      style={{ ["--c" as any]: cvar }}>
      {icon}
      <span className="font-display text-[9px] font-extrabold tracking-[0.2em]">{label}</span>
    </button>
  );
}

function CodeModal({ s, onClose, onRun }: { s: LibScript; onClose: () => void; onRun: () => void }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(s.script); setCopied(true); setTimeout(() => setCopied(false), 1400); } catch {}
  };
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/80" onClick={onClose}>
      <div className="panel-cyber w-full max-w-md p-3 m-2"
           onClick={(e) => e.stopPropagation()}
           style={{ ["--c" as any]: "var(--magenta)" }}>
        <div className="mb-2 flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <div className="font-mono text-[9px] tracking-widest text-[color:var(--magenta)]">{s.category} · {s.id}</div>
            <div className="font-display text-[13px] font-extrabold tracking-[0.06em] text-foreground">{s.title}</div>
            <div className="mt-0.5 font-mono text-[10px] text-foreground/60">{s.description}</div>
          </div>
          <button onClick={onClose} className="text-foreground/50 hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>
        {s.requirements.length > 0 && (
          <div className="mb-2 rounded border border-[color:var(--orange)]/40 bg-[color:var(--orange)]/5 p-1.5">
            <div className="font-display text-[8.5px] font-extrabold tracking-widest text-[color:var(--orange)]">PIP REQUIREMENTS</div>
            <div className="mt-0.5 font-mono text-[10px] text-foreground/80">pip install {s.requirements.join(" ")}</div>
          </div>
        )}
        <div className="relative">
          <button onClick={copy}
            className="absolute right-1.5 top-1.5 z-10 flex items-center gap-1 rounded border border-[color:var(--border)] bg-[var(--ink)]/90 px-1.5 py-0.5 font-display text-[8.5px] font-extrabold tracking-widest text-foreground/70 hover:text-cyan">
            {copied ? <><Check className="h-2.5 w-2.5 text-[color:var(--green)]" /> COPIED</>
                    : <><Copy className="h-2.5 w-2.5" /> COPY</>}
          </button>
          <pre className="max-h-[42vh] overflow-auto rounded border border-[color:var(--border)] bg-[var(--ink)] p-2 pr-16 font-mono text-[10.5px] leading-relaxed text-cyan whitespace-pre">
{s.script}
          </pre>
        </div>
        {s.notes && <div className="mt-1.5 font-mono text-[9.5px] text-foreground/55">{s.notes}</div>}
        <button onClick={onRun}
          className="mt-2 flex w-full items-center justify-center gap-2 rounded-md border border-[color:var(--magenta)]/60 bg-[color:var(--magenta)]/10 px-3 py-2 font-display text-[11px] font-extrabold tracking-[0.22em] text-[color:var(--magenta)]"
          style={{ boxShadow: "0 0 18px -4px var(--magenta)" }}>
          <Play className="h-3.5 w-3.5" /> RUN ON PC
        </button>
      </div>
    </div>
  );
}

```


### `/src/routes/settings.tsx`

```ts path=/src/routes/settings.tsx
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Settings as SettingsIcon, Power, ShieldCheck, Bell, Wifi, Brain, Database,
  Trash2, FileLock2, Lock, Activity, Eye, ChevronRight, Search, Plug, PlugZap,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";
import { JsonImporter } from "@/components/JsonImporter";
import { useServerLink } from "@/hooks/useServerLink";
import { serverLink } from "@/lib/serverLink";
import { toast } from "sonner";



export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings — Butler AI" }] }),
  component: SettingsPage,
});

function Toggle({ on, onChange }: { on: boolean; onChange: () => void }) {
  return (
    <button
      onClick={onChange}
      role="switch"
      aria-checked={on}
      className="relative h-6 w-11 shrink-0 rounded-full border border-[color:var(--border)] transition"
      style={{ background: on ? "color-mix(in oklab, var(--cyan) 28%, transparent)" : "var(--ink)" }}
    >
      <span
        className="absolute top-0.5 h-4 w-4 rounded-full transition-all"
        style={{
          left: on ? "22px" : "4px",
          background: on ? "var(--cyan)" : "var(--muted-foreground, #5b6172)",
          boxShadow: on ? "0 0 10px var(--cyan)" : "none",
        }}
      />
    </button>
  );
}

function ToggleRow({ icon, title, sub, init = false }: { icon: React.ReactNode; title: string; sub: string; init?: boolean }) {
  const [on, setOn] = useState(init);
  return (
    <li className="flex items-center gap-2.5 py-2">
      <span className="grid h-8 w-8 place-items-center rounded border border-[color:var(--border)] bg-[var(--ink)] text-cyan">{icon}</span>
      <div className="min-w-0 flex-1">
        <div className="font-display text-[11px] font-extrabold tracking-[0.18em] text-foreground/90">{title}</div>
        <div className="font-mono text-[9px] tracking-widest text-foreground/45">{sub}</div>
      </div>
      <Toggle on={on} onChange={() => setOn(v => !v)} />
    </li>
  );
}

function LinkRow({ icon, title, sub, to }: { icon: React.ReactNode; title: string; sub: string; to: string }) {
  return (
    <li>
      <Link to={to as any} className="flex items-center gap-2.5 py-2">
        <span className="grid h-8 w-8 place-items-center rounded border border-[color:var(--border)] bg-[var(--ink)] text-cyan">{icon}</span>
        <div className="min-w-0 flex-1">
          <div className="font-display text-[11px] font-extrabold tracking-[0.18em] text-foreground/90">{title}</div>
          <div className="font-mono text-[9px] tracking-widest text-foreground/45">{sub}</div>
        </div>
        <ChevronRight className="h-3.5 w-3.5 text-foreground/40" />
      </Link>
    </li>
  );
}

function SettingsPage() {
  return (
    <AppShell active="settings">
      <PageTitle kicker="SYSTEM · v7.4" title="SETTINGS" sub="ONBOARDING · PRIVACY · POWER" color="cyan" />

      <div className="mt-3">
        <ThemedCard color="cyan" title="ONBOARDING" icon={<SettingsIcon className="h-3.5 w-3.5" />}>
          <ul className="divide-y divide-[color:var(--border)]">
            <LinkRow icon={<Eye className="h-3.5 w-3.5" />} title="REPLAY INTRO TOUR" sub="step through onboarding again" to="/" />
            <ToggleRow icon={<Activity className="h-3.5 w-3.5" />} title="SHOW WELCOME" sub="display welcome card on launch" init />
            <ToggleRow icon={<ShieldCheck className="h-3.5 w-3.5" />} title="RESET ALL CONSENTS" sub="re-prompt every legal sign" />
          </ul>
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ServerLinkCard />
      </div>

      <div className="mt-2.5">
        <ThemedCard color="green" title="CONNECTION · BEHAVIOR" icon={<Wifi className="h-3.5 w-3.5" />}>
          <ul className="divide-y divide-[color:var(--border)]">
            <ToggleRow icon={<Wifi className="h-3.5 w-3.5" />} title="AUTO-CONNECT" sub="discover PC on LAN at launch" init />
            <ToggleRow icon={<Activity className="h-3.5 w-3.5" />} title="AUTO-RUN" sub="run scripts without confirm prompt" />
            <ToggleRow icon={<Bell className="h-3.5 w-3.5" />} title="NOTIFICATIONS" sub="push results to system tray" init />
            <ToggleRow icon={<Lock className="h-3.5 w-3.5" />} title="REQUIRE AUTH" sub="biometric before script dispatch" init />
          </ul>
        </ThemedCard>
      </div>


      <div className="mt-2.5">
        <ThemedCard color="violet" title="LOCAL AI · OLLAMA" icon={<Brain className="h-3.5 w-3.5" />}>
          <div className="font-mono text-[11px] leading-relaxed text-foreground/80">
            <div className="flex items-center justify-between">
              <span>Status</span>
              <span className="font-display text-[10px] font-extrabold tracking-[0.18em] text-[color:var(--green)]">● RUNNING</span>
            </div>
            <div className="mt-1 flex items-center justify-between">
              <span>Active model</span>
              <span className="text-[color:var(--magenta)]">llama3.1:8b</span>
            </div>
            <div className="mt-1 flex items-center justify-between">
              <span>Pulled</span>
              <span className="text-foreground/60">4 models · 18.2 GB</span>
            </div>
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {["llama3.1:8b", "qwen2.5:7b", "phi3:mini", "codellama:13b"].map((m) => (
              <span key={m} className="panel-cyber px-2 py-1 font-mono text-[9px] tracking-widest text-foreground/80"
                    style={{ ["--c" as any]: "var(--magenta)" }}>{m}</span>
            ))}
          </div>
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ThemedCard color="amber" title="PC POWER" icon={<Power className="h-3.5 w-3.5" />}>
          <div className="grid grid-cols-3 gap-1.5">
            {["SLEEP", "RESTART", "SHUTDOWN"].map((p) => (
              <button key={p}
                className="panel-cyber lift py-2 font-display text-[10px] font-extrabold tracking-[0.2em] text-[color:var(--orange)]"
                style={{ ["--c" as any]: "var(--orange)" }}>{p}</button>
            ))}
          </div>
          <div className="mt-2 font-mono text-[9px] tracking-widest text-foreground/45">requires confirmation</div>
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ThemedCard color="cyan" title="PRIVACY · LEGAL" icon={<FileLock2 className="h-3.5 w-3.5" />}>
          <ul className="divide-y divide-[color:var(--border)]">
            <LinkRow icon={<FileLock2 className="h-3.5 w-3.5" />} title="PRIVACY POLICY" sub="what we collect (nothing)"   to="/legal/privacy" />
            <LinkRow icon={<ShieldCheck className="h-3.5 w-3.5" />} title="TERMS OF SERVICE" sub="rules of engagement"        to="/legal/terms" />
            <LinkRow icon={<Database className="h-3.5 w-3.5" />} title="DATA SAFETY" sub="zero-cloud architecture"        to="/legal/safety" />
            <LinkRow icon={<Trash2 className="h-3.5 w-3.5" />} title="DELETE MY DATA" sub="wipe everything locally"      to="/legal/delete" />
          </ul>
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ThemedCard color="cyan" title="MASTER JSON" icon={<Database className="h-3.5 w-3.5" />}>
          <p className="mb-2 font-mono text-[10.5px] leading-relaxed text-foreground/70">
            Import a Butler master export (e.g. <span className="text-cyan">butler_master_v8_0_complete.json</span>) to inspect bundled files & metadata. Runs entirely on-device.
          </p>
          <JsonImporter />
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ThemedCard color="red" title="DANGER ZONE" icon={<Trash2 className="h-3.5 w-3.5" />}>
          <button className="panel-cyber lift w-full py-2 font-display text-[10px] font-extrabold tracking-[0.22em] text-[color:var(--red)]"
                  style={{ ["--c" as any]: "var(--red)" }}>
            CLEAR APP CACHE · LOGS · KB
          </button>
        </ThemedCard>
      </div>


      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        BUTLER AI · v7.4 · LOCAL-FIRST
      </div>
    </AppShell>
  );
}

function ServerLinkCard() {
  const link = useServerLink();
  const [ip, setIp] = useState(link.ip || "127.0.0.1");
  const [port, setPort] = useState(link.port || "8765");
  const [busy, setBusy] = useState(false);

  const connected = link.status === "connected";
  const statusColor = connected ? "var(--green)" : link.status === "discovering" || link.status === "connecting" ? "var(--orange)" : "var(--red)";
  const statusLabel = connected ? "● LINKED" : link.status === "discovering" ? "● SCANNING" : link.status === "connecting" ? "● PROBING" : "○ OFFLINE";

  const onConnect = async () => {
    setBusy(true);
    const ok = await serverLink.connect(ip, port);
    setBusy(false);
    toast[ok ? "success" : "error"](ok ? `Linked ${ip}:${port} · ${link.latencyMs ?? "?"}ms` : `No response from ${ip}:${port}`);
  };
  const onDiscover = async () => {
    setBusy(true);
    const ok = await serverLink.autoDiscover();
    setBusy(false);
    toast[ok ? "success" : "warning"](ok ? "PC server discovered" : "No host answered — set IP manually");
  };

  return (
    <ThemedCard color="green" title="SERVER LINK · PC BRIDGE" icon={<PlugZap className="h-3.5 w-3.5" />}>
      <div className="flex items-center justify-between">
        <div className="font-mono text-[11px] text-foreground/80">
          Host
          <span className="ml-2 text-foreground/55">{link.ip || "—"}:{link.port || "—"}</span>
        </div>
        <span className="font-display text-[10px] font-extrabold tracking-[0.18em]" style={{ color: statusColor }}>
          {statusLabel}
        </span>
      </div>
      <div className="mt-1 font-mono text-[10px] text-foreground/55">
        latency {link.latencyMs != null ? `${link.latencyMs}ms` : "—"}
        {link.lastOkAt ? ` · last ok ${new Date(link.lastOkAt).toLocaleTimeString()}` : ""}
      </div>

      <div className="mt-2 grid grid-cols-[1fr_88px] gap-1.5">
        <input
          value={ip}
          onChange={(e) => setIp(e.target.value)}
          placeholder="192.168.1.x"
          className="rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5 font-mono text-[12px] text-foreground outline-none focus:border-[color:var(--green)]"
        />
        <input
          value={port}
          onChange={(e) => setPort(e.target.value)}
          placeholder="8765"
          className="rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5 font-mono text-[12px] text-foreground outline-none focus:border-[color:var(--green)]"
        />
      </div>

      <div className="mt-2 grid grid-cols-3 gap-1.5">
        <button
          disabled={busy}
          onClick={onConnect}
          className="panel-cyber lift flex items-center justify-center gap-1 py-1.5 font-display text-[10px] font-extrabold tracking-[0.18em] text-[color:var(--green)] disabled:opacity-50"
          style={{ ["--c" as any]: "var(--green)" }}
        >
          <Plug className="h-3 w-3" /> CONNECT
        </button>
        <button
          disabled={busy}
          onClick={onDiscover}
          className="panel-cyber lift flex items-center justify-center gap-1 py-1.5 font-display text-[10px] font-extrabold tracking-[0.18em] text-[color:var(--cyan)] disabled:opacity-50"
          style={{ ["--c" as any]: "var(--cyan)" }}
        >
          <Search className="h-3 w-3" /> SCAN
        </button>
        <button
          disabled={busy || !connected}
          onClick={() => { serverLink.disconnect(); toast("Disconnected"); }}
          className="panel-cyber lift flex items-center justify-center gap-1 py-1.5 font-display text-[10px] font-extrabold tracking-[0.18em] text-[color:var(--red)] disabled:opacity-40"
          style={{ ["--c" as any]: "var(--red)" }}
        >
          <Power className="h-3 w-3" /> DROP
        </button>
      </div>

      <div className="mt-2 font-mono text-[9px] tracking-widest text-foreground/45">
        probes /api/status · /health · /status — works with Butler server & Ollama (port 11434).
      </div>
    </ThemedCard>
  );
}


```


### `/src/routes/support.tsx`

```ts path=/src/routes/support.tsx
import { createFileRoute } from "@tanstack/react-router";
import { Headphones, Heart, Sparkles, Palette, Check, Mail, Github, Coffee } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";

export const Route = createFileRoute("/support")({
  head: () => ({ meta: [{ title: "Cosmetic Packs — Butler AI" }] }),
  component: SupportPage,
});

const PACKS: Array<{ name: string; tag: string; color: "cyan" | "violet" | "green" | "amber" | "red"; owned: boolean; sub: string }> = [
  { name: "NEXUS CORE",       tag: "DEFAULT",  color: "cyan",   owned: true,  sub: "Cyan/magenta neon · stock theme" },
  { name: "OBSIDIAN BLOOM",   tag: "PREMIUM",  color: "violet", owned: true,  sub: "Magenta haze, lower contrast" },
  { name: "VIRIDIAN MATRIX",  tag: "PREMIUM",  color: "green",  owned: false, sub: "Phosphor green, terminal feel" },
  { name: "SOLAR FLARE",      tag: "PREMIUM",  color: "amber",  owned: false, sub: "Amber/orange warm cyberpunk" },
  { name: "CRIMSON PROTOCOL", tag: "LIMITED",  color: "red",    owned: false, sub: "Red alert, high-contrast" },
];

function SupportPage() {
  return (
    <AppShell active="support">
      <PageTitle kicker="THEMES · TIPS" title="SUPPORT BUTLER" sub="COSMETIC PACKS · NO PAYWALL ON FEATURES" color="violet" />

      <div className="mt-3">
        <ThemedCard color="violet" title="WHY SUPPORT" icon={<Heart className="h-3.5 w-3.5" />}>
          <p className="font-mono text-[11px] leading-relaxed text-foreground/80">
            Butler AI is <span className="text-[color:var(--magenta)] font-bold">100% free</span> and <span className="text-cyan font-bold">local-only</span> forever. Cosmetic packs unlock new themes and skins — they don't gate features. Every pack funds future development.
          </p>
        </ThemedCard>
      </div>

      <div className="mt-2.5 grid grid-cols-1 gap-2.5">
        {PACKS.map((p) => (
          <ThemedCard
            key={p.name}
            color={p.color}
            title={p.name}
            icon={<Palette className="h-3.5 w-3.5" />}
            action={
              p.owned
                ? <span className="flex items-center gap-1 font-display text-[9px] font-extrabold tracking-[0.2em] text-[color:var(--green)]"><Check className="h-3 w-3" /> OWNED</span>
                : <span className="font-mono text-[9px] tracking-widest text-foreground/55">{p.tag}</span>
            }
          >
            <p className="font-mono text-[11px] text-foreground/75">{p.sub}</p>
            <div className="mt-2 flex items-center gap-2">
              {!p.owned ? (
                <button className="panel-cyber lift px-3 py-1.5 font-display text-[10px] font-extrabold tracking-[0.2em]"
                        style={{ ["--c" as any]: p.color === "violet" ? "var(--magenta)" : p.color === "amber" ? "var(--orange)" : `var(--${p.color})` }}>
                  UNLOCK · €3
                </button>
              ) : (
                <button className="panel-cyber lift px-3 py-1.5 font-display text-[10px] font-extrabold tracking-[0.2em]"
                        style={{ ["--c" as any]: "var(--cyan)" }}>
                  APPLY THEME
                </button>
              )}
              <span className="font-mono text-[9px] tracking-widest text-foreground/45">PREVIEW · LONG-PRESS</span>
            </div>
          </ThemedCard>
        ))}
      </div>

      <div className="mt-2.5">
        <ThemedCard color="cyan" title="CONTACT" icon={<Headphones className="h-3.5 w-3.5" />}>
          <ul className="space-y-2">
            <ContactRow icon={<Mail className="h-3.5 w-3.5" />}   label="support@butler.ai" sub="bug reports · feedback" />
            <ContactRow icon={<Github className="h-3.5 w-3.5" />} label="github / butler-ai" sub="source · issues" />
            <ContactRow icon={<Coffee className="h-3.5 w-3.5" />} label="ko-fi / butler"    sub="tip the developer" />
          </ul>
        </ThemedCard>
      </div>

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · COSMETICS · v1.0
      </div>
    </AppShell>
  );
}

function ContactRow({ icon, label, sub }: { icon: React.ReactNode; label: string; sub: string }) {
  return (
    <li className="flex items-center gap-2.5">
      <span className="grid h-8 w-8 place-items-center rounded border border-[color:var(--border)] bg-[var(--ink)] text-cyan">{icon}</span>
      <div className="flex-1">
        <div className="font-display text-[11px] font-extrabold tracking-[0.18em] text-foreground/90">{label}</div>
        <div className="font-mono text-[9px] tracking-widest text-foreground/45">{sub}</div>
      </div>
      <Sparkles className="h-3.5 w-3.5 text-foreground/30" />
    </li>
  );
}

```


### `/src/routes/terminal.tsx`

```ts path=/src/routes/terminal.tsx
import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Terminal as TerminalIcon, ChevronRight } from "lucide-react";
import { AppShell, PageHeader, SectionTitle } from "@/components/AppShell";

export const Route = createFileRoute("/terminal")({
  head: () => ({
    meta: [
      { title: "Butler AI — Terminal" },
      { name: "description", content: "Signed shell over your LAN. Every command HMAC-verified." },
    ],
  }),
  component: TerminalPage,
});

type Line = { who: "out" | "in" | "err"; text: string };

function TerminalPage() {
  const [lines, setLines] = useState<Line[]>([
    { who: "out", text: "butler-shell v1.0 — signed channel established" },
    { who: "out", text: 'type "help" for available commands' },
  ]);
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "auto" }); }, [lines]);

  const exec = (cmd: string) => {
    const c = cmd.trim();
    if (!c) return;
    const out: Line[] = [{ who: "in", text: c }];
    if (c === "help") out.push({ who: "out", text: "commands: help, whoami, uptime, ls, ping <host>, clear" });
    else if (c === "clear") { setLines([]); setInput(""); return; }
    else if (c === "whoami") out.push({ who: "out", text: "operator@butler-pc" });
    else if (c === "uptime") out.push({ who: "out", text: "up 3 days, 14:22, load 0.42 0.38 0.31" });
    else if (c === "ls") out.push({ who: "out", text: "Documents  Downloads  Scripts  butler.log" });
    else if (c.startsWith("ping ")) out.push({ who: "out", text: `64 bytes from ${c.slice(5)}: time=1.2 ms` });
    else out.push({ who: "err", text: `butler: command not found: ${c}` });
    setLines((l) => [...l, ...out]);
    setInput("");
  };

  return (
    <AppShell active="term">
      <PageHeader title="TERMINAL" sub="SIGNED · LAN-ONLY" color="green" />
      <section className="panel-cyber space-y-2 p-3 glow-green">
        <SectionTitle icon={<TerminalIcon className="h-4 w-4" />} color="green" label="SHELL" />
        <div className="max-h-[60vh] overflow-y-auto rounded-md border border-green/20 bg-black p-2 font-mono text-[12px] leading-relaxed">
          {lines.map((l, i) => (
            <div key={i} className={l.who === "in" ? "text-cyan" : l.who === "err" ? "text-red-400" : "text-green"}>
              {l.who === "in" ? <span className="text-foreground/40">$ </span> : null}{l.text}
            </div>
          ))}
          <div ref={endRef} />
        </div>
        <form
          onSubmit={(e) => { e.preventDefault(); exec(input); }}
          className="flex items-center gap-2 rounded-md border border-green/30 bg-black/60 px-2"
        >
          <ChevronRight className="h-3.5 w-3.5 text-green" />
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="enter command…"
            autoFocus
            className="flex-1 bg-transparent py-2 font-mono text-[12px] text-green outline-none placeholder:text-foreground/30"
          />
        </form>
      </section>
    </AppShell>
  );
}

```


### `/src/server.ts`

```ts path=/src/server.ts
import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!body.includes('"unhandled":true') || !body.includes('"message":"HTTPError"')) {
    return response;
  }

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      return await normalizeCatastrophicSsrResponse(response);
    } catch (error) {
      console.error(error);
      return new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      });
    }
  },
};

```


### `/src/start.ts`

```ts path=/src/start.ts
import { createStart, createMiddleware } from "@tanstack/react-start";

import { renderErrorPage } from "./lib/error-page";

const errorMiddleware = createMiddleware().server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error != null && typeof error === "object" && "statusCode" in error) {
      throw error;
    }
    console.error(error);
    return new Response(renderErrorPage(), {
      status: 500,
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  }
});

export const startInstance = createStart(() => ({
  requestMiddleware: [errorMiddleware],
}));

```


### `/src/styles.css`

```css path=/src/styles.css
@import "tailwindcss" source(none);
@source "../src";
@import "tw-animate-css";

@custom-variant dark (&:is(.dark *));

@theme inline {
  --font-mono: "JetBrains Mono", ui-monospace, "SF Mono", Menlo, monospace;
  --font-sans: "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  --font-display: "Space Grotesk", "Inter", ui-sans-serif, system-ui, sans-serif;


  --radius-sm: 6px;
  --radius-md: 10px;
  --radius-lg: 14px;
  --radius-xl: 20px;
  --radius-2xl: 28px;

  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --color-surface: var(--surface);
  --color-surface-2: var(--surface-2);
  --color-border: var(--border);
  --color-muted: var(--muted);
  --color-muted-foreground: var(--muted-foreground);

  --color-cyan: var(--cyan);
  --color-cyan-dim: var(--cyan-dim);
  --color-green: var(--green);
  --color-green-dim: var(--green-dim);
  --color-magenta: var(--magenta);
  --color-magenta-dim: var(--magenta-dim);
  --color-orange: var(--orange);
  --color-orange-dim: var(--orange-dim);
  --color-red: var(--red);
  --color-yellow: var(--yellow);
  --color-violet: var(--magenta);
  --color-amber: var(--orange);

  /* Deep "ink" inset surfaces — used everywhere for terminals, chips, code blocks */
  --color-ink: var(--ink);
  --color-ink-2: var(--ink-2);
  --color-ink-3: var(--ink-3);

  --color-primary: var(--cyan);
  --color-primary-foreground: oklch(0.08 0.02 220);
  --color-ring: var(--cyan);
  --color-input: var(--border);
  --color-card: var(--surface);
  --color-card-foreground: var(--foreground);
}

:root {
  /* Cyberpunk dark-alloy base */
  --background: #06080d;
  --foreground: #d8f7ff;
  --surface: #0d1117;
  --surface-2: #141a23;
  --border: #1f2a3a;
  --muted: #11161e;
  --muted-foreground: #6c8194;

  /* Neon accents (exact cyberpunk palette) */
  --cyan: #00f3ff;
  --cyan-dim: #008b95;
  --green: #00ff9d;
  --green-dim: #00805a;
  --magenta: #bc00ff;
  --magenta-dim: #6a0099;
  --orange: #ffb800;
  --orange-dim: #8a6300;
  --red: #ff003c;
  --yellow: #ffd400;
  --violet: var(--magenta);
  --amber: var(--orange);

  /* Inset ink surfaces (centralized — every "terminal/code/chip" bg routes here) */
  --ink:   #04060b;
  --ink-2: #06090f;
  --ink-3: #0a0d13;
  --ink-deep: #03050a;

  /* Reusable gradients (centralized — shells, panels, CTAs) */
  --grad-shell:   linear-gradient(180deg, var(--ink) 0%, var(--background) 50%, var(--ink-deep) 100%);
  --grad-cta:     linear-gradient(180deg, #131a26, #07090f);
  --grad-tile:    linear-gradient(180deg, #0d1320, #05070c);
  --grad-chip:    linear-gradient(180deg, #0e1420, #060810);
  --grad-title:   linear-gradient(180deg, #f4ffff 0%, var(--cyan) 45%, color-mix(in oklab, var(--magenta) 80%, var(--cyan)) 100%);
  --grad-banner:  linear-gradient(90deg, color-mix(in oklab, var(--cyan) 14%, var(--ink-2)), color-mix(in oklab, var(--magenta) 14%, var(--ink-2)));

  --destructive: var(--red);
  --destructive-foreground: oklch(0.98 0 0);
  --popover: var(--surface);
  --popover-foreground: var(--foreground);
  --secondary: var(--surface-2);
  --secondary-foreground: var(--foreground);
  --accent: var(--surface-2);
  --accent-foreground: var(--cyan);

  --success: #4ade80;
  --warning: #fbbf24;
  --danger: #ff4d6d;
  --border-strong: color-mix(in oklab, var(--cyan) 36%, transparent);
}

.dark { color-scheme: dark; }

@layer base {
  * { border-color: var(--color-border); }
  html, body {
    background: var(--color-background);
    color: var(--color-foreground);
    font-family: var(--font-sans);
    font-feature-settings: "ss01", "cv11", "cv02";
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-rendering: optimizeLegibility;
    letter-spacing: 0.005em;
  }
  body {
    background-image:
      radial-gradient(ellipse 80% 50% at 50% -10%, color-mix(in oklab, var(--cyan) 18%, transparent), transparent 60%),
      radial-gradient(ellipse 60% 40% at 100% 100%, color-mix(in oklab, var(--magenta) 14%, transparent), transparent 60%),
      radial-gradient(ellipse 60% 40% at 0% 100%, color-mix(in oklab, var(--green) 10%, transparent), transparent 60%);
    /* background-attachment:fixed freezes scroll on Android WebView — keep default scroll */
    min-height: 100vh;
  }
  /* Display headlines: Space Grotesk, tighter tracking */
  h1, h2, h3, .font-display {
    font-family: var(--font-display);
    letter-spacing: -0.01em;
  }
  /* Anything monospaced opt-in only (terminals, code, hashes, telemetry) */
  .font-mono, pre, code, kbd, samp {
    font-family: var(--font-mono);
    font-feature-settings: "ss02", "cv01", "calt";
  }
  /* Tracked/uppercase tags read better with a touch more spacing in Inter */
  .tracking-widest { letter-spacing: 0.14em; }
}

@layer utilities {
  .text-cyan { color: var(--cyan); }
  .text-green { color: var(--green); }
  .text-magenta { color: var(--magenta); }
  .text-orange { color: var(--orange); }
  .text-yellow { color: var(--yellow); }

  .glow-cyan { box-shadow: 0 0 0 1px color-mix(in oklab, var(--cyan) 50%, transparent), 0 0 24px -4px color-mix(in oklab, var(--cyan) 60%, transparent), inset 0 0 24px -12px color-mix(in oklab, var(--cyan) 50%, transparent); }
  .glow-green { box-shadow: 0 0 0 1px color-mix(in oklab, var(--green) 50%, transparent), 0 0 24px -4px color-mix(in oklab, var(--green) 60%, transparent), inset 0 0 24px -12px color-mix(in oklab, var(--green) 50%, transparent); }
  .glow-magenta { box-shadow: 0 0 0 1px color-mix(in oklab, var(--magenta) 50%, transparent), 0 0 24px -4px color-mix(in oklab, var(--magenta) 60%, transparent), inset 0 0 24px -12px color-mix(in oklab, var(--magenta) 50%, transparent); }
  .glow-orange { box-shadow: 0 0 0 1px color-mix(in oklab, var(--orange) 50%, transparent), 0 0 24px -4px color-mix(in oklab, var(--orange) 60%, transparent), inset 0 0 24px -12px color-mix(in oklab, var(--orange) 50%, transparent); }

  .text-glow-cyan { text-shadow: 0 0 12px color-mix(in oklab, var(--cyan) 70%, transparent); }
  .text-glow-green { text-shadow: 0 0 12px color-mix(in oklab, var(--green) 70%, transparent); }

  .scanlines {
    background-image: repeating-linear-gradient(180deg, transparent 0 2px, color-mix(in oklab, var(--cyan) 4%, transparent) 2px 3px);
  }
  .grid-bg {
    background-image:
      linear-gradient(color-mix(in oklab, var(--cyan) 8%, transparent) 1px, transparent 1px),
      linear-gradient(90deg, color-mix(in oklab, var(--cyan) 8%, transparent) 1px, transparent 1px);
    background-size: 32px 32px;
  }

  .panel {
    background:
      linear-gradient(180deg, color-mix(in oklab, var(--surface-2) 92%, transparent), color-mix(in oklab, var(--surface) 92%, transparent)),
      linear-gradient(135deg, #1a2230 0%, #0a0d13 100%);
    border: 1px solid var(--border);
    border-radius: 6px;
    /* Android/WebView: translucent blurs over neon layers tank scroll FPS. */
    position: relative;
    box-shadow:
      inset 0 1px 0 color-mix(in oklab, var(--cyan) 14%, transparent),
      inset 0 -1px 0 #000,
      0 6px 22px -10px #000;
  }
  .panel::before {
    content: ""; position: absolute; inset: 0; pointer-events: none; border-radius: inherit;
    background:
      linear-gradient(transparent 0 50%, color-mix(in oklab, var(--cyan) 2.5%, transparent) 50% 51%, transparent 51%) 0 0 / 100% 4px;
    opacity: .35;
  }
  /* Beveled hex/cyberpunk panel — clipped corners */
  .panel-cyber {
    --c: var(--cyan);
    position: relative;
    background:
      linear-gradient(135deg, #1c2330 0%, #0b0f17 60%, #060810 100%);
    border: 1px solid color-mix(in oklab, var(--c) 55%, var(--border));
    clip-path: polygon(14px 0, 100% 0, 100% calc(100% - 14px), calc(100% - 14px) 100%, 0 100%, 0 14px);
    box-shadow:
      0 0 0 1px color-mix(in oklab, var(--c) 22%, transparent),
      0 0 22px -8px color-mix(in oklab, var(--c) 70%, transparent),
      inset 0 0 30px -16px color-mix(in oklab, var(--c) 60%, transparent);
  }
  .panel-cyber.c-violet { --c: var(--magenta); }
  .panel-cyber.c-green  { --c: var(--green); }
  .panel-cyber.c-amber  { --c: var(--orange); }
  .panel-cyber.c-red    { --c: var(--red); }

  /* Hex toolbar tab */
  .hex-tab {
    --c: var(--cyan);
    position: relative;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    gap: 2px; padding: 6px 1px; min-width: 0;
    background: linear-gradient(180deg, #1a2130, #0a0d13);
    color: color-mix(in oklab, var(--c) 80%, white);
    border: 1px solid color-mix(in oklab, var(--c) 35%, var(--border));
    clip-path: polygon(6px 0, calc(100% - 6px) 0, 100% 6px, 100% calc(100% - 6px), calc(100% - 6px) 100%, 6px 100%, 0 calc(100% - 6px), 0 6px);
    transition: filter .15s, transform .1s;
  }

  .hex-tab:hover { filter: brightness(1.25); }
  .hex-tab[data-active="true"] {
    background: linear-gradient(180deg, color-mix(in oklab, var(--c) 28%, #0a0d13), #0a0d13);
    box-shadow:
      0 0 0 1px var(--c),
      0 0 18px -2px color-mix(in oklab, var(--c) 80%, transparent),
      inset 0 0 16px -6px color-mix(in oklab, var(--c) 80%, transparent);
    color: #fff;
    text-shadow: 0 0 8px var(--c);
  }
  .hex-tab svg { color: var(--c); filter: drop-shadow(0 0 6px color-mix(in oklab, var(--c) 70%, transparent)); }

  /* Animated scanline overlay */
  @keyframes scan-sweep { 0% { transform: translateY(-10vh); } 100% { transform: translateY(110vh); } }
  .scan-sweep { animation: scan-sweep 6s linear infinite; }

  .panel-strong {
    border-color: var(--border-strong);
    background: linear-gradient(180deg, color-mix(in oklab, var(--surface-2) 92%, transparent), color-mix(in oklab, var(--surface) 92%, transparent));
    box-shadow: 0 0 0 1px color-mix(in oklab, var(--cyan) 6%, transparent) inset;
  }
  .screen-shell {
    width: 100%;
    max-width: 460px;
    min-height: 100vh;
    position: relative;
    background: linear-gradient(180deg, color-mix(in oklab, var(--surface) 80%, transparent) 0%, var(--background) 100%);
    border-left: 1px solid var(--border);
    border-right: 1px solid var(--border);
    background-image:
      repeating-linear-gradient(180deg, color-mix(in oklab, var(--cyan) 2%, transparent) 0 1px, transparent 1px 3px);
  }
  .chip {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 4px 10px;
    border-radius: 999px;
    border: 1px solid var(--border);
    background: var(--surface-2);
    font-size: 10px; font-weight: 700;
    letter-spacing: 0.14em; text-transform: uppercase;
    color: var(--muted-foreground);
  }
  .chip-cyan    { color: var(--cyan);    border-color: color-mix(in oklab, var(--cyan) 40%, transparent);    background: color-mix(in oklab, var(--cyan) 10%, transparent); }
  .chip-magenta { color: var(--magenta); border-color: color-mix(in oklab, var(--magenta) 40%, transparent); background: color-mix(in oklab, var(--magenta) 10%, transparent); }
  .chip-success { color: var(--success); border-color: color-mix(in oklab, var(--success) 40%, transparent); background: color-mix(in oklab, var(--success) 10%, transparent); }
  .chip-warning { color: var(--warning); border-color: color-mix(in oklab, var(--warning) 40%, transparent); background: color-mix(in oklab, var(--warning) 10%, transparent); }
  .chip-danger  { color: var(--danger);  border-color: color-mix(in oklab, var(--danger) 40%, transparent);  background: color-mix(in oklab, var(--danger) 10%, transparent); }
  .eyebrow {
    font-family: var(--font-display);
    font-size: 10px; font-weight: 700;
    letter-spacing: 0.22em; text-transform: uppercase;
    color: color-mix(in oklab, var(--cyan) 70%, transparent);
  }
  .dot { width: 6px; height: 6px; border-radius: 999px; background: var(--cyan); display: inline-block; }
  .dot-success { background: var(--success); }
  .dot-warning { background: var(--warning); }
  .dot-danger  { background: var(--danger); }
  .divider {
    height: 1px; width: 100%;
    background: linear-gradient(90deg, transparent, color-mix(in oklab, var(--cyan) 22%, transparent), transparent);
  }
  .tile {
    display: block; padding: 14px;
    border-radius: 14px;
    border: 1px solid var(--border);
    background: color-mix(in oklab, var(--surface) 80%, transparent);
    transition: border-color 0.15s, transform 0.15s, box-shadow 0.15s;
  }
  .tile:hover {
    border-color: var(--border-strong);
    transform: translateY(-1px);
    box-shadow: 0 4px 16px color-mix(in oklab, var(--cyan) 12%, transparent);
  }
  .btn-primary {
    display: inline-flex; align-items: center; justify-content: center; gap: 8px;
    padding: 12px 16px;
    border-radius: 12px;
    background: linear-gradient(180deg, var(--cyan), var(--cyan-dim));
    color: #02101a;
    font-weight: 700; font-size: 14px;
    border: 1px solid rgba(255,255,255,0.18);
    box-shadow: 0 0 18px color-mix(in oklab, var(--cyan) 24%, transparent);
  }
  .btn-ghost {
    display: inline-flex; align-items: center; justify-content: center; gap: 8px;
    padding: 12px 16px;
    border-radius: 12px;
    background: var(--surface-2);
    color: var(--foreground);
    font-weight: 600; font-size: 14px;
    border: 1px solid var(--border);
  }

  @keyframes blink { 0%, 49% { opacity: 1 } 50%, 100% { opacity: 0 } }
  .cursor-blink { animation: blink 1s steps(1) infinite; }

  @keyframes pulse-dot { 0%, 100% { opacity: 1; transform: scale(1) } 50% { opacity: .4; transform: scale(.85) } }
  .pulse-dot { animation: pulse-dot 1.6s ease-in-out infinite; }

  @keyframes spin-slow { to { transform: rotate(360deg) } }
  .spin-slow { animation: spin-slow 20s linear infinite; }
  .spin-reverse { animation: spin-slow 28s linear infinite reverse; }

  @keyframes orbit { to { transform: rotate(360deg) translateX(0) } }

  @keyframes slide-up { from { opacity: 0; transform: translateY(20px) } to { opacity: 1; transform: translateY(0) } }
  .anim-slide-up { animation: slide-up .5s ease-out both; }

  /* ===== Per-step camera whip — each step gets its own pan ===== */
  @keyframes whip-r  { 0%{opacity:0;transform:perspective(900px) rotateY(-28deg) translate3d(45%,0,-140px) scale(.9);filter:blur(6px)} 60%{opacity:1;transform:perspective(900px) rotateY(6deg) translate3d(-2%,0,0) scale(1.02);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }
  @keyframes whip-l  { 0%{opacity:0;transform:perspective(900px) rotateY(28deg) translate3d(-45%,0,-140px) scale(.9);filter:blur(6px)} 60%{opacity:1;transform:perspective(900px) rotateY(-6deg) translate3d(2%,0,0) scale(1.02);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }
  @keyframes whip-up { 0%{opacity:0;transform:perspective(900px) rotateX(22deg) translate3d(0,40%,-120px) scale(.92);filter:blur(6px)} 60%{opacity:1;transform:perspective(900px) rotateX(-4deg) translate3d(0,-2%,0) scale(1.02);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }
  @keyframes whip-dn { 0%{opacity:0;transform:perspective(900px) rotateX(-22deg) translate3d(0,-40%,-120px) scale(.92);filter:blur(6px)} 60%{opacity:1;transform:perspective(900px) rotateX(4deg) translate3d(0,2%,0) scale(1.02);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }
  @keyframes whip-in { 0%{opacity:0;transform:perspective(900px) scale(.55) rotateZ(-6deg);filter:blur(8px)} 60%{opacity:1;transform:perspective(900px) scale(1.04) rotateZ(1deg);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }
  @keyframes whip-out{ 0%{opacity:0;transform:perspective(900px) scale(1.5) rotateZ(4deg);filter:blur(8px)} 60%{opacity:1;transform:perspective(900px) scale(.98) rotateZ(-1deg);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }
  @keyframes whip-tl { 0%{opacity:0;transform:perspective(900px) rotateY(20deg) rotateX(14deg) translate3d(-30%,-25%,-100px);filter:blur(6px)} 60%{opacity:1;transform:perspective(900px) rotateY(-4deg) rotateX(-2deg) translate3d(2%,2%,0) scale(1.02);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }
  @keyframes whip-tr { 0%{opacity:0;transform:perspective(900px) rotateY(-20deg) rotateX(14deg) translate3d(30%,-25%,-100px);filter:blur(6px)} 60%{opacity:1;transform:perspective(900px) rotateY(4deg) rotateX(-2deg) translate3d(-2%,2%,0) scale(1.02);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }
  @keyframes whip-roll { 0%{opacity:0;transform:perspective(900px) rotateZ(-18deg) scale(.85) translate3d(-12%,12%,-80px);filter:blur(5px)} 60%{opacity:1;transform:perspective(900px) rotateZ(3deg) scale(1.02);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }
  @keyframes whip-orbit { 0%{opacity:0;transform:perspective(1100px) rotateY(60deg) translate3d(40%,0,-180px) scale(.8);filter:blur(8px)} 50%{opacity:1;transform:perspective(1100px) rotateY(-12deg) translate3d(-4%,0,0) scale(1.04);filter:blur(0)} 100%{opacity:1;transform:none;filter:blur(0)} }

  .whip-1  { animation: whip-r     .7s cubic-bezier(.2,.8,.2,1) both; transform-origin: 80% 30%; }
  .whip-2  { animation: whip-l     .7s cubic-bezier(.2,.8,.2,1) both; transform-origin: 20% 40%; }
  .whip-3  { animation: whip-dn    .7s cubic-bezier(.2,.8,.2,1) both; transform-origin: 50% 0%; }
  .whip-4  { animation: whip-up    .7s cubic-bezier(.2,.8,.2,1) both; transform-origin: 50% 100%; }
  .whip-5  { animation: whip-tr    .7s cubic-bezier(.2,.8,.2,1) both; transform-origin: 90% 0%; }
  .whip-6  { animation: whip-tl    .7s cubic-bezier(.2,.8,.2,1) both; transform-origin: 10% 0%; }
  .whip-7  { animation: whip-roll  .7s cubic-bezier(.2,.8,.2,1) both; transform-origin: 50% 50%; }
  .whip-8  { animation: whip-in    .7s cubic-bezier(.2,.8,.2,1) both; transform-origin: 50% 50%; }
  .whip-9  { animation: whip-out   .7s cubic-bezier(.2,.8,.2,1) both; transform-origin: 50% 50%; }
  .whip-10 { animation: whip-orbit .9s cubic-bezier(.2,.8,.2,1) both; transform-origin: 50% 50%; }

  @keyframes mascot-float { 0%,100% { transform: translateY(0) rotate(-2deg) } 50% { transform: translateY(-6px) rotate(2deg) } }
  .mascot-float { animation: mascot-float 3.4s ease-in-out infinite; }

  @keyframes mascot-pop { 0% { transform: scale(.4) rotate(-30deg); opacity: 0 } 70% { transform: scale(1.08) rotate(4deg); opacity: 1 } 100% { transform: scale(1) rotate(0); opacity: 1 } }
  .mascot-pop { animation: mascot-pop .55s cubic-bezier(.2,1.6,.3,1) both; }

  @keyframes bubble-in { from { opacity: 0; transform: translateY(8px) scale(.94) } to { opacity: 1; transform: translateY(0) scale(1) } }
  .bubble-in { animation: bubble-in .4s ease-out .25s both; }

  @keyframes flicker { 0%, 100% { opacity: 1 } 50% { opacity: .7 } }
  .flicker { animation: flicker 3s ease-in-out infinite; }

  @keyframes stamp-in { 0% { transform: scale(2) rotate(-22deg); opacity: 0 } 60% { transform: scale(.92) rotate(-8deg); opacity: 1 } 100% { transform: scale(1) rotate(-8deg); opacity: 1 } }
  .stamp-in { animation: stamp-in .4s cubic-bezier(.3,1.4,.4,1) both; }

  /* ===== Reveal burst — invisible → visible on final launch ===== */
  @keyframes reveal-burst {
    0%   { opacity: 0; transform: scale(.4) rotate(-8deg); filter: blur(14px) brightness(2.4); clip-path: circle(0% at 50% 50%); }
    40%  { opacity: 1; transform: scale(1.08) rotate(2deg); filter: blur(0) brightness(1.6); clip-path: circle(80% at 50% 50%); }
    70%  { transform: scale(.98) rotate(-1deg); filter: blur(0) brightness(1.1); clip-path: circle(120% at 50% 50%); }
    100% { opacity: 1; transform: scale(1) rotate(0); filter: none; clip-path: circle(150% at 50% 50%); }
  }
  .reveal-burst { animation: reveal-burst 1.1s cubic-bezier(.2,.9,.2,1.05) both; }

  @keyframes ring-burst { 0%{opacity:1;transform:scale(.2)} 100%{opacity:0;transform:scale(2.6)} }
  .ring-burst { animation: ring-burst 1.1s ease-out both; }

  @keyframes icon-pop-in { 0%{opacity:0;transform:translateY(4px) scale(.6)} 100%{opacity:1;transform:none} }
  .icon-pop-in { animation: icon-pop-in .4s cubic-bezier(.2,1.6,.3,1) both; }

  /* ===== Per-step mascot animations (applied to the bust wrapper) ===== */
  @keyframes m-wave   { 0%,100%{transform:rotate(0) translateY(0)} 20%{transform:rotate(-7deg) translateY(-2px)} 60%{transform:rotate(8deg) translateY(-3px)} }
  @keyframes m-spy    { 0%,100%{transform:translateX(0) rotate(0)} 25%{transform:translateX(-4px) rotate(-7deg)} 75%{transform:translateX(4px) rotate(7deg)} }
  @keyframes m-nod    { 0%,100%{transform:translateY(0) rotate(0)} 50%{transform:translateY(3px) rotate(3deg)} }
  @keyframes m-oath   { 0%,100%{transform:translateY(0) scale(1)} 50%{transform:translateY(-5px) scale(1.03)} }
  @keyframes m-tilt   { 0%,100%{transform:rotate(-4deg) translateY(-1px)} 50%{transform:rotate(4deg) translateY(1px)} }
  @keyframes m-shake  { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-3px) rotate(-2deg)} 60%{transform:translateX(3px) rotate(2deg)} }
  @keyframes m-think  { 0%,100%{transform:rotate(-6deg) translateY(0)} 50%{transform:rotate(2deg) translateY(-3px)} }
  @keyframes m-bow    { 0%,100%{transform:rotate(0) translateY(0)} 50%{transform:rotate(10deg) translateY(4px) scale(.97)} }
  @keyframes m-build  { 0%,100%{transform:translateY(0) rotate(0)} 25%{transform:translateY(-2px) rotate(-4deg)} 75%{transform:translateY(2px) rotate(5deg)} }
  @keyframes m-launch { 0%{transform:translateY(0) scale(1)} 50%{transform:translateY(-6px) scale(1.04)} 100%{transform:translateY(-14px) scale(1.07)} }
  @keyframes m-glow   { 0%,100%{filter:drop-shadow(0 0 4px currentColor)} 50%{filter:drop-shadow(0 0 18px currentColor) brightness(1.15)} }

  .m-wave   { animation: m-wave   2.2s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-spy    { animation: m-spy    2.6s ease-in-out infinite; transform-origin: 50% 70%; }
  .m-nod    { animation: m-nod    1.6s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-oath   { animation: m-oath   1.8s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-tilt   { animation: m-tilt   3.2s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-shake  { animation: m-shake  .9s  ease-in-out infinite; transform-origin: 50% 80%; }
  .m-think  { animation: m-think  2.4s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-bow    { animation: m-bow    2.4s ease-in-out infinite; transform-origin: 50% 90%; }
  .m-build  { animation: m-build  1.3s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-launch { animation: m-launch 1.4s cubic-bezier(.3,.7,.2,1) infinite alternate; transform-origin: 50% 100%; }
  .m-glow   { animation: m-glow   2s   ease-in-out infinite; }

  /* ===== Extended mascot library — reusable post-onboarding ===== */
  @keyframes m-spin    { 0%{transform:rotate(0)} 100%{transform:rotate(360deg)} }
  @keyframes m-bounce  { 0%,100%{transform:translateY(0)} 30%{transform:translateY(-10px) scale(1.04)} 60%{transform:translateY(2px) scale(.98)} }
  @keyframes m-dance   { 0%,100%{transform:translateX(0) rotate(0)} 25%{transform:translateX(-6px) rotate(-8deg)} 50%{transform:translateY(-4px) rotate(0)} 75%{transform:translateX(6px) rotate(8deg)} }
  @keyframes m-cheer   { 0%,100%{transform:translateY(0) scale(1)} 50%{transform:translateY(-10px) scale(1.08) rotate(-3deg)} }
  @keyframes m-salute  { 0%,100%{transform:rotate(0)} 30%{transform:rotate(-6deg) translateY(-2px)} 60%{transform:rotate(2deg)} }
  @keyframes m-peek    { 0%,100%{transform:translateX(-40%) rotate(-10deg);opacity:.5} 50%{transform:translateX(0) rotate(0);opacity:1} }
  @keyframes m-blink   { 0%,92%,100%{filter:none} 95%{filter:brightness(1.6) saturate(1.4)} }
  @keyframes m-zoom    { 0%,100%{transform:scale(1)} 50%{transform:scale(1.12)} }
  @keyframes m-orbit2  { 0%{transform:rotate(0) translateX(4px) rotate(0)} 100%{transform:rotate(360deg) translateX(4px) rotate(-360deg)} }
  @keyframes m-meditate{ 0%,100%{transform:translateY(0)} 50%{transform:translateY(-3px)} }
  @keyframes m-juggle  { 0%,100%{transform:translateY(0) rotate(0)} 25%{transform:translateY(-4px) rotate(-10deg)} 75%{transform:translateY(-4px) rotate(10deg)} }
  @keyframes m-victory { 0%{transform:translateY(0) scale(1)} 50%{transform:translateY(-14px) scale(1.1) rotate(-5deg)} 100%{transform:translateY(-6px) scale(1.05) rotate(5deg)} }
  @keyframes m-sleep   { 0%,100%{transform:rotate(-6deg) translateY(2px)} 50%{transform:rotate(-4deg) translateY(0)} }
  @keyframes m-alert   { 0%,100%{transform:translateY(0)} 10%{transform:translateY(-6px) scale(1.06)} 20%{transform:translateY(0)} }
  @keyframes m-wink    { 0%,80%,100%{transform:rotate(0)} 88%{transform:rotate(-12deg) scale(1.04)} }
  @keyframes m-skate   { 0%,100%{transform:translateX(-12px) rotate(-4deg)} 50%{transform:translateX(12px) rotate(4deg)} }
  @keyframes m-hover   { 0%,100%{transform:translateY(-4px)} 50%{transform:translateY(-12px)} }
  @keyframes m-boop    { 0%,100%{transform:scale(1)} 40%{transform:scale(.92) translateY(2px)} 70%{transform:scale(1.05) translateY(-3px)} }
  @keyframes m-scan    { 0%,100%{filter:drop-shadow(0 0 4px currentColor)} 50%{filter:drop-shadow(0 0 22px currentColor) hue-rotate(20deg) brightness(1.2)} }

  .m-spin     { animation: m-spin     4s linear infinite; transform-origin: 50% 60%; }
  .m-bounce   { animation: m-bounce   1.4s cubic-bezier(.3,1.4,.4,1) infinite; transform-origin: 50% 100%; }
  .m-dance    { animation: m-dance    1.6s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-cheer    { animation: m-cheer    1.2s cubic-bezier(.3,1.4,.4,1) infinite; transform-origin: 50% 100%; }
  .m-salute   { animation: m-salute   1.8s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-peek     { animation: m-peek     2.4s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-blink    { animation: m-blink    3.6s ease-in-out infinite; }
  .m-zoom     { animation: m-zoom     2s   ease-in-out infinite; transform-origin: 50% 70%; }
  .m-orbit    { animation: m-orbit2   5s   linear infinite; transform-origin: 50% 60%; }
  .m-meditate { animation: m-meditate 3.2s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-juggle   { animation: m-juggle   1.2s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-victory  { animation: m-victory  1.6s cubic-bezier(.3,1.4,.4,1) infinite alternate; transform-origin: 50% 100%; }
  .m-sleep    { animation: m-sleep    3s   ease-in-out infinite; transform-origin: 50% 90%; }
  .m-alert    { animation: m-alert    1.1s ease-out infinite; transform-origin: 50% 80%; }
  .m-wink     { animation: m-wink     3s   ease-in-out infinite; transform-origin: 50% 70%; }
  .m-skate    { animation: m-skate    2.2s ease-in-out infinite; transform-origin: 50% 90%; }
  .m-hover    { animation: m-hover    2.6s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-boop     { animation: m-boop     1.4s ease-in-out infinite; transform-origin: 50% 80%; }
  .m-scan     { animation: m-scan     2.4s ease-in-out infinite; }

  /* Reduced-motion: keep mascot calm */
  @media (prefers-reduced-motion: reduce) {
    .mascot-pop, .mascot-float, .m-wave, .m-spy, .m-nod, .m-oath, .m-tilt, .m-shake,
    .m-think, .m-bow, .m-build, .m-launch, .m-glow, .m-spin, .m-bounce,
    .m-dance, .m-cheer, .m-salute, .m-peek, .m-blink, .m-zoom, .m-orbit,
    .m-meditate, .m-juggle, .m-victory, .m-sleep, .m-alert, .m-wink,
    .m-skate, .m-hover, .m-boop, .m-scan,
    .step-enter, .bubble-in, .stamp-in, .cta-heartbeat, .focus-pulse,
    .tap-pulse, .pulse-dot { animation: none !important; transition: none !important; }
    html { scroll-behavior: auto !important; }
  }



  .scrollbar-hidden::-webkit-scrollbar { display: none; }
  .scrollbar-hidden { scrollbar-width: none; }
}

/* Page-enter animation — every step fades + lifts in on load/click */
@keyframes step-enter {
  0%   { opacity: 0; transform: translateY(14px) scale(.985); }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}
.step-enter { animation: step-enter .55s cubic-bezier(.2,.8,.2,1) both; }
.step-enter > * { animation: step-enter .65s cubic-bezier(.2,.8,.2,1) both; }
.step-enter > *:nth-child(1){ animation-delay: .04s }
.step-enter > *:nth-child(2){ animation-delay: .10s }
.step-enter > *:nth-child(3){ animation-delay: .16s }
.step-enter > *:nth-child(4){ animation-delay: .22s }

/* Click feedback — every button/link gives a tactile press */
button, a { transition: transform .12s ease, color .15s ease, background-color .15s ease, border-color .15s ease; }
button:active, a:active { transform: scale(.98); }

/* Smooth in-page scroll + Android/WebView scroll fixes */
html { scroll-behavior: auto; }
html, body {
  touch-action: pan-y;
  overscroll-behavior-y: auto;
  -webkit-overflow-scrolling: touch;
  overflow-x: clip;
}
/* Prevent fixed-position overlays from freezing scroll on Android WebView */
.pointer-events-none { touch-action: pan-y; }

/* ============ Hand-holding camera & haptic visuals ============ */
/* Focus pulse — applied when the camera "zooms" onto a target */
@keyframes focus-pulse {
  0%   { box-shadow: 0 0 0 0 color-mix(in oklab, var(--cyan) 65%, transparent), 0 0 0 0 transparent; transform: scale(1); }
  25%  { box-shadow: 0 0 0 6px color-mix(in oklab, var(--cyan) 35%, transparent), 0 0 38px -6px var(--cyan); transform: scale(1.012); }
  100% { box-shadow: 0 0 0 0 transparent, 0 0 0 0 transparent; transform: scale(1); }
}
.focus-pulse { animation: focus-pulse 1.15s cubic-bezier(.2,.8,.2,1) both; }

/* Small tap-pulse for inline buttons */
@keyframes tap-pulse {
  0% { transform: scale(.96); filter: brightness(1.25); }
  100% { transform: scale(1); filter: brightness(1); }
}
.tap-pulse { animation: tap-pulse .22s ease-out both; }

/* ===== SIGN-button flourish — visual confirmation above the button ===== */
@keyframes sign-flourish {
  0%   { opacity: 0; transform: translate(-50%, 6px) scale(.6); filter: blur(4px); }
  35%  { opacity: 1; transform: translate(-50%, -4px) scale(1.08); filter: blur(0); }
  70%  { opacity: 1; transform: translate(-50%, -10px) scale(1); }
  100% { opacity: 0; transform: translate(-50%, -22px) scale(.94); }
}
.sign-flourish {
  position: absolute;
  left: 50%;
  bottom: 100%;
  margin-bottom: 6px;
  pointer-events: none;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 8px;
  border-radius: 999px;
  background: color-mix(in oklab, var(--green) 22%, transparent);
  border: 1px solid color-mix(in oklab, var(--green) 70%, transparent);
  color: var(--green);
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 10px;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  text-shadow: 0 0 10px color-mix(in oklab, var(--green) 70%, transparent);
  box-shadow: 0 0 22px -4px var(--green), inset 0 0 12px -6px var(--green);
  animation: sign-flourish 1.05s cubic-bezier(.2,.9,.2,1) both;
  white-space: nowrap;
}
@keyframes sign-ring {
  0%   { opacity: .9; transform: translate(-50%, -50%) scale(.4); }
  100% { opacity: 0;  transform: translate(-50%, -50%) scale(2.4); }
}
.sign-ring {
  position: absolute;
  left: 50%;
  top: 50%;
  width: 70px;
  height: 70px;
  border-radius: 999px;
  border: 2px solid var(--green);
  pointer-events: none;
  animation: sign-ring .9s ease-out both;
}

/* Android / embedded WebView performance mode.
   Keeps the cyber visual system, removes continuous repaint/compositing work. */
@media (max-width: 640px), (pointer: coarse) {
  html,
  body {
    scroll-behavior: auto !important;
    overscroll-behavior-y: auto !important;
    overflow-x: clip !important;
  }

  *, *::before, *::after {
    animation-duration: 0.001ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.04s !important;
  }

  .scan-sweep,
  .pulse-dot,
  .cursor-blink,
  .card-accent,
  .shine::after,
  .led,
  .hero-beam,
  .step-enter,
  .step-enter > *,
  .mascot-pop,
  .mascot-float,
  .mascot-3d,
  .focus-pulse,
  .tap-pulse,
  .sign-flourish,
  .sign-ring,
  .cta-heartbeat,
  .ring-burst,
  .reveal-burst,
  .icon-pop-in,
  .bubble-in,
  .stamp-in,
  .animate-fade-in,
  .animate-blink,
  .animate-pulse-glow,
  .animate-scan,
  .animate-spring-up,
  [class*="whip-"],
  [class*="m-"] {
    animation: none !important;
    transform: none !important;
    filter: none !important;
  }

  .panel,
  .panel-cyber,
  .cyber-card,
  .cyber-card-glow,
  .glow-cyan,
  .glow-green,
  .glow-magenta,
  .glow-orange {
    box-shadow:
      inset 0 1px 0 color-mix(in oklab, var(--cyan) 8%, transparent),
      0 1px 10px color-mix(in oklab, #000 45%, transparent) !important;
  }

  .panel::before,
  .holo-grain::before,
  .caustics::before {
    mix-blend-mode: normal !important;
    opacity: 0.16 !important;
    animation: none !important;
  }
}

/* Next-button heartbeat once gate clears */
@keyframes cta-heartbeat {
  0%,100% { box-shadow: 0 0 20px -4px currentColor; }
  50%     { box-shadow: 0 0 38px -2px currentColor; }
}
.cta-heartbeat { animation: cta-heartbeat 1.6s ease-in-out infinite; }

/* Leave room under the sticky header when auto-scrolling */
html { scroll-padding-top: 92px; }
[data-tour] { scroll-margin-top: 96px; }

/* Brighter text helpers */
.text-bright   { color: oklch(0.98 0.02 240); }
.text-bright-2 { color: oklch(0.92 0.03 240); }

/* ============ Dynamic perf throttling ============
   The usePerfTier() hook tags <html> with .perf-low / .perf-mid / .perf-high.
   We progressively cheapen visual FX without changing the visual identity. */

/* MID: drop expensive filters but keep movement. */
.perf-mid [class*="m-glow"],
.perf-mid .mascot-float img { filter: none !important; }
.perf-mid .scanlines        { opacity: .35 !important; }
.perf-mid .grid-bg          { opacity: .25 !important; }

/* LOW: freeze ambient motion, kill blurs/shadows, keep instant feedback. */
.perf-low *,
.perf-low *::before,
.perf-low *::after {
  animation-duration: .001ms !important;
  animation-iteration-count: 1 !important;
  transition-duration: .08s !important;
}
.perf-low .focus-pulse,
.perf-low .tap-pulse,
.perf-low .cta-heartbeat {
  animation: none !important;
}
.perf-low [class*="m-glow"],
.perf-low .mascot-float img,
.perf-low .mascot-pop { filter: none !important; }
.perf-low .scanlines,
.perf-low .grid-bg     { display: none !important; }
html.perf-low         { scroll-behavior: auto; }

/* Reduced-motion master override — placed outside @layer to ensure it wins
   the cascade against the animation utilities defined above. */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.001ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.001ms !important;
    scroll-behavior: auto !important;
  }
}

/* ───────── Nexus Hero ───────── */
@keyframes hero-spin { to { transform: rotate(360deg); } }
.hero-spin-slow { animation: hero-spin 32s linear infinite; transform-origin: 50% 50%; will-change: transform; }
.hero-spin-rev  { animation: hero-spin 22s linear infinite reverse; transform-origin: 50% 50%; will-change: transform; }
.hero-halo {
  background:
    radial-gradient(circle at 50% 50%, color-mix(in oklab, var(--cyan) 30%, transparent) 0%, transparent 62%),
    radial-gradient(circle at 50% 50%, color-mix(in oklab, var(--magenta) 22%, transparent) 0%, transparent 80%);
  filter: blur(6px);
}
.hero-title {
  color: #d6f6ff;
  background: linear-gradient(180deg, #eafcff 0%, #6fd9ff 55%, #1090c8 100%);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  text-shadow:
    0 0 18px color-mix(in oklab, var(--cyan) 70%, transparent),
    0 0 38px color-mix(in oklab, var(--magenta) 35%, transparent);
}
.perf-low .hero-spin-slow,
.perf-low .hero-spin-rev { animation: none !important; }

/* Subtle 3D float for the mascot */
@keyframes mascot-3d-float {
  0%, 100% { transform: translate(-50%, -50%) translateY(0) rotateX(0deg) rotateY(0deg); }
  50%      { transform: translate(-50%, -50%) translateY(-4px) rotateX(2deg) rotateY(-2deg); }
}
.mascot-3d {
  animation: mascot-3d-float 6s ease-in-out infinite;
  transform-style: preserve-3d;
  will-change: transform;
}
.perf-low .mascot-3d { animation: none !important; }

/* ============ Premium component flourishes ============ */

/* Animated top accent bar that pulses across each card header */
@keyframes accent-flow {
  0%   { background-position: 0% 0; }
  100% { background-position: 200% 0; }
}
.card-accent {
  height: 2px;
  background: linear-gradient(90deg,
    transparent 0%,
    color-mix(in oklab, var(--c, var(--cyan)) 85%, transparent) 40%,
    #fff 50%,
    color-mix(in oklab, var(--c, var(--cyan)) 85%, transparent) 60%,
    transparent 100%);
  background-size: 200% 100%;
  animation: accent-flow 4.5s linear infinite;
  box-shadow: 0 0 10px color-mix(in oklab, var(--c, var(--cyan)) 70%, transparent);
}

/* Corner brackets — 4 glowing L-shapes anchored to a card's corners */
.brackets { position: relative; }
.brackets::before,
.brackets::after {
  content: ""; position: absolute; width: 10px; height: 10px;
  border: 1.5px solid var(--c, var(--cyan));
  filter: drop-shadow(0 0 4px var(--c, var(--cyan)));
  pointer-events: none;
}
.brackets::before { top: 4px; left: 4px; border-right: 0; border-bottom: 0; }
.brackets::after  { bottom: 4px; right: 4px; border-left: 0; border-top: 0; }
.brackets > .br-tr,
.brackets > .br-bl {
  position: absolute; width: 10px; height: 10px;
  border: 1.5px solid var(--c, var(--cyan));
  filter: drop-shadow(0 0 4px var(--c, var(--cyan)));
  pointer-events: none;
}
.brackets > .br-tr { top: 4px; right: 4px; border-left: 0; border-bottom: 0; }
.brackets > .br-bl { bottom: 4px; left: 4px; border-right: 0; border-top: 0; }

/* Diagonal shine sweep — for buttons/CTAs */
@keyframes shine-sweep {
  0%   { transform: translateX(-120%) skewX(-18deg); opacity: 0; }
  20%  { opacity: 1; }
  80%  { opacity: 1; }
  100% { transform: translateX(220%) skewX(-18deg); opacity: 0; }
}
.shine { position: relative; overflow: hidden; isolation: isolate; }
.shine::after {
  content: ""; position: absolute; inset: 0;
  background: linear-gradient(100deg,
    transparent 30%,
    color-mix(in oklab, var(--c, var(--cyan)) 38%, transparent) 48%,
    rgba(255,255,255,0.55) 50%,
    color-mix(in oklab, var(--c, var(--cyan)) 38%, transparent) 52%,
    transparent 70%);
  mix-blend-mode: screen;
  animation: shine-sweep 3.4s ease-in-out infinite;
  pointer-events: none;
}

/* Subtle hover lift for any premium tile */
.lift { transition: transform .18s ease, filter .18s ease, box-shadow .25s ease; }
.lift:hover {
  transform: translateY(-2px);
  filter: brightness(1.08);
}

/* Holographic noise/grain overlay */
.holo-grain::before {
  content: ""; position: absolute; inset: 0; pointer-events: none;
  background-image: repeating-linear-gradient(
    180deg,
    transparent 0 2px,
    color-mix(in oklab, var(--c, var(--cyan)) 6%, transparent) 2px 3px
  );
  mix-blend-mode: overlay;
  opacity: 0.55;
  border-radius: inherit;
}

/* Status LED — small live indicator dot in card header */
@keyframes led-pulse {
  0%,100% { box-shadow: 0 0 4px var(--c, var(--cyan)), 0 0 0 0 color-mix(in oklab, var(--c, var(--cyan)) 70%, transparent); }
  50%     { box-shadow: 0 0 10px var(--c, var(--cyan)), 0 0 0 4px color-mix(in oklab, var(--c, var(--cyan)) 0%, transparent); }
}
.led {
  width: 6px; height: 6px; border-radius: 999px;
  background: var(--c, var(--cyan));
  animation: led-pulse 1.8s ease-in-out infinite;
  display: inline-block;
}

/* Hero title scan beam */
@keyframes hero-beam-slide {
  0%   { transform: translateX(-50%); }
  100% { transform: translateX(450%); }
}
.hero-beam { animation: hero-beam-slide 3.2s ease-in-out infinite; }

@media (prefers-reduced-motion: reduce) {
  .card-accent, .shine::after, .led, .hero-beam { animation: none !important; }
}





/* ============================================================
   NEXUS · Cybernetic Command port — utilities + HSL aliases
   Drained from Cybernetic Command + Butler AI Home projects.
   ============================================================ */
:root {
  /* HSL triplets so `hsl(var(--x))` in ported components works */
  --primary:        187 100% 50%;
  --primary-foreground: 222 40% 5%;
  --accent:         296 100% 55%;
  --success:        135 100% 50%;
  --warning:         38 100% 55%;
  --destructive:    350  95% 55%;
  --card:           224  35%  8%;
  --surface-3:      226  30% 14%;

  /* Gradients & glows used by Cybernetic atoms */
  --gradient-cyan-magenta: linear-gradient(135deg, hsl(187 100% 50%), hsl(296 100% 55%));
  --gradient-card:         linear-gradient(155deg, hsl(224 35% 8%) 0%, hsl(225 32% 10%) 100%);
  --gradient-border:       linear-gradient(135deg, hsl(187 100% 50% / .6), hsl(296 100% 55% / .4));
  --glow-cyan:    0 0 20px hsl(187 100% 50% / .35), 0 0 40px hsl(187 100% 50% / .15);
  --glow-green:   0 0 14px hsl(135 100% 50% / .45);
  --glow-magenta: 0 0 20px hsl(296 100% 55% / .35);
}

/* Expose new tokens to Tailwind v4 utilities */
@theme inline {
  --color-primary: hsl(var(--primary));
  --color-accent:  hsl(var(--accent));
  --color-success: hsl(var(--success));
  --color-warning: hsl(var(--warning));
  --color-destructive: hsl(var(--destructive));
  --color-card: hsl(var(--card));
  --color-surface-3: hsl(var(--surface-3));
  --color-background: var(--background);
  --color-border: var(--border);
}

/* Components ported from Cybernetic Command */
.cyber-card {
  background: var(--gradient-card);
  border: 1px solid hsl(222 35% 18%);
  border-radius: 1rem;
  position: relative;
  overflow: hidden;
  box-shadow: 0 4px 16px hsl(0 0% 0% / .55), inset 0 1px 0 hsl(0 0% 100% / .04);
}
.cyber-card-glow {
  background: var(--gradient-card);
  border: 1px solid hsl(222 35% 18%);
  border-radius: 1rem;
  box-shadow: 0 4px 16px hsl(0 0% 0% / .55), 0 0 18px hsl(187 100% 50% / .12), inset 0 1px 0 hsl(0 0% 100% / .05);
}
.cyber-border-grad { position: relative; }
.cyber-border-grad::before {
  content: ''; position: absolute; inset: 0; border-radius: inherit; padding: 1px;
  background: var(--gradient-border);
  -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
  -webkit-mask-composite: xor; mask-composite: exclude; pointer-events: none;
}
.label-mono {
  font-family: var(--font-mono);
  text-transform: uppercase;
  letter-spacing: 0.2em;
  font-size: 0.55rem;
  color: hsl(var(--muted-foreground, 222 15% 55%));
}
.stat-number { font-family: var(--font-mono); font-weight: 700; font-variant-numeric: tabular-nums; }
.pressable { transition: transform .15s ease; }
.pressable:active { transform: scale(.97); }
.glow-text-cyan    { color: hsl(187 100% 50%); text-shadow: 0 0 12px hsl(187 100% 50% / .55); }
.glow-text-green   { color: hsl(135 100% 50%); text-shadow: var(--glow-green); }
.glow-text-magenta { color: hsl(296 100% 55%); text-shadow: var(--glow-magenta); }
.glow-text-warning { color: hsl(38 100% 55%);  text-shadow: 0 0 14px hsl(38 100% 50% / .45); }
.no-scrollbar::-webkit-scrollbar { display: none; }
.no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }

/* Abyss / observatory theme used by ConnectionTab */
.abyss-bg {
  background:
    radial-gradient(ellipse at 20% 0%, hsl(190 90% 22% / .55), transparent 55%),
    radial-gradient(ellipse at 80% 18%, hsl(280 70% 30% / .35), transparent 60%),
    radial-gradient(ellipse at 50% 110%, hsl(170 80% 18% / .6), transparent 60%),
    linear-gradient(180deg, #02060b 0%, #03101a 45%, #010407 100%);
}
.abyss-card {
  background:
    radial-gradient(120% 80% at 50% 0%, hsl(180 80% 40% / .12), transparent 60%),
    linear-gradient(180deg, hsl(200 60% 10% / .75), hsl(210 70% 6% / .85));
  border: 1px solid hsl(180 70% 45% / .25);
  border-radius: 28px;
  box-shadow:
    inset 0 1px 0 hsl(180 90% 70% / .08),
    inset 0 0 40px hsl(190 100% 50% / .05),
    0 20px 50px -20px hsl(190 100% 40% / .35);
}
.biolume-text  { color: hsl(170 100% 78%); text-shadow: 0 0 10px hsl(170 100% 55% / .65); }
.biolume-pink  { color: hsl(320 100% 80%); text-shadow: 0 0 10px hsl(320 100% 60% / .7); }
.caustics::before{
  content:""; position:absolute; inset:0; pointer-events:none; mix-blend-mode:screen; opacity:.18;
  background:
    repeating-linear-gradient(115deg, transparent 0 18px, hsl(180 100% 70% /.35) 18px 19px, transparent 19px 60px),
    repeating-linear-gradient(65deg,  transparent 0 24px, hsl(200 100% 75% /.25) 24px 25px, transparent 25px 80px);
  background-size: 200% 100%, 200% 100%;
  animation: caustic-shift 18s linear infinite;
}

/* Animations */
@keyframes fade-in       { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }
@keyframes blink         { 0%,100% { opacity: 1; } 50% { opacity: .25; } }
@keyframes pulse-glow    { 0%,100% { box-shadow: 0 0 10px hsl(187 100% 50% / .35); } 50% { box-shadow: 0 0 24px hsl(187 100% 50% / .65); } }
@keyframes scan          { 0% { transform: translateY(-100%); } 100% { transform: translateY(300%); } }
@keyframes spring-up     { 0% { opacity: 0; transform: translateY(20px) scale(.96); } 100% { opacity: 1; transform: none; } }
@keyframes sonar-pulse   { 0% { transform: scale(.6); opacity: .9; } 100% { transform: scale(2.4); opacity: 0; } }
@keyframes lure-flicker  { 0%,100% { opacity: 1; } 50% { opacity: .55; } }
@keyframes jelly-pulse   { 0%,100% { transform: scaleY(1) translateY(0); } 50% { transform: scaleY(.78) translateY(6px); } }
@keyframes sway          { 0%,100% { transform: translateX(-6px) rotate(-2deg); } 50% { transform: translateX(6px) rotate(2deg); } }
@keyframes caustic-shift { 0% { background-position: 0% 0%, 100% 0%; } 100% { background-position: 200% 0%, -200% 0%; } }

.animate-fade-in    { animation: fade-in .35s ease-out both; }
.animate-blink      { animation: blink 1.2s ease-in-out infinite; }
.animate-pulse-glow { animation: pulse-glow 2.4s ease-in-out infinite; }
.animate-scan       { animation: scan 4s linear infinite; }
.animate-spring-up  { animation: spring-up .35s cubic-bezier(.2,.9,.3,1.2) both; }

/* ─────────────────────────────────────────────────────────────
   Ported from butler_ai_chatbox.html — premium chat shell:
   top accent gradient line, bottom faint line, slow scan-line,
   and a pulsing left side-glow rail. Composes with panel-cyber.
   ───────────────────────────────────────────────────────────── */
@utility chat-shell {
  position: relative;
  overflow: hidden;
  background: linear-gradient(135deg, #0d1523 0%, #091018 60%, #07101a 100%);
  border: 1.5px solid #1e3048;
  box-shadow:
    0 0 0 1px #0a1928,
    0 4px 40px rgba(0,0,0,0.55),
    inset 0 1px 0 rgba(255,255,255,0.04);

  &::before {
    content: ""; position: absolute; top: 0; left: 0; right: 0; height: 1px;
    background: linear-gradient(90deg, transparent 0%, #1e4060 20%, var(--cyan) 50%, #1e4060 80%, transparent 100%);
    opacity: .85; pointer-events: none;
  }
  &::after {
    content: ""; position: absolute; bottom: 0; left: 0; right: 0; height: 1px;
    background: linear-gradient(90deg, transparent 0%, #0e2535 50%, transparent 100%);
    pointer-events: none;
  }
}
@utility chat-rail {
  position: absolute; left: 0; top: 0; bottom: 0; width: 3px;
  background: linear-gradient(180deg, transparent, var(--cyan), transparent);
  opacity: .5; pointer-events: none;
  animation: pulse-glow 3s ease-in-out infinite;
}
@utility chat-scan {
  position: absolute; left: 0; top: -60px; width: 100%; height: 60px;
  background: linear-gradient(180deg, transparent 0%, rgba(0,160,255,0.06) 50%, transparent 100%);
  pointer-events: none;
  animation: chat-scan-down 6s linear infinite;
}
@keyframes chat-scan-down {
  0%   { top: -60px; }
  100% { top: 100%; }
}

/* ─────────────────────────────────────────────────────────────
   Ported from tools_hub_1.html — NCX cards, drop zones, PC screen,
   tool tiles. Composes with panel-cyber when desired but works alone.
   ───────────────────────────────────────────────────────────── */
@utility ncx-card {
  position: relative;
  border-radius: 14px;
  border: 1.5px solid color-mix(in oklab, var(--c, var(--cyan)) 50%, transparent);
  background: linear-gradient(135deg,
    color-mix(in oklab, var(--c, var(--cyan)) 6%, #050a14) 0%,
    #060d14 100%);
  box-shadow:
    0 0 20px -6px color-mix(in oklab, var(--c, var(--cyan)) 35%, transparent),
    inset 0 0 30px -18px color-mix(in oklab, var(--c, var(--cyan)) 60%, transparent);
  overflow: hidden;
  display: flex; flex-direction: column;
}
@utility ncx-card-top {
  position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, transparent, var(--c, var(--cyan)), transparent);
  pointer-events: none;
}
@utility drop-zone {
  border: 1.5px dashed color-mix(in oklab, var(--c, var(--cyan)) 35%, transparent);
  border-radius: 10px;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 18px 10px; min-height: 130px; text-align: center;
  background: color-mix(in oklab, var(--c, var(--cyan)) 3%, transparent);
  transition: background .15s, border-color .15s, transform .1s;
  cursor: pointer;
}
.drop-zone:hover { background: color-mix(in oklab, var(--c, var(--cyan)) 8%, transparent); border-color: var(--c, var(--cyan)); }
.drop-zone:active { transform: scale(.985); }
.drop-zone[data-has-file="true"] { background: color-mix(in oklab, var(--c, var(--cyan)) 10%, transparent); border-color: var(--c, var(--cyan)); }

@utility pc-screen {
  position: relative; border-radius: 12px;
  background: linear-gradient(135deg, #04070d 0%, #060a13 100%);
  border: 1px solid color-mix(in oklab, var(--cyan) 30%, var(--border));
  min-height: 180px;
  display: flex; align-items: center; justify-content: center;
  overflow: hidden;
}
.pc-screen::before {
  content: ""; position: absolute; inset: 0; pointer-events: none;
  background: repeating-linear-gradient(0deg, transparent 0 2px, color-mix(in oklab, var(--cyan) 4%, transparent) 2px 3px);
  opacity: .5;
}
.pc-screen-corner {
  position: absolute; width: 12px; height: 12px;
  border: 1.5px solid var(--cyan);
  filter: drop-shadow(0 0 4px color-mix(in oklab, var(--cyan) 70%, transparent));
}
.pc-screen-corner.tl { top: 8px; left: 8px; border-right: 0; border-bottom: 0; }
.pc-screen-corner.tr { top: 8px; right: 8px; border-left: 0; border-bottom: 0; }
.pc-screen-corner.bl { bottom: 8px; left: 8px; border-right: 0; border-top: 0; }
.pc-screen-corner.br { bottom: 8px; right: 8px; border-left: 0; border-top: 0; }

@utility tool-tile {
  position: relative;
  border-radius: 10px;
  border: 1px solid color-mix(in oklab, var(--c, var(--cyan)) 35%, var(--border));
  background: linear-gradient(135deg,
    color-mix(in oklab, var(--c, var(--cyan)) 5%, #050a13) 0%,
    #060a12 100%);
  padding: 12px 8px; display: flex; flex-direction: column; align-items: center; gap: 4px;
  cursor: pointer; transition: transform .1s, border-color .15s, background .15s;
  text-align: center;
}
.tool-tile:hover { border-color: var(--c, var(--cyan)); background: color-mix(in oklab, var(--c, var(--cyan)) 10%, #060a12); }
.tool-tile:active { transform: scale(.97); }

@utility ncx-btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  padding: 9px 10px; border-radius: 8px;
  border: 1px solid color-mix(in oklab, var(--c, var(--cyan)) 45%, transparent);
  background: color-mix(in oklab, var(--c, var(--cyan)) 12%, transparent);
  color: var(--c, var(--cyan));
  font-family: var(--font-mono); font-size: 11px; letter-spacing: 1px;
  text-transform: uppercase; cursor: pointer;
  transition: background .12s, transform .08s;
}
.ncx-btn:hover { background: color-mix(in oklab, var(--c, var(--cyan)) 20%, transparent); }
.ncx-btn:active { transform: scale(.96); }
.ncx-btn-ghost {
  border-color: var(--border);
  background: rgba(255,255,255,.03);
  color: color-mix(in oklab, var(--foreground) 70%, transparent);
}

```


### `/tsconfig.json`

```json path=/tsconfig.json
{
  "include": ["src/**/*.ts", "src/**/*.tsx", "vite.config.ts", "eslint.config.js"],
  "compilerOptions": {
    "target": "ES2022",
    "jsx": "react-jsx",
    "module": "ESNext",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "types": ["vite/client"],

    /* Bundler mode */
    "moduleResolution": "Bundler",
    "allowImportingTsExtensions": true,
    "verbatimModuleSyntax": false,
    "noEmit": true,

    /* Linting */
    "skipLibCheck": true,
    "strict": true,
    "noUnusedLocals": false,
    "noUnusedParameters": false,
    "noFallthroughCasesInSwitch": true,
    "noUncheckedSideEffectImports": true,
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}

```


### `/twa-manifest.json`

```json path=/twa-manifest.json
{
  "packageId": "REPLACE_WITH_YOUR_PACKAGE_ID",
  "host": "REPLACE_WITH_YOUR_PUBLISHED_DOMAIN",
  "name": "Butler AI",
  "launcherName": "Butler AI",
  "display": "standalone",
  "orientation": "portrait",
  "themeColor": "#22c55e",
  "navigationColor": "#05080d",
  "backgroundColor": "#05080d",
  "enableNotifications": false,
  "startUrl": "/",
  "iconUrl": "https://REPLACE_WITH_YOUR_PUBLISHED_DOMAIN/icon-512.png",
  "maskableIconUrl": "https://REPLACE_WITH_YOUR_PUBLISHED_DOMAIN/icon-512.png",
  "appVersionName": "1.0.0",
  "appVersionCode": 1,
  "signingKey": {
    "path": "./android.keystore",
    "alias": "android"
  },
  "shortcuts": [],
  "generatorApp": "bubblewrap-cli",
  "webManifestUrl": "https://REPLACE_WITH_YOUR_PUBLISHED_DOMAIN/manifest.webmanifest",
  "fallbackType": "customtabs",
  "features": {},
  "alphaDependencies": { "enabled": false },
  "enableSiteSettingsShortcut": true,
  "isChromeOSOnly": false,
  "isMetaQuest": false,
  "fullScopeUrl": "https://REPLACE_WITH_YOUR_PUBLISHED_DOMAIN/",
  "minSdkVersion": 21,
  "orientation": "portrait"
}

```


### `/vite.config.ts`

```ts path=/vite.config.ts
// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
});

```
