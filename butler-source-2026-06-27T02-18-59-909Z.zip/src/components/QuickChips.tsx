import { memo } from "react";
import {
  Zap, Trash2, HeartPulse, Clock, HardDrive, ShieldCheck,
  Cpu, Network, Bug, Globe, FileText, Wand2,
  type LucideIcon,
} from "lucide-react";

export type QuickChip = {
  icon: LucideIcon;
  label: string;
  prompt: string;
  color?: string;
};

/** Cyberpunk-pill version of the original NexusQuickChips (RN → web port). */
export const NEXUS_CHIPS: QuickChip[] = [
  { icon: Zap,        label: "FIX MY PC",     prompt: "Diagnose what's making my PC slow and write a Python script that fixes the top 3 issues without admin rights.", color: "var(--magenta)" },
  { icon: Trash2,     label: "CLEAN TEMP",    prompt: "Write a safe Python script that clears %TEMP%, Windows cache, and the recycle bin — and reports how many MB it freed.", color: "var(--cyan)" },
  { icon: HeartPulse, label: "PC HEALTH",     prompt: "Run a full PC health check: CPU/RAM/disk pressure, top processes by RAM, disk free %, network latency. Output a one-page summary.", color: "var(--green)" },
  { icon: Clock,      label: "SCHEDULE",      prompt: "Help me schedule a daily task at 9am — open my work apps and mute Discord. Use Windows Task Scheduler from Python.", color: "var(--orange)" },
  { icon: HardDrive,  label: "BACKUP",        prompt: "Write a Python backup script for my Documents folder to an external drive — incremental, zipped, timestamped.", color: "var(--cyan)" },
  { icon: ShieldCheck,label: "SECURITY",      prompt: "Audit my PC's security posture from Python: open ports, firewall state, Windows Update status, BitLocker, antivirus.", color: "var(--red)" },
  { icon: Cpu,        label: "WHY CPU SPIKE", prompt: "My CPU spikes when idle. Sample CPU usage every second for 60s and print the top 5 offending processes with PIDs.", color: "var(--magenta)" },
  { icon: Network,    label: "LAN SCAN",      prompt: "Scan my LAN for live hosts and open ports (22/80/443/3389). Pure-Python, no nmap.", color: "var(--green)" },
  { icon: Bug,        label: "FIND DUPES",    prompt: "Find duplicate files in my Downloads folder by MD5 hash and group them, oldest kept.", color: "var(--orange)" },
  { icon: Globe,      label: "SCRAPE NEWS",   prompt: "Scrape today's top headlines from 3 tech RSS feeds and pretty-print them.", color: "var(--cyan)" },
  { icon: FileText,   label: "PDF → TXT",     prompt: "Convert every PDF in a folder to .txt using pure Python. Show progress.", color: "var(--green)" },
  { icon: Wand2,      label: "WRITE SCRIPT",  prompt: "Ask me 1-2 quick clarifying questions, then write a complete Python script. Include pip-install line + comments.", color: "var(--magenta)" },
];

export const QuickChips = memo(function QuickChips({
  chips = NEXUS_CHIPS,
  onPick,
  header = "QUICK CHIPS",
}: { chips?: QuickChip[]; onPick: (prompt: string) => void; header?: string }) {
  return (
    <div className="mt-1">
      {header && (
        <div className="mb-1 flex items-center gap-1.5 px-1">
          <span className="h-1 w-1 rounded-full bg-[color:var(--cyan)] pulse-dot" />
          <span className="font-display text-[8.5px] font-extrabold tracking-[0.32em] text-foreground/55">{header}</span>
        </div>
      )}
      <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1"
           style={{ scrollbarWidth: "none" }}>
        {chips.map((c, i) => {
          const Icon = c.icon;
          const accent = c.color ?? "var(--cyan)";
          return (
            <button key={i}
              onClick={() => onPick(c.prompt)}
              className="hex-tab shrink-0 flex-row gap-1.5 px-2.5"
              style={{ ["--c" as any]: accent }}>
              <Icon className="h-3.5 w-3.5" />
              <span className="font-display text-[9px] font-extrabold tracking-[0.2em]">{c.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
});
