import type { ReactNode } from "react";

export function SectionPanel({
  title, icon, children, action, strong, color = "cyan",
}: {
  title?: string;
  icon?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
  strong?: boolean;
  color?: "cyan" | "violet" | "green" | "amber" | "red";
}) {
  const cls = color === "violet" ? "c-violet" : color === "green" ? "c-green" : color === "amber" ? "c-amber" : color === "red" ? "c-red" : "";
  const tone = color === "violet" ? "magenta" : color === "amber" ? "orange" : color;
  return (
    <section className={`panel-cyber ${cls} ${strong ? "panel-strong" : ""} p-4`}>
      {title ? (
        <header className="mb-3 flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2" style={{ color: `var(--${tone})` }}>
            {icon ? <span className="shrink-0">{icon}</span> : null}
            <h2 className="truncate font-display text-[11px] font-bold uppercase tracking-[0.22em]" style={{ textShadow: `0 0 8px var(--${tone})` }}>{title}</h2>
          </div>
          {action ? <div className="shrink-0">{action}</div> : null}
        </header>
      ) : null}
      {children}
    </section>
  );
}
