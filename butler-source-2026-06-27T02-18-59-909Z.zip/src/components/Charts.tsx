/**
 * Charts — zero-dep SVG/CSS charts ported from the CommandCube RN sources.
 *
 * Web ports of:
 *   AreaSparkline · MiniBarChart · ActivityBarChart · CircRing
 *   StorageDonut · DiskProgressBar · MetricLineChart · DomainBreakdownChart
 *   ThreatHeatmap · DataStatCard
 *
 * All animation-free (no JS loops / requestAnimationFrame) — pure CSS gradients
 * and static SVG so the cyberpunk shell stays lag-free on low-end phones.
 */
import { useMemo } from "react";

/* ────────────────────────────── AREA SPARKLINE BARS ─ */
export function AreaSparkline({ points, color, height = 60 }: { points: number[]; color: string; height?: number }) {
  const max = Math.max(1, ...points);
  return (
    <div className="flex items-end gap-[1px] overflow-hidden" style={{ height }}>
      {points.map((p, i) => {
        const h = Math.max(3, (p / max) * (height - 4));
        const last = i === points.length - 1;
        const op = last ? 1 : 0.35 + (i / points.length) * 0.6;
        return (
          <div key={i} className="flex-1 rounded-[2px]"
            style={{
              height: h, background: color, opacity: op,
              boxShadow: last ? `0 0 8px ${color}` : undefined,
            }} />
        );
      })}
    </div>
  );
}

/* ────────────────────────────── MINI WEEKDAY BAR CHART ─ */
export function MiniBarChart({ data, color, label }: { data: { day: string; value: number }[]; color: string; label: string }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="space-y-1.5">
      <div className="font-mono text-[9px] tracking-widest text-foreground/55">{label}</div>
      <div className="flex h-14 items-end gap-1">
        {data.map((d, i) => {
          const h = Math.max(4, (d.value / max) * 48);
          return (
            <div key={i} className="flex flex-1 flex-col items-center gap-0.5">
              <div className="flex w-full flex-1 items-end justify-center">
                <div className="w-[80%] rounded-sm"
                  style={{ height: h, background: color, opacity: 0.55 + (i / data.length) * 0.45 }} />
              </div>
              <div className="font-mono text-[8px] text-foreground/55">{d.day}</div>
            </div>
          );
        })}
      </div>
      <div className="flex justify-between font-mono text-[8px]">
        <span className="text-foreground/55">0</span>
        <span style={{ color }}>{max}</span>
      </div>
    </div>
  );
}

/* ────────────────────────────── ACTIVITY BAR CHART (multi-color) ─ */
export function ActivityBarChart({ heights, palette }: { heights?: number[]; palette?: string[] }) {
  const H = heights ?? [45, 70, 30, 85, 55, 40, 75, 60, 50, 65, 42, 78];
  const P = palette ?? ["var(--cyan)", "var(--green)", "var(--magenta)", "var(--orange)", "var(--red)"];
  return (
    <div className="flex h-24 items-end justify-between gap-[3px]">
      {H.map((h, i) => {
        const c = P[i % P.length];
        return (
          <div key={i} className="w-3.5 rounded-sm"
            style={{ height: `${h}%`, background: c, opacity: 0.75 + (i % 3) * 0.08, boxShadow: `0 0 4px ${c}` }} />
        );
      })}
    </div>
  );
}

/* ────────────────────────────── CIRCULAR RING ─ */
export function CircRing({ label, pct, color, size = 84 }: { label: string; pct: number; color: string; size?: number }) {
  const r = (size - 14) / 2;
  const C = 2 * Math.PI * r;
  const dash = (pct / 100) * C;
  return (
    <div className="flex flex-col items-center gap-1.5">
      <div className="relative grid place-items-center" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth="7"
            stroke={`color-mix(in oklab, ${color} 18%, transparent)`} />
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth="7"
            stroke={color} strokeLinecap="round"
            strokeDasharray={`${dash} ${C}`}
            style={{ filter: `drop-shadow(0 0 6px ${color})` }} />
        </svg>
        <div className="absolute font-display font-black tabular-nums" style={{ color, fontSize: size * 0.22 }}>
          {Math.round(pct)}%
        </div>
      </div>
      <div className="font-mono text-[9px] tracking-widest text-foreground/55">{label}</div>
    </div>
  );
}

/* ────────────────────────────── STORAGE DONUT ─ */
export function StorageDonut({ slices, label, sub }: { slices: { color: string; pct: number; label: string }[]; label: string; sub: string }) {
  const segs: string[] = [];
  let acc = 0;
  for (const s of slices) {
    const start = (acc / 100) * 360;
    const end = ((acc + s.pct) / 100) * 360;
    segs.push(`${s.color} ${start}deg ${end}deg`);
    acc += s.pct;
  }
  if (acc < 100) segs.push(`color-mix(in oklab, var(--cyan) 8%, transparent) ${(acc / 100) * 360}deg 360deg`);
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="grid place-items-center rounded-full" style={{
        width: 110, height: 110,
        background: `conic-gradient(${segs.join(", ")})`,
        boxShadow: "0 0 14px color-mix(in oklab, var(--cyan) 30%, transparent)",
      }}>
        <div className="grid h-[78px] w-[78px] place-items-center rounded-full bg-[var(--ink)] border border-[color:var(--border)]">
          <div className="text-center leading-tight">
            <div className="font-display text-[16px] font-black text-foreground">{label}</div>
            <div className="font-mono text-[8px] tracking-widest text-foreground/55">{sub}</div>
          </div>
        </div>
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2">
        {slices.map((s) => (
          <div key={s.label} className="flex items-center gap-1">
            <div className="h-2 w-2 rounded-[2px]" style={{ background: s.color }} />
            <span className="font-mono text-[8.5px] tracking-widest text-foreground/65">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ────────────────────────────── DISK PROGRESS BAR ─ */
export function DiskProgressBar({ label, pct, color }: { label: string; pct: number; color: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="w-10 font-mono text-[10px] font-bold tracking-widest text-foreground/65">{label}</span>
      <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-[#15171c]">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color, boxShadow: `0 0 6px ${color}` }} />
      </div>
      <span className="w-10 text-right font-mono text-[11px] font-black tabular-nums" style={{ color }}>{pct}%</span>
    </div>
  );
}

/* ────────────────────────────── METRIC LINE CHART (SVG area + line) ─ */
export function MetricLineChart({ history, color, height = 64, width = 280, label }: {
  history: number[]; color: string; height?: number; width?: number; label: string;
}) {
  const pts = history.slice(-24);
  if (pts.length < 2) {
    return (
      <div className="grid place-items-center font-mono text-[9px] tracking-widest text-foreground/40" style={{ height }}>NO DATA</div>
    );
  }
  const max = Math.max(...pts, 1);
  const min = Math.min(...pts, 0);
  const range = Math.max(1, max - min);
  const step = width / (pts.length - 1);
  const y = (v: number) => height - ((v - min) / range) * (height - 8) - 4;
  const path = pts.map((v, i) => `${i === 0 ? "M" : "L"}${i * step},${y(v)}`).join(" ");
  const fill = `${path} L${(pts.length - 1) * step},${height} L0,${height} Z`;
  const id = `g_${label.replace(/\W/g, "")}`;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="block h-auto w-full">
      <defs>
        <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.45" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={fill} fill={`url(#${id})`} />
      <path d={path} fill="none" stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"
        style={{ filter: `drop-shadow(0 0 4px ${color})` }} />
      <circle cx={(pts.length - 1) * step} cy={y(pts[pts.length - 1])} r="2.6" fill={color}
        style={{ filter: `drop-shadow(0 0 6px ${color})` }} />
    </svg>
  );
}

/* ────────────────────────────── DOMAIN BREAKDOWN BARS ─ */
export function DomainBreakdownChart({ data }: { data: { domain: string; count: number; color: string }[] }) {
  const max = Math.max(1, ...data.map((d) => d.count));
  const CH = 88;
  return (
    <div className="flex items-end gap-2" style={{ height: CH }}>
      {data.slice(0, 8).map((d, i) => {
        const h = Math.max(3, (d.count / max) * (CH - 28));
        return (
          <div key={d.domain} className="flex flex-1 flex-col items-center justify-end gap-1" style={{ height: CH }}>
            <span className="font-mono text-[9px] font-bold tabular-nums" style={{ color: d.color }}>{d.count}</span>
            <div className="w-full rounded-sm"
              style={{ height: h, background: d.color, opacity: i === 0 ? 1 : 0.75, boxShadow: i === 0 ? `0 0 8px ${d.color}` : undefined }} />
            <span className="truncate font-mono text-[8px] font-bold tracking-wider" style={{ color: d.color }}>
              {d.domain.toUpperCase().slice(0, 6)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

/* ────────────────────────────── THREAT HEATMAP (cols × rows) ─ */
export function ThreatHeatmap({ cols = 14, rows = 3, color = "var(--red)", title = "THREAT HEATMAP" }: {
  cols?: number; rows?: number; color?: string; title?: string;
}) {
  const data = useMemo(
    () => Array.from({ length: cols * rows }, (_, i) => (Math.sin(i * 1.7) + 1) / 2),
    [cols, rows],
  );
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 font-mono text-[10px] tracking-widest" style={{ color }}>
        <span className="h-2 w-2 rounded-full" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
        <span className="font-display font-bold">{title}</span>
        <span className="text-foreground/40">· 7D</span>
      </div>
      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
        {data.map((v, i) => {
          const op = v > 0.75 ? 0.9 : v > 0.5 ? 0.55 : v > 0.3 ? 0.3 : 0.12;
          return <div key={i} className="aspect-square rounded-[3px]" style={{ background: color, opacity: op }} />;
        })}
      </div>
      <div className="flex items-center gap-1.5 border-t border-[color:var(--border)] pt-1.5 font-mono text-[8.5px] tracking-widest text-foreground/55">
        <span>LOW</span>
        {[0.12, 0.3, 0.55, 0.9].map((o, i) => (
          <span key={i} className="h-2.5 w-3 rounded-[2px]" style={{ background: color, opacity: o }} />
        ))}
        <span>HIGH</span>
      </div>
    </div>
  );
}

/* ────────────────────────────── DATA STAT CARD ─ */
export function DataStatCard({ title, subtitle, value, statusLabel, statusColor, color, sparkPoints, statRow }: {
  title: string; subtitle: string; value: string; statusLabel: string; statusColor: string; color: string;
  sparkPoints: number[]; statRow: { label: string; value: string }[];
}) {
  return (
    <div className="relative overflow-hidden rounded-md border border-[color:var(--border)] bg-[var(--ink-2)]"
      style={{ boxShadow: `0 6px 20px -10px ${color}` }}>
      <div className="h-[3px]" style={{ background: color }} />
      <div className="flex items-center gap-2.5 px-3 pb-1 pt-3">
        <div className="grid h-9 w-9 place-items-center rounded-md border"
          style={{ borderColor: `color-mix(in oklab, ${color} 40%, transparent)`, background: `color-mix(in oklab, ${color} 12%, transparent)`, color }}>
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 12a9 9 0 1 0 9-9" /><path d="M12 3v9l6 6" />
          </svg>
        </div>
        <div className="flex-1">
          <div className="font-display text-[13px] font-black tracking-wide text-foreground">{title}</div>
          <div className="font-mono text-[9px] tracking-widest text-foreground/55">{subtitle}</div>
        </div>
        <div className="flex items-center gap-1 rounded-md border px-1.5 py-0.5"
          style={{ borderColor: `color-mix(in oklab, ${statusColor} 55%, transparent)`, background: `color-mix(in oklab, ${statusColor} 12%, transparent)` }}>
          <span className="h-1.5 w-1.5 rounded-full pulse-dot" style={{ background: statusColor, boxShadow: `0 0 6px ${statusColor}` }} />
          <span className="font-mono text-[8.5px] font-bold tracking-widest" style={{ color: statusColor }}>{statusLabel}</span>
        </div>
      </div>
      <div className="px-3 font-display text-[40px] font-black leading-none tabular-nums" style={{ color, textShadow: `0 0 14px ${color}` }}>
        {value}
      </div>
      <div className="px-3 pb-2 pt-2">
        <AreaSparkline points={sparkPoints} color={color} height={48} />
      </div>
      <div className="flex border-t border-[color:var(--border)]">
        {statRow.map((s, i) => (
          <div key={i} className={`flex-1 px-3 py-2 ${i < statRow.length - 1 ? "border-r border-[color:var(--border)]" : ""}`}>
            <div className="font-mono text-[8px] font-bold tracking-widest text-foreground/55">{s.label}</div>
            <div className="font-display text-[13px] font-black text-foreground">{s.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
