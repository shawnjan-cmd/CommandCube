export function BarMeter({
  label, value, max = 100, unit = "%", color = "var(--cyan)", detail,
}: {
  label: string;
  value: number | null;
  max?: number;
  unit?: string;
  color?: string;
  detail?: string;
}) {
  const pct = typeof value === "number" ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  return (
    <div>
      <div className="flex items-baseline justify-between text-[11px] mb-1">
        <span className="font-display font-bold tracking-[0.14em] uppercase text-muted-foreground">{label}</span>
        <span className="font-mono tabular-nums font-bold" style={{ color }}>
          {typeof value === "number" ? `${Math.round(value)}${unit}` : "—"}
          {detail ? <span className="text-muted-foreground font-normal ml-1.5">· {detail}</span> : null}
        </span>
      </div>
      <div className="relative h-2.5 rounded-sm overflow-hidden border border-[color:var(--border)] bg-[rgba(77,217,255,0.04)]">
        <div
          className="absolute inset-y-0 left-0 transition-[width] duration-700"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(180deg, ${color} 0%, color-mix(in oklab, ${color} 60%, transparent) 100%)`,
            boxShadow: `0 0 12px ${color}, inset 0 1px 0 rgba(255,255,255,0.25)`,
          }}
        />
        <div className="absolute inset-y-0 left-0 w-full pointer-events-none"
          style={{
            backgroundImage: "repeating-linear-gradient(90deg, rgba(255,255,255,0.05) 0 1px, transparent 1px 8px)",
          }}
        />
      </div>
    </div>
  );
}
