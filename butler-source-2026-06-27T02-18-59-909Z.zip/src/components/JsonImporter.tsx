import { useEffect, useRef, useState } from "react";
import { Upload, Check, AlertTriangle, FileJson, Download, RotateCcw, Palette, Undo2, FileText, ClipboardCopy, Package } from "lucide-react";
import { toast } from "sonner";
import { loadStored as loadStoredTheme, clearTheme, downloadJson } from "@/lib/themeOverrides";
import {
  importMasterFromText,
  masterTemplate,
  exportCurrentMaster,
  AI_UPGRADE_PROMPT,
  hasUndo,
  undoLast,
  LAST_APPLIED_KEY,
} from "@/lib/appOverrides";

type LastApplied = {
  ts: number;
  source: "json" | "markdown";
  appliedTheme: number;
  appliedText: number;
  appliedFiles: number;
  appliedData: number;
  fileList: string[];
} | null;

/**
 * Master uploader: accepts JSON or Markdown (filename ignored).
 * Auto-applies theme + text + file/data overrides, snapshots previous state,
 * exposes a one-step UNDO, and soft-reloads so changes are visible immediately.
 */
export function JsonImporter() {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [hasTheme, setHasTheme] = useState(false);
  const [canUndo, setCanUndo] = useState(false);
  const [last, setLast] = useState<LastApplied>(null);

  const refreshState = () => {
    setHasTheme(!!loadStoredTheme());
    setCanUndo(hasUndo());
    try {
      const raw = localStorage.getItem(LAST_APPLIED_KEY);
      setLast(raw ? JSON.parse(raw) : null);
    } catch { setLast(null); }
  };

  useEffect(() => {
    refreshState();
    const h = () => refreshState();
    window.addEventListener("butler:master-applied", h);
    return () => window.removeEventListener("butler:master-applied", h);
  }, []);

  const onFile = async (file: File) => {
    setBusy(true); setError(null);
    try {
      const txt = await file.text();
      const r = importMasterFromText(txt, { autoReload: true });
      if (!r.ok) throw new Error(r.error || "Apply failed");
      const total = r.appliedTheme + r.appliedText + r.appliedFiles + r.appliedData;
      toast.success(
        `Applied ${total} change${total === 1 ? "" : "s"} from ${r.source.toUpperCase()} · refreshing…`,
      );
      refreshState();
    } catch (e: any) {
      setError(e?.message ?? "Failed to parse file");
      toast.error(e?.message ?? "Failed to parse file");
    } finally { setBusy(false); }
  };

  const downloadMasterTemplate = () => {
    downloadJson(`butler_master_${Date.now()}.json`, masterTemplate());
    toast.success("Master template downloaded — edit and re-upload");
  };

  const exportCurrent = () => {
    downloadJson(`butler_master_current_${Date.now()}.json`, exportCurrentMaster());
    toast.success("Current master exported — edit offline and re-upload");
  };

  const copyAiPrompt = async () => {
    try {
      await navigator.clipboard.writeText(AI_UPGRADE_PROMPT);
      toast.success("AI upgrade prompt copied to clipboard");
    } catch {
      // Fallback for older browsers / insecure contexts
      const ta = document.createElement("textarea");
      ta.value = AI_UPGRADE_PROMPT;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand("copy"); toast.success("AI upgrade prompt copied"); }
      catch { toast.error("Clipboard blocked — long-press to select manually"); }
      finally { document.body.removeChild(ta); }
    }
  };

  const onUndo = () => {
    const r = undoLast();
    if (!r.ok) { toast.error(r.error ?? "Undo failed"); return; }
    toast.success("Reverted to previous state · refreshing…");
    setTimeout(() => window.location.reload(), 300);
  };

  const onResetTheme = () => {
    clearTheme();
    toast.success("Theme reset to defaults");
    refreshState();
  };

  return (
    <div className="space-y-2">
      <input
        ref={inputRef}
        type="file"
        /* accept ANY file — detection is content-based */
        accept="*/*"
        className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f) void onFile(f); }}
      />

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => inputRef.current?.click()}
          className="panel-cyber lift flex w-full items-center justify-center gap-2 px-3 py-2.5 font-display text-[11px] font-extrabold tracking-[0.22em] text-cyan"
          style={{ ["--c" as any]: "var(--cyan)" }}>
          <Upload className="h-3.5 w-3.5" /> UPLOAD MASTER
        </button>
        <button
          onClick={downloadMasterTemplate}
          className="panel-cyber lift flex w-full items-center justify-center gap-2 px-3 py-2.5 font-display text-[11px] font-extrabold tracking-[0.22em] text-magenta"
          style={{ ["--c" as any]: "var(--magenta)" }}>
          <Download className="h-3.5 w-3.5" /> MASTER TEMPLATE
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={exportCurrent}
          className="panel-cyber lift flex w-full items-center justify-center gap-2 px-3 py-2.5 font-display text-[11px] font-extrabold tracking-[0.22em] text-[color:var(--green)]"
          style={{ ["--c" as any]: "var(--green)" }}>
          <Package className="h-3.5 w-3.5" /> EXPORT CURRENT MASTER
        </button>
        <button
          onClick={copyAiPrompt}
          className="panel-cyber lift flex w-full items-center justify-center gap-2 px-3 py-2.5 font-display text-[11px] font-extrabold tracking-[0.22em] text-[color:var(--orange)]"
          style={{ ["--c" as any]: "var(--orange)" }}>
          <ClipboardCopy className="h-3.5 w-3.5" /> COPY AI UPGRADE PROMPT
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={onUndo}
          disabled={!canUndo}
          className="flex w-full items-center justify-center gap-2 rounded border border-[color:var(--border)] bg-[var(--ink-2)] px-3 py-1.5 font-mono text-[10px] tracking-[0.22em] text-foreground/80 hover:text-[color:var(--orange)] disabled:opacity-40">
          <Undo2 className="h-3 w-3" /> UNDO LAST UPLOAD
        </button>
        {hasTheme && (
          <button
            onClick={onResetTheme}
            className="flex w-full items-center justify-center gap-2 rounded border border-[color:var(--border)] bg-[var(--ink-2)] px-3 py-1.5 font-mono text-[10px] tracking-[0.22em] text-foreground/70 hover:text-[color:var(--red)]">
            <RotateCcw className="h-3 w-3" /> RESET THEME
          </button>
        )}
      </div>

      <p className="font-mono text-[9.5px] leading-snug text-foreground/55">
        Accepts <span className="text-cyan">.json</span> or <span className="text-magenta">.md</span> (filename ignored).
        Auto-detects theme · text · files · data and applies live. Snapshots previous state — use{" "}
        <span className="text-[color:var(--orange)]">UNDO</span> to revert the last upload.
      </p>

      {busy && <div className="font-mono text-[10px] tracking-widest text-foreground/55">parsing…</div>}

      {error && (
        <div className="flex items-center gap-2 rounded border border-[color:var(--red)]/50 bg-[color:var(--red)]/10 px-2 py-1.5 font-mono text-[10.5px] text-[color:var(--red)]">
          <AlertTriangle className="h-3.5 w-3.5" /> {error}
        </div>
      )}

      {last && (
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 rounded border border-[color:var(--green)]/40 bg-[color:var(--green)]/10 px-2 py-1.5">
            <Check className="h-3.5 w-3.5 text-[color:var(--green)]" />
            <span className="font-mono text-[10.5px] text-foreground/90">
              Last applied · {new Date(last.ts).toLocaleTimeString()} · {last.source.toUpperCase()}
            </span>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            <Pill label="THEME" value={String(last.appliedTheme)} icon={<Palette className="h-3 w-3" />} />
            <Pill label="TEXT"  value={String(last.appliedText)}  icon={<FileText className="h-3 w-3" />} />
            <Pill label="FILES" value={String(last.appliedFiles)} icon={<FileJson className="h-3 w-3" />} />
            <Pill label="DATA"  value={String(last.appliedData)}  icon={<FileJson className="h-3 w-3" />} />
          </div>
          {last.fileList.length > 0 && (
            <div className="rounded border border-[color:var(--border)] bg-[var(--ink)] p-2">
              <div className="mb-1 font-display text-[9px] font-extrabold tracking-[0.22em] text-cyan">
                FILE OVERRIDES
              </div>
              <ul className="space-y-0.5 font-mono text-[10px] text-foreground/70 max-h-32 overflow-auto">
                {last.fileList.map((f) => <li key={f} className="truncate">· {f}</li>)}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Pill({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div className="rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5 text-center">
      <div className="flex items-center justify-center gap-1 font-display text-[12px] font-black text-cyan">
        {icon}{value}
      </div>
      <div className="font-mono text-[8px] tracking-widest text-foreground/45">{label}</div>
    </div>
  );
}
