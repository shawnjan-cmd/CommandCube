import { useEffect, useMemo, useRef, useState } from "react";
import { Activity, Cpu, HardDrive, Database, Zap, Radio, Brain, Network } from "lucide-react";

function freezeLiveFx() {
  if (typeof window === "undefined") return false;
  const nav = navigator as Navigator & { connection?: { saveData?: boolean } };
  return Boolean(
    nav.connection?.saveData ||
    window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ||
    window.matchMedia?.("(pointer: coarse)").matches ||
    window.matchMedia?.("(max-width: 640px)").matches,
  );
}

/* ============================================================
   Live data sourced/derived from the uploaded Butler AI exports:
   - butler_ai_config_1.json   → scripts roster + security/connection
   - butler_ai_MASTER_v15_0... → palette + tab persona names
   - butler_master_*           → server/HMAC facts
   ============================================================ */

export const BUTLER_SCRIPTS = [
  { id: 1, name: "System Monitor", status: "active",  interval: "1s",            icon: Activity, color: "green"   as const },
  { id: 2, name: "Web Crawler",    status: "idle",    interval: "—",             icon: Radio,    color: "cyan"    as const },
  { id: 3, name: "File Sync",      status: "waiting", interval: "bidirectional", icon: Database, color: "yellow"  as const },
  { id: 4, name: "Brain Trainer",  status: "ready",   interval: "epoch 0",       icon: Brain,    color: "magenta" as const },
];

/* ---------- Live sparkline (CPU / RAM / NET) ---------- */
export function LiveSparkline({
  label, color, base = 32, jitter = 18, unit = "%", icon: Icon,
}: { label: string; color: "cyan"|"green"|"magenta"|"orange"|"yellow"; base?: number; jitter?: number; unit?: string; icon: typeof Cpu }) {
  // SSR-safe: start with deterministic sine wave, then animate client-side
  const [pts, setPts] = useState<number[]>(() =>
    Array.from({ length: 40 }, (_, i) => base + Math.sin(i * 0.35) * (jitter / 2))
  );
  useEffect(() => {
    if (freezeLiveFx()) return;
    setPts(Array.from({ length: 40 }, () => base + (Math.random() - 0.5) * jitter));
    const t = window.setInterval(() => {
      setPts((p) => {
        const next = Math.max(2, Math.min(98, p[p.length - 1] + (Math.random() - 0.5) * 14));
        return [...p.slice(1), next];
      });
    }, 1200);
    return () => window.clearInterval(t);
  }, [base, jitter]);
  const max = 100;
  const w = 100, h = 32;
  const d = pts
    .map((y, i) => `${i === 0 ? "M" : "L"} ${(i / (pts.length - 1)) * w} ${h - (y / max) * h}`)
    .join(" ");
  const last = pts[pts.length - 1].toFixed(0);
  return (
    <div className={`panel relative overflow-hidden p-3 glow-${color}`}>
      <div className="flex items-center justify-between">
        <div className={`flex items-center gap-1.5 text-[10px] tracking-widest text-${color}`}>
          <Icon className="h-3 w-3" /> {label}
        </div>
        <div className={`font-mono text-sm font-bold text-${color}`}>{last}{unit}</div>
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="mt-1.5 h-10 w-full">
        <defs>
          <linearGradient id={`grad-${label}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={`var(--${color})`} stopOpacity=".6" />
            <stop offset="100%" stopColor={`var(--${color})`} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={`${d} L ${w} ${h} L 0 ${h} Z`} fill={`url(#grad-${label})`} />
        <path d={d} fill="none" stroke={`var(--${color})`} strokeWidth="1.2" />
      </svg>
    </div>
  );
}

/* ---------- Telemetry grid for HOME tour ---------- */
export function TelemetryGrid() {
  return (
    <div className="grid grid-cols-3 gap-2">
      <LiveSparkline label="CPU"  color="cyan"    icon={Cpu}      base={28} />
      <LiveSparkline label="RAM"  color="magenta" icon={HardDrive} base={54} />
      <LiveSparkline label="NET"  color="green"   icon={Network}   base={12} unit="MB" />
    </div>
  );
}

/* ---------- Scripts roster sourced from butler_ai_config_1 ---------- */
export function ScriptsRoster() {
  const [pulse, setPulse] = useState(0);
  useEffect(() => {
    if (freezeLiveFx()) return;
    const t = setInterval(() => setPulse((p) => p + 1), 1400);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="panel-cyber overflow-hidden p-2">
      <div className="flex items-center justify-between px-1 pb-1">
        <span className="text-[10px] tracking-widest text-muted-foreground">SCRIPTS · v6.0 ROSTER</span>
        <span className="text-[10px] tracking-widest text-green">{BUTLER_SCRIPTS.length} LOADED</span>
      </div>
      <ul className="divide-y divide-border/40">
        {BUTLER_SCRIPTS.map((s, i) => {
          const Icon = s.icon;
          const live = s.status === "active" && pulse % 2 === 0;
          return (
            <li key={s.id} className="flex items-center gap-3 px-1 py-2">
              <div className={`grid h-8 w-8 place-items-center rounded-md border border-${s.color}/40 bg-${s.color}/5 text-${s.color}`}>
                <Icon className="h-3.5 w-3.5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className={`text-xs font-bold tracking-wider text-${s.color}`}>{s.name}</div>
                <div className="text-[10px] tracking-widest text-muted-foreground">id:{s.id} · {s.interval}</div>
              </div>
              <span className={`flex items-center gap-1 rounded border border-${s.color}/40 bg-${s.color}/10 px-1.5 py-0.5 font-mono text-[9px] tracking-widest text-${s.color}`}>
                <span className={`h-1.5 w-1.5 rounded-full bg-${s.color} ${live ? "pulse-dot" : ""}`} />
                {s.status.toUpperCase()}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/* ---------- SIGMA-NET knowledge graph (animated nodes) ---------- */
export function SigmaNetGraph() {
  // SSR-safe deterministic seed (golden-angle scatter), randomised on mount
  const [nodes, setNodes] = useState(() =>
    Array.from({ length: 14 }, (_, i) => {
      const a = i * 2.399; const r = 6 + (i % 5) * 3;
      return { id: i, x: 50 + Math.cos(a) * r * 3, y: 50 + Math.sin(a) * r * 3, r: 1.8 + (i % 3) * 0.6 };
    })
  );
  useEffect(() => {
    if (freezeLiveFx()) return;
    setNodes(Array.from({ length: 14 }, (_, i) => ({
      id: i, x: 10 + Math.random() * 80, y: 10 + Math.random() * 80, r: 1.6 + Math.random() * 2.2,
    })));
  }, []);
  const edges = useMemo(() => {
    const out: [number, number][] = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y;
        if (Math.hypot(dx, dy) < 28) out.push([i, j]);
      }
    }
    return out;
  }, [nodes]);
  return (
    <div className="panel-cyber relative overflow-hidden p-3 glow-cyan">
      <div className="flex items-center justify-between">
        <span className="text-[10px] tracking-widest text-cyan">SIGMA-NET · LOCAL KB</span>
        <span className="text-[10px] tracking-widest text-muted-foreground">{nodes.length} nodes · {edges.length} edges</span>
      </div>
      <svg viewBox="0 0 100 100" className="mt-2 h-32 w-full">
        {edges.map(([a, b], i) => (
          <line key={i} x1={nodes[a].x} y1={nodes[a].y} x2={nodes[b].x} y2={nodes[b].y}
            stroke="var(--cyan)" strokeOpacity="0.22" strokeWidth="0.35" />
        ))}
        {nodes.map((n, i) => (
          <g key={n.id}>
            <circle cx={n.x} cy={n.y} r={n.r + 1.6} fill="var(--cyan)" opacity="0.15">
              <animate attributeName="r" values={`${n.r + 1.2};${n.r + 2.6};${n.r + 1.2}`} dur={`${2 + (i % 5) * 0.4}s`} repeatCount="indefinite" />
            </circle>
            <circle cx={n.x} cy={n.y} r={n.r} fill="var(--cyan)" />
          </g>
        ))}
      </svg>
    </div>
  );
}

/* ---------- Animated QR pairing tile ---------- */
export function PairingQR() {
  // SSR-safe deterministic pattern, scrambled on mount
  const [cells, setCells] = useState<boolean[]>(() =>
    Array.from({ length: 13 * 13 }, (_, i) => ((i * 73) ^ (i >> 2)) % 3 !== 0)
  );
  useEffect(() => {
    setCells(Array.from({ length: 13 * 13 }, () => Math.random() > 0.5));
  }, []);
  return (
    <div className="panel-cyber grid place-items-center gap-2 p-4 glow-green">
      <div className="grid gap-[1px] rounded-md border border-green/40 bg-background/60 p-2"
        style={{ gridTemplateColumns: "repeat(13, minmax(0, 1fr))" }}>
        {cells.map((on, i) => (
          <span key={i} className={`h-2 w-2 ${on ? "bg-green shadow-[0_0_4px_var(--green)]" : "bg-background/60"}`} />
        ))}
      </div>
      <div className="text-[10px] tracking-widest text-green">SCAN ON YOUR PC · butler_server.py</div>
      <div className="font-mono text-[10px] text-muted-foreground">192.168.1.42:8765 · HMAC-SHA256</div>
    </div>
  );
}

/* ---------- HMAC live signer (cosmetic, marquee) ---------- */
export function HmacMarquee() {
  const [hash, setHash] = useState("");
  useEffect(() => {
    if (freezeLiveFx()) {
      setHash("9f2c7a88d13b44c0a91e00ff88b7aa10");
      return;
    }
    const hex = "0123456789abcdef";
    const t = window.setInterval(() => {
      setHash(Array.from({ length: 32 }, () => hex[Math.floor(Math.random() * 16)]).join(""));
    }, 900);
    return () => window.clearInterval(t);
  }, []);
  return (
    <div className="panel-cyber flex items-center gap-2 overflow-hidden px-3 py-2">
      <Zap className="h-3.5 w-3.5 shrink-0 text-yellow" />
      <span className="text-[10px] tracking-widest text-muted-foreground">HMAC</span>
      <span className="truncate font-mono text-[10px] text-yellow">{hash}</span>
    </div>
  );
}

/* ---------- Boot/health ring (radial gauge) ---------- */
export function HealthRing({ value = 92, label = "HEALTH", color = "green" as "green" | "cyan" | "magenta" }) {
  const ref = useRef<SVGCircleElement>(null);
  const C = 2 * Math.PI * 28;
  useEffect(() => {
    if (!ref.current) return;
    ref.current.style.strokeDashoffset = `${C - (value / 100) * C}`;
  }, [value, C]);
  return (
    <div className={`panel flex items-center gap-3 p-3 glow-${color}`}>
      <svg viewBox="0 0 64 64" className="h-14 w-14 -rotate-90">
        <circle cx="32" cy="32" r="28" fill="none" stroke="currentColor" strokeOpacity="0.15" strokeWidth="5" />
        <circle ref={ref} cx="32" cy="32" r="28" fill="none" stroke={`var(--${color})`} strokeWidth="5"
          strokeDasharray={C} strokeDashoffset={C} strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 1.2s ease-out", filter: `drop-shadow(0 0 6px var(--${color}))` }} />
      </svg>
      <div>
        <div className={`text-lg font-extrabold text-${color}`}>{value}<span className="text-xs">/100</span></div>
        <div className="text-[10px] tracking-widest text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}
