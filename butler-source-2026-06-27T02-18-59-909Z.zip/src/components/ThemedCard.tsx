import type { ReactNode } from "react";

export type CardColor = "cyan" | "violet" | "green" | "amber" | "red";

export function ThemedCard({
  color = "cyan", title, icon, action, children, className = "",
}: {
  color?: CardColor;
  title: string;
  icon: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  const cls = color === "cyan" ? "" : `c-${color}`;
  const cvar = color === "violet" ? "var(--magenta)"
    : color === "amber" ? "var(--orange)"
    : `var(--${color})`;
  return (
    <div
      className={`panel-cyber ${cls} brackets holo-grain lift relative overflow-hidden ${className}`}
      style={{ ["--c" as any]: cvar }}
    >
      <span className="br-tr" aria-hidden />
      <span className="br-bl" aria-hidden />
      <div className="card-accent absolute left-0 right-0 top-0" aria-hidden />
      <div className="p-3 pt-3.5">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5" style={{ color: cvar }}>
            <span className="led" aria-hidden />
            {icon}
            <span className="font-display text-[10px] font-extrabold tracking-[0.22em]">{title}</span>
          </div>
          {action}
        </div>
        {children}
      </div>
    </div>
  );
}

export function PageTitle({ kicker, title, sub, color = "cyan" }: {
  kicker: string; title: string; sub?: string; color?: CardColor;
}) {
  const cvar = color === "violet" ? "var(--magenta)"
    : color === "amber" ? "var(--orange)"
    : `var(--${color})`;
  return (
    <header className="panel-cyber relative px-3 py-3"
      style={{ ["--c" as any]: cvar }}>
      <div className="font-mono text-[9px] tracking-[0.4em]" style={{ color: cvar }}>{kicker}</div>
      <h1 className="font-display text-[22px] font-black leading-tight tracking-[0.18em] text-foreground"
        style={{ textShadow: `0 0 14px ${cvar}, 0 0 28px color-mix(in oklab, ${cvar} 40%, transparent)` }}>
        {title}
      </h1>
      {sub ? <div className="mt-1 font-mono text-[10px] tracking-[0.22em] text-foreground/55">{sub}</div> : null}
    </header>
  );
}
