import { Link } from "@tanstack/react-router";
import { Activity, Circle, FolderClosed, Zap, Wifi, WifiOff, Loader2 } from "lucide-react";
import { useEffect, useState, useSyncExternalStore } from "react";
import { kbGrowthTracker } from "@/lib/kbGrowthTracker";
import { useServerLink } from "@/hooks/useServerLink";
import { serverLink } from "@/lib/serverLink";


/**
 * Persistent top utility bar — recent activity, connection, quick jumps.
 * Mounted globally inside AppShell so every screen has it.
 */
export function TopBar() {
  useSyncExternalStore(
    (cb) => kbGrowthTracker.subscribe(cb),
    () => kbGrowthTracker.getEventCount(),
    () => 0,
  );
  const [time, setTime] = useState<string>("");
  useEffect(() => {
    const update = () =>
      setTime(new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }));
    update();
    const id = setInterval(update, 4000);
    return () => clearInterval(id);
  }, []);

  const recent = kbGrowthTracker.getRecentEvents(8);
  const total = kbGrowthTracker.getTotalCount();


  return (
    <header
      className="panel-cyber sticky top-0 z-30 -mx-1 mb-2 flex items-center gap-2 px-2 py-1.5"
      style={{ ["--c" as any]: "var(--cyan)", backgroundColor: "color-mix(in oklab, var(--ink-2) 92%, transparent)" }}
    >
      <div className="flex items-center gap-1.5 shrink-0">
        <Circle className="h-1.5 w-1.5 fill-[color:var(--green)] text-[color:var(--green)]" />
        <span className="font-display text-[8px] font-extrabold tracking-[0.22em] text-[color:var(--green)]">LIVE</span>
        <span className="font-mono text-[8px] tracking-widest text-foreground/45" suppressHydrationWarning>{time}</span>
      </div>

      <div className="mx-1 h-3 w-px bg-[color:var(--border)]" />

      <div className="flex flex-1 items-center gap-2 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
        <Activity className="h-3 w-3 shrink-0 text-[color:var(--cyan)]" />
        {recent.length === 0 ? (
          <span className="font-mono text-[9px] tracking-widest text-foreground/40">no recent activity · awaiting nexus events</span>
        ) : (
          recent.map((e, i) => (
            <span
              key={i}
              className="shrink-0 rounded-sm border border-[color:var(--border)] bg-[var(--ink)] px-1.5 py-0.5 font-mono text-[8.5px] tracking-wider text-foreground/70"
              title={`${e.method} · ${e.domain ?? "—"} · ${new Date(e.ts).toLocaleTimeString()}`}
            >
              +{e.count} <span className="text-[color:var(--cyan)]">{e.method}</span>
              {e.domain ? <span className="text-foreground/40"> · {e.domain}</span> : null}
            </span>
          ))
        )}
      </div>

      <div className="flex shrink-0 items-center gap-1">
        <Link
          to="/files"
          className="grid h-6 w-6 place-items-center rounded-sm border border-[color:var(--border)] bg-[var(--ink)] text-[color:var(--cyan)]"
          title="Vault / Files"
        >
          <FolderClosed className="h-3 w-3" />
        </Link>
        <Link
          to="/ai"
          className="grid h-6 w-6 place-items-center rounded-sm border border-[color:var(--border)] bg-[var(--ink)] text-[color:var(--magenta)]"
          title="Butler chat"
        >
          <Zap className="h-3 w-3" />
        </Link>
        <ServerLinkBadge />
        <Link
          to="/settings"
          className="grid h-6 w-6 place-items-center rounded-sm border border-[color:var(--border)] bg-[var(--ink)] text-[color:var(--green)]"
          title="Settings"
        >
          <Wifi className="h-3 w-3" />
        </Link>
        <span className="ml-1 hidden font-mono text-[8.5px] tracking-widest text-foreground/45 sm:inline">
          KB {total.toLocaleString()}
        </span>

      </div>
    </header>
  );
}

function ServerLinkBadge() {
  const link = useServerLink();
  const connected = link.status === "connected";
  const busy = link.status === "connecting" || link.status === "discovering";
  const color = connected
    ? "var(--green)"
    : busy
      ? "var(--orange)"
      : "var(--red)";
  const Icon = busy ? Loader2 : connected ? Wifi : WifiOff;
  const label = connected
    ? `${link.latencyMs ?? "?"}ms`
    : busy
      ? "…"
      : "off";
  const onClick = () => {
    if (connected) return;
    void serverLink.autoDiscover();
  };
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex h-6 items-center gap-1 rounded-sm border border-[color:var(--border)] bg-[var(--ink)] px-1.5"
      style={{ color }}
      title={connected ? `Linked ${link.ip}:${link.port}` : "Tap to auto-discover PC server"}
    >
      <Icon className={`h-3 w-3 ${busy ? "animate-spin" : ""}`} />
      <span className="font-mono text-[8.5px] tracking-widest">{label}</span>
    </button>
  );
}

