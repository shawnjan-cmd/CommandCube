import { useEffect, useState } from "react";

export function LiveClock() {
  const [mounted, setMounted] = useState(false);
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setMounted(true);
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  if (!mounted || !now) {
    return (
      <div className="text-right font-mono text-xs text-muted-foreground tabular-nums">
        <div className="text-base font-bold text-cyan">--:--:--</div>
        <div className="text-[10px] tracking-[0.2em] mt-0.5">SYSTEM TIME</div>
      </div>
    );
  }
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  return (
    <div className="text-right font-mono tabular-nums">
      <div className="text-base font-bold text-cyan leading-none">
        {hh}:{mm}<span className="opacity-60">:{ss}</span>
      </div>
      <div className="text-[10px] tracking-[0.2em] text-muted-foreground mt-1">LOCAL · SECURE</div>
    </div>
  );
}
