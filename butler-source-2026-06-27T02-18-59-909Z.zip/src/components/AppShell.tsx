import { Link } from "@tanstack/react-router";
import {
  Home, Code2, User, Network, FolderClosed, ScrollText,
  Wrench, Headphones, Settings as SettingsIcon, Circle,
} from "lucide-react";
import type { ReactNode } from "react";
import { AskBar } from "@/components/AskBar";
import { TopBar } from "@/components/TopBar";


type ActiveKey =
  | "home" | "scripts" | "butler" | "knowledge" | "files"
  | "logs" | "builder" | "support" | "settings"
  | "run" | "ai" | "cfg" | "term";

const ALIAS: Record<string, ActiveKey> = {
  run: "scripts", ai: "butler", term: "logs", cfg: "settings",
};


export function AppShell({ children, active }: { children: ReactNode; active?: ActiveKey }) {
  const a: ActiveKey | undefined = active ? ((ALIAS[active as string] ?? active) as ActiveKey) : undefined;
  return (
    <main
      className="relative min-h-screen overflow-x-clip text-foreground"
      style={{
        background:
          "radial-gradient(ellipse 88% 44% at 50% -10%, color-mix(in oklab, var(--cyan) 18%, transparent), transparent 62%)," +
          "radial-gradient(ellipse 70% 44% at 100% 100%, color-mix(in oklab, var(--magenta) 12%, transparent), transparent 64%)," +
          "linear-gradient(180deg, var(--ink) 0%, var(--background) 52%, var(--ink-deep) 100%)",
      }}
    >
      {/* === themed cyberpunk backdrop === */}
      {/* deep radial bloom */}
      {/* circuit grid */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.10]"
           style={{
             backgroundImage:
                "linear-gradient(color-mix(in oklab, var(--cyan) 55%, transparent) 1px, transparent 1px)," +
                "linear-gradient(90deg, color-mix(in oklab, var(--cyan) 55%, transparent) 1px, transparent 1px)",
              backgroundSize: "46px 46px, 46px 46px",
           }} />
      {/* faint hex/diagonal traces */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.08]"
           style={{
             backgroundImage:
               "repeating-linear-gradient(60deg, color-mix(in oklab, var(--magenta) 50%, transparent) 0 1px, transparent 1px 28px)," +
               "repeating-linear-gradient(-60deg, color-mix(in oklab, var(--cyan) 40%, transparent) 0 1px, transparent 1px 36px)",
           }} />

      {/* static scanline veil (cheap, no repaint) */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.12]"
           style={{
             backgroundImage: "repeating-linear-gradient(180deg, transparent 0 2px, color-mix(in oklab, var(--cyan) 6%, transparent) 2px 3px)",
           }} />
      {/* static neon edge accents */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[2px]"
           style={{ background: "linear-gradient(90deg, transparent, var(--cyan) 30%, var(--magenta) 70%, transparent)", opacity: 0.55 }} />
      <div className="pointer-events-none absolute inset-x-0 bottom-[58px] h-[1px]"
           style={{ background: "linear-gradient(90deg, transparent, var(--magenta), transparent)", opacity: 0.5 }} />
      <div className="relative mx-auto flex max-w-md flex-col gap-3 px-3 pb-[140px] pt-2">
        <TopBar />
        {children}

        <AskBar />
        <nav className="fixed inset-x-0 bottom-0 z-40" style={{ touchAction: "pan-y" }}>
          <div className="mx-auto flex max-w-md items-stretch justify-between gap-[2px] border-t border-[color:var(--border)] bg-[var(--ink-2)] px-1 py-1.5">
            <Tab to="/home"      icon={<Home className="h-[16px] w-[16px]" />}        label="CORE"    color="cyan"    active={a === "home"} />
            <Tab to="/run"       icon={<Code2 className="h-[16px] w-[16px]" />}       label="OPS"     color="violet"  active={a === "scripts"} />
            <Tab to="/ai"        icon={<User className="h-[16px] w-[16px]" />}        label="BUTLR"   color="cyan"    active={a === "butler"} />
            <Tab to="/knowledge" icon={<Network className="h-[16px] w-[16px]" />}     label="KB"      color="green"   active={a === "knowledge"} />
            <Tab to="/intel"     icon={<ScrollText className="h-[16px] w-[16px]" />}  label="INTEL"   color="amber"   active={a === "logs"} />
            <Tab to="/files"     icon={<FolderClosed className="h-[16px] w-[16px]"/>} label="VAULT"   color="cyan"    active={a === "files"} />
            <Tab to="/builder"   icon={<Wrench className="h-[16px] w-[16px]" />}      label="FORGE"   color="violet"  active={a === "builder"} />
            <Tab to="/support"   icon={<Headphones className="h-[16px] w-[16px]" />}  label="LINK"    color="cyan"    active={a === "support"} />
            <Tab to="/settings"  icon={<SettingsIcon className="h-[16px] w-[16px]"/>} label="CONF"    color="cyan"    active={a === "settings"} />
          </div>
        </nav>


      </div>
    </main>
  );
}

const COLOR_VAR: Record<string, string> = {
  cyan: "var(--cyan)", violet: "var(--magenta)", green: "var(--green)", amber: "var(--orange)", red: "var(--red)",
};
function Tab({ to, icon, label, color, active }: { to: string; icon: ReactNode; label: string; color: string; active?: boolean }) {
  return (
    <Link
      to={to as any}
      data-active={active ? "true" : "false"}
      className="hex-tab flex-1 basis-0"
      style={{ ["--c" as any]: COLOR_VAR[color] ?? "var(--cyan)" }}
    >
      {icon}
      <span className="font-display text-[7.5px] font-extrabold tracking-[0.12em]">{label}</span>
    </Link>
  );
}


export function SectionTitle({ icon, color, label }: { icon: ReactNode; color: string; label: string }) {
  return (
    <div className="flex items-center gap-2" style={{ color: `var(--${color})` }}>
      {icon}
      <span className="font-display text-[11px] font-extrabold tracking-[0.25em]">{label}</span>
    </div>
  );
}

/** Cyberpunk page header — centered title + butler badge (no side menu) */
export function PageHeader({ title, sub, color = "cyan" }: { title: string; sub?: string; color?: string }) {
  const c = `var(--${color})`;
  return (
    <header className="panel-cyber flex items-center gap-3 px-3 py-3" style={{ ["--c" as any]: c }}>
      <div className="flex-1 text-center">
        <div className="font-display text-[18px] font-extrabold tracking-[0.32em]" style={{ color: c, textShadow: `0 0 14px ${c}` }}>
          {title}
        </div>
        {sub && <div className="font-mono text-[9px] tracking-[0.4em] text-foreground/60">{sub}</div>}
      </div>
      <div className="flex items-center gap-2 rounded-sm border border-[color:var(--border)] bg-[var(--ink-3)] px-2 py-1">
        <div className="grid h-7 w-7 place-items-center rounded-sm bg-gradient-to-br from-[#1a2230] to-[#06080d] text-cyan">
          <User className="h-4 w-4" />
        </div>
        <div className="flex flex-col leading-tight">
          <span className="font-display text-[9px] font-bold tracking-widest text-foreground/80">BUTLER</span>
          <span className="flex items-center gap-1 font-mono text-[8px] tracking-widest text-[color:var(--green)]">
            <Circle className="h-1.5 w-1.5 fill-current" /> ONLINE
          </span>
        </div>
      </div>
    </header>
  );
}
