import { Link, useNavigate } from "@tanstack/react-router";
import { X, Share2, Check, Lock, Scale, ShieldCheck, Trash2, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

export type Accent = "cyan" | "green" | "magenta" | "orange" | "yellow" | "red";

export type Badge = { label: string; tone: Accent };

const NAV: { to: string; label: string; icon: LucideIcon; tone: Accent }[] = [
  { to: "/legal/privacy", label: "Privacy Policy",   icon: Lock,        tone: "yellow" },
  { to: "/legal/terms",   label: "Terms of Service", icon: Scale,       tone: "cyan"   },
  { to: "/legal/safety",  label: "Data Safety",      icon: ShieldCheck, tone: "green"  },
  { to: "/legal/delete",  label: "Delete My Data",   icon: Trash2,      tone: "red"    },
];

export function LegalShell({
  title, accent, emoji, badges, headline, children,
}: {
  title: string;
  accent: Accent;
  emoji: string;
  badges: Badge[];
  headline: string;
  children: ReactNode;
}) {
  const navigate = useNavigate();
  const onShare = async () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    try {
      if (navigator.share) await navigator.share({ title, url });
      else await navigator.clipboard.writeText(url);
    } catch { /* user cancelled */ }
  };

  return (
    <main className="relative min-h-screen overflow-x-clip bg-background text-foreground">
      {/* === themed cyberpunk backdrop (matches homepage) === */}
      <div className="pointer-events-none absolute inset-0"
           style={{
             background:
               "radial-gradient(ellipse 90% 60% at 50% -10%, color-mix(in oklab, var(--cyan) 22%, transparent), transparent 60%)," +
               "radial-gradient(ellipse 70% 50% at 100% 100%, color-mix(in oklab, var(--magenta) 18%, transparent), transparent 60%)," +
               "radial-gradient(ellipse 70% 50% at 0% 100%, color-mix(in oklab, var(--green) 12%, transparent), transparent 60%)," +
               "linear-gradient(180deg, var(--ink) 0%, #06080d 50%, var(--ink-deep) 100%)",
           }} />
      <div className="pointer-events-none absolute inset-0 opacity-[0.10]"
           style={{
             backgroundImage:
               "linear-gradient(color-mix(in oklab, var(--cyan) 60%, transparent) 1px, transparent 1px)," +
               "linear-gradient(90deg, color-mix(in oklab, var(--cyan) 60%, transparent) 1px, transparent 1px)",
             backgroundSize: "44px 44px, 44px 44px",
             maskImage: "radial-gradient(ellipse 80% 70% at 50% 40%, #000 40%, transparent 90%)",
           }} />
      <div className="pointer-events-none absolute inset-0 opacity-[0.08]"
           style={{
             backgroundImage:
               "repeating-linear-gradient(60deg, color-mix(in oklab, var(--magenta) 50%, transparent) 0 1px, transparent 1px 28px)," +
               "repeating-linear-gradient(-60deg, color-mix(in oklab, var(--cyan) 40%, transparent) 0 1px, transparent 1px 36px)",
           }} />
      <div className="pointer-events-none absolute left-2 top-24 h-1.5 w-1.5 rounded-full"
           style={{ background: "var(--cyan)", boxShadow: "0 0 12px var(--cyan)" }} />
      <div className="pointer-events-none absolute right-3 top-44 h-1.5 w-1.5 rounded-full"
           style={{ background: "var(--magenta)", boxShadow: "0 0 12px var(--magenta)", animationDelay: "0.6s" }} />
      <div className="pointer-events-none absolute left-3 top-[60vh] h-1 w-1 rounded-full"
           style={{ background: "var(--green)", boxShadow: "0 0 10px var(--green)", animationDelay: "1.1s" }} />
      <div className="pointer-events-none absolute inset-0 scanlines opacity-15" />
      <div className="pointer-events-none absolute inset-x-0 top-0 z-0 h-[2px]"
           style={{ background: "linear-gradient(90deg, transparent, var(--cyan), transparent)", boxShadow: "0 0 14px var(--cyan)" }} />


      {/* Top bar */}
      <header className="sticky top-0 z-20 border-b border-border/60 bg-background/95">
        <div className="mx-auto grid max-w-md grid-cols-[auto_minmax(0,1fr)_auto_auto] items-center gap-2 px-3 py-3 sm:max-w-2xl">
          <button
            onClick={() => navigate({ to: "/" })}
            aria-label="Close and return to onboarding"
            className={`panel grid h-11 w-11 shrink-0 place-items-center text-${accent} transition hover:bg-${accent}/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-${accent}/70`}
          >
            <X className="h-4 w-4" />
          </button>
          <h1
            className="min-w-0 truncate font-mono text-sm font-bold tracking-widest text-foreground"
            title={title}
          >
            {title}
          </h1>
          <button
            onClick={onShare}
            aria-label="Share document link"
            className={`panel grid h-11 w-11 shrink-0 place-items-center text-${accent} transition hover:bg-${accent}/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-${accent}/70`}
          >
            <Share2 className="h-4 w-4" />
          </button>
          <Link
            to="/"
            aria-label="Mark as read and return"
            className="panel-cyber flex h-11 items-center gap-1.5 rounded-full border border-green/60 px-3 text-[10px] font-extrabold tracking-widest text-green glow-green transition hover:bg-green/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green/70"
          >
            <Check className="h-4 w-4" />
            <span className="text-[10px]">DONE</span>
          </Link>
        </div>
      </header>

      <div className="relative mx-auto max-w-md px-4 pb-16 pt-6 sm:max-w-2xl">
        {/* Hero */}
        <section className={`panel relative overflow-hidden p-5 glow-${accent}`}>
          <div className="pointer-events-none absolute inset-0 opacity-50"
            style={{ background: `radial-gradient(circle at 50% 0%, color-mix(in oklab, var(--${accent}) 28%, transparent), transparent 60%)` }} />
          <div className="relative space-y-4 text-center">
            <h2 className={`flex flex-wrap items-center justify-center gap-2 text-2xl font-extrabold tracking-widest text-${accent} text-glow-cyan`}>
              <span aria-hidden className="text-3xl">{emoji}</span>
              <span>{title.toUpperCase()}</span>
            </h2>
            <p className="text-xs tracking-widest text-muted-foreground">{headline}</p>
            <div className="mx-auto flex flex-wrap items-center justify-center gap-2 pt-1">
              {badges.map((b) => (
                <span key={b.label}
                  className={`rounded-md border border-${b.tone}/60 bg-${b.tone}/5 px-3 py-1.5 text-[10px] font-extrabold tracking-widest text-${b.tone}`}>
                  {b.label}
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* Quick-jump nav between legal docs — full labels, never truncated */}
        <nav aria-label="Legal documents" className="mt-5 flex flex-col gap-2">
          <div className="px-1 text-[10px] font-bold tracking-widest text-muted-foreground">
            JUMP TO DOCUMENT
          </div>
          {NAV.map((n) => {
            const active = typeof window !== "undefined" && window.location.pathname === n.to;
            const Icon = n.icon;
            return (
              <Link
                key={n.to}
                to={n.to}
                aria-current={active ? "page" : undefined}
                className={`panel flex items-center gap-3 px-3 py-3 text-xs font-bold tracking-widest transition text-${n.tone} focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-${n.tone}/70 ${active ? `glow-${n.tone}` : `hover:bg-${n.tone}/5`}`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="flex-1 break-words text-left leading-tight">{n.label}</span>
                {active && (
                  <span className={`shrink-0 rounded border border-${n.tone}/60 bg-${n.tone}/10 px-1.5 py-0.5 text-[9px] tracking-widest`}>
                    VIEWING
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* Body */}
        <article className="prose-legal mt-6 space-y-5 text-sm leading-relaxed text-foreground/85">
          {children}
        </article>

        <footer className="mt-10 border-t border-border/60 pt-4 text-center text-[10px] tracking-widest text-muted-foreground">
          BUTLER AI · ANDROID · EFFECTIVE APRIL 1, 2026 · v7.3
        </footer>
      </div>
    </main>
  );
}

/* Reusable section block */
export function LegalSection({ title, tone = "cyan", children }: { title: string; tone?: Accent; children: ReactNode }) {
  return (
    <section className={`panel p-4`}>
      <h3 className={`mb-2 text-xs font-extrabold tracking-widest text-${tone}`}>{title}</h3>
      <div className="space-y-2 text-[13px] leading-relaxed text-foreground/85">{children}</div>
    </section>
  );
}

/* Safelist hint:
   text-cyan text-green text-magenta text-orange text-yellow text-red
   bg-cyan/5 bg-green/5 bg-magenta/5 bg-orange/5 bg-yellow/5 bg-red/5
   bg-cyan/10 bg-green/10 bg-magenta/10 bg-orange/10 bg-yellow/10 bg-red/10
   border-cyan/60 border-green/60 border-magenta/60 border-orange/60 border-yellow/60 border-red/60
   glow-cyan glow-green glow-magenta glow-orange
*/
