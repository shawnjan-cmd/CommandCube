import { useEffect, useRef, useState } from "react";
import mascotImg from "@/assets/mascot-butler.png";
import { usePerfTier } from "@/hooks/use-perf-tier";

/**
 * Reusable Butler mascot. Bow-tie-up bust crop with a wide library of
 * named moods + the ability to auto-cycle through a list for ambient
 * variety after onboarding completes.
 *
 *  <Mascot mood="wave" />
 *  <Mascot mood={["wave","spin","cheer","peek"]} cycleMs={2400} />
 */

export type MascotMood =
  | "wave" | "spy" | "nod" | "oath" | "tilt" | "shake" | "think" | "bow"
  | "build" | "launch" | "glow" | "spin" | "bounce" | "dance" | "cheer"
  | "salute" | "peek" | "blink" | "zoom" | "orbit" | "meditate" | "juggle"
  | "victory" | "sleep" | "alert" | "wink" | "skate" | "hover" | "boop"
  | "scan";

const MOOD_CLASS: Record<MascotMood, string> = {
  wave: "m-wave",        spy: "m-spy",          nod: "m-nod",
  oath: "m-oath m-glow", tilt: "m-tilt",        shake: "m-shake",
  think: "m-think",      bow: "m-bow",          build: "m-build",
  launch: "m-launch m-glow", glow: "m-glow",    spin: "m-spin",
  bounce: "m-bounce",    dance: "m-dance",      cheer: "m-cheer m-glow",
  salute: "m-salute",    peek: "m-peek",        blink: "m-blink",
  zoom: "m-zoom",        orbit: "m-orbit",      meditate: "m-meditate m-glow",
  juggle: "m-juggle",    victory: "m-victory m-glow", sleep: "m-sleep",
  alert: "m-alert m-glow", wink: "m-wink",      skate: "m-skate",
  hover: "m-hover m-glow", boop: "m-boop",      scan: "m-scan m-glow",
};

type Size = "xs" | "sm" | "md" | "lg" | "xl";
const SIZE_CLASS: Record<Size, string> = {
  xs: "w-16",  sm: "w-24",  md: "w-32",  lg: "w-44",  xl: "w-56",
};

export function Mascot({
  mood = "wave",
  cycleMs = 0,
  accent = "cyan",
  size = "md",
  className = "",
  parallax = true,
}: {
  mood?: MascotMood | MascotMood[];
  cycleMs?: number;
  accent?: "cyan" | "green" | "magenta" | "orange" | "yellow";
  size?: Size;
  className?: string;
  parallax?: boolean;
}) {
  const list = Array.isArray(mood) ? mood : [mood];
  const [idx, setIdx] = useState(0);
  const ref = useRef<HTMLDivElement | null>(null);
  const tier = usePerfTier();
  // Throttle: slower cycles on mid, freeze on low. Parallax off on low.
  const effectiveCycle = cycleMs && (tier === "low" ? 0 : tier === "mid" ? cycleMs * 1.6 : cycleMs);
  const allowParallax = parallax && tier !== "low";

  useEffect(() => {
    if (!effectiveCycle || list.length < 2) return;
    const t = window.setInterval(() => setIdx((i) => (i + 1) % list.length), effectiveCycle);
    return () => window.clearInterval(t);
  }, [effectiveCycle, list.length]);

  const current = list[idx % list.length];

  const onMove = (e: React.MouseEvent) => {
    if (!allowParallax) return;
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    // Mid tier gets a damped tilt to save GPU on transforms.
    const k = tier === "mid" ? 0.55 : 1;
    el.style.setProperty("--rx", `${(-y * 10 * k).toFixed(2)}deg`);
    el.style.setProperty("--ry", `${(x * 14 * k).toFixed(2)}deg`);
  };
  const onLeave = () => {
    const el = ref.current; if (!el) return;
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--ry", "0deg");
  };

  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      className={`relative grid aspect-square ${SIZE_CLASS[size]} shrink-0 place-items-center overflow-hidden rounded-md border border-${accent}/40 bg-background/60 ${className}`}
      style={{ perspective: "700px" }}
    >
      <div className="absolute inset-0 grid-bg opacity-25" />
      <div
        className="absolute inset-0 opacity-70"
        style={{ background: `radial-gradient(circle at 50% 55%, color-mix(in oklab, var(--${accent}) 38%, transparent), transparent 62%)` }}
      />
      <div
        key={current}
        className="mascot-pop relative h-full w-full"
        style={{
          transform: "rotateX(var(--rx,0deg)) rotateY(var(--ry,0deg))",
          transformStyle: "preserve-3d",
          transition: "transform .25s ease-out",
        }}
      >
        <div
          className="absolute inset-0 grid place-items-center"
          style={{ transform: "translateZ(16px)" }}
        >
          <div className={`relative grid h-full w-full place-items-center ${MOOD_CLASS[current]}`} style={{ color: `var(--${accent})` }}>
            <img
              src={mascotImg}
              alt="Butler mascot"
              draggable={false}
              loading="eager"
              decoding="async"
              className="h-[92%] w-[92%] select-none object-contain"
              style={{
                willChange: "transform",
                filter: "drop-shadow(0 6px 14px rgba(0,0,0,.55))",
              }}
            />
          </div>
        </div>
        <div
          className="pointer-events-none absolute -bottom-1 left-1/2 h-3 w-24 -translate-x-1/2 rounded-full opacity-60 blur-lg"
          style={{ background: `var(--${accent})` }}
        />
      </div>
    </div>
  );
}

/** Pre-warm the mascot image into the HTTP cache. */
export function prefetchMascot() {
  if (typeof window === "undefined") return;
  const img = new Image();
  img.src = mascotImg;
}
