import type { ReactNode } from "react";

export type NcxColor = "blue" | "green" | "purple" | "cyan" | "amber" | "red";

const COLOR_VAR: Record<NcxColor, string> = {
  blue:   "#4488ff",
  green:  "var(--green)",
  purple: "var(--magenta)",
  cyan:   "var(--cyan)",
  amber:  "var(--orange)",
  red:    "var(--red)",
};

/**
 * NCX card — ported from tools_hub_1.html. Used everywhere the Tools Hub
 * needs a coloured panel with an accent top line + neon-tinted glow.
 */
export function NcxCard({
  color = "cyan",
  icon,
  title,
  children,
  className,
  full,
}: {
  color?: NcxColor;
  icon?: ReactNode;
  title: string;
  children: ReactNode;
  className?: string;
  full?: boolean;
}) {
  const c = COLOR_VAR[color];
  return (
    <div
      className={`ncx-card ${full ? "col-span-2" : ""} ${className ?? ""}`}
      style={{ ["--c" as any]: c }}
    >
      <span className="ncx-card-top" />
      <div className="flex items-center gap-2 border-b border-white/[0.04] px-3 py-2">
        <span className="text-[14px]" style={{ color: c }}>{icon}</span>
        <span
          className="font-mono text-[10px] font-medium uppercase tracking-[0.15em]"
          style={{ color: c }}
        >
          {title}
        </span>
      </div>
      <div className="flex flex-1 flex-col">{children}</div>
    </div>
  );
}

/** Section header with color bar + title + horizontal line. */
export function NcxSection({
  color = "cyan",
  title,
  action,
}: {
  color?: NcxColor;
  title: string;
  action?: ReactNode;
}) {
  const c = COLOR_VAR[color];
  return (
    <div className="mb-2.5 flex items-center gap-2.5">
      <span className="h-[18px] w-[3px] rounded-sm" style={{ background: c }} />
      <h2
        className="font-display text-[12px] font-semibold uppercase tracking-[0.22em]"
        style={{ color: c }}
      >
        {title}
      </h2>
      <span className="h-px flex-1" style={{ background: "var(--border)" }} />
      {action}
    </div>
  );
}

/** Ghost/primary tonal button. */
export function NcxBtn({
  color = "cyan",
  ghost,
  children,
  className,
  ...rest
}: {
  color?: NcxColor;
  ghost?: boolean;
  children: ReactNode;
  className?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const c = COLOR_VAR[color];
  return (
    <button
      {...rest}
      style={{ ["--c" as any]: c, ...(rest.style ?? {}) }}
      className={`ncx-btn ${ghost ? "ncx-btn-ghost" : ""} ${className ?? ""}`}
    >
      {children}
    </button>
  );
}
