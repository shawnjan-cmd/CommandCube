import { useEffect, useRef, useState } from "react";

/**
 * Touch + scroll + click diagnostic overlay.
 * Enable with `?debug=1` in URL or `localStorage.setItem('butler.debug','1')`.
 * Toggle visibility via the tiny [D] FAB. Tap [×] to clear log; long-press to disable.
 */
type Row = { t: number; kind: string; info: string };

function describe(el: Element | null): string {
  if (!el) return "<none>";
  const tag = el.tagName.toLowerCase();
  const id = (el as HTMLElement).id ? `#${(el as HTMLElement).id}` : "";
  const cls = typeof (el as HTMLElement).className === "string"
    ? "." + ((el as HTMLElement).className as string).trim().split(/\s+/).slice(0, 2).join(".")
    : "";
  const role = el.getAttribute("role");
  const aria = el.getAttribute("aria-label");
  const txt = (el.textContent || "").trim().slice(0, 24);
  return `${tag}${id}${cls}${role ? `[${role}]` : ""}${aria ? `"${aria}"` : ""}${txt ? ` ⟨${txt}⟩` : ""}`;
}

export function DebugOverlay() {
  const [enabled, setEnabled] = useState(false);
  const [open, setOpen] = useState(true);
  const [rows, setRows] = useState<Row[]>([]);
  const [sy, setSy] = useState(0);
  const buf = useRef<Row[]>([]);
  const raf = useRef<number | null>(null);
  const lastTouchMove = useRef(0);

  // Activate detection (client-only — never runs during SSR)
  useEffect(() => {
    try {
      const url = new URL(window.location.href);
      const flag = url.searchParams.get("debug") === "1"
        || window.localStorage.getItem("butler.debug") === "1";
      if (url.searchParams.get("debug") === "1") {
        window.localStorage.setItem("butler.debug", "1");
      }
      setEnabled(flag);
    } catch { /* noop */ }
  }, []);

  // Instrument
  useEffect(() => {
    if (!enabled) return;
    const push = (kind: string, info: string) => {
      const row: Row = { t: performance.now(), kind, info };
      buf.current = [...buf.current.slice(-49), row];
      if (raf.current == null) {
        raf.current = window.requestAnimationFrame(() => {
          raf.current = null;
          setRows(buf.current);
          setSy(window.scrollY);
        });
      }
    };
    const onTouch = (e: TouchEvent) => {
      if (e.type === "touchmove") {
        const now = performance.now();
        if (now - lastTouchMove.current < 140) return;
        lastTouchMove.current = now;
      }
      const t = e.touches[0] || e.changedTouches[0];
      const target = t ? document.elementFromPoint(t.clientX, t.clientY) : null;
      push(e.type, `(${t?.clientX|0},${t?.clientY|0}) → ${describe(target)}`);
    };
    const onClick = (e: MouseEvent) => {
      push("click", `(${e.clientX},${e.clientY}) → ${describe(e.target as Element)}`);
    };
    const onScroll = () => {
      push("scroll", `y=${window.scrollY|0} h=${document.documentElement.scrollHeight}`);
    };
    const onErr = (e: ErrorEvent) => push("error", String(e.message).slice(0, 80));

    window.addEventListener("touchstart", onTouch, { capture: true, passive: true });
    window.addEventListener("touchmove",  onTouch, { capture: true, passive: true });
    window.addEventListener("touchend",   onTouch, { capture: true, passive: true });
    window.addEventListener("click",      onClick, { capture: true });
    window.addEventListener("scroll",     onScroll, { capture: true, passive: true });
    window.addEventListener("error",      onErr);
    return () => {
      window.removeEventListener("touchstart", onTouch, true);
      window.removeEventListener("touchmove",  onTouch, true);
      window.removeEventListener("touchend",   onTouch, true);
      window.removeEventListener("click",      onClick, true);
      window.removeEventListener("scroll",     onScroll, true);
      window.removeEventListener("error",      onErr);
      if (raf.current != null) cancelAnimationFrame(raf.current);
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-[9999] pointer-events-none font-mono text-[10px] leading-tight">
      {/* FAB toggles */}
      <div className="pointer-events-auto absolute right-2 bottom-[148px] flex flex-col gap-1">
        <button
          onClick={() => setOpen(o => !o)}
          className="grid h-7 w-7 place-items-center rounded-sm border border-emerald-400/60 bg-black/80 text-emerald-300"
          aria-label="Toggle debug overlay"
        >D</button>
        <button
          onClick={() => { buf.current = []; setRows([]); }}
          onContextMenu={(e) => { e.preventDefault(); window.localStorage.removeItem("butler.debug"); setEnabled(false); }}
          className="grid h-7 w-7 place-items-center rounded-sm border border-rose-400/60 bg-black/80 text-rose-300"
          aria-label="Clear / long-press to disable"
        >×</button>
      </div>

      {open && (
        <div className="pointer-events-none mx-2 mb-2 max-h-[40vh] overflow-hidden rounded-md border border-emerald-400/40 bg-black/90 p-2 text-emerald-200">
          <div className="mb-1 flex justify-between text-emerald-300">
            <span>DBG · y={sy} · h={typeof document!=="undefined"?document.documentElement.scrollHeight:0} · {rows.length}</span>
            <span>?debug=1</span>
          </div>
          {rows.slice().reverse().map((r, i) => (
            <div key={rows.length - i} className="truncate">
              <span className="text-cyan-300">{r.kind.padEnd(10)}</span> {r.info}
            </div>
          ))}
          {rows.length === 0 && <div className="text-emerald-300/60">tap, swipe, scroll…</div>}
        </div>
      )}
    </div>
  );
}
