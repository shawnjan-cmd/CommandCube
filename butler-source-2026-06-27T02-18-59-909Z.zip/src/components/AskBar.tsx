import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Send, Sparkles, Circle } from "lucide-react";

const HINTS = [
  "clean my temp files",
  "list top 10 RAM processes",
  "sort Downloads by file type",
  "why is my CPU spiking?",
  "scan my LAN",
  "format Python files in this folder",
];

/**
 * Slim AI chat dock pinned above the bottom toolbar.
 * Rotates suggestion via CSS only (no JS interval = zero re-render cost).
 */
export function AskBar() {
  const navigate = useNavigate();
  const [v, setV] = useState("");
  // SSR-safe: deterministic on first render, randomised after mount so hydration matches.
  const [idx, setIdx] = useState(0);
  useEffect(() => { setIdx(Math.floor(Math.random() * HINTS.length)); }, []);
  const placeholder = `ASK BUTLER — "${HINTS[idx]}"`;

  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const q = v.trim();
    void navigate({ to: "/ai", search: q ? { q } : undefined } as any);
    setV("");
  };

  return (
    <div className="fixed inset-x-0 bottom-[58px] z-30 pointer-events-none" style={{ touchAction: "pan-y" }}>
      <div className="mx-auto max-w-md px-2 pointer-events-auto" style={{ touchAction: "pan-y" }}>
        <form onSubmit={submit}
              className="panel-cyber flex items-center gap-2 px-2 py-1.5"
              style={{ ["--c" as any]: "var(--magenta)" }}>
          <span className="relative grid h-7 w-7 shrink-0 place-items-center rounded-sm border border-[color:var(--border)] bg-[var(--ink)] text-[color:var(--magenta)]">
            <Sparkles className="h-3.5 w-3.5" />
            <Circle className="pulse-dot absolute -right-0.5 -top-0.5 h-1.5 w-1.5 fill-[color:var(--green)] text-[color:var(--green)]" />
          </span>
          <input
            value={v}
            onChange={(e) => setV(e.target.value)}
            placeholder={placeholder}
            className="min-w-0 flex-1 bg-transparent font-mono text-[11px] tracking-[0.04em] text-foreground placeholder:text-foreground/35 focus:outline-none"
          />
          <span className="hidden xs:inline font-mono text-[8.5px] tracking-widest text-foreground/35">⏎</span>
          <button type="submit"
                  className="grid h-7 w-7 shrink-0 place-items-center rounded-sm border text-[color:var(--magenta)]"
                  style={{ borderColor: "color-mix(in oklab, var(--magenta) 60%, transparent)",
                           boxShadow: "0 0 10px -2px var(--magenta)" }}
                  aria-label="Send to Butler">
            <Send className="h-3.5 w-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
}
