import { useEffect, useState } from "react";
import { Activity, AlertTriangle, CheckCircle2, Info, XCircle } from "lucide-react";
import { loadLog, type ExecRecord } from "@/lib/execlog";

function relTime(ts: number) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  return `${Math.floor(s / 86400)}d`;
}

const ICON = {
  success: CheckCircle2,
  info: Info,
  warn: AlertTriangle,
  error: XCircle,
} as const;

const TONE = {
  success: "var(--success)",
  info: "var(--cyan)",
  warn: "var(--warning)",
  error: "var(--danger)",
} as const;

export function ActivityFeed({ limit = 6 }: { limit?: number }) {
  const [items, setItems] = useState<ExecRecord[]>([]);
  useEffect(() => {
    const refresh = () => setItems(loadLog().slice(0, limit));
    refresh();
    const id = setInterval(refresh, 4000);
    window.addEventListener("butler:log", refresh as any);
    return () => { clearInterval(id); window.removeEventListener("butler:log", refresh as any); };
  }, [limit]);

  if (!items.length) {
    return (
      <div className="flex items-center gap-2 text-[11px] text-muted-foreground font-mono py-1">
        <Activity className="size-3.5" /> No activity yet.
      </div>
    );
  }

  return (
    <ul className="space-y-1.5">
      {items.map((r) => {
        const Icon = ICON[r.level];
        const color = TONE[r.level];
        return (
          <li key={r.id} className="flex items-start gap-2 panel p-2">
            <Icon className="size-3.5 mt-0.5 shrink-0" style={{ color }} />
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-display text-[11px] font-bold truncate">{r.title}</span>
                <span className="font-mono text-[9px] text-muted-foreground shrink-0">{relTime(r.ts)}</span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-muted-foreground font-mono">
                <span className="uppercase tracking-[0.14em]">{r.source}</span>
                {r.detail ? <span className="truncate">· {r.detail}</span> : null}
              </div>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
