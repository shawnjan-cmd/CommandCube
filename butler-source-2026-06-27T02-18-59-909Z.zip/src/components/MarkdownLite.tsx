import { useState, memo } from "react";
import { Check, Copy } from "lucide-react";

/**
 * Zero-dep, fast markdown subset: fenced code blocks, inline `code`,
 * **bold**, *italic*, bullet lists, headings (#..###), links.
 * Designed for streaming chat — runs cheaply on each token.
 */

function escapeHtml(s: string) {
  return s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]!));
}

function renderInline(src: string): string {
  let s = escapeHtml(src);
  // links [text](url)
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
    '<a href="$2" target="_blank" rel="noreferrer" class="text-cyan underline underline-offset-2">$1</a>');
  // inline code
  s = s.replace(/`([^`]+)`/g, '<code class="rounded bg-[color:var(--surface-2)] px-1 py-[1px] text-[11px] text-[color:var(--magenta)]">$1</code>');
  // bold
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong class="text-foreground">$1</strong>');
  // italic
  s = s.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em class="text-foreground/80">$2</em>');
  return s;
}

type Block =
  | { type: "code"; lang: string; body: string }
  | { type: "p"; body: string }
  | { type: "h"; level: 1 | 2 | 3; body: string }
  | { type: "ul"; items: string[] };

function parse(md: string): Block[] {
  const lines = md.split("\n");
  const out: Block[] = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    const fence = line.match(/^```(\w*)\s*$/);
    if (fence) {
      const lang = fence[1] || "";
      const body: string[] = [];
      i++;
      while (i < lines.length && !/^```\s*$/.test(lines[i])) { body.push(lines[i]); i++; }
      i++; // skip closing fence (or end)
      out.push({ type: "code", lang, body: body.join("\n") });
      continue;
    }
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      out.push({ type: "h", level: h[1].length as 1 | 2 | 3, body: h[2] });
      i++; continue;
    }
    if (/^\s*[-*]\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*[-*]\s+/, ""));
        i++;
      }
      out.push({ type: "ul", items });
      continue;
    }
    if (line.trim() === "") { i++; continue; }
    // paragraph (join consecutive non-empty, non-special lines)
    const body: string[] = [line];
    i++;
    while (i < lines.length && lines[i].trim() !== "" && !/^```|^#{1,3}\s|^\s*[-*]\s/.test(lines[i])) {
      body.push(lines[i]); i++;
    }
    out.push({ type: "p", body: body.join("\n") });
  }
  return out;
}

function CodeBlock({ lang, body }: { lang: string; body: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(body);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {}
  };
  return (
    <div className="my-1.5 overflow-hidden rounded-md border border-[color:var(--border)] bg-[var(--ink)]">
      <div className="flex items-center justify-between border-b border-[color:var(--border)] bg-[var(--ink-2)] px-2 py-1">
        <span className="font-mono text-[9px] tracking-widest text-[color:var(--magenta)]">
          {(lang || "code").toUpperCase()}
        </span>
        <button onClick={copy}
          className="flex items-center gap-1 font-display text-[9px] font-extrabold tracking-widest text-foreground/60 hover:text-cyan">
          {copied ? <><Check className="h-3 w-3 text-[color:var(--green)]" /> COPIED</>
                  : <><Copy className="h-3 w-3" /> COPY</>}
        </button>
      </div>
      <pre className="overflow-x-auto p-2 font-mono text-[11px] leading-relaxed text-cyan">{body}</pre>
    </div>
  );
}

export const MarkdownLite = memo(function MarkdownLite({ text }: { text: string }) {
  const blocks = parse(text);
  return (
    <div className="space-y-1.5">
      {blocks.map((b, i) => {
        if (b.type === "code") return <CodeBlock key={i} lang={b.lang} body={b.body} />;
        if (b.type === "h") {
          const sz = b.level === 1 ? "text-[13px]" : b.level === 2 ? "text-[12px]" : "text-[11.5px]";
          return (
            <div key={i}
              className={`font-display ${sz} font-extrabold tracking-[0.12em] text-cyan`}
              dangerouslySetInnerHTML={{ __html: renderInline(b.body) }} />
          );
        }
        if (b.type === "ul") {
          return (
            <ul key={i} className="ml-3 list-none space-y-0.5">
              {b.items.map((it, j) => (
                <li key={j} className="relative pl-3 font-mono text-[12px] leading-relaxed text-foreground/90">
                  <span className="absolute left-0 top-[7px] h-1 w-1 rounded-full bg-[color:var(--magenta)]" />
                  <span dangerouslySetInnerHTML={{ __html: renderInline(it) }} />
                </li>
              ))}
            </ul>
          );
        }
        return (
          <p key={i}
            className="font-mono text-[12px] leading-relaxed text-foreground/90 whitespace-pre-wrap"
            dangerouslySetInnerHTML={{ __html: renderInline(b.body) }} />
        );
      })}
    </div>
  );
});
