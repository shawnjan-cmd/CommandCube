import { useState } from "react";
import { Bar, SectionHeader, Tag } from "../atoms";

const SUBS = ["Nexus", "System", "Bridge", "Bot"] as const;

const NeuralGraph = () => {
  const nodes = Array.from({ length: 22 }, (_, i) => ({
    x: 12 + ((i * 47) % 88),
    y: 14 + ((i * 31) % 72),
    r: 1.4 + ((i * 7) % 3) * 0.6,
  }));
  const edges: [number, number][] = [];
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const dx = nodes[i].x - nodes[j].x;
      const dy = nodes[i].y - nodes[j].y;
      if (Math.hypot(dx, dy) < 22) edges.push([i, j]);
    }
  }
  return (
    <svg viewBox="0 0 100 100" className="w-full h-44" preserveAspectRatio="none">
      {edges.map(([a, b], i) => (
        <line key={i} x1={nodes[a].x} y1={nodes[a].y} x2={nodes[b].x} y2={nodes[b].y}
              stroke="hsl(187 100% 50% / .25)" strokeWidth="0.2" />
      ))}
      {nodes.map((n, i) => (
        <circle key={i} cx={n.x} cy={n.y} r={n.r}
                fill={i % 5 === 0 ? "hsl(296 100% 55%)" : "hsl(187 100% 50%)"}
                style={{ filter: "drop-shadow(0 0 2px currentColor)" }} />
      ))}
    </svg>
  );
};

const FindingsChart = () => {
  const data = [12, 18, 22, 19, 28, 35, 31, 42, 48, 44, 55, 63];
  const max = Math.max(...data);
  return (
    <div className="flex items-end gap-1 h-24">
      {data.map((v, i) => (
        <div key={i} className="flex-1 rounded-t-sm transition-all"
             style={{
               height: `${(v / max) * 100}%`,
               background: "linear-gradient(180deg, hsl(187 100% 50%), hsl(296 100% 55% / .5))",
               boxShadow: "0 0 6px hsl(187 100% 50% / .4)",
             }} />
      ))}
    </div>
  );
};

const Donut = () => {
  const segs = [
    { v: 38, c: "hsl(187 100% 50%)" },
    { v: 26, c: "hsl(296 100% 55%)" },
    { v: 18, c: "hsl(135 100% 50%)" },
    { v: 12, c: "hsl(38 100% 50%)" },
    { v: 6,  c: "hsl(350 95% 55%)" },
  ];
  const total = segs.reduce((s, x) => s + x.v, 0);
  const C = 2 * Math.PI * 30;
  let acc = 0;
  return (
    <div className="flex items-center gap-3">
      <svg width="90" height="90" viewBox="0 0 80 80" className="-rotate-90">
        <circle cx="40" cy="40" r="30" stroke="hsl(var(--surface-3))" strokeWidth="10" fill="none" />
        {segs.map((s, i) => {
          const len = (s.v / total) * C;
          const off = (acc / total) * C;
          acc += s.v;
          return (
            <circle key={i} cx="40" cy="40" r="30" stroke={s.c} strokeWidth="10" fill="none"
                    strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-off} />
          );
        })}
      </svg>
      <div className="flex-1 space-y-1">
        {["Tutorials", "API Refs", "Snippets", "Issues", "Other"].map((l, i) => (
          <div key={l} className="flex items-center gap-2 text-[0.6rem] font-mono">
            <span className="w-2 h-2 rounded-full" style={{ background: segs[i].c }} />
            <span className="text-foreground/80 flex-1">{l}</span>
            <span className="text-muted-foreground">{segs[i].v}%</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export const KbTab = () => {
  const [sub, setSub] = useState<typeof SUBS[number]>("Nexus");
  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex gap-1.5 p-1 bg-surface-2 border border-border rounded-full w-fit mx-auto">
        {SUBS.map((s) => (
          <button key={s} onClick={() => setSub(s)}
            className={`px-4 py-1.5 rounded-full font-mono text-[0.6rem] font-bold tracking-wider transition ${
              sub === s ? "text-background" : "text-muted-foreground"
            }`}
            style={sub === s ? { background: "var(--gradient-cyan-magenta)", boxShadow: "var(--glow-cyan)" } : undefined}
          >
            {s.toUpperCase()}
          </button>
        ))}
      </div>

      <section>
        <SectionHeader title="NEURAL KB GRAPH" badge="LIVE" />
        <div className="cyber-card p-3 cyber-border-grad relative overflow-hidden">
          <NeuralGraph />
          <div className="absolute inset-x-0 top-0 h-1/3 pointer-events-none animate-scan"
               style={{ background: "linear-gradient(180deg, hsl(187 100% 50% / .08), transparent)" }} />
        </div>
        <div className="grid grid-cols-4 gap-2 mt-2">
          {[["FINDINGS","482"],["SESSIONS","37"],["KB LINKS","1.2K"],["NODES","94"]].map(([l,v]) => (
            <div key={l} className="cyber-card p-2 text-center">
              <div className="label-mono">{l}</div>
              <div className="font-mono text-sm font-bold glow-text-cyan">{v}</div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader title="FINDINGS GROWTH" badge="12 MO" />
        <div className="cyber-card p-3"><FindingsChart /></div>
      </section>

      <section>
        <SectionHeader title="PROTOCOL STATUS" />
        <div className="space-y-2">
          {[
            { n: "ANEX Local", t: "ACTIVE",   c: "green"   as const, v: "204 ops/s" },
            { n: "SNET Relay", t: "STANDBY",  c: "warning" as const, v: "12 peers"  },
            { n: "FUSE Inject",t: "RUNNING",  c: "cyan"    as const, v: "3 hooks"   },
            { n: "QLOOP",      t: "IDLE",     c: "magenta" as const, v: "queue 0"   },
          ].map((p) => (
            <div key={p.n} className="cyber-card p-3 flex items-center justify-between">
              <div>
                <div className="font-mono text-xs font-bold">{p.n}</div>
                <div className="font-mono text-[0.55rem] text-muted-foreground">{p.v}</div>
              </div>
              <Tag color={p.c}>{p.t}</Tag>
            </div>
          ))}
        </div>
      </section>

      <section className="grid grid-cols-2 gap-2.5">
        <div className="cyber-card p-3">
          <div className="label-mono mb-2">ARTICLES BY SOURCE</div>
          <div className="space-y-2">
            {[["Python Docs",82],["GitHub",64],["StackOverflow",47],["MDN",33],["Reddit",18]].map(([l,v]) => (
              <Bar key={l as string} label={l as string} value={v as number} color="cyan" />
            ))}
          </div>
        </div>
        <div className="cyber-card p-3">
          <div className="label-mono mb-2">KB CATEGORIES</div>
          <Donut />
        </div>
      </section>
    </div>
  );
};
