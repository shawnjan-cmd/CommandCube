import { useState } from "react";
import { ArrowDownToLine, ArrowUpFromLine, Backpack, Cpu, FolderTree, HardDrive, Network, Radar, ScanLine, Shield, TerminalSquare } from "lucide-react";
import { SectionHeader, Tag } from "../atoms";

const SUBS = ["Files", "Tools", "Terminal"] as const;

const TOOLS = [
  { Icon: Cpu,        title: "Performance", tag: "SYSTEM",  c: "cyan"    as const },
  { Icon: HardDrive,  title: "Sys Snapshot",tag: "SYSTEM",  c: "cyan"    as const },
  { Icon: Network,    title: "LAN Map",     tag: "NETWORK", c: "magenta" as const },
  { Icon: Radar,      title: "Port Scan",   tag: "NETWORK", c: "magenta" as const },
  { Icon: Backpack,   title: "Backup Docs", tag: "FILES",   c: "green"   as const },
  { Icon: FolderTree, title: "Tree View",   tag: "FILES",   c: "green"   as const },
  { Icon: Shield,     title: "Firewall",    tag: "NETWORK", c: "magenta" as const },
  { Icon: ScanLine,   title: "Deep Scan",   tag: "SYSTEM",  c: "cyan"    as const },
];

const COMMANDS = [
  "> python --version",
  "> ps aux | head -10",
  "> netstat -an | grep LISTEN",
  "> df -h",
  "> systeminfo",
  "> tasklist /v",
  "> ipconfig /all",
  "> tracert google.com",
];

export const FilesTab = () => {
  const [sub, setSub] = useState<typeof SUBS[number]>("Files");
  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex gap-1.5 p-1 bg-surface-2 border border-border rounded-full w-fit mx-auto">
        {SUBS.map((s) => (
          <button key={s} onClick={() => setSub(s)}
            className={`px-4 py-1.5 rounded-full font-mono text-[0.6rem] font-bold tracking-wider transition ${sub===s?"text-background":"text-muted-foreground"}`}
            style={sub===s ? { background: "var(--gradient-cyan-magenta)", boxShadow: "var(--glow-cyan)" } : undefined}>
            {s.toUpperCase()}
          </button>
        ))}
      </div>

      {sub === "Files" && (
        <>
          <section>
            <SectionHeader title="FILE TRANSFER" badge="P2P" />
            <div className="grid grid-cols-2 gap-2.5">
              <button className="cyber-card aspect-square flex flex-col items-center justify-center gap-2 pressable hover:border-primary/40">
                <ArrowUpFromLine className="w-9 h-9 text-primary" style={{ filter: "drop-shadow(0 0 8px hsl(187 100% 50% / .6))" }} />
                <div className="font-mono text-xs font-bold">SEND FILES</div>
                <div className="label-mono">DROP HERE</div>
              </button>
              <button className="cyber-card aspect-square flex flex-col items-center justify-center gap-2 pressable hover:border-accent/40">
                <ArrowDownToLine className="w-9 h-9 text-accent" style={{ filter: "drop-shadow(0 0 8px hsl(296 100% 55% / .6))" }} />
                <div className="font-mono text-xs font-bold">RECEIVED</div>
                <div className="label-mono">3 ITEMS</div>
              </button>
            </div>
          </section>
          <section>
            <SectionHeader title="CLIPBOARD SYNC" />
            <div className="cyber-card p-3">
              <textarea
                rows={4}
                placeholder="// Paste here to instantly sync with paired PC..."
                className="w-full bg-transparent font-mono text-xs outline-none resize-none placeholder:text-muted-foreground"
              />
              <div className="flex justify-between items-center mt-2">
                <span className="label-mono">END-TO-END · ENCRYPTED</span>
                <Tag color="green">LIVE</Tag>
              </div>
            </div>
          </section>
        </>
      )}

      {sub === "Tools" && (
        <section>
          <SectionHeader title="QUICK TOOLS" badge={`${TOOLS.length}`} />
          <div className="grid grid-cols-2 gap-2.5">
            {TOOLS.map(({ Icon, title, tag, c }) => (
              <button key={title} className="cyber-card p-3 pressable text-left hover:border-primary/40 transition relative">
                <div className="absolute top-2 right-2"><Tag color={c}>{tag}</Tag></div>
                <Icon className="w-6 h-6 mb-2"
                      style={{ color: `hsl(var(--${c==="cyan"?"primary":c==="green"?"success":"accent"}))` }} />
                <div className="font-mono text-xs font-bold">{title}</div>
              </button>
            ))}
          </div>
        </section>
      )}

      {sub === "Terminal" && (
        <section>
          <SectionHeader title="QUICK EXECUTE" badge="LIVE TTY" />
          <div className="grid grid-cols-1 gap-2">
            {COMMANDS.map((cmd) => (
              <button key={cmd} className="cyber-card p-3 pressable text-left flex items-center gap-3 hover:border-success/40 transition">
                <TerminalSquare className="w-4 h-4 text-success" />
                <code className="font-mono text-xs text-success/90 flex-1 truncate" style={{ textShadow: "0 0 6px hsl(135 100% 50% / .35)" }}>
                  {cmd}
                </code>
                <span className="label-mono">RUN</span>
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
