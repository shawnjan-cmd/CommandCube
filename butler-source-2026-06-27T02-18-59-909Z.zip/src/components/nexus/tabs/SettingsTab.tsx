import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { SectionHeader, Tag } from "../atoms";

const THEMES = [
  { id: "nexus",   name: "Nexus Core",       palette: ["#00E5FF", "#FF00FF", "#0B0E14", "#00FF66"] },
  { id: "phantom", name: "Phantom Red",      palette: ["#FF1744", "#FF6E40", "#0B0E14", "#FFAA00"] },
  { id: "aurora",  name: "Aurora Borealis",  palette: ["#00FFB2", "#7C4DFF", "#0B0E14", "#00E5FF"] },
  { id: "matrix",  name: "Matrix Green",     palette: ["#00FF66", "#00C853", "#000000", "#76FF03"] },
  { id: "synth",   name: "Synthwave",        palette: ["#FF00FF", "#00E5FF", "#1A0033", "#FFAA00"] },
];

const TOGGLES = [
  { id: "anim",  label: "Pause All Animations", desc: "Disable transitions and motion. Best for low-power devices." },
  { id: "bare",  label: "Bare Minimum Mode",    desc: "Strip all effects, glows, and gradients for max performance." },
  { id: "hap",   label: "Disable Haptics",      desc: "Turn off vibration feedback on button press." },
  { id: "tab",   label: "Compact Tab Bar",      desc: "Hide labels in the bottom toolbar to save space." },
];

const STACK = [
  { k: "App Version",   v: "v8.0.0-cyber" },
  { k: "Package",       v: "com.butler.ai" },
  { k: "Engine",        v: "Ollama Local AI" },
  { k: "Architecture",  v: "TanStack Start · React 19" },
];
const DEPS = [
  ["react", "19"], ["@tanstack/react-router", "1"],
  ["tailwindcss", "4"], ["lucide-react", "0.4"], ["ai", "5"],
];

export const SettingsTab = () => {
  const [active, setActive] = useState("nexus");
  const [tg, setTg] = useState<Record<string, boolean>>({ tab: true });
  const [stackOpen, setStackOpen] = useState(true);
  return (
    <div className="space-y-5 animate-fade-in">
      <section>
        <SectionHeader title="ACTIVE THEME" badge={active.toUpperCase()} />
        <div className="space-y-2">
          {THEMES.map((t) => (
            <button key={t.id} onClick={() => setActive(t.id)}
              className={`cyber-card w-full p-3 flex items-center gap-3 pressable transition ${
                active === t.id ? "border-primary/60" : ""
              }`}
              style={active === t.id ? { boxShadow: "0 0 20px hsl(187 100% 50% / .25), inset 0 1px 0 hsl(0 0% 100% / .05)" } : undefined}>
              <div className="relative w-10 h-10 rounded-full overflow-hidden border border-border">
                {t.palette.map((c, i) => (
                  <div key={i} className="absolute" style={{
                    inset: 0,
                    background: c,
                    clipPath: `polygon(50% 50%, ${50 + 50 * Math.cos((i * Math.PI) / 2)}% ${50 + 50 * Math.sin((i * Math.PI) / 2)}%, ${50 + 50 * Math.cos(((i + 1) * Math.PI) / 2)}% ${50 + 50 * Math.sin(((i + 1) * Math.PI) / 2)}%)`,
                  }} />
                ))}
              </div>
              <div className="flex-1 text-left">
                <div className="font-mono text-xs font-bold">{t.name}</div>
                <div className="font-mono text-[0.55rem] text-muted-foreground tracking-wider">{t.palette.join(" · ")}</div>
              </div>
              {active === t.id && <Tag color="cyan">ACTIVE</Tag>}
            </button>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader title="SERVER ADDRESS" />
        <div className="cyber-card p-3 space-y-2">
          {[["IP ADDRESS","192.168.1.42"],["PORT","8765"]].map(([l, v]) => (
            <div key={l}>
              <div className="label-mono mb-1">{l}</div>
              <div className="flex items-center gap-2 px-3 py-2 bg-surface-3 border border-border rounded-lg">
                <span className="text-success font-mono text-xs">{`>`}</span>
                <input defaultValue={v} className="bg-transparent flex-1 font-mono text-xs outline-none" />
                <span className="w-1.5 h-4 bg-primary animate-blink" />
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader title="PERFORMANCE MODE" />
        <div className="space-y-2">
          {TOGGLES.map((t) => {
            const on = !!tg[t.id];
            return (
              <div key={t.id} className="cyber-card p-3 flex items-start gap-3">
                <div className="flex-1">
                  <div className="font-mono text-xs font-bold">{t.label}</div>
                  <div className="font-mono text-[0.6rem] text-muted-foreground mt-0.5">{t.desc}</div>
                </div>
                <button onClick={() => setTg((s) => ({ ...s, [t.id]: !on }))}
                  className={`relative w-10 h-5 rounded-full border transition ${on ? "border-primary/60" : "border-border bg-surface-3"}`}
                  style={on ? { background: "hsl(187 100% 50% / .2)", boxShadow: "0 0 10px hsl(187 100% 50% / .4)" } : undefined}>
                  <span className={`absolute top-0.5 w-4 h-4 rounded-full transition-all ${on ? "left-[22px] bg-primary" : "left-0.5 bg-muted-foreground"}`}
                        style={on ? { boxShadow: "0 0 8px hsl(187 100% 50% / .8)" } : undefined} />
                </button>
              </div>
            );
          })}
        </div>
      </section>

      <section>
        <SectionHeader title="TECH STACK" />
        <div className="cyber-card overflow-hidden">
          <button onClick={() => setStackOpen((o) => !o)} className="w-full flex items-center justify-between p-3 pressable">
            <span className="font-mono text-xs font-bold">System Info</span>
            <ChevronDown className={`w-4 h-4 transition ${stackOpen ? "rotate-180" : ""} text-muted-foreground`} />
          </button>
          {stackOpen && (
            <div className="px-3 pb-3 space-y-2 border-t border-border pt-3">
              {STACK.map((s) => (
                <div key={s.k} className="flex justify-between font-mono text-[0.65rem]">
                  <span className="text-muted-foreground">{s.k}</span>
                  <span className="text-foreground">{s.v}</span>
                </div>
              ))}
              <div className="pt-2 border-t border-border">
                <div className="label-mono mb-2">DEPENDENCIES</div>
                <div className="flex flex-wrap gap-1.5">
                  {DEPS.map(([k, v]) => (
                    <span key={k} className="px-2 py-0.5 rounded-md bg-surface-3 border border-border font-mono text-[0.55rem]">
                      <span className="text-foreground/85">{k}</span>
                      <span className="text-primary"> {v}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
