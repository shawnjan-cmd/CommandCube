import {
  Activity, Cpu, FileSearch, HardDrive, MemoryStick, Power, Recycle, Search, ShieldCheck, Trash2, Wifi, Zap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Bar, Ring, SectionHeader, StatBox, Tag } from "../atoms";

const quickScripts: { Icon: LucideIcon; label: string }[] = [
  { Icon: Trash2,      label: "Clean Temp" },
  { Icon: HardDrive,   label: "Disk Info" },
  { Icon: Activity,    label: "Top Processes" },
  { Icon: Wifi,        label: "Network Test" },
  { Icon: Recycle,     label: "Empty Recycle" },
  { Icon: MemoryStick, label: "Free RAM" },
  { Icon: ShieldCheck, label: "Quick Virus Scan" },
  { Icon: Power,       label: "Startup Apps" },
  { Icon: Search,      label: "IP + Network" },
];

export const DashboardTab = () => (
  <div className="space-y-5 animate-fade-in">
    <section>
      <SectionHeader title="PC HEALTH OVERVIEW" />
      <div className="grid grid-cols-2 gap-2.5">
        <StatBox label="DISK HEALTH"     value="94%"  color="green" sub="SMART · OK" />
        <StatBox label="THREATS BLOCKED" value="142"  color="destructive" sub="LAST 30D" />
        <StatBox label="FILES ORGANIZED" value="3.2K" color="cyan" sub="AUTO-RULES" />
        <StatBox label="SPACE RECOVERED" value="48GB" color="magenta" sub="LIFETIME" />
        <StatBox label="SCRIPTS ACTIVE"  value="12"   color="warning" />
        <StatBox label="UPTIME"          value="3d 4h" color="green" />
      </div>
    </section>

    <section>
      <SectionHeader title="PERFORMANCE MONITOR" badge="REALTIME" />
      <div className="cyber-card p-4">
        <div className="grid grid-cols-3 gap-2 mb-4">
          <Ring value={42} label="CPU" color="cyan" size={72} />
          <Ring value={67} label="RAM" color="magenta" size={72} />
          <Ring value={28} label="GPU" color="green" size={72} />
        </div>
        <Bar value={81} label="DISK USAGE" color="warning" right="412 / 512 GB" />
      </div>
    </section>

    <section>
      <SectionHeader title="QUICK PC SCRIPTS" badge="9" />
      <div className="grid grid-cols-3 gap-2">
        {quickScripts.map(({ Icon, label }) => (
          <button key={label} className="cyber-card aspect-square flex flex-col items-center justify-center gap-1.5 p-2 pressable hover:border-primary/40 transition">
            <Icon className="w-5 h-5 text-primary" />
            <div className="font-mono text-[0.55rem] text-center font-semibold leading-tight">{label}</div>
          </button>
        ))}
      </div>
    </section>

    <section>
      <SectionHeader title="SCAN RESULTS" />
      <div className="cyber-card p-4 space-y-3">
        <Bar label="TEMP FILES"   value={62} color="cyan"    right="2.4 GB" />
        <Bar label="CACHE"        value={48} color="magenta" right="1.1 GB" />
        <Bar label="LARGE FILES"  value={31} color="warning" right="14 items" />
        <Bar label="DISK"         value={81} color="destructive" right="412 / 512 GB" />
      </div>
    </section>

    <section>
      <SectionHeader title="LIFETIME STATS" />
      <div className="grid grid-cols-2 gap-2.5">
        {[
          { Icon: Trash2,     n: "12.4K", l: "Cleaned ops",     c: "cyan"    as const },
          { Icon: FileSearch, n: "8.7K",  l: "Organized files", c: "magenta" as const },
          { Icon: Cpu,        n: "1.2K",  l: "Scripts executed",c: "green"   as const },
          { Icon: Zap,        n: "342",   l: "Undone rollbacks", c: "warning" as const },
        ].map(({ Icon, n, l, c }) => (
          <div key={l} className="cyber-card p-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center"
                 style={{ background: `hsl(var(--${c === "cyan" ? "primary" : c === "green" ? "success" : c === "magenta" ? "accent" : "warning"}) / .12)` }}>
              <Icon className="w-5 h-5" style={{ color: `hsl(var(--${c === "cyan" ? "primary" : c === "green" ? "success" : c === "magenta" ? "accent" : "warning"}))` }} />
            </div>
            <div>
              <div className={`stat-number text-base ${c === "cyan" ? "glow-text-cyan" : c === "green" ? "glow-text-green" : c === "magenta" ? "glow-text-magenta" : "glow-text-warning"}`}>{n}</div>
              <div className="label-mono">{l}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex justify-end gap-1.5">
        <Tag color="green">SAFE MODE</Tag>
        <Tag color="cyan">AUTO-LOG</Tag>
      </div>
    </section>
  </div>
);
