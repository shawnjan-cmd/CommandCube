import { SectionHeader, Tag } from "../atoms";

export const PlaceholderTab = ({ title, desc }: { title: string; desc: string }) => (
  <div className="space-y-5 animate-fade-in">
    <SectionHeader title={title} badge="MODULE" />
    <div className="cyber-card cyber-border-grad p-6 text-center relative overflow-hidden">
      <div className="absolute inset-x-0 top-0 h-1/2 pointer-events-none animate-scan"
           style={{ background: "linear-gradient(180deg, hsl(187 100% 50% / .08), transparent)" }} />
      <div className="font-mono text-2xl font-black glow-text-cyan tracking-widest">{title}</div>
      <div className="font-mono text-[0.65rem] text-muted-foreground mt-2 max-w-xs mx-auto leading-relaxed">{desc}</div>
      <div className="mt-4 flex justify-center gap-2">
        <Tag color="cyan">READY</Tag>
        <Tag color="magenta">v8.0</Tag>
      </div>
    </div>
  </div>
);
