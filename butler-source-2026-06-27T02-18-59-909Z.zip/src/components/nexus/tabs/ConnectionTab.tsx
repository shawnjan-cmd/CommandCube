import { useEffect, useState } from "react";
import { Anchor, Compass, Fish, Radio, Send, Shell, Waves } from "lucide-react";

const Jellyfish = ({ hue = 180, delay = 0 }: { hue?: number; delay?: number }) => (
  <svg viewBox="0 0 120 160" className="w-full h-full">
    <defs>
      <radialGradient id={`jg${hue}`} cx="50%" cy="40%" r="60%">
        <stop offset="0%"  stopColor={`hsl(${hue} 100% 80%)`} stopOpacity=".95"/>
        <stop offset="60%" stopColor={`hsl(${hue} 100% 55%)`} stopOpacity=".5"/>
        <stop offset="100%" stopColor={`hsl(${hue} 100% 35%)`} stopOpacity="0"/>
      </radialGradient>
    </defs>
    <g style={{ transformOrigin: "60px 80px", animation: `jelly-pulse 3.4s ease-in-out ${delay}s infinite` }}>
      <ellipse cx="60" cy="55" rx="40" ry="32" fill={`url(#jg${hue})`} />
      <ellipse cx="60" cy="55" rx="40" ry="32" fill="none" stroke={`hsl(${hue} 100% 70% / .55)`} strokeWidth="1"/>
      {[42,52,60,68,78].map((x,i)=>(
        <path key={i} d={`M${x} 80 Q${x-4} 110 ${x+2} 140`} stroke={`hsl(${hue} 100% 70% / .6)`} strokeWidth="1.4" fill="none"
              style={{ animation:`sway ${2+i*0.3}s ease-in-out ${i*0.1}s infinite`, transformOrigin:`${x}px 80px` }}/>
      ))}
    </g>
  </svg>
);

const Anglerfish = ({ depth = 0 }: { depth?: number }) => (
  <svg viewBox="0 0 220 160" className="w-full h-full">
    <defs>
      <radialGradient id="lure" cx="50%" cy="50%" r="50%">
        <stop offset="0%"  stopColor="hsl(50 100% 85%)"/>
        <stop offset="60%" stopColor="hsl(40 100% 55% /.7)"/>
        <stop offset="100%" stopColor="transparent"/>
      </radialGradient>
      <linearGradient id="body" x1="0" x2="1">
        <stop offset="0" stopColor="hsl(220 40% 8%)"/>
        <stop offset="1" stopColor="hsl(200 60% 16%)"/>
      </linearGradient>
    </defs>
    <circle cx="56" cy="60" r="44" fill="url(#lure)" style={{animation:"lure-flicker 2.4s ease-in-out infinite"}}/>
    <path d="M70 80 Q120 30 200 70 Q170 100 200 130 Q120 150 70 105 Z" fill="url(#body)" stroke="hsl(180 80% 55% /.4)"/>
    <path d="M90 70 Q70 50 58 58" stroke="hsl(180 80% 55% /.7)" strokeWidth="1.5" fill="none"/>
    <circle cx="58" cy="58" r="6" fill="hsl(50 100% 70%)" style={{animation:"lure-flicker 2.4s ease-in-out infinite"}}/>
    <circle cx="120" cy="78" r="4" fill="hsl(170 100% 70%)"/>
    {[100,110,120,130,140].map((x,i)=>(
      <polygon key={i} points={`${x},96 ${x+4},96 ${x+2},104`} fill="hsl(40 30% 90%)"/>
    ))}
    <text x="160" y="155" fontSize="9" fill="hsl(180 60% 60%)" fontFamily="monospace">{depth}m</text>
  </svg>
);

export const ConnectionTab = () => {
  const [depth, setDepth] = useState(2847);
  const [pressure, setPressure] = useState(284.3);
  const [o2, setO2] = useState(72);
  const [salinity, setSalinity] = useState(34.7);

  useEffect(() => {
    const id = setInterval(() => {
      setDepth(d => d + (Math.random() > .5 ? 1 : -1));
      setPressure(p => +(p + (Math.random() - .5) * .4).toFixed(1));
      setO2(o => Math.max(40, Math.min(98, o + (Math.random() > .5 ? 1 : -1))));
      setSalinity(s => +(s + (Math.random() - .5) * .1).toFixed(1));
    }, 1500);
    return () => clearInterval(id);
  }, []);

  return (
  <div className="relative space-y-5 animate-fade-in pt-2">
    <section className="relative abyss-card caustics overflow-hidden p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Shell className="w-4 h-4" style={{color:"hsl(170 100% 70%)"}}/>
          <span className="font-mono text-[0.65rem] tracking-[0.3em] biolume-text">ABYSSAL · OBSERVATORY</span>
        </div>
        <span className="font-mono text-[0.6rem] biolume-pink animate-pulse">⬤ LIVE FEED</span>
      </div>

      <div className="relative h-44 rounded-2xl overflow-hidden mb-4"
           style={{background:"radial-gradient(ellipse at 30% 50%, hsl(190 90% 18% /.8), hsl(220 80% 4%) 70%)"}}>
        <div className="absolute left-[18%] top-[42%] -translate-x-1/2 -translate-y-1/2">
          {[0,1,2].map(i=>(
            <div key={i} className="absolute w-20 h-20 rounded-full border"
                 style={{borderColor:"hsl(180 100% 60% /.5)", animation:`sonar-pulse 3s ease-out ${i*1}s infinite`}}/>
          ))}
        </div>
        <div className="absolute inset-0">
          <Anglerfish depth={depth}/>
        </div>
        <div className="absolute top-2 right-2 font-mono text-[0.55rem] biolume-text leading-tight text-right">
          <div>LAT  -34.892°</div>
          <div>LON  151.207°</div>
          <div>HEAD 247.4°</div>
        </div>
        <div className="absolute bottom-2 left-2 font-mono text-[0.55rem] biolume-text">
          <span className="biolume-pink">▸</span> THERMAL VENT · 2.1km
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {[
          {l:"DEPTH",  v:`${depth}`, u:"m",   h:180},
          {l:"PRESS",  v:`${pressure}`, u:"bar", h:320},
          {l:"O₂",     v:`${o2}`, u:"%",   h:160},
          {l:"SALIN",  v:`${salinity}`, u:"psu", h:200},
        ].map(s=>(
          <div key={s.l} className="rounded-xl p-2 text-center"
               style={{background:"hsl(200 70% 6% /.7)", border:`1px solid hsl(${s.h} 80% 50% /.35)`}}>
            <div className="font-mono text-[0.5rem] tracking-widest" style={{color:`hsl(${s.h} 70% 70%)`}}>{s.l}</div>
            <div className="font-mono text-base font-bold" style={{color:`hsl(${s.h} 100% 78%)`, textShadow:`0 0 10px hsl(${s.h} 100% 60% /.7)`}}>{s.v}</div>
            <div className="font-mono text-[0.5rem] opacity-60" style={{color:`hsl(${s.h} 50% 70%)`}}>{s.u}</div>
          </div>
        ))}
      </div>
    </section>

    <section className="abyss-card p-4 relative overflow-hidden">
      <div className="flex items-center justify-between mb-3">
        <span className="font-mono text-[0.65rem] tracking-[0.3em] biolume-text">DRIFT · NODES</span>
        <span className="font-mono text-[0.55rem] biolume-pink">4 ACTIVE · SWARM SYNC</span>
      </div>
      <div className="grid grid-cols-4 gap-2">
        {[
          {n:"AURA",   hue:180, lat:"42ms"},
          {n:"NYMPH",  hue:320, lat:"89ms"},
          {n:"ECHO",   hue:160, lat:"31ms"},
          {n:"VESPER", hue:280, lat:"117ms"},
        ].map((j,i)=>(
          <div key={j.n} className="relative">
            <div className="h-20"><Jellyfish hue={j.hue} delay={i*0.4}/></div>
            <div className="text-center font-mono text-[0.55rem] tracking-widest"
                 style={{color:`hsl(${j.hue} 100% 75%)`, textShadow:`0 0 8px hsl(${j.hue} 100% 55% /.7)`}}>{j.n}</div>
            <div className="text-center font-mono text-[0.5rem] opacity-70" style={{color:`hsl(${j.hue} 60% 70%)`}}>{j.lat}</div>
          </div>
        ))}
      </div>
    </section>

    <section className="abyss-card p-4">
      <div className="flex items-center justify-between mb-3">
        <span className="font-mono text-[0.65rem] tracking-[0.3em] biolume-text">TIDAL · COMMANDS</span>
        <Waves className="w-4 h-4" style={{color:"hsl(180 100% 70%)"}}/>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {[
          {i:Compass, n:"PLOT COURSE",   h:180},
          {i:Radio,   n:"PING SWARM",    h:320},
          {i:Anchor,  n:"DROP ANCHOR",   h:200},
          {i:Fish,    n:"SCAN BIOMASS",  h:160},
        ].map(({i:Ic,n,h})=>(
          <button key={n} className="group relative overflow-hidden rounded-2xl p-3 flex items-center gap-3 transition active:scale-[.97]"
                  style={{
                    background:`linear-gradient(135deg, hsl(${h} 80% 14% /.9), hsl(${h} 60% 6% /.95))`,
                    border:`1px solid hsl(${h} 100% 55% /.4)`,
                    boxShadow:`inset 0 1px 0 hsl(${h} 100% 70% /.15), 0 0 20px hsl(${h} 100% 50% /.15)`,
                  }}>
            <div className="w-9 h-9 rounded-full flex items-center justify-center"
                 style={{background:`radial-gradient(circle, hsl(${h} 100% 60% /.4), transparent 70%)`}}>
              <Ic className="w-4 h-4" style={{color:`hsl(${h} 100% 80%)`, filter:`drop-shadow(0 0 6px hsl(${h} 100% 60%))`}}/>
            </div>
            <span className="font-mono text-[0.65rem] tracking-[0.2em]"
                  style={{color:`hsl(${h} 100% 80%)`, textShadow:`0 0 8px hsl(${h} 100% 50% /.5)`}}>{n}</span>
          </button>
        ))}
      </div>
    </section>

    <section className="abyss-card p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="font-mono text-[0.65rem] tracking-[0.3em] biolume-text">HYDROPHONE · RX</span>
        <span className="font-mono text-[0.55rem]" style={{color:"hsl(50 100% 70%)"}}>◉ REC 00:42</span>
      </div>
      <div className="flex items-end gap-[2px] h-10 mb-3">
        {Array.from({length:48}).map((_,i)=>{
          const h = 20 + Math.abs(Math.sin(i*0.6+depth*0.01))*80;
          return <div key={i} className="flex-1 rounded-sm"
            style={{height:`${h}%`, background:`linear-gradient(to top, hsl(180 100% 30%), hsl(170 100% 65%))`, opacity:.4 + h/200}}/>;
        })}
      </div>
      <div className="flex items-center gap-2 rounded-xl px-3 py-2"
           style={{background:"hsl(200 80% 4%)", border:"1px solid hsl(180 80% 40% /.4)"}}>
        <span className="font-mono text-[0.6rem] biolume-pink">abyss▸</span>
        <input placeholder="transmit to swarm…" className="flex-1 bg-transparent outline-none font-mono text-xs biolume-text placeholder:opacity-40"/>
        <button className="w-7 h-7 rounded-full flex items-center justify-center"
                style={{background:"radial-gradient(circle, hsl(50 100% 60%), hsl(30 100% 35%))",
                        boxShadow:"0 0 14px hsl(50 100% 60% /.6)"}}>
          <Send className="w-3.5 h-3.5" style={{color:"hsl(20 60% 10%)"}}/>
        </button>
      </div>
    </section>
  </div>
  );
};
