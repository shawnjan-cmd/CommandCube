import { useEffect, useRef, useState } from "react";
import { Send, Sparkles, Bot, User, Trash2, Cpu, ShieldCheck, Workflow, FileSearch } from "lucide-react";

type Role = "butler" | "you";
type Msg = { id: number; role: Role; text: string; ts: string };

const now = () =>
  new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

const SEED: Msg[] = [
  { id: 1, role: "butler", text: "Butler online. How can I assist, sir?", ts: now() },
];

const QUICK: { label: string; prompt: string; Icon: typeof Cpu }[] = [
  { label: "System status",   prompt: "Give me a full system status report.", Icon: Cpu },
  { label: "Security check",  prompt: "Run a security check on the network.", Icon: ShieldCheck },
  { label: "Summarize files", prompt: "Summarize the most recent files.",     Icon: FileSearch },
  { label: "Build a flow",    prompt: "Help me build an automation flow.",    Icon: Workflow },
];

function butlerReply(prompt: string): string {
  const p = prompt.toLowerCase();
  if (p.includes("status"))   return "All systems nominal. CPU 12%, MEM 38%, link stable.";
  if (p.includes("security")) return "No anomalies detected. Firewall and RLS policies intact.";
  if (p.includes("file"))     return "I can index the Files tab on request — say the word.";
  if (p.includes("flow"))     return "Tell me the trigger and the desired action; I'll wire it up.";
  return `Acknowledged: "${prompt}". I'll handle it.`;
}

export const AiChatTab = () => {
  const [msgs, setMsgs] = useState<Msg[]>(SEED);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "auto" });
  }, [msgs, typing]);

  const send = (text: string) => {
    const t = text.trim();
    if (!t) return;
    const userMsg: Msg = { id: Date.now(), role: "you", text: t, ts: now() };
    setMsgs((m) => [...m, userMsg]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setMsgs((m) => [...m, { id: Date.now() + 1, role: "butler", text: butlerReply(t), ts: now() }]);
      setTyping(false);
    }, 600);
  };

  const clear = () => setMsgs(SEED);

  return (
    <section className="flex flex-col gap-2 min-h-[70vh]">
      <header className="flex items-center justify-between rounded-lg border border-border bg-card/85 px-3 py-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="inline-flex items-center justify-center w-8 h-8 rounded-md bg-primary/15 text-primary">
            <Bot className="w-4 h-4" />
          </span>
          <div className="min-w-0">
            <h2 className="text-sm font-semibold tracking-tight truncate">Butler AI</h2>
            <p className="text-[11px] text-muted-foreground flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Online · ready to assist
            </p>
          </div>
        </div>
        <button onClick={clear} aria-label="Clear conversation"
          className="text-muted-foreground hover:text-foreground p-2 rounded-md hover:bg-muted/50 transition-colors">
          <Trash2 className="w-4 h-4" />
        </button>
      </header>

      <div ref={scrollRef}
        className="flex-1 min-h-[40vh] overflow-y-auto rounded-lg border border-border bg-background/70 p-3 space-y-3">
        {msgs.map((m) => <Bubble key={m.id} msg={m} />)}
        {typing && (
          <div className="flex items-center gap-2 text-muted-foreground text-xs">
            <Bot className="w-3.5 h-3.5" />
            <span className="inline-flex gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-bounce [animation-delay:-0.2s]" />
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-bounce [animation-delay:-0.1s]" />
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-bounce" />
            </span>
          </div>
        )}
      </div>

      <div className="flex gap-1.5 overflow-x-auto pb-0.5 -mx-0.5 px-0.5">
        {QUICK.map(({ label, prompt, Icon }) => (
          <button key={label} onClick={() => send(prompt)}
            className="shrink-0 inline-flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-full border border-border bg-card/60 hover:bg-muted/60 transition-colors">
            <Icon className="w-3.5 h-3.5 text-primary" />
            {label}
          </button>
        ))}
      </div>

      <form onSubmit={(e) => { e.preventDefault(); send(input); }}
        className="flex items-center gap-2 rounded-lg border border-border bg-card/85 p-1.5">
        <Sparkles className="w-4 h-4 text-primary ml-1.5 shrink-0" />
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask Butler anything…"
          className="flex-1 bg-transparent outline-none text-sm placeholder:text-muted-foreground" />
        <button type="submit" disabled={!input.trim()} aria-label="Send"
          className="inline-flex items-center justify-center w-9 h-9 rounded-md bg-primary text-primary-foreground disabled:opacity-40 hover:opacity-90 transition-opacity">
          <Send className="w-4 h-4" />
        </button>
      </form>
    </section>
  );
};

const Bubble = ({ msg }: { msg: Msg }) => {
  const mine = msg.role === "you";
  return (
    <div className={`flex gap-2 ${mine ? "flex-row-reverse" : ""}`}>
      <span className={`shrink-0 w-7 h-7 rounded-md inline-flex items-center justify-center ${mine ? "bg-muted text-foreground" : "bg-primary/15 text-primary"}`}>
        {mine ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
      </span>
      <div className={`max-w-[78%] ${mine ? "items-end" : "items-start"} flex flex-col gap-0.5`}>
        <div className={`rounded-2xl px-3 py-2 text-sm leading-snug border ${mine ? "bg-primary text-primary-foreground border-transparent rounded-tr-sm" : "bg-card text-card-foreground border-border rounded-tl-sm"}`}>
          {msg.text}
        </div>
        <span className="text-[10px] text-muted-foreground px-1">{msg.ts}</span>
      </div>
    </div>
  );
};

export default AiChatTab;
