import type { ReactNode } from "react";

export const SectionHeader = ({ title, badge }: { title: string; badge?: string }) => (
  <div className="flex items-center gap-2.5 mb-2.5">
    <div className="label-mono">{title}</div>
    <div className="flex-1 h-px bg-gradient-to-r from-border to-transparent" />
    {badge && (
      <span className="font-mono text-[0.5rem] px-2 py-0.5 rounded-full bg-surface-2 border border-border text-muted-foreground">
        {badge}
      </span>
    )}
  </div>
);

type RingColor = "cyan" | "green" | "magenta" | "warning" | "destructive";
const ringColorMap: Record<RingColor, string> = {
  cyan: "hsl(var(--primary))",
  green: "hsl(var(--success))",
  magenta: "hsl(var(--accent))",
  warning: "hsl(var(--warning))",
  destructive: "hsl(var(--destructive))",
};

export const Ring = ({
  value, label, color = "cyan", size = 64,
}: { value: number; label: string; color?: RingColor; size?: number }) => {
  const r = (size - 8) / 2;
  const c = 2 * Math.PI * r;
  const dash = (value / 100) * c;
  const stroke = ringColorMap[color];
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} stroke="hsl(var(--surface-3))" strokeWidth={4} fill="none" />
          <circle
            cx={size / 2} cy={size / 2} r={r}
            stroke={stroke} strokeWidth={4} fill="none"
            strokeDasharray={`${dash} ${c}`} strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${stroke})`, transition: "stroke-dasharray 1s ease" }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center font-mono text-xs font-bold" style={{ color: stroke }}>
          {value}%
        </div>
      </div>
      <div className="label-mono">{label}</div>
    </div>
  );
};

export const StatBox = ({
  label, value, color = "cyan", sub,
}: { label: string; value: string; color?: RingColor; sub?: string }) => {
  const colorClass = {
    cyan: "glow-text-cyan",
    green: "glow-text-green",
    magenta: "glow-text-magenta",
    warning: "glow-text-warning",
    destructive: "text-destructive",
  }[color];
  return (
    <div className="cyber-card p-3">
      <div className="label-mono mb-1">{label}</div>
      <div className={`stat-number text-lg ${colorClass}`}>{value}</div>
      {sub && <div className="font-mono text-[0.55rem] text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
};

export const Bar = ({ value, color = "cyan", label, right }: { value: number; color?: RingColor; label?: string; right?: string }) => {
  const stroke = ringColorMap[color];
  return (
    <div>
      {(label || right) && (
        <div className="flex justify-between mb-1">
          <span className="label-mono">{label}</span>
          <span className="font-mono text-[0.6rem]" style={{ color: stroke }}>{right ?? `${value}%`}</span>
        </div>
      )}
      <div className="h-1.5 rounded-full bg-surface-3 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${value}%`, background: stroke, boxShadow: `0 0 8px ${stroke}` }}
        />
      </div>
    </div>
  );
};

export const Tag = ({ children, color = "cyan" }: { children: ReactNode; color?: RingColor }) => {
  const palette: Record<RingColor, string> = {
    cyan:        "bg-primary/10 border-primary/30 text-primary",
    green:       "bg-success/10 border-success/30 text-success",
    magenta:     "bg-accent/10 border-accent/30 text-accent",
    warning:     "bg-warning/10 border-warning/30 text-warning",
    destructive: "bg-destructive/10 border-destructive/30 text-destructive",
  };
  return (
    <span className={`inline-flex items-center px-1.5 py-0.5 rounded-md border font-mono text-[0.5rem] font-bold tracking-wider ${palette[color]}`}>
      {children}
    </span>
  );
};
