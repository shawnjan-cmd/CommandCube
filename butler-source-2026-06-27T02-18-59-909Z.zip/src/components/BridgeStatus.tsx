import { Link } from "@tanstack/react-router";
import { Cpu, Loader2, ShieldOff, Wifi, WifiOff } from "lucide-react";
import { fmtUptime, type Telemetry } from "@/lib/useTelemetry";

export function BridgeStatus({ t }: { t: Telemetry }) {
  if (!t.paired) {
    return (
      <Link to={"/home" as any} className="chip chip-warning">
        <ShieldOff className="size-3" /> Pair PC
      </Link>
    );
  }
  if (!t.online) {
    return (
      <span className="chip chip-danger">
        <WifiOff className="size-3" /> Offline
      </span>
    );
  }
  return (
    <span className="chip chip-success">
      <Wifi className="size-3" /> {t.hostname || "Bridge"}{t.uptime ? ` · ${fmtUptime(t.uptime)}` : ""}
    </span>
  );
}

export function ModelChip({ t }: { t: Telemetry }) {
  if (!t.paired) return null;
  return (
    <span className="chip chip-cyan">
      {t.online ? <Cpu className="size-3" /> : <Loader2 className="size-3 animate-spin" />}
      {t.model || "model"}
    </span>
  );
}
