type Props = { data: number[]; color?: string; height?: number; fill?: boolean };

export function Sparkline({ data, color = "#4dd9ff", height = 40, fill = true }: Props) {
  const w = 100, h = 30;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / range) * h;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const path = `M ${pts.join(" L ")}`;
  const area = `${path} L ${w},${h} L 0,${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ width: "100%", height }}>
      {fill && <path d={area} fill={color} opacity={0.14} />}
      <path d={path} fill="none" stroke={color} strokeWidth="1.4" />
    </svg>
  );
}

export function MultiSparkline({ series, height = 60 }: { series: { data: number[]; color: string }[]; height?: number }) {
  return (
    <div className="relative" style={{ height }}>
      {series.map((s, i) => (
        <div key={i} className="absolute inset-0">
          <Sparkline data={s.data} color={s.color} height={height} fill={false} />
        </div>
      ))}
    </div>
  );
}
