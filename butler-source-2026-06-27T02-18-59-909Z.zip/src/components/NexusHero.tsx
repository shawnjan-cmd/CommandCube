import { Link } from "@tanstack/react-router";
import { Server, Shield, BrainCircuit, Link2, MessageSquare, Cpu, Code2, Sparkles, Clock, ChevronRight, Zap } from "lucide-react";
import { fmtUptime, type Telemetry } from "@/lib/useTelemetry";


/**
 * NexusHero — Butler AI landing block.
 * Status chips, neon title with scan beam, two chat CTAs, four telemetry stat tiles.
 */
export function NexusHero({ t }: { t: Telemetry }) {
  const vectors = Math.max(1, (t.history?.length ?? 0) * 137 + 8_720_000);
  const scripts = 1246;
  const runtime = t.uptime ? fmtUptime(t.uptime) : "72:48:31";

  return (
    <section className="relative" aria-label="Butler AI">
      {/* Top status chips row */}
      <div className="grid grid-cols-4 gap-1.5 px-1 pb-3">
        <StatusChip icon={<Server className="h-3 w-3" />} label="SELF-HOSTED" color="cyan" />
        <StatusChip icon={<Shield className="h-3 w-3" />} label="PRIVATE" color="magenta" />
        <StatusChip icon={<BrainCircuit className="h-3 w-3" />} label="LOCAL AI" color="green" />
        <StatusChip icon={<Link2 className="h-3 w-3" />} label="SECURE LINK" color="orange" />
      </div>

      {/* Title */}
      <div className="mt-3 text-center">
        <div className="font-mono text-[9px] tracking-[0.5em] text-foreground/55">// SYS.BOOT · v3.2.1</div>
        <h1
          className="hero-title font-display text-[46px] font-black leading-none tracking-[0.08em] mt-1.5"
          style={{
            background:
              "linear-gradient(180deg,#f4ffff 0%, var(--cyan) 45%, color-mix(in oklab, var(--magenta) 80%, var(--cyan)) 100%)",
            WebkitBackgroundClip: "text",
            backgroundClip: "text",
            WebkitTextFillColor: "transparent",
            filter:
              "drop-shadow(0 0 10px color-mix(in oklab, var(--cyan) 55%, transparent)) drop-shadow(0 0 22px color-mix(in oklab, var(--magenta) 35%, transparent))",
          }}
        >
          BUTLER&nbsp;AI
        </h1>
        <div className="relative mx-auto mt-2 h-[2px] w-44 overflow-hidden">
          <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent,var(--cyan),var(--magenta),transparent)] opacity-70" />
          <div className="absolute inset-y-0 -left-1/3 w-1/3 bg-[linear-gradient(90deg,transparent,#fff,transparent)] hero-beam" />
        </div>

        {/* Reworked NEXUS INTELLIGENCE PLATFORM banner */}
        <div className="mx-auto mt-2.5 inline-flex max-w-full items-stretch">
          <span
            aria-hidden
            className="grid place-items-center px-1.5 font-mono text-[9px] font-bold text-[color:var(--cyan)]/80"
            style={{
              borderLeft: "1px solid color-mix(in oklab, var(--cyan) 60%, transparent)",
              borderTop: "1px solid color-mix(in oklab, var(--cyan) 60%, transparent)",
              borderBottom: "1px solid color-mix(in oklab, var(--cyan) 60%, transparent)",
            }}
          >
            ◣
          </span>
          <div
            className="flex items-center gap-2 px-2.5 py-1"
            style={{
              background:
                "linear-gradient(90deg, color-mix(in oklab, var(--cyan) 14%, var(--ink-2)), color-mix(in oklab, var(--magenta) 14%, var(--ink-2)))",
              border: "1px solid color-mix(in oklab, var(--cyan) 45%, var(--border))",
              boxShadow: "inset 0 0 14px -8px var(--cyan), 0 0 12px -8px var(--magenta)",
            }}
          >
            <span className="inline-block h-1 w-3 bg-[color:var(--cyan)]" style={{ boxShadow: "0 0 8px var(--cyan)" }} />
            <span
              className="font-display text-[10px] font-extrabold tracking-[0.46em]"
              style={{
                background: "linear-gradient(90deg, var(--cyan), #ffffff 50%, var(--magenta))",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              NEXUS · INTELLIGENCE · PLATFORM
            </span>
            <span className="inline-block h-1 w-3 bg-[color:var(--magenta)]" style={{ boxShadow: "0 0 8px var(--magenta)" }} />
          </div>
          <span
            aria-hidden
            className="grid place-items-center px-1.5 font-mono text-[9px] font-bold text-[color:var(--magenta)]/80"
            style={{
              borderRight: "1px solid color-mix(in oklab, var(--magenta) 60%, transparent)",
              borderTop: "1px solid color-mix(in oklab, var(--magenta) 60%, transparent)",
              borderBottom: "1px solid color-mix(in oklab, var(--magenta) 60%, transparent)",
            }}
          >
            ◥
          </span>
        </div>
      </div>


      {/* CTAs */}
      <div className="mt-5 grid grid-cols-2 gap-2.5">
        <HeroCta to="/ai" color="cyan" icon={<Zap className="h-5 w-5" />} title="ASK" sub="BUTLER" />
        <HeroCta to="/ai" color="magenta" icon={<MessageSquare className="h-5 w-5" />} title="OPEN" sub="AI CHAT" />
      </div>

      {/* Stat tiles */}
      <div className="mt-3 grid grid-cols-4 gap-1.5">
        <StatTile color="cyan" icon={<Sparkles className="h-3.5 w-3.5" />} label={"VECTORS\nINDEXED"} value={formatM(vectors)} bar={84} />
        <StatTile color="magenta" icon={<Code2 className="h-3.5 w-3.5" />} label={"SCRIPTS\nFORGED"} value={scripts.toLocaleString()} bar={62} />
        <StatTile color="green" icon={<Cpu className="h-3.5 w-3.5" />} label={"AI\nMODE"} value="NEXUS" sub="ADAPTIVE" bar={97} />
        <StatTile color="orange" icon={<Clock className="h-3.5 w-3.5" />} label={"AI\nRUNTIME"} value={runtime} mono bar={73} />
      </div>
    </section>
  );
}

function formatM(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(2) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K";
  return String(n);
}

function StatusChip({ icon, label, color }: { icon: React.ReactNode; label: string; color: "cyan" | "magenta" | "green" | "orange" }) {
  const cvar = `var(--${color})`;
  return (
    <div
      className="relative flex items-center justify-center gap-1 px-1.5 py-1.5 font-mono text-[8px] font-bold tracking-[0.18em]"
      style={{
        color: cvar,
        background: "linear-gradient(180deg, #0e1420, var(--background))",
        border: `1px solid color-mix(in oklab, ${cvar} 45%, var(--border))`,
        clipPath: "polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px)",
        boxShadow: `inset 0 0 14px -8px ${cvar}, 0 0 10px -6px ${cvar}`,
        ["--c" as any]: cvar,
      }}
    >
      <span className="led" style={{ width: 4, height: 4 }} />
      {icon}
      <span className="truncate">{label}</span>
    </div>
  );
}

function HeroCta({ to, color, icon, title, sub }: { to: string; color: "cyan" | "magenta"; icon: React.ReactNode; title: string; sub: string }) {
  const cvar = `var(--${color})`;
  return (
    <Link
      to={to}
      className="shine brackets group relative flex items-center gap-3 px-3 py-3 transition active:translate-y-px lift"
      style={{
        color: cvar,
        background: "linear-gradient(180deg, #131a26, #07090f)",
        border: `1px solid color-mix(in oklab, ${cvar} 55%, var(--border))`,
        clipPath: "polygon(12px 0, 100% 0, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%, 0 12px)",
        boxShadow: `inset 0 0 22px -8px ${cvar}, 0 0 18px -6px ${cvar}`,
        ["--c" as any]: cvar,
      }}
    >
      <i className="br-tr" /><i className="br-bl" />
      <span
        className="grid h-9 w-9 place-items-center relative z-10"
        style={{
          color: cvar,
          background: "var(--ink-deep)",
          border: `1px solid color-mix(in oklab, ${cvar} 60%, transparent)`,
          boxShadow: `inset 0 0 12px -4px ${cvar}`,
          clipPath: "polygon(4px 0, 100% 0, 100% calc(100% - 4px), calc(100% - 4px) 100%, 0 100%, 0 4px)",
        }}
      >
        {icon}
      </span>
      <span className="relative z-10 flex flex-col leading-tight font-display font-extrabold tracking-[0.2em]">
        <span className="text-[14px]" style={{ textShadow: `0 0 10px ${cvar}` }}>{title}</span>
        <span className="text-[12px] opacity-90">{sub}</span>
      </span>
      <ChevronRight className="relative z-10 ml-auto h-4 w-4 opacity-70 transition-transform group-hover:translate-x-0.5" />
    </Link>
  );
}


function StatTile({ color, icon, label, value, sub, mono, bar = 70 }: { color: "cyan" | "magenta" | "green" | "orange"; icon: React.ReactNode; label: string; value: string; sub?: string; mono?: boolean; bar?: number }) {
  const cvar = `var(--${color})`;
  return (
    <div
      className="relative flex flex-col items-center gap-1 px-1 py-2 lift overflow-hidden"
      style={{
        background: "linear-gradient(180deg, #0d1320, var(--ink-deep))",
        border: `1px solid color-mix(in oklab, ${cvar} 50%, var(--border))`,
        clipPath: "polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px)",
        boxShadow: `inset 0 0 16px -10px ${cvar}`,
        ["--c" as any]: cvar,
      }}
    >
      <span className="font-mono text-[8px] font-bold leading-[1.05] tracking-[0.18em] whitespace-pre text-center text-foreground/70">{label}</span>
      <span style={{ color: cvar, filter: `drop-shadow(0 0 6px ${cvar})` }}>{icon}</span>
      <span className={`mt-0.5 font-display text-[13px] font-black leading-none ${mono ? "font-mono" : ""}`} style={{ color: cvar, textShadow: `0 0 10px ${cvar}` }}>
        {value}
      </span>
      {sub && <span className="font-mono text-[7px] tracking-[0.2em] text-foreground/55">{sub}</span>}
      <div className="mt-1 h-[3px] w-full bg-[color:var(--border)]/50 overflow-hidden">
        <div
          className="h-full"
          style={{
            width: `${bar}%`,
            background: `linear-gradient(90deg, ${cvar}, color-mix(in oklab, ${cvar} 30%, transparent))`,
            boxShadow: `0 0 8px ${cvar}`,
          }}
        />
      </div>
    </div>
  );
}
