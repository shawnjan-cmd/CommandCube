export function RadialGauge({
  value, label, unit = "%", size = 96, color = "var(--cyan)", segments = 24,
}: {
  value: number | null;
  label: string;
  unit?: string;
  size?: number;
  color?: string;
  segments?: number;
}) {
  const v = typeof value === "number" ? Math.max(0, Math.min(100, value)) : 0;
  const filled = Math.round((v / 100) * segments);
  const cx = size / 2;
  const cy = size / 2;
  const rOuter = size / 2 - 4;
  const rInner = rOuter - 9;
  const arc = 270;
  const start = 135;
  const step = arc / segments;

  return (
    <div className="relative inline-flex flex-col items-center" style={{ width: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="block">
        <defs>
          <filter id={`glow-${label}`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="1.4" />
          </filter>
        </defs>
        {Array.from({ length: segments }).map((_, i) => {
          const a = (start + i * step + step / 2) * (Math.PI / 180);
          const x1 = cx + rInner * Math.cos(a);
          const y1 = cy + rInner * Math.sin(a);
          const x2 = cx + rOuter * Math.cos(a);
          const y2 = cy + rOuter * Math.sin(a);
          const on = i < filled;
          return (
            <line
              key={i}
              x1={x1} y1={y1} x2={x2} y2={y2}
              stroke={on ? color : "rgba(77,217,255,0.10)"}
              strokeWidth={2.4}
              strokeLinecap="round"
              filter={on ? `url(#glow-${label})` : undefined}
              opacity={on ? 1 : 0.6}
            />
          );
        })}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <span className="font-display text-base font-black leading-none tabular-nums" style={{ color }}>
          {typeof value === "number" ? Math.round(value) : "—"}
          <span className="text-[9px] text-muted-foreground ml-0.5">{typeof value === "number" ? unit : ""}</span>
        </span>
        <span className="mt-1 text-[8px] font-bold tracking-[0.18em] uppercase text-muted-foreground">{label}</span>
      </div>
    </div>
  );
}
