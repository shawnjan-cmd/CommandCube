import { useEffect, useState } from "react";

/**
 * Device performance tier. Used to dynamically throttle expensive
 * animations (parallax, drop-shadows, mood cycling) so low-end devices
 * stay smooth without changing the visual identity on high-end ones.
 *
 *   "high"  — desktop / flagship phones (parallax + full FX)
 *   "mid"   — typical phones            (parallax kept, shadows trimmed)
 *   "low"   — old phones / reduced-motion / data-saver (static + cheap FX)
 */
export type PerfTier = "high" | "mid" | "low";

type NavWithDeviceMemory = Navigator & {
  deviceMemory?: number;
  connection?: { saveData?: boolean; effectiveType?: string };
};

function detectStatic(): PerfTier {
  if (typeof window === "undefined") return "high";

  // Honor user accessibility preference first.
  if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return "low";

  const nav = navigator as NavWithDeviceMemory;
  if (nav.connection?.saveData) return "low";

  const mem = nav.deviceMemory ?? 8;
  const cores = nav.hardwareConcurrency ?? 8;
  const dpr = window.devicePixelRatio ?? 1;
  const small = Math.min(window.innerWidth, window.innerHeight) < 420;
  const coarse = window.matchMedia?.("(pointer: coarse)").matches ?? false;

  // Android WebViews at high DPR are the main target: bias them toward static FX.
  if (coarse && small) return "low";
  if (mem <= 2 || cores <= 2) return "low";
  if (mem <= 4 || cores <= 4 || (small && dpr >= 3)) return "low";
  return "high";
}

export function usePerfTier(): PerfTier {
  const [tier, setTier] = useState<PerfTier>(() => detectStatic());

  useEffect(() => {
    // Live downgrade: sample frame rate for 1s. If we can't sustain ~45fps,
    // step the tier down one notch. Never upgrade — measurement noise only.
    let raf = 0;
    let frames = 0;
    const start = performance.now();
    const tick = () => {
      frames++;
      if (performance.now() - start < 1000) raf = requestAnimationFrame(tick);
      else {
        const fps = frames;
        setTier((t) => {
          if (fps >= 45) return t;
          if (fps >= 25) return t === "high" ? "mid" : t;
          return "low";
        });
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  // Reflect tier on <html> so plain CSS can react too (e.g. .perf-low *).
  useEffect(() => {
    if (typeof document === "undefined") return;
    const el = document.documentElement;
    el.dataset.perf = tier;
    el.classList.toggle("perf-low", tier === "low");
    el.classList.toggle("perf-mid", tier === "mid");
    el.classList.toggle("perf-high", tier === "high");
  }, [tier]);

  return tier;
}
