import { useSyncExternalStore } from "react";
import { serverLink, type LinkState } from "@/lib/serverLink";

const SSR_SNAPSHOT: LinkState = {
  status: "idle",
  ip: "",
  port: "",
  latencyMs: null,
  lastOkAt: null,
};

/** React hook that mirrors the singleton serverLink state. */
export function useServerLink(): LinkState {
  return useSyncExternalStore(
    (cb) => serverLink.subscribe(cb),
    () => serverLink.getState(),
    () => SSR_SNAPSHOT,
  );
}
