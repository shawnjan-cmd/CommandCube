/**
 * useChatHistory — Debounced localStorage persistence for AI chat (web port).
 * Ported from BUTLER-AI/hooks/useChatHistory.ts
 */
import { useEffect, useRef, useCallback } from 'react';
import { storage } from '@/lib/storage';

const HISTORY_KEY = '@butler_conv_nexus_v1';
const MAX_STORED = 200;
const DEBOUNCE_MS = 800;

interface Message {
  id: string;
  role: string;
  content: string;
  timestamp: number;
  streaming?: boolean;
  [key: string]: unknown;
}

interface UseChatHistoryOptions {
  onLoad?: (msgs: Message[]) => void;
  storageKey?: string;
}

export function useChatHistory(messages?: Message[], options?: UseChatHistoryOptions) {
  const onLoad = options?.onLoad;
  const KEY = options?.storageKey ?? HISTORY_KEY;
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isLoaded = useRef(false);

  useEffect(() => {
    let cancelled = false;
    storage.getItem(KEY).then((raw) => {
      if (cancelled) return;
      if (!raw) { isLoaded.current = true; return; }
      try {
        const saved = JSON.parse(raw) as Message[];
        if (Array.isArray(saved) && saved.length > 0) {
          const clean = saved.filter((m) => !m.streaming && m.content?.length > 0).slice(-MAX_STORED);
          if (clean.length > 0) onLoad?.(clean);
        }
      } catch {
        storage.removeItem(KEY);
      }
      isLoaded.current = true;
    }).catch(() => { isLoaded.current = true; });
    return () => { cancelled = true; };
  }, [KEY, onLoad]);

  useEffect(() => {
    if (!isLoaded.current) return;
    if (!messages || messages.length === 0) return;

    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        const toSave = messages.filter((m) => !m.streaming).slice(-MAX_STORED);
        await storage.setItem(KEY, JSON.stringify(toSave));
      } catch {
        try {
          const trimmed = messages.filter((m) => !m.streaming).slice(-50);
          await storage.setItem(KEY, JSON.stringify(trimmed));
        } catch { /* swallow */ }
      }
    }, DEBOUNCE_MS);

    return () => { if (saveTimer.current) clearTimeout(saveTimer.current); };
  }, [messages, KEY]);

  const clearHistory = useCallback(async () => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    await storage.removeItem(KEY);
  }, [KEY]);

  return { clearHistory };
}
