import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";

import {
  QrCode, Code2, Bot, MonitorCog, ShieldCheck, Network, Lock, WifiOff, UserX,
  ChevronLeft, ChevronRight, SkipForward, Cpu, HardDrive, Activity,
  Brain, FileLock2, KeyRound, Sparkles, CheckCircle2, Rocket,
  Play, Power, BookOpen, ListChecks, Scroll, HandMetal, Camera, Folder,
  Fingerprint, Wifi, HelpCircle, AlertTriangle, Gavel, Eye, Trash2,
  PenLine, ExternalLink, Server, Database, ShieldAlert, Ban, Telescope,
  Wrench, Heart, Infinity as InfinityIcon, ScanLine, Download,
} from "lucide-react";
import { TelemetryGrid, ScriptsRoster, SigmaNetGraph, PairingQR, HmacMarquee, HealthRing } from "@/components/ButlerLive";
import { usePerfTier } from "@/hooks/use-perf-tier";
import SourceConfigManager, { exportMasterSourceMd } from "@/components/SourceConfigManager";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Butler AI — Onboarding" },
      { name: "description", content: "AI-driven PC automation. 100% local. Zero cloud. Begin your guided tour of Butler AI." },
      { property: "og:title", content: "Butler AI — Onboarding" },
      { property: "og:description", content: "AI-driven PC automation. 100% local. Zero cloud." },
    ],
  }),
  component: Onboarding,
});

/* ============================================================
   THEME — per-step palette, mascot persona, dialogue
   ============================================================ */

type Accent = "cyan" | "green" | "magenta" | "orange" | "yellow";

type StepTheme = {
  id: number;
  tag: string;
  title: string;
  next: string;
  accent: Accent;
  /** mascot persona */
  mascot: {
    name: string;          // e.g. "NEXUS"
    mood: "wave" | "spy" | "shield" | "oath" | "scribe" | "key" | "thinker" | "host" | "builder" | "launch";
    line: string;          // speech bubble
    sub?: string;          // secondary one-liner
  };
};

const STEPS: StepTheme[] = [
  { id: 1,  tag: "WELCOME",     title: "WELCOME TO NEXUS",       next: "APP TOUR",    accent: "cyan",
    mascot: { name: "NEXUS",   mood: "wave",    line: "I'm NEXUS — your local-only butler. Let me show you around.", sub: "Tap NEXT or use → keys. Camera follows me." } },
  { id: 2,  tag: "APP_TOUR",    title: "NINE TABS · ONE OS",     next: "SAFETY",      accent: "magenta",
    mascot: { name: "SCOUT",   mood: "spy",     line: "Here's the whole house. Nine rooms — I'll whip the camera through each.", sub: "HOME · SCRIPTS · AI · KB · PC · BUILD · SKINS · CONFIG · INTRO" } },
  { id: 3,  tag: "SAFETY",      title: "SAFETY CONSENT",         next: "PLEDGE",      accent: "yellow",
    mascot: { name: "AEGIS",   mood: "shield",  line: "These aren't legalese — they ARE the contract. Sign each card to continue.", sub: "All six required." } },
  { id: 4,  tag: "PLEDGE",      title: "SAFETY PLEDGE",          next: "LEGAL",       accent: "orange",
    mascot: { name: "OATH",    mood: "oath",    line: "Raise your hand and pledge. Sign each line — I'll be watching.", sub: "Five lines · all required." } },
  { id: 5,  tag: "LEGAL",       title: "LEGAL DOCUMENTS",        next: "PERMISSIONS", accent: "cyan",
    mascot: { name: "SCRIBE",  mood: "scribe",  line: "The full text lives online — tap any doc to open it, then SIGN.", sub: "Four documents." } },
  { id: 6,  tag: "PERMISSIONS", title: "PERMISSIONS",            next: "Q & A",       accent: "green",
    mascot: { name: "KEYRING", mood: "key",     line: "Bare-minimum permissions. One is required — the others are yours to choose.", sub: "Required: LOCAL NETWORK." } },
  { id: 7,  tag: "Q_AND_A",     title: "QUESTIONS & ANSWERS",    next: "SERVER",      accent: "magenta",
    mascot: { name: "ORACLE",  mood: "thinker", line: "Most-asked questions, up front. No fine print.", sub: "Ten answers." } },
  { id: 8,  tag: "SERVER",      title: "SERVER PRIVACY",         next: "SETUP",       accent: "green",
    mascot: { name: "HOST",    mood: "host",    line: "butler_server.py runs on YOUR PC. Acknowledge the five facts.", sub: "All five required." } },
  { id: 9,  tag: "SETUP",       title: "PC SETUP",               next: "LAUNCH",      accent: "magenta",
    mascot: { name: "RIGGER",  mood: "builder", line: "Three steps · about five minutes. I'll prep your PC.", sub: "Open the setup docs anytime." } },
  { id: 10, tag: "LAUNCH",      title: "INITIATE BUTLER OS",     next: "READY",       accent: "cyan",
    mascot: { name: "NEXUS",   mood: "launch",  line: "All clear, operator. ENGAGE when ready.", sub: "Cold-boot · ~3 seconds." } },
];

/* ============================================================
   ROOT
   ============================================================ */

function Onboarding() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const total = STEPS.length;
  const meta = STEPS[step];
  usePerfTier(); // tags <html> with .perf-low/.perf-mid/.perf-high so CSS can throttle FX

  // sign-to-accept gate
  const [signed, setSigned] = useState<Record<string, number>>({});
  const required = REQUIRED_BY_STEP[step] ?? [];
  const allSigned = required.every((id) => signed[id]);
  const sign = (id: string) => setSigned((s) => (s[id] ? s : { ...s, [id]: Date.now() }));

  const next = () => { if (!allSigned) return; setStep((s) => Math.min(total - 1, s + 1)); };
  const back = () => setStep((s) => Math.max(0, s - 1));
  const skip = () => setStep(total - 1);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") back();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, allSigned]);

  // Step changes should never fight Android touch scrolling.
  useEffect(() => {
    if (typeof window === "undefined") return;
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [step]);

  // Highlight first required target without auto-scrolling over the user's finger.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const t = window.setTimeout(() => {
      const targets = Array.from(document.querySelectorAll<HTMLElement>("[data-tour]"));
      const first = targets[0];
      if (first) {
        first.classList.add("focus-pulse");
        window.setTimeout(() => first.classList.remove("focus-pulse"), 1200);
      }
    }, 180);
    return () => window.clearTimeout(t);
  }, [step]);

  // CAMERA: after every sign, glide to the NEXT unsigned card so the user can't miss it
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (required.length === 0) return;
    const nextId = required.find((id) => !signed[id]);
    if (!nextId) {
      // all signed — gently pull the footer CTA into view
      const cta = document.getElementById("primary-cta");
      cta?.scrollIntoView({ behavior: "auto", block: "center" });
      return;
    }
    const el = document.querySelector<HTMLElement>(`[data-tour="${nextId}"]`);
    if (!el) return;
    const id = window.setTimeout(() => {
      el.scrollIntoView({ behavior: "auto", block: "center" });
      el.classList.add("focus-pulse");
      window.setTimeout(() => el.classList.remove("focus-pulse"), 1200);
    }, 280);
    return () => window.clearTimeout(id);
  }, [signed, step, required]);

  // GLOBAL HAPTICS — pulse the device on any tap, varied by intent
  //   • SIGN buttons  → success burst (12,40,12)
  //   • Primary CTA   → medium tap (18)
  //   • Toolbar / nav → light tap (8)
  //   • Anything else → soft tap (12)
  useEffect(() => {
    if (typeof window === "undefined") return;
    const onClick = (e: MouseEvent) => {
      const t = e.target as HTMLElement | null;
      const hit = t?.closest("button, a, [role='button']") as HTMLElement | null;
      if (!hit) return;
      const label = (hit.textContent || "").toUpperCase();
      let pattern: number | number[] = 12;
      if (label.includes("SIGN") && !label.includes("CONTINUE")) pattern = [12, 40, 12];
      else if (hit.id === "primary-cta" || label.includes("NEXT") || label.includes("READY")) pattern = 18;
      else if (label.includes("BACK") || label.includes("SKIP")) pattern = 8;
      try { navigator.vibrate?.(pattern); } catch { /* noop */ }
      hit.classList.remove("tap-pulse");
      // re-trigger animation
      void hit.offsetWidth;
      hit.classList.add("tap-pulse");
    };
    document.addEventListener("click", onClick, true);
    return () => document.removeEventListener("click", onClick, true);
  }, []);

  // ===== PREFETCH NEXT STEP — images, routes, downloads, fonts =====
  // Buttery transitions: warm the browser cache for what the user is
  // most likely to hit next so the "NEXT" tap renders instantly.
  // router already declared above
  useEffect(() => {
    if (typeof window === "undefined") return;
    const nextStep = Math.min(total - 1, step + 1);

    // 1. Per-step external URL prefetches via <link rel="prefetch"> (idempotent)
    const urlsByStep: Record<number, string[]> = {
      4: ["/legal/privacy", "/legal/terms", "/legal/safety", "/legal/delete"],
      8: [REPO_RAW + "/butler_server.py", REPO_URL, POLICY_URL],
      9: [REPO_RAW + "/butler_server.py"],
    };
    const heads: HTMLLinkElement[] = [];
    const addLink = (rel: string, href: string, as?: string) => {
      if (document.head.querySelector(`link[data-prefetch="${href}"]`)) return;
      const l = document.createElement("link");
      l.rel = rel;
      l.href = href;
      if (as) l.as = as;
      // NOTE: do NOT set crossOrigin on prefetch/dns-prefetch — it triggers
      // CORS preflights against third-party hosts that don't return ACAO.
      l.setAttribute("data-prefetch", href);
      document.head.appendChild(l);
      heads.push(l);
    };
    // dns-prefetch + preconnect to external origins once
    ["https://raw.githubusercontent.com", "https://github.com", "https://shawnjan-cmd.github.io"].forEach((o) => {
      addLink("dns-prefetch", o);
      addLink("preconnect", o);
    });

    const runPrefetch = () => {
      if (step < 3) return;
      // 2. Prefetch next-step external files
      (urlsByStep[nextStep] ?? []).forEach((u) => {
        if (u.startsWith("/")) router.preloadRoute?.({ to: u }).catch(() => {});
        else addLink("prefetch", u, u.endsWith(".py") ? "fetch" : undefined);
      });
      // 3. Pre-warm mascot image (already cached after first paint, cheap)
      const img = new Image();
      img.src = mascotImg;
    };

    const w = window as typeof window & {
      requestIdleCallback?: (cb: () => void, opts?: { timeout: number }) => number;
      cancelIdleCallback?: (id: number) => void;
    };
    let idleId: number | undefined;
    let timeoutId: number | undefined;
    if (w.requestIdleCallback) idleId = w.requestIdleCallback(runPrefetch, { timeout: 2500 });
    else timeoutId = window.setTimeout(runPrefetch, 1400);

    return () => {
      if (idleId != null) w.cancelIdleCallback?.(idleId);
      if (timeoutId != null) window.clearTimeout(timeoutId);
      // leave <link> tags in place — they're cheap and keep working across steps
    };
  }, [step, total, router]);


  return (
    <main
      className="relative min-h-screen overflow-x-clip text-foreground"
      style={{
        background:
          "radial-gradient(ellipse 90% 42% at 50% -10%, color-mix(in oklab, var(--cyan) 18%, transparent), transparent 62%)," +
          "radial-gradient(ellipse 70% 44% at 100% 100%, color-mix(in oklab, var(--magenta) 12%, transparent), transparent 64%)," +
          "linear-gradient(180deg, var(--ink) 0%, var(--background) 52%, var(--ink-deep) 100%)",
      }}
    >
      {/* === themed cyberpunk backdrop (matches homepage) === */}
      <div className="pointer-events-none absolute inset-0 opacity-[0.10]"
           style={{
             backgroundImage:
               "linear-gradient(color-mix(in oklab, var(--cyan) 55%, transparent) 1px, transparent 1px)," +
               "linear-gradient(90deg, color-mix(in oklab, var(--cyan) 55%, transparent) 1px, transparent 1px)",
             backgroundSize: "46px 46px, 46px 46px",
           }} />
      <div className="pointer-events-none absolute inset-0 opacity-[0.08]"
           style={{
             backgroundImage:
               "repeating-linear-gradient(60deg, color-mix(in oklab, var(--magenta) 50%, transparent) 0 1px, transparent 1px 28px)," +
               "repeating-linear-gradient(-60deg, color-mix(in oklab, var(--cyan) 40%, transparent) 0 1px, transparent 1px 36px)",
           }} />
      <div className="pointer-events-none absolute inset-0 scanlines opacity-15" />


      <div className="relative mx-auto flex min-h-screen max-w-md flex-col px-4 pb-44 pt-6 sm:max-w-lg">
        <Header step={step} total={total} meta={meta} onSkip={skip} />

        {/* CAMERA STAGE — per-step whip path */}
        <section key={step} className={`whip-${step + 1} step-enter mt-5 flex-1`}>
          <MascotPanel meta={meta} />
          <StepCard step={step + 1} total={total} title={meta.title} next={meta.next} accent={meta.accent}>
            {renderStep(step, sign, signed, () => { void router.navigate({ to: "/home" }); })}
          </StepCard>
          {required.length > 0 && (
            <GateBanner accent={meta.accent} required={required.length} done={required.filter((id) => signed[id]).length} />
          )}
        </section>

        <StepToolbar step={step} onJump={setStep} />

        {/* Meta strip — version + support, always visible */}
        <div className="mt-4 mb-2 flex items-center justify-between gap-2 px-1 text-[10px] tracking-widest text-muted-foreground/80">
          <span className="font-mono">BUTLER AI · v{APP_VERSION}</span>
          <a
            href={`mailto:${SUPPORT_EMAIL}?subject=Butler%20AI%20support`}
            className="font-mono text-foreground/70 underline-offset-2 hover:text-cyan hover:underline"
          >
            {SUPPORT_EMAIL}
          </a>
        </div>

      </div>

      <Footer step={step} total={total} onBack={back} onNext={next} canNext={allSigned} accent={meta.accent} />
    </main>
  );
}

/* ============================================================
   HEADER / FOOTER
   ============================================================ */

function Header({ step, total, meta, onSkip }: { step: number; total: number; meta: StepTheme; onSkip: () => void }) {
  const pct = ((step + 1) / total) * 100;
  return (
    <header className="space-y-3">
      <div className="flex items-center gap-2">
        <div className={`relative grid h-14 w-14 shrink-0 place-items-center rounded-full border border-${meta.accent}/40 bg-surface/60`}>
          <span className={`absolute -top-0.5 left-1/2 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-${meta.accent} pulse-dot`} />
          <span className={`font-mono text-lg font-bold text-${meta.accent}`}>{step + 1}</span>
        </div>
        <div className="panel-cyber relative flex h-14 min-w-0 flex-1 items-center justify-between gap-2 px-3">
          <span className={`min-w-0 truncate text-[13px] font-bold tracking-[0.18em] text-${meta.accent}`}>
            {meta.tag.replace(/_/g, " ")}
          </span>
          <span className="shrink-0 whitespace-nowrap text-[10px] font-medium tracking-widest text-foreground/75">
            {String(step + 1).padStart(2, "0")}/{total}
          </span>
        </div>
        <button onClick={onSkip} className="panel-cyber flex h-14 shrink-0 items-center gap-1.5 px-3 text-xs font-bold tracking-widest text-muted-foreground transition hover:text-cyan">
          SKIP <SkipForward className="h-3.5 w-3.5" />
        </button>

      </div>

      <div className="flex items-center justify-between gap-1">
        {STEPS.map((s, i) => {
          const state = i === step ? "active" : i < step ? "done" : "todo";
          return (
            <button
              key={s.id}
              onClick={() => {/* read-only header dot */}}
              className={
                "grid h-7 w-7 place-items-center rounded-md border transition " +
                (state === "active"
                  ? `border-${s.accent}/70 bg-${s.accent}/15 text-${s.accent} shadow-[0_0_12px_-2px_currentColor]`
                  : state === "done"
                  ? `border-${s.accent}/40 bg-${s.accent}/5 text-${s.accent}/70`
                  : "border-border/60 bg-background/40 text-muted-foreground/60")
              }
              aria-label={s.tag}
            >
              <StepIcon n={s.id} className="h-3.5 w-3.5" />
            </button>
          );
        })}
      </div>


      <div className="h-1 w-full overflow-hidden rounded-full bg-surface">
        <div className="h-full rounded-full bg-gradient-to-r from-green via-cyan to-magenta transition-all duration-500" style={{ width: `${pct}%` }} />
      </div>
    </header>
  );
}

function Footer({ step, total, onBack, onNext, canNext, accent }:
  { step: number; total: number; onBack: () => void; onNext: () => void; canNext: boolean; accent: Accent }) {
  const isLast = step === total - 1;
  return (
    <div className="fixed inset-x-0 bottom-0 z-20 border-t border-border/60 bg-background shadow-[0_-12px_30px_-12px_rgba(0,0,0,.8)]">
      <div className="mx-auto flex max-w-md items-center justify-between gap-3 px-4 py-3 sm:max-w-lg">
        <button
          onClick={onBack}
          disabled={step === 0}
          className="panel-cyber flex items-center gap-2 rounded-full px-5 py-3 text-xs font-bold tracking-widest text-muted-foreground transition disabled:opacity-30 enabled:hover:text-cyan"
        >
          <ChevronLeft className="h-4 w-4" /> BACK
        </button>

        <div className="flex flex-col items-center font-mono leading-none">
          <span className={`text-3xl font-extrabold text-${accent}`}>{step + 1}</span>
          <span className="mt-0.5 text-[10px] tracking-widest text-muted-foreground">OF {total}</span>
        </div>

        <button
          id="primary-cta"
          onClick={onNext}
          disabled={isLast || !canNext}
          title={!canNext ? "Sign all required policies to continue" : ""}
          className={`flex items-center gap-2 rounded-full px-6 py-3 text-xs font-extrabold tracking-widest transition disabled:cursor-not-allowed disabled:opacity-40 bg-${accent} text-primary-foreground shadow-[0_0_30px_-6px_currentColor] hover:brightness-110 ${canNext && !isLast ? "cta-heartbeat" : ""}`}
        >
          {!canNext ? "SIGN TO CONTINUE" : isLast ? "READY" : "NEXT"} <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   MASCOT — animated SVG bot, persona per step
   ============================================================ */

import mascotImg from "@/assets/mascot-butler.png";

const MOOD_ANIM: Record<StepTheme["mascot"]["mood"], string> = {
  wave: "m-wave",
  spy: "m-spy",
  shield: "m-nod",
  oath: "m-oath m-glow",
  scribe: "m-tilt",
  key: "m-shake",
  thinker: "m-think",
  host: "m-bow",
  builder: "m-build",
  launch: "m-launch m-glow",
};

function MascotPanel({ meta }: { meta: StepTheme }) {
  const accent = meta.accent;
  const ref = useRef<HTMLDivElement | null>(null);

  // subtle parallax tilt
  const onMove = (e: React.MouseEvent) => {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    el.style.setProperty("--rx", `${(-y * 10).toFixed(2)}deg`);
    el.style.setProperty("--ry", `${(x * 14).toFixed(2)}deg`);
  };
  const onLeave = () => {
    const el = ref.current; if (!el) return;
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--ry", "0deg");
  };

  return (
      <div className={`panel-cyber relative mb-4 flex items-stretch gap-3 overflow-hidden p-3 glow-${accent}`}>
      {/* mascot stage — bow-tie-up bust only, no floating shapes */}
      <div
        ref={ref}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        className={`relative grid aspect-square w-24 shrink-0 place-items-center overflow-hidden rounded-md border border-${accent}/40 bg-background/60 sm:w-28 md:w-32`}
        style={{ perspective: "700px" }}
      >
        <div className="absolute inset-0 grid-bg opacity-25" />
        {/* halo */}
        <div
          className="absolute inset-0 opacity-70"
          style={{ background: `radial-gradient(circle at 50% 55%, color-mix(in oklab, var(--${accent}) 38%, transparent), transparent 62%)` }}
        />
        <div
          key={meta.id}
          className="mascot-pop relative h-full w-full"
          style={{
            transform: "rotateX(var(--rx,0deg)) rotateY(var(--ry,0deg))",
            transformStyle: "preserve-3d",
            transition: "transform .25s ease-out",
          }}
        >
          <div
            className="absolute inset-0 grid place-items-center"
            style={{ transform: "translateZ(16px)" }}
          >
            <div
              className={`relative grid h-full w-full place-items-center ${MOOD_ANIM[meta.mascot.mood]}`}
              style={{ color: `var(--${accent})` }}
            >
              <img
                src={mascotImg}
                alt="Butler mascot"
                draggable={false}
                loading="eager"
                decoding="async"
                className="h-[92%] w-[92%] select-none object-contain"
                style={{ filter: "drop-shadow(0 6px 14px rgba(0,0,0,.55))" }}
              />
            </div>
          </div>
          {/* floor glow */}
          <div
            className="pointer-events-none absolute -bottom-1 left-1/2 h-2 w-20 -translate-x-1/2 rounded-full opacity-45"
            style={{ background: `var(--${accent})` }}
          />

        </div>
      </div>

      {/* speech bubble — no persona name, just the line */}
      <div key={`b${meta.id}`} className="bubble-in relative min-w-0 flex-1 rounded-md border border-border/60 bg-background/60 p-3">
        <div className="absolute -left-1.5 top-6 h-3 w-3 rotate-45 border-b border-l border-border/60 bg-background/60" />
        <div className={`flex items-center gap-2 text-[10px] tracking-widest text-${accent}`}>
          <span className={`h-1.5 w-1.5 rounded-full bg-${accent} pulse-dot`} />
          <span className="font-bold">BUTLER</span>
        </div>
        <p className="mt-1 text-sm leading-relaxed text-foreground">{meta.mascot.line}</p>
        {meta.mascot.sub && <p className="mt-1.5 text-[11px] tracking-widest text-foreground/70">{meta.mascot.sub}</p>}
      </div>
    </div>
  );
}


/* ============================================================
   CARDS / SHARED
   ============================================================ */

function StepCard({ step: _step, total: _total, title: _title, next: _next, accent: _accent, children }:
  { step: number; total: number; title: string; next: string; accent: Accent; children: ReactNode }) {
  // Header info (step / title / next) is already shown by <Header /> — render content only.
  return <div className="space-y-4">{children}</div>;
}


function GateBanner({ accent, required, done }: { accent: Accent; required: number; done: number }) {
  const complete = done === required;
  return (
    <div className={`panel mt-4 flex items-center justify-center gap-3 px-4 py-3 text-center ${complete ? "glow-green" : `glow-${accent}`}`}>
      {complete ? <CheckCircle2 className="h-5 w-5 text-green" /> : <PenLine className={`h-5 w-5 text-${accent}`} />}
      <div className="text-[13px] font-bold tracking-widest">
        <span className={complete ? "text-green" : `text-${accent}`}>
          {complete ? "ALL POLICIES SIGNED" : "SIGN EACH CARD TO CONTINUE"}
        </span>
        <span className="ml-2 text-muted-foreground">· {done}/{required} ACCEPTED</span>
      </div>
    </div>
  );
}

/** Wrapper that auto-injects index/total into every SignCard child so the chime fades. */
function SignList({ children }: { children: ReactNode }) {
  const arr = Array.isArray(children) ? children.flat() : [children];
  const cards = arr.filter((c): c is React.ReactElement => !!c && typeof c === "object" && (c as React.ReactElement).type === SignCard);
  const total = cards.length;
  let i = 0;
  return (
    <div className="space-y-2.5">
      {arr.map((child, k) => {
        if (child && typeof child === "object" && (child as React.ReactElement).type === SignCard) {
          const idx = i++;
          return <SignCardClone key={k} element={child as React.ReactElement} index={idx} total={total} />;
        }
        return child;
      })}
    </div>
  );
}
function SignCardClone({ element, index, total }: { element: React.ReactElement; index: number; total: number }) {
  // re-create element with injected index/total
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const Cmp = element.type as any;
  return <Cmp {...(element.props as object)} index={index} total={total} />;
}

/* ----- Sign-to-accept card ----- */

// Lazy-init WebAudio; one shared context so we never re-build it.
let _audioCtx: AudioContext | null = null;
/** Soft pen-on-paper chime. `volume` 0..1 — caller fades it down per signature. */
function playSignChime(volume = 1) {
  if (typeof window === "undefined") return;
  // Hard peak cap so the chime never feels harsh regardless of caller.
  const PEAK = 0.7;
  const vol = Math.max(0.015, Math.min(PEAK, volume));
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    _audioCtx = _audioCtx ?? new AC();
    const ctx = _audioCtx;
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
    const now = ctx.currentTime;
    const tones = [
      { f: 1320, t: 0.00, d: 0.09, g: 0.085 * vol },
      { f: 1760, t: 0.06, d: 0.11, g: 0.055 * vol },
    ];
    tones.forEach(({ f, t, d, g }) => {
      const o = ctx.createOscillator();
      const v = ctx.createGain();
      o.type = "triangle";
      o.frequency.setValueAtTime(f, now + t);
      v.gain.setValueAtTime(0, now + t);
      v.gain.linearRampToValueAtTime(g, now + t + 0.012);
      v.gain.exponentialRampToValueAtTime(0.0001, now + t + d);
      o.connect(v).connect(ctx.destination);
      o.start(now + t);
      o.stop(now + t + d + 0.02);
    });
  } catch { /* noop */ }
}

function SignCard({
  id, accent, icon, title, body, signed, onSign, link, index = 0, total = 1,
}: {
  id: string; accent: Accent; icon: ReactNode; title: string; body: string;
  signed: Record<string, number>; onSign: (id: string) => void;
  link?: { label: string; url: string };
  /** position in the signing list — used to fade volume the farther down you go */
  index?: number; total?: number;
}) {
  const isSigned = !!signed[id];
  const [fx, setFx] = useState(0);
  const handleSign = () => {
    if (isSigned) return;
    // Ease-out curve: top of list ≈ full, bottom ≈ whisper. playSignChime caps the peak.
    const ratio = total <= 1 ? 0 : index / (total - 1);
    const eased = 1 - Math.pow(ratio, 1.6);
    const vol = 0.18 + eased * 0.82;
    playSignChime(vol);
    setFx((n) => n + 1);
    onSign(id);
  };
  const tone = isSigned ? "green" : accent;
  return (
    <div
      data-tour={id}
      className={`panel relative overflow-hidden p-4 transition ${isSigned ? "glow-green bg-green/5" : `glow-${accent}`}`}
    >
      <div className="flex items-start gap-3">
        <div className={`grid h-11 w-11 shrink-0 place-items-center rounded-md border border-${tone}/60 bg-background/60 text-${tone}`}>
          {icon}
        </div>
        <div className="min-w-0 flex-1">
          <div className={`font-display text-[17px] font-extrabold leading-tight tracking-wide text-${tone}`}>
            {title}
          </div>
          <p className={`mt-2 text-[15px] leading-relaxed ${isSigned ? "text-green/95" : "text-foreground"}`}>
            {body}
          </p>
          {link && (link.url.startsWith("/") ? (
            <Link to={link.url} className={`mt-2.5 inline-flex items-center gap-1 text-[12px] font-bold tracking-widest text-${accent} underline-offset-2 hover:underline`}>
              <ExternalLink className="h-3.5 w-3.5" /> {link.label}
            </Link>
          ) : (
            <a href={link.url} target="_blank" rel="noreferrer"
              className={`mt-2.5 inline-flex items-center gap-1 text-[12px] font-bold tracking-widest text-${accent} underline-offset-2 hover:underline`}>
              <ExternalLink className="h-3.5 w-3.5" /> {link.label}
            </a>
          ))}
        </div>
      </div>
      <div className={`mt-4 flex items-center justify-between gap-2 border-t pt-3 ${isSigned ? "border-green/40" : "border-border/60"}`}>
        <span className={`font-mono text-[13px] font-bold tracking-widest ${isSigned ? "text-green" : `text-${accent}`}`}>
          {isSigned
            ? `✓ SIGNED · ${new Date(signed[id]).toLocaleTimeString()}`
            : "TAP SIGN TO ACCEPT"}
        </span>
        {isSigned ? (
          <span className="stamp-in select-none rounded-md border border-green/70 bg-green/15 px-3 py-1.5 font-mono text-[13px] font-extrabold tracking-widest text-green">
            ✓ ACCEPTED
          </span>
        ) : (
          <div className="relative">
            {fx > 0 && (
              <>
                <span key={`f-${fx}`} className="sign-flourish">✓ Signed</span>
                <span key={`r-${fx}`} className="sign-ring" />
              </>
            )}
            <button
              onClick={handleSign}
              aria-label={`Sign ${title}`}
              className={`flex items-center gap-2 rounded-md border border-${accent}/70 bg-${accent}/20 px-5 py-2.5 font-display text-[14px] font-extrabold tracking-widest text-${accent} shadow-[0_0_22px_-6px_currentColor] transition hover:bg-${accent}/30`}
            >
              <PenLine className="h-4 w-4" /> SIGN
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================
   REQUIRED-DOC MAP (per step)
   ============================================================ */

const REQUIRED_BY_STEP: Record<number, string[]> = {
  2: ["age18", "tos", "privacy", "lan_only", "camera_qr", "exec_control"],
  3: ["pledge_access", "pledge_malware", "pledge_privacy", "pledge_lawful", "pledge_self"],
  4: ["doc_privacy", "doc_tos", "doc_safety", "doc_deletion"],
  5: ["perm_lan"],
  7: ["srv_local", "srv_sqlite", "srv_python", "srv_hmac", "srv_shield"],
};

/* ============================================================
   STEP RENDERERS
   ============================================================ */

function renderStep(i: number, sign: (id: string) => void, signed: Record<string, number>, advance: () => void) {
  switch (i) {
    case 0: return <Step1Welcome />;
    case 1: return <Step2AppTour />;
    case 2: return <Step3Safety sign={sign} signed={signed} />;
    case 3: return <Step4Pledge sign={sign} signed={signed} />;
    case 4: return <Step5Legal sign={sign} signed={signed} />;
    case 5: return <Step6Permissions sign={sign} signed={signed} />;
    case 6: return <Step7QA />;
    case 7: return <Step8Server sign={sign} signed={signed} />;
    case 8: return <Step9Setup />;
    case 9: return <Step10Launch onLaunch={advance} />;
    default: return null;
  }
}

/* ---------- 1. Welcome ---------- */
function Step1Welcome() {
  return (
    <div className="space-y-5">
      <FeatureHero icon={<Bot className="h-16 w-16" />} color="cyan" title="BUTLER AI" subtitle="100% self-hosted PC automation · no cloud · no accounts" />
      <div className="grid grid-cols-2 gap-2">
        <KVTile icon={<WifiOff className="h-4 w-4" />} label="ZERO CLOUD" value="LAN ONLY" color="green" />
        <KVTile icon={<Lock className="h-4 w-4" />} label="SIGNED" value="HMAC-256" color="cyan" />
        <KVTile icon={<Ban className="h-4 w-4" />} label="AUTO-RUN" value="DISABLED" color="orange" />
        <KVTile icon={<Eye className="h-4 w-4" />} label="TELEMETRY" value="NONE" color="magenta" />
      </div>
      <TelemetryGrid />
      <div className="grid grid-cols-2 gap-2">
        <HealthRing value={96} label="SYSTEM HEALTH" color="green" />
        <HealthRing value={88} label="LAN UPLINK" color="cyan" />
      </div>
      <HmacMarquee />
      <TerminalBox title="BUTLER_OS TERMINAL" badge="SECURE BOOT" lines={[
        "BUTLER_OS v7.3 INITIALIZING...",
        "PYTHON ENGINE ............ OK",
        "HMAC-SHA256 AUTH ......... OK",
        "OLLAMA BRIDGE ............ READY",
        "ZERO CLOUD VERIFIED ...... ✓",
      ]} />
    </div>
  );
}

/* ---------- 2. App Tour ---------- */
const TABS: { icon: ReactNode; name: string; body: string; color: Accent }[] = [
  { icon: <MonitorCog className="h-4 w-4" />, name: "HOME",    body: "Live dashboard · CPU/RAM/Disk · QR-code pairing.",     color: "cyan" },
  { icon: <Code2 className="h-4 w-4" />,      name: "SCRIPTS", body: "250+ Python scripts · run, search, undo.",             color: "orange" },
  { icon: <Brain className="h-4 w-4" />,      name: "AI",      body: "Local LLM via Ollama · llama3 · mistral · phi3.",      color: "magenta" },
  { icon: <BookOpen className="h-4 w-4" />,   name: "KB",      body: "SIGMA-NET self-learning knowledge base.",              color: "yellow" },
  { icon: <Activity className="h-4 w-4" />,   name: "PC",      body: "Real-time telemetry · process list · health score.",   color: "green" },
  { icon: <Wrench className="h-4 w-4" />,     name: "BUILD",   body: "Visual node pipeline · drag-and-drop automations.",    color: "cyan" },
  { icon: <Sparkles className="h-4 w-4" />,   name: "SKINS",   body: "Twelve theme packs · personalise every pixel.",        color: "magenta" },
  { icon: <ListChecks className="h-4 w-4" />, name: "CONFIG",  body: "Server, keys, license, language, notifications.",      color: "orange" },
  { icon: <Telescope className="h-4 w-4" />,  name: "INTRO",   body: "This tutorial · always available · no doom loops.",    color: "cyan" },
];

function Step2AppTour() {
  const [active, setActive] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setActive((a) => (a + 1) % TABS.length), 1400);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="space-y-4">
      <div className="panel-cyber grid grid-cols-3 gap-2 p-2">
        {TABS.map((t, i) => (
          <button key={t.name} onClick={() => setActive(i)}
            className={`flex flex-col items-center gap-1 rounded-md border px-2 py-2 transition ${i === active ? `border-${t.color}/60 bg-${t.color}/10` : "border-border/40"}`}>
            <span className={`text-${t.color}`}>{t.icon}</span>
            <span className={`text-[9px] tracking-widest ${i === active ? `text-${t.color}` : "text-muted-foreground"}`}>{t.name}</span>
          </button>
        ))}
      </div>
      <div className={`panel p-3 glow-${TABS[active].color}`}>
        <div className={`flex items-center gap-2 text-${TABS[active].color}`}>
          {TABS[active].icon}
          <span className="text-sm font-bold tracking-widest">{TABS[active].name}</span>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-foreground">{TABS[active].body}</p>
      </div>
      <ScriptsRoster />
    </div>
  );
}

/* ---------- 3. Safety Consent (SIGN-GATE) ---------- */
function Step3Safety({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <SignList>
      <SignCard id="age18"        accent="orange"  icon={<AlertTriangle className="h-5 w-5" />} title="18+ ONLY · ADULT USE"
        body="Butler AI is a developer-grade automation tool intended for adults only. By signing below, you confirm under your own responsibility that you are at least 18 years old and legally permitted to operate this software in your jurisdiction."
        signed={signed} onSign={sign} />
      <SignCard id="tos"          accent="yellow"  icon={<Gavel className="h-5 w-5" />}         title="TERMS OF SERVICE"
        body="You agree to use Butler AI exclusively on computers you personally own or have explicit, documented authorisation to operate. Unauthorised access to any system is strictly prohibited and may violate criminal law in your country."
        signed={signed} onSign={sign} />
      <SignCard id="privacy"      accent="green"   icon={<ShieldCheck className="h-5 w-5" />}   title="PRIVACY POLICY · LOCAL-FIRST"
        body="A randomly generated device UUID is stored only on this phone. No personal data, scripts, file paths, telemetry, contacts, or location information is ever transmitted off your device — there is no cloud server to send it to."
        signed={signed} onSign={sign} />
      <SignCard id="lan_only"     accent="cyan"    icon={<Wifi className="h-5 w-5" />}          title="LAN-ONLY OPERATION"
        body="Butler AI runs entirely on your own PC over your home Wi-Fi network. There is no cloud relay, no proxy server, no internet round-trip. If your Wi-Fi is off, Butler does not work — that is by design."
        signed={signed} onSign={sign} />
      <SignCard id="camera_qr"    accent="magenta" icon={<ScanLine className="h-5 w-5" />}      title="CAMERA · QR PAIRING ONLY"
        body="When PC setup finishes, the Butler installer automatically downloads and configures about six programs — Python 3.12+, every pip dependency, the Ollama runtime, your private local AI model (qwen2.5-coder:7b), the HMAC bridge, and butler_server.py itself — then immediately displays a one-time pairing QR code on your PC screen. Your phone camera is invoked solely to scan that QR. No photo, video, or frame is ever recorded, saved, transmitted, or analysed — the scanner releases the camera the instant the code is read."
        signed={signed} onSign={sign} />
      <SignCard id="exec_control" accent="orange"  icon={<HandMetal className="h-5 w-5" />}     title="YOU CONTROL EVERY EXECUTION"
        body="Every script runs on YOUR PC under YOUR operating-system permissions, and only after YOU actively tap it. There is no background scheduler, no auto-run, no cron, no hidden trigger. You decide what executes, when, and you can revoke pairing at any time."
        signed={signed} onSign={sign} />
    </SignList>
  );
}

/* ---------- 4. Safety Pledge (SIGN-GATE) ---------- */
function Step4Pledge({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <SignList>
      <SignCard id="pledge_access"  accent="orange"  icon={<Ban className="h-5 w-5" />}         title="I WILL NOT ACCESS WHAT ISN'T MINE"
        body="I solemnly pledge that I will never attempt to use Butler AI — directly or indirectly — to access, monitor, or control any computer, network, or device that I do not personally own or have explicit written authorisation to operate. This includes friends', family members', and employers' systems."
        signed={signed} onSign={sign} />
      <SignCard id="pledge_malware" accent="orange"  icon={<ShieldAlert className="h-5 w-5" />} title="I WILL DEPLOY NO MALICIOUS CODE"
        body="I will not author, distribute, or execute malware, ransomware, crypto-miners, key-loggers, destructive wipers, or any script designed to harm a system, exfiltrate data, or evade the consent of its owner. Butler AI is built to help — never to attack."
        signed={signed} onSign={sign} />
      <SignCard id="pledge_privacy" accent="yellow"  icon={<UserX className="h-5 w-5" />}       title="I WILL RESPECT EVERY PERSON'S PRIVACY"
        body="I will not use Butler AI to spy on, surveil, eavesdrop on, photograph, screen-record, or otherwise violate the privacy of any person — including roommates, colleagues, partners, or members of my own household."
        signed={signed} onSign={sign} />
      <SignCard id="pledge_lawful"  accent="yellow"  icon={<Gavel className="h-5 w-5" />}       title="I WILL OBEY THE LAW"
        body="I will operate Butler AI strictly within the laws of my country, state, and locality. I understand that lawful personal automation on hardware I own is the entire purpose of this tool, and I will not stretch it beyond that boundary."
        signed={signed} onSign={sign} />
      <SignCard id="pledge_self"    accent="green"   icon={<ShieldCheck className="h-5 w-5" />} title="I ACCEPT PERSONAL RESPONSIBILITY"
        body="Butler AI ships with the Malicious-Script Shield, HMAC signing, and a hard-coded blocklist — but no software can replace human judgement. I accept full personal responsibility for every command I execute and every script I add to my library."
        signed={signed} onSign={sign} />
    </SignList>
  );
}


/* ---------- 5. Legal Documents (SIGN-GATE w/ link) ---------- */
const APP_VERSION = "7.3.0";
const SUPPORT_EMAIL = "andrejsladkovic1992@gmail.com";
const POLICY_URL = "https://shawnjan-cmd.github.io/privacy-policy-/";
const REPO_URL = "https://github.com/shawnjan-cmd/CommandCube";
const REPO_RAW = "https://raw.githubusercontent.com/shawnjan-cmd/CommandCube/main";
function Step5Legal({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <>
      <SignList>
        <SignCard id="doc_privacy"  accent="cyan"    icon={<Eye className="h-5 w-5" />}         title="PRIVACY POLICY"
          body="A random device UUID is the only identifier ever stored. No scripts, contacts, locations, analytics, or telemetry are collected — there is no cloud server to receive them. Open the full text below and sign to confirm you have read it."
          signed={signed} onSign={sign} link={{ label: "READ FULL PRIVACY POLICY",  url: "/legal/privacy" }} />
        <SignCard id="doc_tos"      accent="yellow"  icon={<Gavel className="h-5 w-5" />}       title="TERMS OF SERVICE"
          body="Butler AI is provided for adults (18+) operating personal PCs they own. Unauthorised access, malware deployment, and any unlawful use are strictly forbidden. By signing, you accept these terms in full."
          signed={signed} onSign={sign} link={{ label: "READ FULL TERMS",            url: "/legal/terms"   }} />
        <SignCard id="doc_safety"   accent="green"   icon={<ShieldCheck className="h-5 w-5" />} title="DATA SAFETY DECLARATION"
          body="Camera is used for QR pairing only and never stored. No analytics, no advertising, no third-party SDKs. All data lives in a local SQLite file on your PC. The codebase is open-source and independently auditable."
          signed={signed} onSign={sign} link={{ label: "READ DATA SAFETY",           url: "/legal/safety"  }} />
        <SignCard id="doc_deletion" accent="orange"  icon={<Trash2 className="h-5 w-5" />}      title="DATA DELETION POLICY"
          body="Settings → DELETE ALL MY DATA wipes everything in three taps: phone storage, KB entries, command history, and device UUID. The action is immediate, permanent, and irreversible — there is no cloud backup to restore from."
          signed={signed} onSign={sign} link={{ label: "READ DELETION POLICY",       url: "/legal/delete"  }} />
      </SignList>
      <a href="/legal/privacy"
        className="panel-cyber mt-3 flex items-center justify-center gap-2 px-3 py-3 text-[12px] font-bold tracking-widest text-cyan transition hover:bg-cyan/5">
        <ExternalLink className="h-4 w-4" /> OPEN ALL LEGAL DOCUMENTS
      </a>
    </>
  );
}

/* ---------- 6. Permissions (one required) ---------- */
function Step6Permissions({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <div className="space-y-2.5">
      <div className="panel-cyber flex items-center justify-center gap-2 px-3 py-2.5 text-center text-[12px] font-bold tracking-widest text-foreground/85">
        <span className="rounded border border-green/50 bg-green/10 px-2 py-0.5 text-green">REQUIRED</span>
        <span>LOCAL NETWORK · EVERYTHING ELSE IS OPTIONAL</span>
      </div>
      <SignList>
        <SignCard id="perm_lan" accent="green" icon={<Wifi className="h-5 w-5" />} title="LOCAL NETWORK · REQUIRED"
          body="Allows Butler AI to discover your PC server on Wi-Fi and exchange signed commands. No internet permission is requested — this scope is strictly limited to devices on your own home network."
          signed={signed} onSign={sign} />
      </SignList>
      <OptionalPerm icon={<Camera className="h-4 w-4" />}      color="magenta" title="CAMERA · OPTIONAL"      body="Scan QR codes from your PC for one-tap pairing. Nothing is photographed or stored — the camera releases the instant a code is read." />
      <OptionalPerm icon={<Folder className="h-4 w-4" />}      color="orange"  title="STORAGE · OPTIONAL"     body="Send a file from your phone to your PC. Used only when you actively tap 'Send File' — never in the background." />
      <OptionalPerm icon={<Fingerprint className="h-4 w-4" />} color="cyan"    title="BIOMETRICS · OPTIONAL"  body="Lock the app behind FaceID or fingerprint. Disabled by default; enable any time in Settings." />
    </div>
  );
}

function OptionalPerm({ icon, color, title, body }: { icon: ReactNode; color: Accent; title: string; body: string }) {
  const [enabled, setEnabled] = useState(false);
  return (
    <div className="panel-cyber flex items-start gap-3 p-3">
      <div className={`grid h-9 w-9 shrink-0 place-items-center rounded-md border border-${color}/40 bg-background/60 text-${color}`}>{icon}</div>
      <div className="min-w-0 flex-1">
        <div className={`text-xs font-bold tracking-wider text-${color}`}>{title}</div>
        <p className="mt-1 text-[13px] leading-relaxed text-foreground">{body}</p>
      </div>
      <button
        onClick={() => setEnabled((v) => !v)}
        className={`mt-0.5 flex h-6 w-11 shrink-0 items-center rounded-full border transition ${enabled ? `border-${color}/60 bg-${color}/20` : "border-border bg-background/60"}`}
      >
        <span className={`h-4 w-4 rounded-full transition-all ${enabled ? `ml-6 bg-${color} shadow-[0_0_10px_currentColor]` : "ml-1 bg-muted-foreground"}`} />
      </button>
    </div>
  );
}

/* ---------- 7. Q & A (no sign required) ---------- */
const QA: { q: string; a: string; color: Accent; icon: ReactNode }[] = [
  { q: "What does Butler AI actually do?",        a: "Sends signed Python commands over your home Wi-Fi to a server you run on your PC. PC executes → result returns to your phone. 100% local.", color: "cyan",    icon: <HelpCircle className="h-4 w-4" /> },
  { q: "Does it run automatically?",              a: "NO — every script requires your active tap. No background execution, no scheduler, no cron, no auto-start. Enforced server-side.",            color: "orange",  icon: <Ban className="h-4 w-4" /> },
  { q: "Does it upload my data?",                 a: "NEVER — 100% local SQLite database on your PC. No data ever leaves your local network. No cloud relay, no analytics, no telemetry.",         color: "green",   icon: <Eye className="h-4 w-4" /> },
  { q: "How is the LAN connection secured?",      a: "HMAC-SHA256 signed requests · AES-256 encrypted in transit · Single-device pairing · 64-char tokens · Replay protection via timestamp.",     color: "green",   icon: <Lock className="h-4 w-4" /> },
  { q: "How do I pair my PC?",                    a: "Run the one-shot installer on your PC. It auto-downloads Python, Ollama, the local AI model, the HMAC bridge, and butler_server.py (~6 programs), then instantly displays a pairing QR code on your screen. Tap SCAN QR TO PAIR on your phone — one tap and you're connected. After that it auto-reconnects.",     color: "cyan",    icon: <ScanLine className="h-4 w-4" /> },
  { q: "Can I undo a script I ran by accident?",  a: "YES — 1-Tap Undo. Every execution is logged and reversible for 24 hours. PC → Undo Log → tap entry → Undo.",                                  color: "yellow",  icon: <PenLine className="h-4 w-4" /> },
  { q: "Does the AI model call the internet?",    a: "NO — Ollama (qwen2.5-coder:7b) runs entirely on your PC. Fully offline AI inference. Zero outbound calls.",                                  color: "magenta", icon: <Brain className="h-4 w-4" /> },
  { q: "What about malicious-script detection?",  a: "A built-in Malicious-Script Shield scans every payload for dangerous patterns (rm -rf, format, registry wipes, miners) before execution.",   color: "orange",  icon: <ShieldAlert className="h-4 w-4" /> },
  { q: "What data is collected about me?",        a: "None. A random device UUID lives only on your phone. No scripts, outputs, file names, contacts, or analytics ever leave the device.",        color: "cyan",    icon: <Eye className="h-4 w-4" /> },
  { q: "How do I delete all my data?",            a: "Settings → DELETE ALL MY DATA — three taps. Wipes phone storage, KB, history, UUID. PC SQLite is removed via the PC uninstaller.",           color: "orange",  icon: <Trash2 className="h-4 w-4" /> },
];
function Step7QA() {
  const [open, setOpen] = useState(0);
  return (
    <div className="space-y-2">
      <SigmaNetGraph />
      <HmacMarquee />
      {QA.map((qa, i) => {
        const isOpen = open === i;
        return (
          <button key={qa.q} onClick={() => setOpen(isOpen ? -1 : i)}
            className={`panel w-full overflow-hidden p-3 text-left transition ${isOpen ? `glow-${qa.color}` : ""}`}>
            <div className="flex items-start gap-2">
              <span className={`mt-0.5 text-${qa.color}`}>{qa.icon}</span>
              <span className={`flex-1 text-xs font-bold tracking-wider text-${qa.color}`}>{qa.q}</span>
              <ChevronRight className={`h-4 w-4 text-muted-foreground transition ${isOpen ? "rotate-90" : ""}`} />
            </div>
            {isOpen && <p className="mt-2 pl-6 text-[13px] leading-relaxed text-foreground">{qa.a}</p>}
          </button>
        );
      })}
    </div>
  );
}

/* ---------- 8. Server Privacy (SIGN-GATE) ---------- */
function Step8Server({ sign, signed }: { sign: (id: string) => void; signed: Record<string, number> }) {
  return (
    <>
      <TerminalBox title="butler_server.py" badge="LOCALHOST" color="green" lines={[
        "BIND        127.0.0.1 / LAN iface",
        "AUTH        HMAC-SHA256",
        "EXEC        signed Python only",
        "STORAGE     ./butler.db (SQLite)",
        "TELEMETRY   disabled · no remote calls",
      ]} />
      <SignList>
        <SignCard id="srv_local"  accent="cyan"    icon={<Server className="h-5 w-5" />}      title="RUNS ON YOUR PC ONLY"
          body="A small Flask server binds exclusively to your LAN network interface. It is never exposed to the public internet, never proxied through a cloud, and never reachable from outside your own home network."
          signed={signed} onSign={sign} />
        <SignCard id="srv_sqlite" accent="green"   icon={<Database className="h-5 w-5" />}    title="LOCAL SQLITE DATABASE"
          body="Scripts, execution logs, knowledge-base entries, and command history all live in a single .db file on your PC. Nothing is uploaded anywhere — you can inspect, back up, or delete this file at any time."
          signed={signed} onSign={sign} />
        <SignCard id="srv_python" accent="orange"  icon={<Code2 className="h-5 w-5" />}       title="EXECUTES SIGNED PYTHON ONLY"
          body="The server accepts only cryptographically signed Python payloads, executed through your own system Python interpreter. No shell mode, no remote eval, no other execution paths whatsoever."
          signed={signed} onSign={sign} />
        <SignCard id="srv_hmac"   accent="magenta" icon={<KeyRound className="h-5 w-5" />}    title="HMAC-SHA256 AUTHENTICATION"
          body="Every single request is signed with a shared secret generated at pairing time. Any unsigned, malformed, or tampered request is rejected immediately — including replay attacks blocked by per-request timestamps."
          signed={signed} onSign={sign} />
        <SignCard id="srv_shield" accent="orange"  icon={<ShieldAlert className="h-5 w-5" />} title="MALICIOUS-SCRIPT SHIELD"
          body="A hard-coded blocklist scans every payload before execution: rm -rf /, format/diskpart, registry wipes, shutdown commands, crypto-miner patterns, and known destructive sequences are refused server-side, no exceptions."
          signed={signed} onSign={sign} />
      </SignList>
    </>
  );
}

/* ---------- 9. PC Setup ---------- */
function Step9Setup() {
  return (
    <div className="space-y-3">
      <FeatureHero icon={<Wrench className="h-16 w-16" />} color="magenta" title="PC SETUP" subtitle="Three steps · about five minutes total" />
      <PairingQR />
      {[
        { n: "01", title: "INSTALL REQUIREMENTS",   body: "Run the one-shot installer — it silently sets up Python 3.12+, every required pip package, Ollama, and the qwen2.5-coder:7b model. No extra clicks, no manual configuration.", color: "cyan"   as Accent },
        { n: "02", title: "DOWNLOAD BUTLER SERVER", body: "butler_server.py runs on your PC, instantly displays a pairing QR code, and opens a signed LAN bridge bound only to your local network interface.",                            color: "yellow" as Accent },
        { n: "03", title: "CONNECT & CONTROL",      body: "Tap SCAN QR TO PAIR on your phone, point the camera at your PC screen, and you are connected. Pairing is a one-time event — the link auto-restores every time afterwards.",     color: "green"  as Accent },
      ].map((s) => (
        <div key={s.n} className={`panel flex flex-col items-center gap-3 p-4 text-center glow-${s.color}`}>
          <div className={`grid h-14 w-14 place-items-center rounded-md border border-${s.color}/50 bg-background/60 font-mono text-${s.color}`}>
            <span className="text-2xl font-extrabold leading-none">{s.n}</span>
          </div>
          <div className="min-w-0">
            <div className={`font-display text-[15px] font-extrabold tracking-widest text-${s.color}`}>{s.title}</div>
            <p className="mt-2 text-[14px] leading-relaxed text-foreground">{s.body}</p>
          </div>
        </div>
      ))}
      <div className="panel-cyber space-y-2 p-3 glow-green">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-green">
            <Server className="h-4 w-4" />
            <span className="font-mono text-xs font-extrabold tracking-wider">butler_server.py</span>
          </div>
          <span className="rounded border border-green/40 bg-green/10 px-1.5 py-0.5 font-mono text-[9px] tracking-widest text-green">
            PYTHON · ~14 KB
          </span>
        </div>
        <p className="text-[12px] leading-relaxed text-foreground/80">
          The local-only bridge that runs on YOUR PC. Saves to your Downloads folder — no installer, no telemetry.
        </p>
        <div className="grid grid-cols-2 gap-2 pt-1">
          <a
            href={REPO_RAW + "/butler_server.py"}
            target="_blank"
            rel="noreferrer"
            download="butler_server.py"
            className="flex items-center justify-center gap-2 rounded-md border border-green/60 bg-green/15 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-green shadow-[0_0_18px_-6px_currentColor] transition hover:bg-green/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green/70"
          >
            <Server className="h-3.5 w-3.5" /> DOWNLOAD
          </a>
          <a
            href={REPO_URL}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 rounded-md border border-cyan/60 bg-cyan/10 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-cyan transition hover:bg-cyan/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/70"
          >
            <ExternalLink className="h-3.5 w-3.5" /> VIEW SOURCE
          </a>
        </div>
      </div>
      <a href={POLICY_URL} target="_blank" rel="noreferrer"
        className="panel-cyber flex items-center justify-center gap-2 px-3 py-2.5 text-[11px] font-bold tracking-widest text-foreground transition hover:bg-foreground/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-foreground/40">
        <ExternalLink className="h-3 w-3" /> OPEN SETUP DOCS
      </a>
      <div className="grid grid-cols-2 gap-2">
        <KVTile icon={<Cpu className="h-4 w-4" />}      label="MIN RAM"  value="4 GB"   color="cyan" />
        <KVTile icon={<HardDrive className="h-4 w-4" />} label="DISK"    value="2 GB"   color="green" />
      </div>
    </div>
  );
}

/* ---------- 10. Launch ---------- */
function Step10Launch({ onLaunch }: { onLaunch: () => void }) {
  const [armed, setArmed] = useState(false);
  const [progress, setProgress] = useState(0);
  const [lines, setLines] = useState<string[]>([]);
  const seqRef = useRef<number | null>(null);

  const sequence = useMemo(() => [
    "[OK] PYTHON ENGINE",
    "[OK] OLLAMA BRIDGE",
    "[OK] HMAC-SHA256 AUTH",
    "[OK] ZERO CLOUD VERIFIED",
    "[OK] SIGMA-NET ONLINE",
    "BUTLER OS READY",
  ], []);

  useEffect(() => {
    if (!armed) return;
    let i = 0;
    const t = window.setInterval(() => {
      setLines((l) => [...l, sequence[i]]);
      setProgress(((i + 1) / sequence.length) * 100);
      i++;
      if (i >= sequence.length) {
        window.clearInterval(t);
        setTimeout(() => onLaunch(), 600);
      }
    }, 320);
    seqRef.current = t;
    return () => window.clearInterval(t);
  }, [armed, sequence, onLaunch]);

  return (
    <div className="space-y-5">
      <FeatureHero icon={<Rocket className="h-16 w-16" />} color="cyan" title="INITIATE BUTLER OS" subtitle="All policies signed · all systems verified" />
      <TerminalBox title="LAUNCH SEQUENCE" badge={armed ? "RUNNING" : "ARMED"} color="green" lines={armed ? lines : ["awaiting operator confirmation..."]} />
      <div className="h-1 w-full overflow-hidden rounded-full bg-surface">
        <div className="h-full rounded-full bg-gradient-to-r from-green via-cyan to-magenta transition-all duration-300" style={{ width: `${progress}%` }} />
      </div>
      {!armed ? (
        <button
          onClick={() => setArmed(true)}
          className="group relative grid w-full place-items-center overflow-hidden rounded-2xl border border-cyan/50 bg-background/40 py-6 glow-cyan transition hover:bg-cyan/10"
        >
          <span className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan/10 to-transparent opacity-0 transition group-hover:opacity-100" />
          <div className="relative flex items-center gap-3 font-mono">
            <Power className="h-6 w-6 text-cyan text-glow-cyan" />
            <span className="text-lg font-extrabold tracking-[0.3em] text-cyan text-glow-cyan">ENGAGE</span>
          </div>
          <div className="relative mt-1 text-[11px] font-medium tracking-widest text-foreground/75">PRESS TO BOOT BUTLER OS</div>
        </button>
      ) : progress >= 100 ? (
        <div className="relative">
          <span className="pointer-events-none absolute inset-0 ring-burst rounded-full border-2 border-green/60" />
          <div className="reveal-burst panel grid place-items-center gap-2 p-5 glow-green">
            <Sparkles className="h-8 w-8 text-green text-glow-green icon-pop-in" />
            <div className="text-lg font-extrabold tracking-widest text-green text-glow-green">WELCOME, OPERATOR</div>
            <div className="text-[12px] font-medium tracking-widest text-foreground/80">BUTLER OS · ONLINE</div>
          </div>
        </div>
      ) : (
        <div className="panel-cyber flex items-center justify-center gap-2 p-3 text-xs tracking-widest text-cyan">
          <span className="h-2 w-2 rounded-full bg-cyan pulse-dot" /> BOOTING · {Math.round(progress)}%
        </div>
      )}
      <SourceConfigManager />
      <OperatorBundle />
      <div className="grid grid-cols-2 gap-2">
        <KVTile icon={<Heart className="h-4 w-4" />}        label="OPEN"   value="AUDITABLE" color="magenta" />
        <KVTile icon={<InfinityIcon className="h-4 w-4" />} label="YOURS" value="FOREVER"    color="cyan" />
      </div>
    </div>
  );
}

/* ---------- Operator Bundle (download all files) ---------- */
function OperatorBundle() {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(0);
  const [masterLink, setMasterLink] = useState<{ url: string; name: string } | null>(null);
  const FILES = useMemo(
    () => [
      { name: "butler_server.py",       url: REPO_RAW + "/butler_server.py", kind: "remote" as const },
      { name: "README.md",              url: REPO_RAW + "/README.md",        kind: "remote" as const },
      { name: "LICENSE",                url: REPO_RAW + "/LICENSE",          kind: "remote" as const },
      { name: "butler-master-<ts>.md",  url: "",                              kind: "master" as const },
    ],
    [],
  );
  const ZIP_URL = REPO_URL + "/archive/refs/heads/main.zip";

  const triggerRemote = (url: string, name: string) => {
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.rel = "noreferrer";
    a.target = "_blank";
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const downloadAll = async () => {
    if (busy) return;
    setBusy(true);
    setDone(0);
    setMasterLink(null);
    try { navigator.vibrate?.(12); } catch { /* noop */ }
    playSignChime(0.5);
    for (let i = 0; i < FILES.length; i++) {
      const f = FILES[i];
      if (f.kind === "master") {
        try {
          const res = await exportMasterSourceMd();
          if (res.url) setMasterLink({ url: res.url, name: res.name });
        } catch { /* swallow — keep the queue moving */ }
      } else {
        triggerRemote(f.url, f.name);
      }
      setDone(i + 1);
      await new Promise((r) => setTimeout(r, 280));
    }
    setBusy(false);
  };

  return (
    <div className="panel-cyber space-y-3 p-4 glow-green">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-green">
          <HardDrive className="h-4 w-4" />
          <span className="font-display text-[12px] font-extrabold tracking-[0.2em]">OPERATOR BUNDLE</span>
        </div>
        <span className="rounded-full border border-green/40 bg-green/10 px-2 py-0.5 font-mono text-[9px] tracking-widest text-green">
          {FILES.length} FILES
        </span>
      </div>
      <p className="text-[13px] leading-relaxed text-foreground/85">
        Grab everything you need to run Butler OS on your PC in one tap — server bridge, readme, license, and your full master source bundle (.md). All saved straight to your Downloads folder.
      </p>
      <ul className="grid gap-1 font-mono text-[11px] text-foreground/80">
        {FILES.map((f, i) => (
          <li key={f.name} className="flex items-center justify-between gap-2 rounded-md border border-green/20 bg-green/5 px-2 py-1">
            <span className="truncate">{f.name}{f.kind === "master" ? "  ·  full project source" : ""}</span>
            <span className={`text-[10px] tracking-widest ${busy && i >= done ? "text-foreground/40" : "text-green"}`}>
              {busy ? (i < done ? "✓ SENT" : i === done ? "…" : "QUEUED") : "READY"}
            </span>
          </li>
        ))}
      </ul>
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={downloadAll}
          disabled={busy}
          className="flex items-center justify-center gap-2 rounded-md border border-green/60 bg-green/15 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-green shadow-[0_0_18px_-6px_currentColor] transition hover:bg-green/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green/70 disabled:opacity-60"
        >
          <Server className="h-3.5 w-3.5" />
          {busy ? `DOWNLOADING ${done}/${FILES.length}` : "DOWNLOAD ALL FILES"}
        </button>
        <a
          href={ZIP_URL}
          target="_blank"
          rel="noreferrer"
          className="flex items-center justify-center gap-2 rounded-md border border-cyan/60 bg-cyan/10 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-cyan transition hover:bg-cyan/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan/70"
        >
          <ExternalLink className="h-3.5 w-3.5" /> DOWNLOAD .ZIP
        </a>
      </div>
      {masterLink ? (
        <a
          href={masterLink.url}
          download={masterLink.name}
          target="_blank"
          rel="noreferrer"
          className="flex items-center justify-center gap-2 rounded-md border border-green/60 bg-green/20 px-3 py-2.5 text-[11px] font-extrabold tracking-widest text-green shadow-[0_0_18px_-6px_currentColor]"
        >
          <Download className="h-3.5 w-3.5" /> OPEN MASTER .MD — {masterLink.name}
        </a>
      ) : null}
    </div>
  );
}

/* ============================================================
   SHARED PRIMITIVES
   ============================================================ */

function TerminalBox({ title, badge, lines, color = "green" }: { title: string; badge?: string; lines: string[]; color?: "green" | "cyan" }) {
  const c = color;
  return (
    <div className={`panel relative overflow-hidden ${c === "green" ? "glow-green" : "glow-cyan"}`}>
      {/* Header — matches the in-app panel chrome (no fake mac traffic lights) */}
      <div className={`flex items-center justify-between border-b border-${c}/30 bg-gradient-to-r from-${c}/15 via-transparent to-${c}/10 px-3 py-2`}>
        <div className="flex items-center gap-2 min-w-0">
          <span className={`relative grid h-5 w-5 place-items-center rounded-md border border-${c}/60 bg-background/70 text-${c}`}>
            <Code2 className="h-3 w-3" />
            <span className={`pulse-dot absolute -right-0.5 -top-0.5 h-1.5 w-1.5 rounded-full bg-${c} shadow-[0_0_8px_currentColor]`} />
          </span>
          <span className={`font-display text-[11px] font-bold tracking-[0.18em] text-${c} truncate`}>{title}</span>
        </div>
        {badge && (
          <span className={`shrink-0 rounded-full border border-${c}/50 bg-${c}/10 px-2 py-0.5 font-display text-[9px] font-bold tracking-[0.2em] text-${c}`}>
            {badge}
          </span>
        )}
      </div>
      {/* Body */}
      <pre className={`whitespace-pre-wrap px-3 py-3 font-mono text-[12px] leading-relaxed text-${c}`}>
        {lines.map((l, i) => (
          <div key={i} className="flex gap-2">
            <span className={`text-${c}/60 select-none`}>{String(i + 1).padStart(2, "0")}</span>
            <span className={`text-${c}/70 select-none`}>{"›"}</span>
            <span className="text-foreground/95">{l}</span>
          </div>
        ))}
        <div className="flex gap-2">
          <span className={`text-${c}/60 select-none`}>{String(lines.length + 1).padStart(2, "0")}</span>
          <span className={`text-${c}/70 select-none`}>{"›"}</span>
          <span className={`cursor-blink text-${c}`}>▍</span>
        </div>
      </pre>
    </div>
  );
}

function FeatureHero({ icon, color, title, subtitle }: { icon: ReactNode; color: Accent; title: string; subtitle: string }) {
  return (
    <div className={`panel flex items-center gap-4 p-4 glow-${color}`}>
      <div className={`grid h-20 w-20 shrink-0 place-items-center rounded-lg border border-${color}/40 bg-background/50 text-${color}`}>
        {icon}
      </div>
      <div className="min-w-0">
        <div className={`text-lg font-extrabold tracking-wider text-${color}`}>{title}</div>
        <div className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{subtitle}</div>
      </div>
    </div>
  );
}

function KVTile({ icon, label, value, color }: { icon: ReactNode; label: string; value: string; color: Accent }) {
  return (
    <div className="panel-cyber flex items-center gap-3 p-3">
      <div className={`grid h-9 w-9 place-items-center rounded-md border border-${color}/40 bg-${color}/5 text-${color}`}>{icon}</div>
      <div>
        <div className={`text-sm font-bold text-${color}`}>{value}</div>
        <div className="text-[10px] font-medium tracking-widest text-foreground/70">{label}</div>
      </div>
    </div>
  );
}

/* keep Scroll import alive in case lucide re-shakes */
export const __keep = { Scroll };

/* ============================================================
   STEP ICONS — 10 unique custom SVGs (one per page)
   ============================================================ */

function StepIcon({ n, className = "h-4 w-4" }: { n: number; className?: string }) {
  const p = { fill: "none", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (n) {
    case 1: // WELCOME — waving hand + spark
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M8 14V7a1.5 1.5 0 1 1 3 0v6"/><path d="M11 13V5.5a1.5 1.5 0 1 1 3 0V13"/><path d="M14 13V6.5a1.5 1.5 0 1 1 3 0V14"/><path d="M17 14v-3a1.5 1.5 0 1 1 3 0v6a5 5 0 0 1-5 5h-2a5 5 0 0 1-5-5v-1l-2-3a1.4 1.4 0 0 1 2.2-1.7L9 13"/><path d="M5 4l1 1M3 8h1.5M6 2v1.5"/></g></svg>);
    case 2: // APP TOUR — compass / map
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><circle cx="12" cy="12" r="9"/><path d="M15.5 8.5 13 13l-4.5 2.5L11 11z" fill="currentColor" opacity=".25"/><path d="M15.5 8.5 13 13l-4.5 2.5L11 11z"/></g></svg>);
    case 3: // SAFETY — shield + check
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M12 3 4 6v6c0 4.5 3.4 8.4 8 9 4.6-.6 8-4.5 8-9V6z"/><path d="m9 12 2 2 4-4"/></g></svg>);
    case 4: // PLEDGE — raised fist
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M7 21V12a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v9"/><path d="M9 10V7a1.5 1.5 0 1 1 3 0v3"/><path d="M12 10V6a1.5 1.5 0 1 1 3 0v4"/><path d="M15 10V8a1.5 1.5 0 1 1 3 0v3"/></g></svg>);
    case 5: // LEGAL — scroll w/ ribbon
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M6 4h10a2 2 0 0 1 2 2v12a2 2 0 0 0 2 2H8a2 2 0 0 1-2-2z"/><path d="M4 4h2v14a2 2 0 0 0 2 2"/><path d="M9 9h6M9 13h6"/></g></svg>);
    case 6: // PERMISSIONS — keyring
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><circle cx="8" cy="14" r="4"/><path d="m11 11 9-9"/><path d="m17 5 2 2M15 7l2 2"/></g></svg>);
    case 7: // Q&A — speech with question mark
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M21 12a8 8 0 0 1-11.5 7.2L4 21l1.8-5.5A8 8 0 1 1 21 12z"/><path d="M10 10a2 2 0 1 1 3 1.7c-.7.4-1 .8-1 1.6"/><circle cx="12" cy="16.5" r=".6" fill="currentColor"/></g></svg>);
    case 8: // SERVER — tower with signal
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><rect x="4" y="5" width="16" height="6" rx="1.5"/><rect x="4" y="13" width="16" height="6" rx="1.5"/><circle cx="8" cy="8" r=".7" fill="currentColor"/><circle cx="8" cy="16" r=".7" fill="currentColor"/><path d="M15 8h3M15 16h3"/></g></svg>);
    case 9: // SETUP — gear + wrench
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><circle cx="11" cy="11" r="3"/><path d="M11 3v2M11 17v2M3 11h2M17 11h2M5.6 5.6l1.4 1.4M15 15l1.4 1.4M5.6 16.4 7 15M15 7l1.4-1.4"/><path d="M14 18l3 3 4-4-3-3"/></g></svg>);
    case 10: // LAUNCH — rocket
      return (<svg viewBox="0 0 24 24" className={className}><g {...p}><path d="M12 2c3 3 5 6.5 5 10v5l-3 2H10l-3-2v-5c0-3.5 2-7 5-10z"/><circle cx="12" cy="10" r="1.5" fill="currentColor"/><path d="M9 19c-1 1.5-1 3-1 3M15 19c1 1.5 1 3 1 3M7 14l-3 1 1 4 3-1M17 14l3 1-1 4-3-1"/></g></svg>);
    default: return null;
  }
}

/* ============================================================
   STEP TOOLBAR — bottom strip mirroring the in-app dock
   ============================================================ */

function StepToolbar({ step, onJump }: { step: number; onJump: (i: number) => void }) {
  return (
    <nav className="mt-6 panel relative overflow-hidden p-2">
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-20" />
      <div className="relative grid grid-cols-10 gap-1">
        {STEPS.map((s, i) => {
          const active = i === step;
          const done = i < step;
          return (
            <button
              key={s.id}
              onClick={() => onJump(i)}
              aria-label={`Go to step ${s.id}: ${s.tag.replace(/_/g, " ")}`}
              className={
                "relative grid place-items-center rounded-md py-2 transition " +
                (active
                  ? `bg-${s.accent}/15 text-${s.accent} shadow-[0_0_18px_-4px_currentColor]`
                  : done
                  ? `text-${s.accent}/70 hover:bg-${s.accent}/5`
                  : "text-muted-foreground/70 hover:text-foreground")
              }
            >
              {active && <span className={`absolute -top-0.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-${s.accent} pulse-dot`} />}
              <StepIcon n={s.id} className="h-5 w-5" />
              <span className="mt-0.5 text-[8px] tracking-widest">{String(s.id).padStart(2,"0")}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}


/* ===== Tailwind safelist — keep dynamic accent classes in the build =====
   text-cyan text-green text-magenta text-orange text-yellow
   bg-cyan bg-green bg-magenta bg-orange bg-yellow
   bg-cyan/5 bg-green/5 bg-magenta/5 bg-orange/5 bg-yellow/5
   bg-cyan/10 bg-green/10 bg-magenta/10 bg-orange/10 bg-yellow/10
   bg-cyan/20 bg-green/20 bg-magenta/20 bg-orange/20 bg-yellow/20
   border-cyan/40 border-green/40 border-magenta/40 border-orange/40 border-yellow/40
   border-cyan/50 border-green/50 border-magenta/50 border-orange/50 border-yellow/50
   border-cyan/60 border-green/60 border-magenta/60 border-orange/60 border-yellow/60
   glow-cyan glow-green glow-magenta glow-orange
   text-glow-cyan text-glow-green
   from-green via-cyan to-magenta
=========================================================================== */

