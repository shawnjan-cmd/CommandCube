import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState, useEffect } from "react";
import {
  Upload, Download, Send, FileText, RefreshCw, Trash2, Clipboard as ClipIcon,
  X, Monitor, Camera, Lock, VolumeX, Moon, Bell, Power, Wifi, Activity,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { PageTitle } from "@/components/ThemedCard";
import { NcxCard, NcxSection, NcxBtn } from "@/components/tools/NcxCard";
import { toast } from "sonner";

export const Route = createFileRoute("/files")({
  head: () => ({ meta: [{ title: "Tools Hub — Butler AI" }] }),
  component: ToolsHubPage,
});

/* ───────────── Quick PC tools registry ───────────── */
const QUICK_TOOLS = [
  { id: "shot",   icon: <Camera   className="h-4 w-4" />, label: "Screenshot", desc: "Capture PC screen" },
  { id: "lock",   icon: <Lock     className="h-4 w-4" />, label: "Lock",       desc: "Lock PC remotely" },
  { id: "mute",   icon: <VolumeX  className="h-4 w-4" />, label: "Mute",       desc: "Toggle PC audio" },
  { id: "sleep",  icon: <Moon     className="h-4 w-4" />, label: "Sleep",      desc: "Put PC to sleep" },
  { id: "notify", icon: <Bell     className="h-4 w-4" />, label: "Notify",     desc: "Send notification" },
  { id: "wake",   icon: <Power    className="h-4 w-4" />, label: "Wake",       desc: "Wake-on-LAN" },
  { id: "wifi",   icon: <Wifi     className="h-4 w-4" />, label: "Wi-Fi",      desc: "Toggle Wi-Fi" },
  { id: "ping",   icon: <Activity className="h-4 w-4" />, label: "Ping",       desc: "Latency test" },
] as const;

type ClipEntry = { id: string; text: string; ts: number };

function ToolsHubPage() {
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState(0);
  const [clipText, setClipText] = useState("");
  const [clipHist, setClipHist] = useState<ClipEntry[]>([]);
  const [autoSync, setAutoSync] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  /* hydrate clip history */
  useEffect(() => {
    try { const r = localStorage.getItem("nx_clip_hist"); if (r) setClipHist(JSON.parse(r)); } catch {}
  }, []);
  useEffect(() => {
    try { localStorage.setItem("nx_clip_hist", JSON.stringify(clipHist.slice(0, 20))); } catch {}
  }, [clipHist]);

  const pickFile = () => fileRef.current?.click();
  const onPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 10 * 1024 * 1024) { toast.error("Max 10MB"); return; }
    setFile(f); setProgress(0);
  };
  const sendFile = async () => {
    if (!file) { toast("Choose a file first"); return; }
    setProgress(1);
    for (let p = 0; p <= 100; p += 8) {
      await new Promise((r) => setTimeout(r, 40));
      setProgress(p);
    }
    toast.success(`✓ Sent ${file.name}`);
    setFile(null); setProgress(0);
  };

  const sendClip = () => {
    if (!clipText.trim()) { toast("Empty"); return; }
    setClipHist((h) => [{ id: crypto.randomUUID(), text: clipText.slice(0, 200), ts: Date.now() }, ...h].slice(0, 20));
    toast.success("→ PC clipboard");
  };
  const pasteClip = async () => {
    try { const t = await navigator.clipboard.readText(); setClipText(t); } catch { toast.error("Clipboard blocked"); }
  };
  const copyHist = async (t: string) => {
    try { await navigator.clipboard.writeText(t); toast.success("Copied"); } catch {}
  };

  return (
    <AppShell active="files">
      <PageTitle kicker="LAN · DIRECT" title="TOOLS HUB" sub="FILE BRIDGE · CLIPBOARD · REMOTE CTRL" color="cyan" />

      {/* ── FILE BRIDGE ── */}
      <div className="mt-4">
        <NcxSection color="blue" title="File Bridge" />
        <div className="grid grid-cols-2 gap-2.5">
          {/* SEND */}
          <NcxCard color="blue" icon={<Upload className="h-3.5 w-3.5" />} title="Send Files">
            <div className="m-2.5 flex-1">
              <input ref={fileRef} type="file" hidden onChange={onPick} />
              <div className="drop-zone" data-has-file={file ? "true" : "false"} onClick={pickFile}
                   style={{ ["--c" as any]: "#4488ff" }}>
                {!file ? (
                  <>
                    <div className="grid h-10 w-10 place-items-center rounded-md border border-[color:rgba(68,136,255,0.3)] bg-[color:rgba(68,136,255,0.08)]">
                      <Upload className="h-4 w-4 text-[#4488ff]" />
                    </div>
                    <div className="mt-2 font-mono text-[12px] text-foreground/90">Tap to select</div>
                    <div className="mt-0.5 font-mono text-[9.5px] tracking-widest text-cyan">ANY FILE · MAX 10MB</div>
                  </>
                ) : (
                  <>
                    <FileText className="h-6 w-6 text-[#4488ff]" />
                    <div className="mt-1 max-w-[150px] truncate font-mono text-[11px] text-[#4488ff]">{file.name}</div>
                    <div className="font-mono text-[9px] text-foreground/55">{(file.size / 1024).toFixed(1)} KB</div>
                  </>
                )}
              </div>
              {progress > 0 && (
                <div className="mt-2">
                  <div className="flex justify-between font-mono text-[9.5px] text-foreground/65">
                    <span>Uploading…</span><span>{progress}%</span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-[var(--ink)]">
                    <div className="h-full bg-[#4488ff]" style={{ width: `${progress}%`, transition: "width .12s linear" }} />
                  </div>
                </div>
              )}
            </div>
            <div className="px-2.5 pb-2.5">
              <NcxBtn color="blue" onClick={sendFile} className="w-full">
                <Send className="h-3 w-3" /> Send to PC
              </NcxBtn>
            </div>
          </NcxCard>

          {/* RECEIVED */}
          <NcxCard color="green" icon={<Download className="h-3.5 w-3.5" />} title="Received">
            <div className="m-2.5 flex-1">
              <div className="drop-zone" style={{ ["--c" as any]: "var(--green)", cursor: "default" }}>
                <div className="grid h-10 w-10 place-items-center rounded-full border border-[color:color-mix(in_oklab,var(--green)_30%,transparent)] text-[color:color-mix(in_oklab,var(--green)_60%,transparent)]">
                  <Download className="h-4 w-4" />
                </div>
                <div className="mt-2 font-mono text-[12px] text-foreground/65">Waiting…</div>
                <div className="mt-0.5 font-mono text-[10px] text-[color:var(--green)]">FROM DESKTOP</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-1.5 px-2.5 pb-2.5">
              <NcxBtn color="green" onClick={() => toast("Refreshed")}>
                <RefreshCw className="h-3 w-3" /> Refresh
              </NcxBtn>
              <NcxBtn ghost onClick={() => toast("Cleared")}>
                <Trash2 className="h-3 w-3" /> Clear
              </NcxBtn>
            </div>
          </NcxCard>
        </div>
      </div>

      {/* ── CLIPBOARD SYNC ── */}
      <div className="mt-4">
        <NcxSection
          color="purple"
          title="Clipboard Sync"
          action={
            <span className="flex items-center gap-1.5 font-mono text-[9.5px] tracking-widest text-foreground/55">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[color:var(--magenta)] shadow-[0_0_6px_var(--magenta)]" />
              REAL-TIME
            </span>
          }
        />
        <div className="grid grid-cols-2 gap-2.5">
          <NcxCard color="purple" icon={<Send className="h-3.5 w-3.5" />} title="Send to PC">
            <textarea
              value={clipText}
              onChange={(e) => setClipText(e.target.value)}
              placeholder="Type or paste text…"
              rows={4}
              className="m-2.5 resize-none rounded-md border border-[color:color-mix(in_oklab,var(--magenta)_25%,transparent)] bg-black/25 p-2 font-mono text-[12px] text-foreground/95 outline-none focus:border-[color:color-mix(in_oklab,var(--magenta)_55%,transparent)]"
            />
            <div className="flex items-center gap-1.5 px-2.5 pb-1.5">
              <NcxBtn color="purple" onClick={sendClip} className="flex-1"><Send className="h-3 w-3" /> Send</NcxBtn>
              <NcxBtn ghost onClick={pasteClip}><ClipIcon className="h-3 w-3" /></NcxBtn>
              <NcxBtn ghost onClick={() => setClipText("")}><X className="h-3 w-3" /></NcxBtn>
            </div>
            <button
              onClick={() => setAutoSync((v) => !v)}
              className="mx-2.5 mb-2.5 flex items-center gap-2 rounded border border-[color:var(--border)] bg-[var(--ink)]/60 px-2 py-1.5 text-left"
            >
              <span className={`h-1.5 w-1.5 rounded-full ${autoSync ? "bg-[color:var(--magenta)] shadow-[0_0_6px_var(--magenta)]" : "bg-foreground/30"}`} />
              <span className="flex-1 font-mono text-[10px] tracking-widest text-foreground/65">AUTO-SYNC (1s)</span>
              <span
                className={`relative h-[17px] w-[32px] rounded-full border ${autoSync ? "border-[color:color-mix(in_oklab,var(--magenta)_40%,transparent)] bg-[color:color-mix(in_oklab,var(--magenta)_22%,transparent)]" : "border-[color:var(--border)] bg-[var(--surface-2)]"}`}
              >
                <span
                  className={`absolute top-[1.5px] h-[11px] w-[11px] rounded-full transition-all ${autoSync ? "left-[17px] bg-[color:var(--magenta)] shadow-[0_0_6px_var(--magenta)]" : "left-[2px] bg-foreground/45"}`}
                />
              </span>
            </button>
          </NcxCard>

          <NcxCard color="purple" icon={<ClipIcon className="h-3.5 w-3.5" />} title="Clip History">
            {clipHist.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-2 p-5">
                <ClipIcon className="h-7 w-7 text-[color:color-mix(in_oklab,var(--magenta)_25%,transparent)]" />
                <p className="text-center font-mono text-[10.5px] leading-snug text-foreground/55">
                  Empty<br />Send something first
                </p>
              </div>
            ) : (
              <ul className="max-h-[230px] space-y-1 overflow-y-auto p-2">
                {clipHist.map((c) => (
                  <li
                    key={c.id}
                    onClick={() => copyHist(c.text)}
                    className="cursor-pointer rounded-md border border-[color:color-mix(in_oklab,var(--magenta)_18%,transparent)] bg-[color:color-mix(in_oklab,var(--magenta)_7%,transparent)] px-2 py-1.5 hover:border-[color:color-mix(in_oklab,var(--magenta)_38%,transparent)]"
                  >
                    <div className="truncate font-mono text-[11px] text-foreground/95">{c.text}</div>
                    <div className="font-mono text-[8.5px] tracking-widest text-foreground/45">
                      {new Date(c.ts).toLocaleTimeString()}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </NcxCard>
        </div>
      </div>

      {/* ── PC DESKTOP ── */}
      <div className="mt-4">
        <NcxSection
          color="cyan"
          title="PC Desktop"
          action={
            <button onClick={() => toast("Refreshing…")} className="flex items-center gap-1 font-mono text-[10px] tracking-widest text-foreground/55 hover:text-cyan">
              <RefreshCw className="h-3 w-3" /> REFRESH
            </button>
          }
        />
        <div className="pc-screen">
          <span className="pc-screen-corner tl" /><span className="pc-screen-corner tr" />
          <span className="pc-screen-corner bl" /><span className="pc-screen-corner br" />
          <div className="z-10 flex flex-col items-center gap-1 text-center">
            <Monitor className="h-9 w-9 text-foreground/35" />
            <div className="mt-1 font-mono text-[11px] tracking-[0.2em] text-foreground/55">NO SERVER CONNECTED</div>
            <div className="font-mono text-[10px] text-foreground/40">Scan QR on the HOME tab</div>
          </div>
        </div>
      </div>

      {/* ── QUICK TOOLS ── */}
      <div className="mt-4">
        <NcxSection color="amber" title="Quick Tools" />
        <div className="grid grid-cols-4 gap-2">
          {QUICK_TOOLS.map((t, i) => {
            const palette: Array<"cyan" | "amber" | "green" | "purple"> = ["cyan", "amber", "green", "purple"];
            const c = palette[i % palette.length];
            const cssVar = c === "amber" ? "var(--orange)" : c === "purple" ? "var(--magenta)" : `var(--${c})`;
            return (
              <button
                key={t.id}
                onClick={() => toast.success(`${t.label} → PC`)}
                className="tool-tile"
                style={{ ["--c" as any]: cssVar }}
              >
                <span style={{ color: cssVar, filter: `drop-shadow(0 0 4px ${cssVar})` }}>{t.icon}</span>
                <span className="mt-1 font-display text-[10px] font-extrabold tracking-[0.12em] text-foreground/95">{t.label}</span>
                <span className="font-mono text-[8.5px] tracking-wider text-foreground/45">{t.desc}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="pt-3 pb-1 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · TOOLS HUB · LAN-DIRECT
      </div>
    </AppShell>
  );
}
