import { createFileRoute } from "@tanstack/react-router";
import { LegalShell, LegalSection } from "@/components/LegalShell";

export const Route = createFileRoute("/legal/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service — Butler AI" },
      { name: "description", content: "Adult developer tool for personal PC automation. Lawful use only. No unauthorised access." },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <LegalShell
      title="Terms of Service"
      accent="yellow"
      emoji="⚖️"
      headline="Butler AI Automation · Android App · Effective April 1, 2026"
      badges={[
        { label: "18+ ONLY",          tone: "orange" },
        { label: "PERSONAL PCs ONLY", tone: "yellow" },
        { label: "NO MALWARE",        tone: "red"    },
        { label: "NO SURVEILLANCE",   tone: "red"    },
        { label: "LAWFUL USE",        tone: "green"  },
      ]}
    >
      <LegalSection title="01 · WHO MAY USE BUTLER AI" tone="orange">
        <p>You must be at least 18 years old. Butler AI is a developer tool that executes Python on your PC; it is not designed for minors.</p>
      </LegalSection>

      <LegalSection title="02 · ACCEPTABLE USE" tone="yellow">
        <ul className="list-disc space-y-1 pl-5">
          <li>Use Butler AI only on PCs you own, or PCs you are explicitly authorised to control.</li>
          <li>You are responsible for every script you choose to execute.</li>
          <li>Comply with the laws of your jurisdiction.</li>
        </ul>
      </LegalSection>

      <LegalSection title="03 · PROHIBITED USE" tone="red">
        <ul className="list-disc space-y-1 pl-5">
          <li>No unauthorised access to other people's computers, networks, or accounts.</li>
          <li>No malware, ransomware, crypto-miners, keyloggers, or destructive payloads.</li>
          <li>No surveillance or privacy violations of other people.</li>
          <li>No attempts to bypass the malicious-script shield.</li>
        </ul>
      </LegalSection>

      <LegalSection title="04 · NO WARRANTY" tone="cyan">
        <p>Butler AI and the included server are provided "as is", without warranty of any kind. You assume all risk of running scripts on your own hardware.</p>
      </LegalSection>

      <LegalSection title="05 · LIABILITY" tone="cyan">
        <p>To the maximum extent permitted by law, the developer is not liable for any damages arising from your use or misuse of Butler AI.</p>
      </LegalSection>

      <LegalSection title="06 · CHANGES" tone="green">
        <p>If these terms change, the new version takes effect when the app prompts you to re-accept on next launch. Continued use after re-acceptance constitutes agreement.</p>
      </LegalSection>
    </LegalShell>
  );
}
