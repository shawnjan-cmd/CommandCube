import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/kb-growth")({
  beforeLoad: () => {
    throw redirect({ to: "/knowledge", search: { tab: "growth" } as any });
  },
  component: () => null,
});
