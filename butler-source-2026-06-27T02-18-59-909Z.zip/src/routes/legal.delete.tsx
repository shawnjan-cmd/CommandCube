import { createFileRoute } from "@tanstack/react-router";
import { LegalShell, LegalSection } from "@/components/LegalShell";
import { Trash2, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/legal/delete")({
  head: () => ({
    meta: [
      { title: "Delete My Data — Butler AI" },
      { name: "description", content: "Wipe every byte Butler AI stores. Three taps. Irreversible." },
    ],
  }),
  component: DeletePage,
});

function DeletePage() {
  return (
    <LegalShell
      title="Delete My Data"
      accent="red"
      emoji="🗑️"
      headline="Three taps · immediate · irreversible · no cloud backup"
      badges={[
        { label: "PHONE STORAGE",    tone: "red"    },
        { label: "PAIRING SECRET",   tone: "red"    },
        { label: "KB CACHE",         tone: "orange" },
        { label: "UI PREFERENCES",   tone: "orange" },
      ]}
    >
      <LegalSection title="HOW TO DELETE EVERYTHING" tone="red">
        <ol className="list-decimal space-y-2 pl-5">
          <li>Open the app and tap <strong>Settings</strong>.</li>
          <li>Scroll to the bottom and tap <strong className="text-red">DELETE ALL MY DATA</strong>.</li>
          <li>Confirm twice. The app wipes itself and closes.</li>
        </ol>
        <div className="mt-3 flex items-start gap-2 rounded-md border border-red/60 bg-red/5 p-3 text-[12px] text-red">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>This action is <strong>permanent and irreversible</strong>. There is no cloud backup to restore from.</span>
        </div>
      </LegalSection>

      <LegalSection title="WHAT GETS WIPED ON YOUR PHONE" tone="orange">
        <ul className="list-disc space-y-1 pl-5">
          <li>Device UUID</li>
          <li>Pairing secret (Android Keystore entry)</li>
          <li>Paired-PC IP and metadata</li>
          <li>UI preferences (theme, language, layout)</li>
          <li>Knowledge-base cache and undo log mirror</li>
        </ul>
      </LegalSection>

      <LegalSection title="REMOVING SERVER DATA ON YOUR PC" tone="cyan">
        <p>Butler runs locally on your PC. To remove the server-side data:</p>
        <ol className="list-decimal space-y-1 pl-5">
          <li>Stop <code>butler_server.py</code>.</li>
          <li>Delete the <code>butler.db</code> SQLite file.</li>
          <li>Run the PC uninstaller, or manually remove the install directory.</li>
        </ol>
      </LegalSection>

      <LegalSection title="ALREADY UNINSTALLED?" tone="green">
        <p>Uninstalling the Android app already wipes everything stored on the phone. No further action is needed on our side because no data is held off-device.</p>
      </LegalSection>

      <div className="grid place-items-center pt-4">
        <div className="panel-cyber inline-flex items-center gap-2 rounded-full border border-red/60 px-5 py-2.5 text-xs font-extrabold tracking-widest text-red glow-orange">
          <Trash2 className="h-4 w-4" /> DELETE FLOW IS IN THE APP — NOT HERE
        </div>
      </div>
    </LegalShell>
  );
}
