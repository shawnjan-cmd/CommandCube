import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Activity, Bell, Bot, Brain, ClipboardList, Code2, Cpu, Database,
  FileText, Fingerprint, Infinity as InfinityIcon, Lock, MonitorSmartphone,
  Network, ScrollText, Shield, ShieldCheck, Target, TerminalSquare, User,
  Box, Circle, ChevronRight, Play, Clock, Sparkles,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { NexusHero } from "@/components/NexusHero";
import { Sparkline } from "@/components/Sparkline";
import { ActivityFeed } from "@/components/ActivityFeed";
import { useTelemetry, fmtUptime, fmtPct } from "@/lib/useTelemetry";
import { getConfig } from "@/lib/butler";
import mascotImg from "@/assets/mascot-butler.png";


export const Route = createFileRoute("/home")({
  head: () => ({
    meta: [
      { title: "Nexus — Butler AI" },
      { name: "description", content: "Local-only Butler AI command center. Live PC telemetry, scripts, and pairing — all on your LAN." },
      { property: "og:title", content: "Nexus — Butler AI" },
      { property: "og:description", content: "Local-only PC automation. Zero cloud. Your private AI butler." },
    ],
  }),
  component: NexusHomePage,
});

function NexusHomePage() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);
  const t = useTelemetry(2500);
  const cfg = getConfig();
  const host = mounted && cfg.baseUrl ? new URL(cfg.baseUrl).host : "192.168.1.102";
  const hostname = t.hostname || "NEXUS-CORE";

  return (
    <AppShell active="home">
      <NexusHeader online={t.online} />
      <NexusHero t={t} />

      <Link
        to="/nexus"
        className="mt-3 flex items-center justify-between gap-3 panel-cyber px-3 py-2.5 group"
        style={{ boxShadow: "0 0 18px hsl(187 100% 50% / .15), inset 0 1px 0 hsl(0 0% 100% / .04)" }}
      >
        <div className="flex items-center gap-2.5">
          <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg border border-primary/40 bg-primary/10 text-primary">
            <Sparkles className="w-4 h-4" />
          </span>
          <div>
            <div className="font-display text-[13px] font-extrabold tracking-[0.22em] glow-text-cyan">NEXUS · COMMAND CENTER</div>
            <div className="text-[10px] text-muted-foreground font-mono tracking-wider">11 modules · CONN · DASH · AI · KB · TOOLS · CFG</div>
          </div>
        </div>
        <span className="font-mono text-[10px] tracking-widest text-primary group-hover:translate-x-1 transition">OPEN ▸</span>
      </Link>



      <div className="mt-4 mb-1 px-1 font-display text-[10px] font-extrabold tracking-[0.32em] text-foreground/55">
        ── SYSTEM TELEMETRY ──
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <ConnectedPCCard hostname={hostname} host={host} t={t} mounted={mounted} />
        <LiveTerminalCard />
        <CrawlerGraphCard history={t.history} />
        <KnowledgeGraphCard />
        <ScriptForgeCard />
        <FileShareCard />
        <SmartAlertsCard />
        <OmegaLoopCard />
      </div>

      <SecurityProtocols />
      <RecentActivityCard />

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · BUTLER AI · LOCAL-FIRST
      </div>
    </AppShell>
  );
}


/* ============ HEADER ============ */
function NexusHeader({ online }: { online: boolean }) {
  return (
    <header className="panel-cyber flex items-center gap-2.5 px-2.5 py-2.5">
      <div className="flex-1 text-center">
        <h1 className="font-display text-[22px] font-black leading-none tracking-[0.36em] text-cyan"
            style={{
              background: "linear-gradient(180deg,#eafcff 0%, var(--cyan) 55%, color-mix(in oklab, var(--magenta) 70%, var(--cyan)) 100%)",
              WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent",
              textShadow: "0 0 18px color-mix(in oklab, var(--cyan) 60%, transparent)",
              filter: "drop-shadow(0 0 6px color-mix(in oklab, var(--cyan) 50%, transparent))",
            }}>
          BUTLER AI
        </h1>
        <div className="mt-1 font-mono text-[9px] tracking-[0.42em] text-foreground/55">NEXUS DASHBOARD</div>
      </div>
      <div className="panel-cyber flex items-center gap-1.5 px-1.5 py-1" style={{ ["--c" as any]: "var(--cyan)" }}>
        <div className="grid h-8 w-8 place-items-center overflow-hidden rounded-sm border border-[color:var(--border)] bg-[#06080d]">
          <img src={mascotImg} alt="Butler" className="h-7 w-7 object-cover" style={{ filter: "drop-shadow(0 0 6px var(--cyan))" }} />
        </div>
        <div className="flex flex-col leading-tight pr-1">
          <span className="font-display text-[9px] font-bold tracking-widest text-foreground/85">BUTLER</span>
          <span className="flex items-center gap-1 font-mono text-[8px] tracking-widest" style={{ color: online ? "var(--green)" : "var(--orange)" }}>
            <Circle className="h-1.5 w-1.5 fill-current pulse-dot" /> {online ? "ONLINE" : "IDLE"}
          </span>
        </div>
      </div>
    </header>
  );
}

/* ============ CARD HELPER ============ */
function Card({ color = "cyan", title, icon, action, children, className = "" }: {
  color?: "cyan" | "violet" | "green" | "amber" | "red";
  title: string; icon: React.ReactNode; action?: React.ReactNode;
  children: React.ReactNode; className?: string;
}) {
  const cls = color === "cyan" ? "" : `c-${color}`;
  const cvar = color === "violet" ? "var(--magenta)" : color === "amber" ? "var(--orange)" : `var(--${color})`;
  return (
    <div
      className={`panel-cyber ${cls} brackets holo-grain lift relative overflow-hidden ${className}`}
      style={{ ["--c" as any]: cvar }}
    >
      <span className="br-tr" aria-hidden />
      <span className="br-bl" aria-hidden />
      <div className="card-accent absolute left-0 right-0 top-0" aria-hidden />
      <div className="p-2.5 pt-3">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5" style={{ color: cvar }}>
            <span className="led" aria-hidden />
            {icon}
            <span className="font-display text-[10px] font-extrabold tracking-[0.22em]">{title}</span>
          </div>
          {action}
        </div>
        {children}
      </div>
    </div>
  );
}


/* ============ CONNECTED PC ============ */
function ConnectedPCCard({ hostname, host, t, mounted }: any) {
  return (
    <Card color="cyan" title="CONNECTED PC"
      icon={<MonitorSmartphone className="h-3.5 w-3.5" />}
      action={<Circle className="h-2 w-2 fill-[color:var(--green)] text-[color:var(--green)] pulse-dot" />}>
      <div className="font-display text-[16px] font-black leading-tight text-foreground">{hostname}</div>
      <div className="mt-0.5 font-mono text-[10px] text-foreground/65">Windows 11 Pro</div>
      <div className="font-mono text-[10px] text-foreground/65">{host}</div>
      <div className="mt-1.5 flex items-center gap-2 font-mono text-[9px]">
        <span className="flex items-center gap-1 text-[color:var(--green)]"><Circle className="h-1.5 w-1.5 fill-current" />ONLINE</span>
        <span className="text-cyan">+ SECURE</span>
      </div>
      <div className="mt-2 grid grid-cols-4 gap-1 border-t border-[color:var(--border)] pt-1.5 text-center">
        <Stat label="UPTIME" value={mounted ? fmtUptime(t.uptime) : "—"} />
        <Stat label="CPU" value={fmtPct(t.cpu)} />
        <Stat label="RAM" value={fmtPct(t.ram)} />
        <Stat label="DISK" value={fmtPct(t.disk)} />
      </div>
    </Card>
  );
}
function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="font-mono text-[8px] tracking-[0.18em] text-foreground/45">{label}</div>
      <div className="font-display text-[11px] font-bold text-cyan leading-tight truncate">{value}</div>
    </div>
  );
}

/* ============ LIVE TERMINAL ============ */
function LiveTerminalCard() {
  const lines = [
    { t: "09:41:12", m: "System handshake verified" },
    { t: "09:41:13", m: "Nexus protocols initialized" },
    { t: "09:41:13", m: "AI core modules online" },
    { t: "09:41:14", m: "Memory bridge established" },
    { t: "09:41:14", m: "Listening for commands…" },
  ];
  return (
    <Card color="violet" title="LIVE FEED"
      icon={<TerminalSquare className="h-3.5 w-3.5" />}
      action={<span className="flex items-center gap-1 font-mono text-[8px] tracking-widest text-[color:var(--magenta)]"><Circle className="h-1.5 w-1.5 fill-current pulse-dot" />LIVE</span>}>
      <div className="space-y-0.5 font-mono text-[9px] leading-tight">
        {lines.map((l, i) => (
          <div key={i} className="flex items-start gap-1.5">
            <span className="text-[color:var(--magenta)]">{">"}</span>
            <span className="flex-1 truncate text-foreground/75">{l.m}</span>
            <span className="text-foreground/35 tabular-nums">{l.t}</span>
          </div>
        ))}
      </div>
      <div className="mt-1.5 flex items-center justify-between border-t border-[color:var(--border)] pt-1 font-mono text-[8px] tracking-widest">
        <span className="text-foreground/55">STATUS: <span className="text-[color:var(--magenta)]">OPERATIONAL</span></span>
        <span className="cursor-blink h-2 w-1 bg-[color:var(--magenta)] inline-block" />
      </div>
    </Card>
  );
}

/* ============ CRAWLER GRAPH ============ */
function CrawlerGraphCard({ history }: { history: number[] }) {
  const data = history.length ? history : [4,6,5,7,8,7,9,8,10,9,11,10,12,11,13];
  return (
    <Card color="cyan" title="CRAWLER GRAPH" icon={<Activity className="h-3.5 w-3.5" />}>
      <div className="font-display text-[18px] font-black text-cyan leading-none">8.72M</div>
      <div className="font-mono text-[8px] tracking-widest text-foreground/55">ENTITIES INDEXED</div>
      <div className="font-mono text-[9px] text-[color:var(--green)]">▲ 12.4%</div>
      <div className="mt-1.5">
        <Sparkline data={data} height={36} color="var(--cyan)" />
      </div>
      <div className="mt-0.5 flex justify-between font-mono text-[7px] text-foreground/35">
        <span>-24H</span><span>-12H</span><span>NOW</span>
      </div>
    </Card>
  );
}

/* ============ KNOWLEDGE GRAPH ============ */
function KnowledgeGraphCard() {
  return (
    <Card color="green" title="KNOWLEDGE" icon={<Network className="h-3.5 w-3.5" />}>
      <div className="relative mx-auto my-1 h-16 w-full">
        <svg viewBox="0 0 120 64" className="absolute inset-0 h-full w-full">
          <g stroke="var(--green)" strokeOpacity="0.45" strokeWidth="0.5" fill="none">
            <line x1="60" y1="32" x2="20" y2="14" /><line x1="60" y1="32" x2="100" y2="14" />
            <line x1="60" y1="32" x2="14" y2="50" /><line x1="60" y1="32" x2="106" y2="50" />
            <line x1="60" y1="32" x2="60" y2="6" /><line x1="60" y1="32" x2="60" y2="58" />
          </g>
          {[[20,14],[100,14],[14,50],[106,50],[60,6],[60,58]].map(([x,y],i)=>(
            <circle key={i} cx={x} cy={y} r="2.5" fill="var(--green)" style={{filter:"drop-shadow(0 0 3px var(--green))"}}/>
          ))}
          <circle cx="60" cy="32" r="6" fill="none" stroke="var(--green)" strokeWidth="1" style={{filter:"drop-shadow(0 0 6px var(--green))"}}/>
        </svg>
        <Brain className="absolute left-1/2 top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 text-[color:var(--green)]" style={{ filter: "drop-shadow(0 0 4px var(--green))" }} />
      </div>
      <div className="grid grid-cols-2 gap-1 font-mono text-[8px]">
        <div><div className="text-foreground/45 tracking-widest">NODES</div><div className="font-display text-[12px] font-bold text-[color:var(--green)]">128,456</div></div>
        <div><div className="text-foreground/45 tracking-widest">RELATIONS</div><div className="font-display text-[12px] font-bold text-[color:var(--green)]">912,341</div></div>
      </div>
    </Card>
  );
}

/* ============ SCRIPT FORGE ============ */
function ScriptForgeCard() {
  return (
    <Card color="violet" title="SCRIPT FORGE" icon={<Code2 className="h-3.5 w-3.5" />}>
      <div className="font-display text-[20px] font-black text-[color:var(--magenta)] leading-none">1,246</div>
      <div className="font-mono text-[8px] tracking-widest text-foreground/55">SCRIPTS</div>
      <div className="mt-1.5 space-y-1 font-mono text-[9px]">
        <Row label="RUNNING" value="12" icon={<Play className="h-2.5 w-2.5" />} />
        <Row label="SCHEDULED" value="28" icon={<Clock className="h-2.5 w-2.5" />} />
        <div>
          <div className="flex justify-between"><span className="text-foreground/55 tracking-widest">SUCCESS</span><span className="text-[color:var(--magenta)]">98.7%</span></div>
          <div className="mt-0.5 h-1 w-full overflow-hidden rounded-sm bg-[color:var(--border)]">
            <div className="h-full bg-[color:var(--magenta)]" style={{ width: "98.7%", boxShadow: "0 0 6px var(--magenta)" }} />
          </div>
        </div>
      </div>
    </Card>
  );
}
function Row({ label, value, icon }: any) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-foreground/55 tracking-widest">{label}</span>
      <span className="flex items-center gap-1 text-foreground/85">{value}{icon}</span>
    </div>
  );
}

/* ============ FILE SHARE ============ */
function FileShareCard() {
  const files = [
    { n: "research.pdf", s: "134 MB", i: FileText, c: "var(--red)" },
    { n: "dataset.csv", s: "89 MB", i: FileText, c: "var(--green)" },
    { n: "blueprint.png", s: "3.2 MB", i: FileText, c: "var(--cyan)" },
  ];
  return (
    <Card color="green" title="FILE SHARE" icon={<ClipboardList className="h-3.5 w-3.5" />}>
      <div className="flex items-baseline gap-1.5">
        <div className="font-display text-[20px] font-black text-[color:var(--green)] leading-none">24</div>
        <div className="font-mono text-[8px] tracking-widest text-foreground/55">CLIPS</div>
      </div>
      <div className="mt-1.5 space-y-0.5">
        {files.map((f, i) => {
          const Icon = f.i;
          return (
            <div key={i} className="flex items-center gap-1 font-mono text-[9px]">
              <Icon className="h-2.5 w-2.5 shrink-0" style={{ color: f.c }} />
              <span className="flex-1 truncate text-foreground/80">{f.n}</span>
              <span className="text-foreground/45 tabular-nums">{f.s}</span>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

/* ============ SMART ALERTS ============ */
function SmartAlertsCard() {
  const alerts = [
    { t: "High CPU detected", s: "NEXUS-CORE", a: "2m" },
    { t: "Login blocked", s: "NEXUS-CORE", a: "18m" },
    { t: "Script failure", s: "Script Forge", a: "1h" },
  ];
  return (
    <Card color="amber" title="SMART ALERTS"
      icon={<Bell className="h-3.5 w-3.5" />}
      action={<span className="font-display text-[11px] font-black text-[color:var(--orange)]">3</span>}>
      <div className="space-y-1 font-mono text-[8.5px]">
        {alerts.map((a, i) => (
          <div key={i} className="flex items-center gap-1">
            <Circle className="h-2 w-2 shrink-0 fill-[color:var(--orange)] text-[color:var(--orange)]" />
            <span className="flex-1 truncate text-foreground/80">{a.t}</span>
            <span className="text-foreground/40">{a.a}</span>
          </div>
        ))}
      </div>
      <div className="mt-1.5 text-center font-display text-[9px] font-bold tracking-widest text-[color:var(--orange)]">VIEW ALL ›</div>
    </Card>
  );
}

/* ============ OMEGA LEARNING LOOP ============ */
function OmegaLoopCard() {
  return (
    <Card color="green" title="OMEGA LOOP" icon={<InfinityIcon className="h-3.5 w-3.5" />}>
      <div className="relative mx-auto my-1 grid h-14 w-14 place-items-center">
        <div className="absolute inset-0 rounded-full border border-[color:var(--green)] spin-slow" style={{ boxShadow: "0 0 10px var(--green) inset, 0 0 8px var(--green)" }} />
        <div className="absolute inset-2 rounded-full border border-[color:var(--green)]/60 spin-reverse" />
        <InfinityIcon className="h-5 w-5 text-[color:var(--green)]" style={{ filter: "drop-shadow(0 0 6px var(--green))" }} />
      </div>
      <div className="font-mono text-[8px] text-foreground/55 tracking-widest text-center">CONFIDENCE</div>
      <div className="text-center font-display text-[14px] font-black text-[color:var(--green)] leading-none">93.8%</div>
    </Card>
  );
}

/* ============ SECURITY PROTOCOLS ============ */
function SecurityProtocols() {
  const items = [
    { i: ShieldCheck, l: "FIREWALL", s: "ACTIVE", c: "var(--cyan)" },
    { i: Target,     l: "INTRUSION", s: "ACTIVE", c: "var(--green)" },
    { i: Lock,       l: "ENCRYPTION", s: "AES-256", c: "var(--magenta)" },
    { i: User,       l: "ACCESS",   s: "ZERO TRUST", c: "var(--cyan)" },
    { i: Box,        l: "SANDBOX",  s: "ISOLATED", c: "var(--orange)" },
    { i: Fingerprint,l: "INTEGRITY",s: "VERIFIED", c: "var(--green)" },
  ];
  return (
    <Card color="cyan" title="SECURITY PROTOCOLS"
      icon={<Shield className="h-3.5 w-3.5" />}
      action={<span className="flex items-center gap-1 font-mono text-[8px] tracking-widest text-[color:var(--green)]">STATUS: SECURE <Circle className="h-1.5 w-1.5 fill-current" /></span>}>
      <div className="grid grid-cols-6 gap-1.5">
        {items.map((it, i) => {
          const Icon = it.i;
          return (
            <div key={i} className="panel-cyber p-1 text-center" style={{ ["--c" as any]: it.c }}>
              <Icon className="mx-auto h-4 w-4" style={{ color: it.c, filter: `drop-shadow(0 0 4px ${it.c})` }} />
              <div className="mt-0.5 font-display text-[7px] font-bold tracking-widest text-foreground/85">{it.l}</div>
              <div className="font-mono text-[6.5px] tracking-widest" style={{ color: it.c }}>{it.s}</div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

/* ============ RECENT ACTIVITY ============ */
function RecentActivityCard() {
  return (
    <Card color="cyan" title="RECENT ACTIVITY"
      icon={<ScrollText className="h-3.5 w-3.5" />}
      action={<Link to={"/terminal" as any} className="flex items-center gap-0.5 font-mono text-[8px] tracking-widest text-cyan">VIEW LOGS <ChevronRight className="h-2.5 w-2.5" /></Link>}>
      <ActivityFeed limit={5} />
    </Card>
  );
}

// keep unused imports referenced for tree-shaking safety
void Bot; void Database; void Cpu;
