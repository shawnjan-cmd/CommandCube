import { createFileRoute } from "@tanstack/react-router";
import { Headphones, Heart, Sparkles, Palette, Check, Mail, Github, Coffee } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";

export const Route = createFileRoute("/support")({
  head: () => ({ meta: [{ title: "Cosmetic Packs — Butler AI" }] }),
  component: SupportPage,
});

const PACKS: Array<{ name: string; tag: string; color: "cyan" | "violet" | "green" | "amber" | "red"; owned: boolean; sub: string }> = [
  { name: "NEXUS CORE",       tag: "DEFAULT",  color: "cyan",   owned: true,  sub: "Cyan/magenta neon · stock theme" },
  { name: "OBSIDIAN BLOOM",   tag: "PREMIUM",  color: "violet", owned: true,  sub: "Magenta haze, lower contrast" },
  { name: "VIRIDIAN MATRIX",  tag: "PREMIUM",  color: "green",  owned: false, sub: "Phosphor green, terminal feel" },
  { name: "SOLAR FLARE",      tag: "PREMIUM",  color: "amber",  owned: false, sub: "Amber/orange warm cyberpunk" },
  { name: "CRIMSON PROTOCOL", tag: "LIMITED",  color: "red",    owned: false, sub: "Red alert, high-contrast" },
];

function SupportPage() {
  return (
    <AppShell active="support">
      <PageTitle kicker="THEMES · TIPS" title="SUPPORT BUTLER" sub="COSMETIC PACKS · NO PAYWALL ON FEATURES" color="violet" />

      <div className="mt-3">
        <ThemedCard color="violet" title="WHY SUPPORT" icon={<Heart className="h-3.5 w-3.5" />}>
          <p className="font-mono text-[11px] leading-relaxed text-foreground/80">
            Butler AI is <span className="text-[color:var(--magenta)] font-bold">100% free</span> and <span className="text-cyan font-bold">local-only</span> forever. Cosmetic packs unlock new themes and skins — they don't gate features. Every pack funds future development.
          </p>
        </ThemedCard>
      </div>

      <div className="mt-2.5 grid grid-cols-1 gap-2.5">
        {PACKS.map((p) => (
          <ThemedCard
            key={p.name}
            color={p.color}
            title={p.name}
            icon={<Palette className="h-3.5 w-3.5" />}
            action={
              p.owned
                ? <span className="flex items-center gap-1 font-display text-[9px] font-extrabold tracking-[0.2em] text-[color:var(--green)]"><Check className="h-3 w-3" /> OWNED</span>
                : <span className="font-mono text-[9px] tracking-widest text-foreground/55">{p.tag}</span>
            }
          >
            <p className="font-mono text-[11px] text-foreground/75">{p.sub}</p>
            <div className="mt-2 flex items-center gap-2">
              {!p.owned ? (
                <button className="panel-cyber lift px-3 py-1.5 font-display text-[10px] font-extrabold tracking-[0.2em]"
                        style={{ ["--c" as any]: p.color === "violet" ? "var(--magenta)" : p.color === "amber" ? "var(--orange)" : `var(--${p.color})` }}>
                  UNLOCK · €3
                </button>
              ) : (
                <button className="panel-cyber lift px-3 py-1.5 font-display text-[10px] font-extrabold tracking-[0.2em]"
                        style={{ ["--c" as any]: "var(--cyan)" }}>
                  APPLY THEME
                </button>
              )}
              <span className="font-mono text-[9px] tracking-widest text-foreground/45">PREVIEW · LONG-PRESS</span>
            </div>
          </ThemedCard>
        ))}
      </div>

      <div className="mt-2.5">
        <ThemedCard color="cyan" title="CONTACT" icon={<Headphones className="h-3.5 w-3.5" />}>
          <ul className="space-y-2">
            <ContactRow icon={<Mail className="h-3.5 w-3.5" />}   label="support@butler.ai" sub="bug reports · feedback" />
            <ContactRow icon={<Github className="h-3.5 w-3.5" />} label="github / butler-ai" sub="source · issues" />
            <ContactRow icon={<Coffee className="h-3.5 w-3.5" />} label="ko-fi / butler"    sub="tip the developer" />
          </ul>
        </ThemedCard>
      </div>

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · COSMETICS · v1.0
      </div>
    </AppShell>
  );
}

function ContactRow({ icon, label, sub }: { icon: React.ReactNode; label: string; sub: string }) {
  return (
    <li className="flex items-center gap-2.5">
      <span className="grid h-8 w-8 place-items-center rounded border border-[color:var(--border)] bg-[var(--ink)] text-cyan">{icon}</span>
      <div className="flex-1">
        <div className="font-display text-[11px] font-extrabold tracking-[0.18em] text-foreground/90">{label}</div>
        <div className="font-mono text-[9px] tracking-widest text-foreground/45">{sub}</div>
      </div>
      <Sparkles className="h-3.5 w-3.5 text-foreground/30" />
    </li>
  );
}
