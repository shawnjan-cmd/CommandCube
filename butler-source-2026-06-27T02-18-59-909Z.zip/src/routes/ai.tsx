import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useMemo, useRef, useState } from "react";
import { Bot, User2, Send, Sparkles, Trash2, Square, Copy, Check, RotateCw } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";
import { MarkdownLite } from "@/components/MarkdownLite";
import { QuickChips, NEXUS_CHIPS } from "@/components/QuickChips";
import { nexusBot } from "@/lib/nexusBot";
import { z } from "zod";

const search = z.object({ q: z.string().optional() });

export const Route = createFileRoute("/ai")({
  validateSearch: (s) => search.parse(s),
  head: () => ({
    meta: [
      { title: "Ask Butler — Lovable AI" },
      { name: "description", content: "Streaming AI chat with NEXUS · Butler. Powered by Lovable AI Gateway." },
    ],
  }),
  component: ChatPage,
});

const STORAGE_KEY = "butler-chat-v1";
const STARTERS = NEXUS_CHIPS.slice(0, 6);

function ChatPage() {
  const { q } = Route.useSearch();

  const transport = useMemo(() => new DefaultChatTransport({
    api: "/api/chat",
    prepareSendMessagesRequest: ({ messages, id, body }) => ({
      body: { id, messages, kbContext: nexusBot.getContext() },
    }),
  }), []);
  const { messages, sendMessage, status, stop, setMessages } = useChat({
    id: "butler-chat",
    messages: [],
    transport,
    onError: (e) => console.error("[chat]", e),
  });

  // SSR-safe hydrate: load persisted transcript after mount so server/client markup match.
  const hydratedRef = useRef(false);
  useEffect(() => {
    if (hydratedRef.current) return;
    hydratedRef.current = true;
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setMessages(JSON.parse(raw) as UIMessage[]);
    } catch {}
  }, [setMessages]);

  // Persist
  useEffect(() => {
    if (!hydratedRef.current) return;
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(messages)); } catch {}
  }, [messages]);

  // Seed from ?q=
  const seededRef = useRef(false);
  useEffect(() => {
    if (seededRef.current) return;
    if (q && q.trim()) {
      seededRef.current = true;
      void sendMessage({ text: q });
    }
  }, [q, sendMessage]);

  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "auto" });
  }, [messages, status]);

  const busy = status === "submitted" || status === "streaming";

  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const text = input.trim();
    if (!text || busy) return;
    nexusBot.trackQuestion(text);
    void sendMessage({ text });
    setInput("");
  };

  const clear = () => {
    setMessages([]);
    try { window.localStorage.removeItem(STORAGE_KEY); } catch {}
  };

  return (
    <AppShell active="butler">
      <PageTitle kicker="LOVABLE AI · GEMINI" title="ASK BUTLER" sub="STREAMING · OFFLINE-FIRST UI" color="violet" />

      <div className="mt-3">
        <ThemedCard color="violet" title="NEXUS CONVERSATION" icon={<Bot className="h-3.5 w-3.5" />} action={
          <button onClick={clear}
                  className="flex items-center gap-1 font-display text-[9px] font-extrabold tracking-[0.2em] text-foreground/55 hover:text-[color:var(--red)]">
            <Trash2 className="h-3 w-3" /> CLEAR
          </button>
        }>
          <div ref={scrollRef} className="chat-shell h-[52vh] overflow-y-auto space-y-2 rounded p-2">
            <span className="chat-rail" aria-hidden />
            <span className="chat-scan" aria-hidden />
            {messages.length === 0 && (
              <div className="grid h-full place-items-center text-center">
                <div className="w-full px-2">
                  <Sparkles className="mx-auto h-6 w-6 text-[color:var(--magenta)]" />
                  <div className="mt-2 font-display text-[11px] font-extrabold tracking-[0.22em] text-foreground/80">
                    NEXUS STANDING BY
                  </div>
                  <div className="mt-1 font-mono text-[10px] text-foreground/45">
                    tap a starter or write your own
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-1.5 text-left">
                    {STARTERS.map((s, i) => {
                      const Icon = s.icon;
                      const accent = s.color ?? "var(--magenta)";
                      return (
                        <button key={i}
                          onClick={() => void sendMessage({ text: s.prompt })}
                          className="panel-cyber lift flex items-start gap-1.5 px-2 py-1.5 text-left"
                          style={{ ["--c" as any]: accent }}>
                          <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0" style={{ color: accent }} />
                          <span className="font-display text-[9px] font-extrabold tracking-[0.18em] text-foreground/85">{s.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {messages.map((m, mi) => {
              const text = m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
              const isUser = m.role === "user";
              const isLast = mi === messages.length - 1;
              return (
                <MessageBubble
                  key={m.id}
                  isUser={isUser}
                  text={text}
                  streaming={isLast && !isUser && status === "streaming"}
                  onRegen={!isUser && isLast && !busy ? () => {
                    // pop last assistant turn and resend the prior user message
                    const prior = [...messages].reverse().find((mm) => mm.role === "user");
                    const priorText = prior?.parts.map((p) => p.type === "text" ? p.text : "").join("") ?? "";
                    setMessages(messages.slice(0, -1));
                    if (priorText) void sendMessage({ text: priorText });
                  } : undefined}
                />
              );
            })}

            {status === "submitted" && (
              <div className="flex items-center gap-2 px-1 font-mono text-[10.5px] tracking-widest text-[color:var(--magenta)]">
                <Sparkles className="h-3 w-3 animate-pulse" /> THINKING…
              </div>
            )}
          </div>

          <form onSubmit={submit} className="mt-2 flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="message NEXUS…"
              disabled={busy}
              className="min-w-0 flex-1 rounded-md border border-[color:var(--border)] bg-[var(--ink)] px-2.5 py-2 font-mono text-[12px] text-foreground outline-none focus:border-[color:var(--magenta)] disabled:opacity-50"
            />
            {busy ? (
              <button type="button" onClick={() => stop()}
                className="grid h-9 w-10 place-items-center rounded-md border border-[color:var(--red)]/60 bg-[color:var(--red)]/10 text-[color:var(--red)]"
                aria-label="Stop">
                <Square className="h-3.5 w-3.5" />
              </button>
            ) : (
              <button type="submit" disabled={!input.trim()}
                className="grid h-9 w-10 place-items-center rounded-md border border-[color:var(--magenta)]/60 bg-[color:var(--magenta)]/10 text-[color:var(--magenta)] disabled:opacity-40"
                aria-label="Send"
                style={{ boxShadow: "0 0 16px -4px var(--magenta)" }}>
                <Send className="h-3.5 w-3.5" />
              </button>
            )}
          </form>
          {messages.length > 0 && (
            <QuickChips chips={NEXUS_CHIPS} onPick={(p) => void sendMessage({ text: p })} header="QUICK CHIPS" />
          )}
        </ThemedCard>
      </div>

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        LOVABLE AI · STREAMING · {messages.length} MSG
      </div>
    </AppShell>
  );
}

function MessageBubble({ isUser, text, streaming, onRegen }: {
  isUser: boolean; text: string; streaming?: boolean; onRegen?: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1200); } catch {}
  };
  return (
    <div className={`flex gap-2 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded border border-[color:var(--magenta)]/40 bg-[color:var(--magenta)]/10 text-[color:var(--magenta)]"
              style={{ boxShadow: "0 0 10px -3px var(--magenta)" }}>
          <Bot className="h-3 w-3" />
        </span>
      )}
      <div className="group flex max-w-[84%] flex-col gap-0.5">
        {isUser ? (
          <div className="rounded-md border border-cyan/40 bg-cyan/10 px-2.5 py-1.5 font-mono text-[12px] leading-relaxed text-foreground"
               style={{ boxShadow: "inset 0 0 12px -6px var(--cyan)" }}>
            {text}
          </div>
        ) : (
          <div className="rounded-md border border-[color:var(--border)] bg-[var(--ink-2)]/80 px-2.5 py-1.5">
            {text
              ? <MarkdownLite text={text} />
              : <span className="font-mono text-[12px] text-foreground/40">▍</span>}
            {streaming && text && <span className="font-mono text-[12px] text-[color:var(--magenta)]">▍</span>}
          </div>
        )}
        <div className="flex items-center gap-2 px-1 opacity-0 transition-opacity group-hover:opacity-100">
          {text && (
            <button onClick={copy}
              className="flex items-center gap-1 font-display text-[8.5px] font-extrabold tracking-widest text-foreground/55 hover:text-cyan">
              {copied ? <><Check className="h-2.5 w-2.5 text-[color:var(--green)]" /> COPIED</>
                      : <><Copy className="h-2.5 w-2.5" /> COPY</>}
            </button>
          )}
          {onRegen && (
            <button onClick={onRegen}
              className="flex items-center gap-1 font-display text-[8.5px] font-extrabold tracking-widest text-foreground/55 hover:text-[color:var(--magenta)]">
              <RotateCw className="h-2.5 w-2.5" /> REGEN
            </button>
          )}
        </div>
      </div>
      {isUser && (
        <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded border border-cyan/40 bg-cyan/10 text-cyan"
              style={{ boxShadow: "0 0 10px -3px var(--cyan)" }}>
          <User2 className="h-3 w-3" />
        </span>
      )}
    </div>
  );
}
