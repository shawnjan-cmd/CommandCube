import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import {
  Activity, Brain, Database, Network, Globe, BookOpen, Search, Layers,
  TrendingUp, BarChart3, Cpu, ShieldAlert, Gauge, Sparkles, Plus, Download, Trash2, Clock,
  Bot, Play, Pause, Zap, Radio, RefreshCw,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";
import { useTelemetry } from "@/lib/useTelemetry";
import { Sparkline } from "@/components/Sparkline";
import {
  AreaSparkline, MiniBarChart, ActivityBarChart, CircRing, StorageDonut,
  DiskProgressBar, MetricLineChart, DomainBreakdownChart, ThreatHeatmap,
} from "@/components/Charts";
import { kbGrowthTracker, METHOD_META } from "@/lib/kbGrowthTracker";
import { nexusBot, NEXUS_TARGETS, type Activity as BotActivity } from "@/lib/nexusBot";
import { toast } from "sonner";

export const Route = createFileRoute("/knowledge")({
  validateSearch: (s: Record<string, unknown>) => ({
    tab: typeof s.tab === "string" ? s.tab : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Knowledge Base — Butler AI" },
      { name: "description", content: "Φ-Nexus knowledge hub: live crawl, growth timeline, intel charts, neural graph, search." },
    ],
  }),
  component: KnowledgePage,
});


type TabKey =
  | "DASHBOARD" | "NEXUSBOT" | "GROWTH" | "INTEL" | "CRAWLER" | "GRAPH"
  | "SOURCES" | "LSCAN" | "SEARCH" | "EVENTS";

const TABS: Array<{ key: TabKey; label: string }> = [
  { key: "DASHBOARD", label: "DASHBOARD" },
  { key: "NEXUSBOT",  label: "NEXUSBOT"  },
  { key: "GROWTH",    label: "GROWTH"    },
  { key: "INTEL",     label: "INTEL"     },
  { key: "CRAWLER",   label: "CRAWLER"   },
  { key: "GRAPH",     label: "GRAPH"     },
  { key: "SOURCES",   label: "SOURCES"   },
  { key: "LSCAN",     label: "L-SCAN"    },
  { key: "SEARCH",    label: "SEARCH"    },
  { key: "EVENTS",    label: "EVENTS"    },
];

function useBot() {
  return useSyncExternalStore(
    (cb) => nexusBot.subscribe(cb),
    () => nexusBot.getState().cycles + nexusBot.getLog().length,
    () => 0,
  );
}

const SOURCES: Array<{ name: string; pct: number; color: "cyan" | "green" | "violet" | "amber" }> = [
  { name: "PYTHON.ORG",      pct: 92, color: "cyan"   },
  { name: "STACKOVERFLOW",   pct: 78, color: "green"  },
  { name: "GITHUB README",   pct: 64, color: "violet" },
  { name: "MDN WEB DOCS",    pct: 51, color: "amber"  },
  { name: "WIKIPEDIA · CS",  pct: 47, color: "cyan"   },
  { name: "ARCH WIKI",       pct: 43, color: "green"  },
  { name: "REDDIT · TECH",   pct: 39, color: "violet" },
  { name: "CVE · NVD",       pct: 31, color: "amber"  },
];


function useTracker() {
  return useSyncExternalStore(
    (cb) => kbGrowthTracker.subscribe(cb),
    () => kbGrowthTracker.getEventCount(),
    () => 0,
  );
}

function KnowledgePage() {
  useTracker();
  useBot();
  const search = Route.useSearch();
  const initialTab = useMemo<TabKey>(() => {
    const want = (search.tab ?? "").toUpperCase();
    const match = TABS.find((t) => t.key === want || t.label.replace(/-/g, "") === want);
    return (match?.key ?? "DASHBOARD") as TabKey;
  }, [search.tab]);
  const [tab, setTab] = useState<TabKey>(initialTab);
  useEffect(() => { setTab(initialTab); }, [initialTab]);
  const t = useTelemetry(2500);

  const articles = 18_472 + Math.floor(((t.cpu ?? 0) + (t.ram ?? 0)) * 3);
  const queue    = 14 + (Math.floor(t.cpu ?? 0) % 9);
  const workers  = 6;

  return (
    <AppShell active="knowledge">
      <PageTitle kicker="Φ-NEXUS · v5.0" title="KNOWLEDGE BASE" sub="CRAWL · INTEL · GRAPH · SEARCH" color="green" />

      {/* Functional tab strip */}
      <div className="-mx-1 mt-3 flex gap-1.5 overflow-x-auto px-1 pb-1"
           style={{ scrollbarWidth: "none" }}>
        {TABS.map((tb) => (
          <button key={tb.key}
            onClick={() => setTab(tb.key)}
            className="hex-tab shrink-0 px-3"
            data-active={tab === tb.key ? "true" : "false"}
            style={{ ["--c" as any]: "var(--green)" }}>
            <span className="font-display text-[9px] font-extrabold tracking-[0.22em]">{tb.label}</span>
          </button>
        ))}
      </div>

      <div className="mt-3 space-y-2.5">
        {tab === "DASHBOARD" && <DashboardView articles={articles} queue={queue} workers={workers} hist={t.history} uptime={t.uptime ?? 0} />}
        {tab === "NEXUSBOT"  && <NexusBotView />}
        {tab === "GROWTH"    && <GrowthView />}
        {tab === "INTEL"     && <IntelView t={t} />}
        {tab === "CRAWLER"   && <CrawlerView />}
        {tab === "GRAPH"     && <GraphView />}
        {tab === "SOURCES"   && <SourcesView />}
        {tab === "LSCAN"     && <LScanView />}
        {tab === "SEARCH"    && <SearchView />}
        {tab === "EVENTS"    && <EventsView />}
      </div>

      <div className="pt-3 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · KNOWLEDGE LATTICE · LOCAL-FIRST · 10-TAB HUB
      </div>
    </AppShell>
  );
}

/* ─── DASHBOARD ─── */
function DashboardView({ articles, queue, workers, hist, uptime }: { articles: number; queue: number; workers: number; hist: number[]; uptime: number }) {
  return (
    <>
      <div className="grid grid-cols-2 gap-2.5">
        <ThemedCard color="green" title="ARTICLES" icon={<BookOpen className="h-3.5 w-3.5" />}>
          <div className="font-display text-[26px] font-black leading-none">{articles.toLocaleString()}</div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">INDEXED · LOCAL DB</div>
        </ThemedCard>
        <ThemedCard color="cyan" title="QUEUE" icon={<Layers className="h-3.5 w-3.5" />}>
          <div className="font-display text-[26px] font-black leading-none">{queue}</div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">PENDING SHARDS</div>
        </ThemedCard>
        <ThemedCard color="violet" title="WORKERS" icon={<Brain className="h-3.5 w-3.5" />}>
          <div className="font-display text-[26px] font-black leading-none">{workers}</div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">PARALLEL · ASYNC</div>
        </ThemedCard>
        <ThemedCard color="amber" title="UPTIME" icon={<Activity className="h-3.5 w-3.5" />}>
          <div className="font-display text-[26px] font-black leading-none">{Math.floor(uptime / 60)}h</div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">SIGMANET STABLE</div>
        </ThemedCard>
      </div>
      <ThemedCard color="violet" title="NEXUS BOT · LIVE" icon={<Bot className="h-3.5 w-3.5" />}
        action={
          <Link to="/knowledge" search={{ tab: "NEXUSBOT" }}
            className="font-display text-[9px] font-extrabold tracking-widest text-[color:var(--magenta)]">OPEN →</Link>
        }>
        <div className="grid grid-cols-3 gap-2 font-mono text-[10px]">
          <div><div className="text-foreground/45">STATE</div><div className="font-display text-[14px] font-black" style={{ color: nexusBot.getState().running ? "var(--green)" : "var(--orange)" }}>{nexusBot.getState().running ? "ONLINE" : "PAUSED"}</div></div>
          <div><div className="text-foreground/45">CYCLES</div><div className="font-display text-[14px] font-black text-foreground">{nexusBot.getState().cycles}</div></div>
          <div><div className="text-foreground/45">FINDS</div><div className="font-display text-[14px] font-black text-[color:var(--green)]">+{nexusBot.getState().totalFindings}</div></div>
        </div>
      </ThemedCard>
      <ThemedCard color="green" title="GROWTH · LAST 24H" icon={<Activity className="h-3.5 w-3.5" />}>
        <Sparkline data={hist.length ? hist : [10, 14, 12, 18, 22, 19, 26, 31, 28, 34]} color="var(--green)" height={56} />
        <div className="mt-1 flex justify-between font-mono text-[9px] tracking-widest text-foreground/55">
          <span>+{Math.floor(articles * 0.012)} TODAY</span>
          <span>STREAK · {kbGrowthTracker.getStreakDays()}d</span>
        </div>
      </ThemedCard>
    </>
  );
}

/* ─── GROWTH (was kb-growth) ─── */
function GrowthView() {
  const [hoursIdx, setHoursIdx] = useState(1);
  const opts = [{ h: 4, l: "4H", b: 16 }, { h: 24, l: "24H", b: 24 }, { h: 72, l: "3D", b: 36 }, { h: 168, l: "7D", b: 28 }];
  const cfg = opts[hoursIdx];
  const buckets = useMemo(
    () => kbGrowthTracker.getChartData(cfg.h, Math.ceil((cfg.h * 60) / cfg.b)),
    [hoursIdx, kbGrowthTracker.getEventCount()],
  );
  const total = kbGrowthTracker.getTotalCount();
  const delta = buckets.reduce((s, b) => s + b.delta, 0);
  const peak = buckets.reduce((m, b) => Math.max(m, b.delta), 0);
  const methods = kbGrowthTracker.getMethodBreakdown();

  const onSeed = () => {
    const m = ["sigma", "omega", "crawler", "ncx", "lambda"];
    kbGrowthTracker.record(1 + Math.floor(Math.random() * 8), m[Math.floor(Math.random() * m.length)], ["Python", "Security", "PCHelp"][Math.floor(Math.random() * 3)]);
  };

  return (
    <>
      <div className="flex gap-1.5">
        {opts.map((o, i) => (
          <button key={o.l} onClick={() => setHoursIdx(i)} className="hex-tab flex-1 px-2"
            data-active={i === hoursIdx ? "true" : "false"} style={{ ["--c" as any]: "var(--orange)" }}>
            <span className="font-display text-[9px] font-extrabold tracking-[0.22em]">{o.l}</span>
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        <ThemedCard color="amber" title="TOTAL" icon={<Database className="h-3.5 w-3.5" />}>
          <div className="font-display text-[24px] font-black leading-none">{total.toLocaleString()}</div>
        </ThemedCard>
        <ThemedCard color="green" title={`+ ${cfg.l}`} icon={<TrendingUp className="h-3.5 w-3.5" />}>
          <div className="font-display text-[24px] font-black leading-none" style={{ color: delta > 0 ? "var(--green)" : undefined }}>
            {delta > 0 ? `+${delta}` : "idle"}
          </div>
          <div className="mt-1 font-mono text-[9px] tracking-widest text-foreground/55">PEAK · {peak}</div>
        </ThemedCard>
      </div>
      <ThemedCard color="cyan" title="TIMELINE" icon={<BarChart3 className="h-3.5 w-3.5" />}>
        <MiniBarChart data={buckets.map((b) => ({ day: b.label, value: b.delta }))} color="var(--cyan)" label={`bucket Δ · ${cfg.l}`} />
      </ThemedCard>
      <ThemedCard color="violet" title="METHODS" icon={<Sparkles className="h-3.5 w-3.5" />}>
        <div className="space-y-1.5">
          {Object.entries(methods).length === 0 && (
            <div className="font-mono text-[10px] text-foreground/45">No events yet — tap SEED below.</div>
          )}
          {Object.entries(methods).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => {
            const m = METHOD_META[k] ?? { label: k.toUpperCase(), color: "var(--cyan)", desc: "" };
            const max = Math.max(...Object.values(methods), 1);
            return (
              <div key={k}>
                <div className="flex justify-between font-mono text-[10px]">
                  <span style={{ color: m.color }}>{m.label}</span>
                  <span className="text-foreground/70">{v}</span>
                </div>
                <div className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-[color:var(--surface)]">
                  <div className="h-full rounded-full" style={{ width: `${(v / max) * 100}%`, background: m.color, boxShadow: `0 0 6px ${m.color}` }} />
                </div>
              </div>
            );
          })}
        </div>
      </ThemedCard>
      <div className="flex gap-1.5">
        <button onClick={onSeed} className="panel-cyber lift flex-1 px-3 py-2 font-display text-[10px] font-extrabold tracking-[0.2em]" style={{ ["--c" as any]: "var(--green)" }}>
          <Plus className="mr-1 inline h-3 w-3" /> SEED
        </button>
        <button onClick={() => {
          const blob = new Blob([kbGrowthTracker.export()], { type: "application/json" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url; a.download = `kb-growth-${Date.now()}.json`; a.click();
          URL.revokeObjectURL(url);
        }} className="panel-cyber lift flex-1 px-3 py-2 font-display text-[10px] font-extrabold tracking-[0.2em]" style={{ ["--c" as any]: "var(--cyan)" }}>
          <Download className="mr-1 inline h-3 w-3" /> EXPORT
        </button>
        <button onClick={() => { if (confirm("Clear?")) kbGrowthTracker.clear(); }} className="panel-cyber lift flex-1 px-3 py-2 font-display text-[10px] font-extrabold tracking-[0.2em]" style={{ ["--c" as any]: "var(--red)" }}>
          <Trash2 className="mr-1 inline h-3 w-3" /> CLEAR
        </button>
      </div>
    </>
  );
}

/* ─── INTEL (was /intel) ─── */
function IntelView({ t }: { t: ReturnType<typeof useTelemetry> }) {
  const cpu = Math.round(t.cpu ?? 0);
  const ram = Math.round(t.ram ?? 0);
  const disk = 47;
  const hist = t.history.length ? t.history : [12, 18, 14, 22, 26, 21, 30, 28, 34, 31, 38, 42, 36, 44, 48];
  return (
    <>
      <ThemedCard color="cyan" title="LIVE VITALS" icon={<Gauge className="h-3.5 w-3.5" />}>
        <div className="grid grid-cols-3 place-items-center gap-1">
          <CircRing label="CPU" pct={cpu} color="var(--cyan)" />
          <CircRing label="RAM" pct={ram} color="var(--orange)" />
          <CircRing label="DISK" pct={disk} color="var(--magenta)" />
        </div>
        <div className="mt-3 space-y-1.5">
          <DiskProgressBar label="CPU" pct={cpu} color="var(--cyan)" />
          <DiskProgressBar label="RAM" pct={ram} color="var(--orange)" />
          <DiskProgressBar label="DISK" pct={disk} color="var(--magenta)" />
        </div>
      </ThemedCard>
      <ThemedCard color="cyan" title="CPU LINE" icon={<Cpu className="h-3.5 w-3.5" />}>
        <MetricLineChart history={hist} color="var(--cyan)" label="cpu" />
      </ThemedCard>
      <ThemedCard color="violet" title="ACTIVITY · 12 BUCKETS" icon={<BarChart3 className="h-3.5 w-3.5" />}>
        <ActivityBarChart />
      </ThemedCard>
      <ThemedCard color="green" title="STORAGE" icon={<Database className="h-3.5 w-3.5" />}>
        <StorageDonut label="1.2TB" sub="USED" slices={[
          { color: "var(--cyan)", pct: 28, label: "SYS" },
          { color: "var(--orange)", pct: 22, label: "DATA" },
          { color: "var(--magenta)", pct: 14, label: "APPS" },
        ]} />
      </ThemedCard>
      <ThemedCard color="cyan" title="AREA SPARK" icon={<Activity className="h-3.5 w-3.5" />}>
        <AreaSparkline points={hist} color="var(--cyan)" height={64} />
      </ThemedCard>
    </>
  );
}

/* ─── NEXUSBOT ─── */
function NexusBotView() {
  const s = nexusBot.getState();
  const log = nexusBot.getLog().slice(0, 18);
  const snippets = nexusBot.getSnippets().slice(0, 6);
  const upMs = s.bootedAt ? Date.now() - s.bootedAt : 0;
  const upMin = Math.floor(upMs / 60000);
  const lastAgo = s.lastCycleAt ? Math.floor((Date.now() - s.lastCycleAt) / 1000) : null;

  const fire = async (kind: "sigma" | "omega" | "lambda" | "rss" | "once") => {
    const fn = kind === "sigma" ? nexusBot.runSigma
            : kind === "omega" ? nexusBot.runOmega
            : kind === "lambda" ? nexusBot.runLambda
            : kind === "rss"   ? nexusBot.runRSS
            : nexusBot.runOnce;
    const added = await fn.call(nexusBot);
    toast.success(`${kind.toUpperCase()} · +${added} findings`);
  };

  return (
    <>
      <ThemedCard color="violet" title="NEXUS BOT · AUTOPILOT" icon={<Bot className="h-3.5 w-3.5" />}
        action={
          <button
            onClick={() => { if (s.running) nexusBot.stop(); else nexusBot.start(); }}
            className="rounded-sm border border-[color:var(--border)] bg-[var(--ink)] px-2 py-0.5 font-mono text-[9px] tracking-widest"
            style={{ color: s.running ? "var(--green)" : "var(--orange)" }}>
            {s.running ? <><Pause className="mr-1 inline h-2.5 w-2.5" />RUNNING</> : <><Play className="mr-1 inline h-2.5 w-2.5" />PAUSED</>}
          </button>
        }>
        <div className="grid grid-cols-4 gap-2 font-mono text-[10px]">
          <div><div className="text-foreground/45">CYCLES</div><div className="font-display text-[16px] font-black text-foreground">{s.cycles}</div></div>
          <div><div className="text-foreground/45">FINDS</div><div className="font-display text-[16px] font-black text-[color:var(--green)]">{s.totalFindings}</div></div>
          <div><div className="text-foreground/45">FAIL</div><div className="font-display text-[16px] font-black text-[color:var(--orange)]">{s.totalFailed}</div></div>
          <div><div className="text-foreground/45">UP</div><div className="font-display text-[16px] font-black text-[color:var(--cyan)]">{upMin}m</div></div>
        </div>
        <div className="mt-2 font-mono text-[9px] tracking-widest text-foreground/50">
          {lastAgo == null ? "boot pending…" : `last cycle · ${lastAgo}s ago · cursor ${s.cursor}/${NEXUS_TARGETS.length}`}
        </div>
      </ThemedCard>

      <ThemedCard color="cyan" title="MANUAL TRIGGERS" icon={<Zap className="h-3.5 w-3.5" />}>
        <div className="grid grid-cols-5 gap-1.5">
          {(["sigma","omega","lambda","rss","once"] as const).map((k) => (
            <button key={k} onClick={() => void fire(k)}
              className="panel-cyber lift py-1.5 font-display text-[8.5px] font-extrabold tracking-[0.18em]"
              style={{ ["--c" as any]: k === "omega" ? "var(--magenta)" : k === "lambda" ? "var(--orange)" : k === "rss" ? "var(--green)" : "var(--cyan)" }}>
              {k === "sigma" ? "Σ" : k === "omega" ? "Ω" : k === "lambda" ? "λ" : k === "rss" ? "RSS" : "TICK"}
            </button>
          ))}
        </div>
        <div className="mt-1 font-mono text-[8.5px] tracking-widest text-foreground/40">
          ΣNET crawl · ΩLOOP expansion · λEDGE harvest · RSS delta · TICK = one cycle
        </div>
      </ThemedCard>

      <ThemedCard color="green" title={`LIVE BOT LOG · ${log.length}`} icon={<Radio className="h-3.5 w-3.5" />}>
        <div className="max-h-[36vh] space-y-1 overflow-y-auto pr-1">
          {log.length === 0 && <div className="font-mono text-[10px] text-foreground/45">Bot booting…</div>}
          {log.map((e, i) => (
            <BotLogRow key={i} e={e} />
          ))}
        </div>
      </ThemedCard>

      <ThemedCard color="amber" title={`RECENT HARVEST · ${snippets.length}`} icon={<BookOpen className="h-3.5 w-3.5" />}>
        <div className="space-y-1.5">
          {snippets.length === 0 && <div className="font-mono text-[10px] text-foreground/45">No snippets yet — trigger SIGMA above.</div>}
          {snippets.map((s, i) => (
            <div key={i} className="rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5">
              <div className="flex items-center justify-between font-display text-[9px] font-extrabold tracking-widest">
                <span className="text-[color:var(--cyan)]">{s.domain}/{s.topic}</span>
                <span className="text-foreground/45">{new Date(s.ts).toLocaleTimeString()}</span>
              </div>
              <div className="mt-0.5 font-mono text-[10px] text-foreground/80 line-clamp-2">{s.text}</div>
            </div>
          ))}
        </div>
      </ThemedCard>

      <button onClick={() => { if (confirm("Reset NEXUS BOT state?")) { nexusBot.reset(); toast.success("Bot reset"); } }}
        className="panel-cyber lift w-full px-3 py-2 font-display text-[10px] font-extrabold tracking-[0.22em]"
        style={{ ["--c" as any]: "var(--red)" }}>
        <RefreshCw className="mr-1 inline h-3 w-3" /> RESET BOT
      </button>
    </>
  );
}

function BotLogRow({ e }: { e: BotActivity }) {
  const color = e.type === "error" ? "var(--red)"
              : e.type === "omega" ? "var(--magenta)"
              : e.type === "lambda" ? "var(--orange)"
              : e.type === "rss"   ? "var(--green)"
              : e.type === "context" ? "var(--cyan)"
              : e.type === "boot"  ? "var(--foreground)"
              : "var(--cyan)";
  return (
    <div className="flex items-center justify-between rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="font-display text-[8.5px] font-extrabold tracking-widest" style={{ color }}>{e.type.toUpperCase()}</span>
          <span className="font-mono text-[8.5px] tracking-widest text-foreground/40">{new Date(e.ts).toLocaleTimeString()}</span>
        </div>
        <div className="truncate font-mono text-[10px] text-foreground/80">{e.msg}</div>
      </div>
      {e.added != null && <span className="font-display text-[12px] font-black text-[color:var(--green)]">+{e.added}</span>}
    </div>
  );
}

/* ─── CRAWLER (live NexusBot targets) ─── */
function CrawlerView() {
  const s = nexusBot.getState();
  return (
    <>
      <ThemedCard color="cyan" title="NEXUS CRAWLER" icon={<Globe className="h-3.5 w-3.5" />}
        action={
          <Link to="/knowledge" search={{ tab: "NEXUSBOT" }}
            className="rounded-sm border border-[color:var(--border)] bg-[var(--ink)] px-2 py-0.5 font-mono text-[9px] tracking-widest"
            style={{ color: s.running ? "var(--green)" : "var(--orange)" }}>
            {s.running ? "● BOT RUNNING" : "◌ BOT PAUSED"}
          </Link>
        }>
        <div className="grid grid-cols-4 gap-2 font-mono text-[10px]">
          <div><div className="text-foreground/45">TARGETS</div><div className="font-display text-[16px] font-black text-foreground">{NEXUS_TARGETS.length}</div></div>
          <div><div className="text-foreground/45">CRAWLED</div><div className="font-display text-[16px] font-black text-[color:var(--green)]">{s.totalCrawled}</div></div>
          <div><div className="text-foreground/45">FINDS</div><div className="font-display text-[16px] font-black text-[color:var(--cyan)]">{s.totalFindings}</div></div>
          <div><div className="text-foreground/45">FAIL</div><div className="font-display text-[16px] font-black text-[color:var(--orange)]">{s.totalFailed}</div></div>
        </div>
      </ThemedCard>
      <ThemedCard color="green" title={`ACTIVE TARGETS · ${NEXUS_TARGETS.length}`} icon={<Layers className="h-3.5 w-3.5" />}>
        <div className="max-h-[50vh] space-y-1 overflow-y-auto pr-1">
          {NEXUS_TARGETS.map((d, i) => {
            const active = (i % NEXUS_TARGETS.length) === s.cursor;
            const c = active ? "var(--green)" : "var(--cyan)";
            return (
              <div key={d.id} className="flex items-center justify-between rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5">
                <div className="min-w-0 flex-1">
                  <div className="truncate font-mono text-[10.5px] text-foreground/90">{d.domain} · {d.topic}</div>
                  <div className="truncate font-mono text-[8.5px] tracking-widest text-foreground/45">{d.url.replace(/^https?:\/\//, "")}</div>
                </div>
                <div className="ml-2 text-right">
                  <div className="font-display text-[9px] font-extrabold tracking-widest" style={{ color: c }}>{active ? "ACTIVE" : "QUEUED"}</div>
                  <div className="font-mono text-[8.5px] tracking-widest text-foreground/45">p{d.priority} · {(d.confidence * 100).toFixed(0)}%</div>
                </div>
              </div>
            );
          })}
        </div>
      </ThemedCard>
    </>
  );
}

/* ─── GRAPH ─── */
function GraphView() {
  return (
    <ThemedCard color="violet" title="NEURAL GRAPH" icon={<Network className="h-3.5 w-3.5" />}>
      <div className="relative h-64 overflow-hidden rounded border border-[color:var(--border)] bg-[var(--ink)]">
        <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full">
          {Array.from({ length: 36 }).map((_, i) => {
            const x = 10 + ((i * 23) % 180);
            const y = 10 + ((i * 47) % 180);
            return <circle key={i} cx={x} cy={y} r="2.5" fill="var(--magenta)"
              style={{ filter: "drop-shadow(0 0 4px var(--magenta))" }}>
              <animate attributeName="r" values="2;3.5;2" dur={`${2 + (i % 4) * 0.3}s`} repeatCount="indefinite" />
            </circle>;
          })}
          {Array.from({ length: 28 }).map((_, i) => {
            const x1 = 10 + ((i * 23) % 180), y1 = 10 + ((i * 47) % 180);
            const x2 = 10 + (((i + 3) * 23) % 180), y2 = 10 + (((i + 3) * 47) % 180);
            return <line key={`l${i}`} x1={x1} y1={y1} x2={x2} y2={y2}
              stroke="var(--cyan)" strokeOpacity="0.3" strokeWidth="0.5" />;
          })}
        </svg>
      </div>
      <div className="mt-1.5 flex justify-between font-mono text-[9px] tracking-widest text-foreground/55">
        <span>NODES · 1,284</span><span>EDGES · 3,917</span><span>COMM · 18</span>
      </div>
    </ThemedCard>
  );
}

/* ─── SOURCES ─── */
function SourcesView() {
  return (
    <ThemedCard color="cyan" title="TOP SOURCES · CONFIDENCE" icon={<Globe className="h-3.5 w-3.5" />}>
      <div className="space-y-2">
        {SOURCES.map((s) => {
          const c = s.color === "violet" ? "var(--magenta)" : s.color === "amber" ? "var(--orange)" : `var(--${s.color})`;
          return (
            <div key={s.name}>
              <div className="flex justify-between font-mono text-[10px]">
                <span className="text-foreground/80">{s.name}</span>
                <span style={{ color: c }}>{s.pct}%</span>
              </div>
              <div className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-[color:var(--surface)]">
                <div className="h-full rounded-full" style={{ width: `${s.pct}%`, background: c, boxShadow: `0 0 8px ${c}` }} />
              </div>
            </div>
          );
        })}
      </div>
    </ThemedCard>
  );
}

/* ─── L-SCAN (threat heatmap) ─── */
function LScanView() {
  return (
    <>
      <ThemedCard color="red" title="THREAT HEATMAP" icon={<ShieldAlert className="h-3.5 w-3.5" />}>
        <ThreatHeatmap />
      </ThemedCard>
      <ThemedCard color="amber" title="CATEGORY RISK" icon={<Layers className="h-3.5 w-3.5" />}>
        <div className="space-y-2">
          {[
            { label: "SECURITY", color: "var(--red)",     pct: 82 },
            { label: "FILES",    color: "var(--green)",   pct: 68 },
            { label: "NETWORK",  color: "var(--orange)",  pct: 55 },
            { label: "PRIVACY",  color: "var(--magenta)", pct: 44 },
            { label: "SYSTEM",   color: "var(--cyan)",    pct: 31 },
          ].map((c) => (
            <div key={c.label}>
              <div className="flex justify-between font-mono text-[10px]">
                <span className="text-foreground/80">{c.label}</span>
                <span style={{ color: c.color }}>{c.pct}%</span>
              </div>
              <div className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-[color:var(--surface)]">
                <div className="h-full rounded-full" style={{ width: `${c.pct}%`, background: c.color, boxShadow: `0 0 8px ${c.color}` }} />
              </div>
            </div>
          ))}
        </div>
      </ThemedCard>
    </>
  );
}

/* ─── SEARCH ─── */
function SearchView() {
  const [q, setQ] = useState("");
  const HITS = ["asyncio gather pattern", "regex windows path", "CVE-2026-1142 mitigation", "systemd-resolved DNS", "PEP-704 type guards", "Fetch API streaming"];
  const filtered = q ? HITS.filter((h) => h.toLowerCase().includes(q.toLowerCase())) : HITS;
  return (
    <>
      <ThemedCard color="cyan" title="ASK THE KB" icon={<Search className="h-3.5 w-3.5" />}>
        <div className="flex items-center gap-2 rounded-md border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5">
          <Search className="h-3.5 w-3.5 text-foreground/40" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ask the knowledge base…"
            className="flex-1 bg-transparent font-mono text-[11px] text-foreground placeholder:text-foreground/30 focus:outline-none"
          />
          <kbd className="font-mono text-[9px] tracking-widest text-foreground/40">⏎</kbd>
        </div>
      </ThemedCard>
      <ThemedCard color="green" title={`HITS · ${filtered.length}`} icon={<BookOpen className="h-3.5 w-3.5" />}>
        <div className="space-y-1">
          {filtered.map((h, i) => (
            <Link key={i} to="/ai" className="block rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5 font-mono text-[10.5px] text-foreground/85 hover:border-[color:var(--cyan)] hover:text-[color:var(--cyan)]">
              {h}
            </Link>
          ))}
        </div>
      </ThemedCard>
    </>
  );
}

/* ─── EVENTS ─── */
function EventsView() {
  const events = kbGrowthTracker.getRecentEvents(40);
  return (
    <ThemedCard color="amber" title={`EVENT LOG · ${events.length}`} icon={<Clock className="h-3.5 w-3.5" />}>
      <div className="max-h-[60vh] space-y-1 overflow-y-auto pr-1">
        {events.length === 0 && <div className="font-mono text-[10px] text-foreground/45">No events recorded yet. Run the crawler or seed from Growth tab.</div>}
        {events.map((e, i) => {
          const m = METHOD_META[e.method] ?? { label: e.method, color: "var(--cyan)", desc: "" };
          return (
            <div key={i} className="flex items-center justify-between rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="font-display text-[9px] font-extrabold tracking-widest" style={{ color: m.color }}>{m.label}</span>
                  {e.domain && <span className="font-mono text-[9px] tracking-widest text-foreground/55">· {e.domain}</span>}
                </div>
                <div className="font-mono text-[8.5px] tracking-widest text-foreground/40">{new Date(e.ts).toLocaleString()}</div>
              </div>
              <span className="font-display text-[14px] font-black text-[color:var(--green)]">+{e.count}</span>
            </div>
          );
        })}
      </div>
    </ThemedCard>
  );
}
