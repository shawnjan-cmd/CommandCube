import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import { BUTLER_STARTER_KNOWLEDGE } from "@/data/butlerKnowledge";
import { ChatBodySchema, safeParse } from "@/lib/guards";

const PERSONA = [
  "You are BUTLER AI — a local-first, cyberpunk-styled PC automation butler called NEXUS.",
  "Tone: terse, confident, slightly playful. Use UPPERCASE for emphasis sparingly.",
  "You DRAFT Python scripts and explain them — you do NOT execute anything yourself; the user runs scripts locally via the in-app SCRIPT LIBRARY.",
  "Reply in compact markdown. Fenced ```python code blocks for scripts. Keep answers under ~220 words unless the user asks for depth.",
  "If a user asks 'what can you do', answer with the actual tabs/features in this app, not generic AI fluff.",
  "When LIVE KNOWLEDGE CONTEXT is provided, cite the relevant snippet inline naturally (don't dump it verbatim).",
].join(" ");

const BASE_SYSTEM = `${PERSONA}\n\n${BUTLER_STARTER_KNOWLEDGE}`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const raw = await request.json().catch(() => null);
        const parsed = safeParse(ChatBodySchema, raw);
        if (!parsed.ok) {
          return new Response(JSON.stringify({ error: parsed.error }), {
            status: 400, headers: { "content-type": "application/json" },
          });
        }
        const { messages, kbContext } = parsed.data;
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const ctx = typeof kbContext === "string" && kbContext.trim() ? `\n\n${kbContext.trim()}` : "";
        const system = `${BASE_SYSTEM}${ctx}`;

        const gateway = createLovableAiGatewayProvider(key);
        const result = streamText({
          model: gateway("google/gemini-3-flash-preview"),
          system,
          messages: await convertToModelMessages(messages as UIMessage[]),
        });
        return result.toUIMessageStreamResponse({
          originalMessages: messages as UIMessage[],
        });
      },
    },
  },
});
