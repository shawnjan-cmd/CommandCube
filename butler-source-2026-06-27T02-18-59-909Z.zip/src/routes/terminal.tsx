import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Terminal as TerminalIcon, ChevronRight } from "lucide-react";
import { AppShell, PageHeader, SectionTitle } from "@/components/AppShell";

export const Route = createFileRoute("/terminal")({
  head: () => ({
    meta: [
      { title: "Butler AI — Terminal" },
      { name: "description", content: "Signed shell over your LAN. Every command HMAC-verified." },
    ],
  }),
  component: TerminalPage,
});

type Line = { who: "out" | "in" | "err"; text: string };

function TerminalPage() {
  const [lines, setLines] = useState<Line[]>([
    { who: "out", text: "butler-shell v1.0 — signed channel established" },
    { who: "out", text: 'type "help" for available commands' },
  ]);
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "auto" }); }, [lines]);

  const exec = (cmd: string) => {
    const c = cmd.trim();
    if (!c) return;
    const out: Line[] = [{ who: "in", text: c }];
    if (c === "help") out.push({ who: "out", text: "commands: help, whoami, uptime, ls, ping <host>, clear" });
    else if (c === "clear") { setLines([]); setInput(""); return; }
    else if (c === "whoami") out.push({ who: "out", text: "operator@butler-pc" });
    else if (c === "uptime") out.push({ who: "out", text: "up 3 days, 14:22, load 0.42 0.38 0.31" });
    else if (c === "ls") out.push({ who: "out", text: "Documents  Downloads  Scripts  butler.log" });
    else if (c.startsWith("ping ")) out.push({ who: "out", text: `64 bytes from ${c.slice(5)}: time=1.2 ms` });
    else out.push({ who: "err", text: `butler: command not found: ${c}` });
    setLines((l) => [...l, ...out]);
    setInput("");
  };

  return (
    <AppShell active="term">
      <PageHeader title="TERMINAL" sub="SIGNED · LAN-ONLY" color="green" />
      <section className="panel-cyber space-y-2 p-3 glow-green">
        <SectionTitle icon={<TerminalIcon className="h-4 w-4" />} color="green" label="SHELL" />
        <div className="max-h-[60vh] overflow-y-auto rounded-md border border-green/20 bg-black p-2 font-mono text-[12px] leading-relaxed">
          {lines.map((l, i) => (
            <div key={i} className={l.who === "in" ? "text-cyan" : l.who === "err" ? "text-red-400" : "text-green"}>
              {l.who === "in" ? <span className="text-foreground/40">$ </span> : null}{l.text}
            </div>
          ))}
          <div ref={endRef} />
        </div>
        <form
          onSubmit={(e) => { e.preventDefault(); exec(input); }}
          className="flex items-center gap-2 rounded-md border border-green/30 bg-black/60 px-2"
        >
          <ChevronRight className="h-3.5 w-3.5 text-green" />
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="enter command…"
            autoFocus
            className="flex-1 bg-transparent py-2 font-mono text-[12px] text-green outline-none placeholder:text-foreground/30"
          />
        </form>
      </section>
    </AppShell>
  );
}
