import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Settings as SettingsIcon, Power, ShieldCheck, Bell, Wifi, Brain, Database,
  Trash2, FileLock2, Lock, Activity, Eye, ChevronRight, Search, Plug, PlugZap,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";
import { JsonImporter } from "@/components/JsonImporter";
import { useServerLink } from "@/hooks/useServerLink";
import { serverLink } from "@/lib/serverLink";
import { toast } from "sonner";



export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings — Butler AI" }] }),
  component: SettingsPage,
});

function Toggle({ on, onChange }: { on: boolean; onChange: () => void }) {
  return (
    <button
      onClick={onChange}
      role="switch"
      aria-checked={on}
      className="relative h-6 w-11 shrink-0 rounded-full border border-[color:var(--border)] transition"
      style={{ background: on ? "color-mix(in oklab, var(--cyan) 28%, transparent)" : "var(--ink)" }}
    >
      <span
        className="absolute top-0.5 h-4 w-4 rounded-full transition-all"
        style={{
          left: on ? "22px" : "4px",
          background: on ? "var(--cyan)" : "var(--muted-foreground, #5b6172)",
          boxShadow: on ? "0 0 10px var(--cyan)" : "none",
        }}
      />
    </button>
  );
}

function ToggleRow({ icon, title, sub, init = false }: { icon: React.ReactNode; title: string; sub: string; init?: boolean }) {
  const [on, setOn] = useState(init);
  return (
    <li className="flex items-center gap-2.5 py-2">
      <span className="grid h-8 w-8 place-items-center rounded border border-[color:var(--border)] bg-[var(--ink)] text-cyan">{icon}</span>
      <div className="min-w-0 flex-1">
        <div className="font-display text-[11px] font-extrabold tracking-[0.18em] text-foreground/90">{title}</div>
        <div className="font-mono text-[9px] tracking-widest text-foreground/45">{sub}</div>
      </div>
      <Toggle on={on} onChange={() => setOn(v => !v)} />
    </li>
  );
}

function LinkRow({ icon, title, sub, to }: { icon: React.ReactNode; title: string; sub: string; to: string }) {
  return (
    <li>
      <Link to={to as any} className="flex items-center gap-2.5 py-2">
        <span className="grid h-8 w-8 place-items-center rounded border border-[color:var(--border)] bg-[var(--ink)] text-cyan">{icon}</span>
        <div className="min-w-0 flex-1">
          <div className="font-display text-[11px] font-extrabold tracking-[0.18em] text-foreground/90">{title}</div>
          <div className="font-mono text-[9px] tracking-widest text-foreground/45">{sub}</div>
        </div>
        <ChevronRight className="h-3.5 w-3.5 text-foreground/40" />
      </Link>
    </li>
  );
}

function SettingsPage() {
  return (
    <AppShell active="settings">
      <PageTitle kicker="SYSTEM · v7.4" title="SETTINGS" sub="ONBOARDING · PRIVACY · POWER" color="cyan" />

      <div className="mt-3">
        <ThemedCard color="cyan" title="ONBOARDING" icon={<SettingsIcon className="h-3.5 w-3.5" />}>
          <ul className="divide-y divide-[color:var(--border)]">
            <LinkRow icon={<Eye className="h-3.5 w-3.5" />} title="REPLAY INTRO TOUR" sub="step through onboarding again" to="/" />
            <ToggleRow icon={<Activity className="h-3.5 w-3.5" />} title="SHOW WELCOME" sub="display welcome card on launch" init />
            <ToggleRow icon={<ShieldCheck className="h-3.5 w-3.5" />} title="RESET ALL CONSENTS" sub="re-prompt every legal sign" />
          </ul>
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ServerLinkCard />
      </div>

      <div className="mt-2.5">
        <ThemedCard color="green" title="CONNECTION · BEHAVIOR" icon={<Wifi className="h-3.5 w-3.5" />}>
          <ul className="divide-y divide-[color:var(--border)]">
            <ToggleRow icon={<Wifi className="h-3.5 w-3.5" />} title="AUTO-CONNECT" sub="discover PC on LAN at launch" init />
            <ToggleRow icon={<Activity className="h-3.5 w-3.5" />} title="AUTO-RUN" sub="run scripts without confirm prompt" />
            <ToggleRow icon={<Bell className="h-3.5 w-3.5" />} title="NOTIFICATIONS" sub="push results to system tray" init />
            <ToggleRow icon={<Lock className="h-3.5 w-3.5" />} title="REQUIRE AUTH" sub="biometric before script dispatch" init />
          </ul>
        </ThemedCard>
      </div>


      <div className="mt-2.5">
        <ThemedCard color="violet" title="LOCAL AI · OLLAMA" icon={<Brain className="h-3.5 w-3.5" />}>
          <div className="font-mono text-[11px] leading-relaxed text-foreground/80">
            <div className="flex items-center justify-between">
              <span>Status</span>
              <span className="font-display text-[10px] font-extrabold tracking-[0.18em] text-[color:var(--green)]">● RUNNING</span>
            </div>
            <div className="mt-1 flex items-center justify-between">
              <span>Active model</span>
              <span className="text-[color:var(--magenta)]">llama3.1:8b</span>
            </div>
            <div className="mt-1 flex items-center justify-between">
              <span>Pulled</span>
              <span className="text-foreground/60">4 models · 18.2 GB</span>
            </div>
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {["llama3.1:8b", "qwen2.5:7b", "phi3:mini", "codellama:13b"].map((m) => (
              <span key={m} className="panel-cyber px-2 py-1 font-mono text-[9px] tracking-widest text-foreground/80"
                    style={{ ["--c" as any]: "var(--magenta)" }}>{m}</span>
            ))}
          </div>
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ThemedCard color="amber" title="PC POWER" icon={<Power className="h-3.5 w-3.5" />}>
          <div className="grid grid-cols-3 gap-1.5">
            {["SLEEP", "RESTART", "SHUTDOWN"].map((p) => (
              <button key={p}
                className="panel-cyber lift py-2 font-display text-[10px] font-extrabold tracking-[0.2em] text-[color:var(--orange)]"
                style={{ ["--c" as any]: "var(--orange)" }}>{p}</button>
            ))}
          </div>
          <div className="mt-2 font-mono text-[9px] tracking-widest text-foreground/45">requires confirmation</div>
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ThemedCard color="cyan" title="PRIVACY · LEGAL" icon={<FileLock2 className="h-3.5 w-3.5" />}>
          <ul className="divide-y divide-[color:var(--border)]">
            <LinkRow icon={<FileLock2 className="h-3.5 w-3.5" />} title="PRIVACY POLICY" sub="what we collect (nothing)"   to="/legal/privacy" />
            <LinkRow icon={<ShieldCheck className="h-3.5 w-3.5" />} title="TERMS OF SERVICE" sub="rules of engagement"        to="/legal/terms" />
            <LinkRow icon={<Database className="h-3.5 w-3.5" />} title="DATA SAFETY" sub="zero-cloud architecture"        to="/legal/safety" />
            <LinkRow icon={<Trash2 className="h-3.5 w-3.5" />} title="DELETE MY DATA" sub="wipe everything locally"      to="/legal/delete" />
          </ul>
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ThemedCard color="cyan" title="MASTER JSON" icon={<Database className="h-3.5 w-3.5" />}>
          <p className="mb-2 font-mono text-[10.5px] leading-relaxed text-foreground/70">
            Import a Butler master export (e.g. <span className="text-cyan">butler_master_v8_0_complete.json</span>) to inspect bundled files & metadata. Runs entirely on-device.
          </p>
          <JsonImporter />
        </ThemedCard>
      </div>

      <div className="mt-2.5">
        <ThemedCard color="red" title="DANGER ZONE" icon={<Trash2 className="h-3.5 w-3.5" />}>
          <button className="panel-cyber lift w-full py-2 font-display text-[10px] font-extrabold tracking-[0.22em] text-[color:var(--red)]"
                  style={{ ["--c" as any]: "var(--red)" }}>
            CLEAR APP CACHE · LOGS · KB
          </button>
        </ThemedCard>
      </div>


      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        BUTLER AI · v7.4 · LOCAL-FIRST
      </div>
    </AppShell>
  );
}

function ServerLinkCard() {
  const link = useServerLink();
  const [ip, setIp] = useState(link.ip || "127.0.0.1");
  const [port, setPort] = useState(link.port || "8765");
  const [busy, setBusy] = useState(false);

  const connected = link.status === "connected";
  const statusColor = connected ? "var(--green)" : link.status === "discovering" || link.status === "connecting" ? "var(--orange)" : "var(--red)";
  const statusLabel = connected ? "● LINKED" : link.status === "discovering" ? "● SCANNING" : link.status === "connecting" ? "● PROBING" : "○ OFFLINE";

  const onConnect = async () => {
    setBusy(true);
    const ok = await serverLink.connect(ip, port);
    setBusy(false);
    toast[ok ? "success" : "error"](ok ? `Linked ${ip}:${port} · ${link.latencyMs ?? "?"}ms` : `No response from ${ip}:${port}`);
  };
  const onDiscover = async () => {
    setBusy(true);
    const ok = await serverLink.autoDiscover();
    setBusy(false);
    toast[ok ? "success" : "warning"](ok ? "PC server discovered" : "No host answered — set IP manually");
  };

  return (
    <ThemedCard color="green" title="SERVER LINK · PC BRIDGE" icon={<PlugZap className="h-3.5 w-3.5" />}>
      <div className="flex items-center justify-between">
        <div className="font-mono text-[11px] text-foreground/80">
          Host
          <span className="ml-2 text-foreground/55">{link.ip || "—"}:{link.port || "—"}</span>
        </div>
        <span className="font-display text-[10px] font-extrabold tracking-[0.18em]" style={{ color: statusColor }}>
          {statusLabel}
        </span>
      </div>
      <div className="mt-1 font-mono text-[10px] text-foreground/55">
        latency {link.latencyMs != null ? `${link.latencyMs}ms` : "—"}
        {link.lastOkAt ? ` · last ok ${new Date(link.lastOkAt).toLocaleTimeString()}` : ""}
      </div>

      <div className="mt-2 grid grid-cols-[1fr_88px] gap-1.5">
        <input
          value={ip}
          onChange={(e) => setIp(e.target.value)}
          placeholder="192.168.1.x"
          className="rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5 font-mono text-[12px] text-foreground outline-none focus:border-[color:var(--green)]"
        />
        <input
          value={port}
          onChange={(e) => setPort(e.target.value)}
          placeholder="8765"
          className="rounded border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5 font-mono text-[12px] text-foreground outline-none focus:border-[color:var(--green)]"
        />
      </div>

      <div className="mt-2 grid grid-cols-3 gap-1.5">
        <button
          disabled={busy}
          onClick={onConnect}
          className="panel-cyber lift flex items-center justify-center gap-1 py-1.5 font-display text-[10px] font-extrabold tracking-[0.18em] text-[color:var(--green)] disabled:opacity-50"
          style={{ ["--c" as any]: "var(--green)" }}
        >
          <Plug className="h-3 w-3" /> CONNECT
        </button>
        <button
          disabled={busy}
          onClick={onDiscover}
          className="panel-cyber lift flex items-center justify-center gap-1 py-1.5 font-display text-[10px] font-extrabold tracking-[0.18em] text-[color:var(--cyan)] disabled:opacity-50"
          style={{ ["--c" as any]: "var(--cyan)" }}
        >
          <Search className="h-3 w-3" /> SCAN
        </button>
        <button
          disabled={busy || !connected}
          onClick={() => { serverLink.disconnect(); toast("Disconnected"); }}
          className="panel-cyber lift flex items-center justify-center gap-1 py-1.5 font-display text-[10px] font-extrabold tracking-[0.18em] text-[color:var(--red)] disabled:opacity-40"
          style={{ ["--c" as any]: "var(--red)" }}
        >
          <Power className="h-3 w-3" /> DROP
        </button>
      </div>

      <div className="mt-2 font-mono text-[9px] tracking-widest text-foreground/45">
        probes /api/status · /health · /status — works with Butler server & Ollama (port 11434).
      </div>
    </ThemedCard>
  );
}

