import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Plug, LayoutGrid, BookOpen, TerminalSquare, Folder, Bot,
  Sparkles, Brain, Workflow, Antenna, Settings,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ConnectionTab } from "@/components/nexus/tabs/ConnectionTab";
import { DashboardTab } from "@/components/nexus/tabs/DashboardTab";
import { KbTab } from "@/components/nexus/tabs/KbTab";
import { FilesTab } from "@/components/nexus/tabs/FilesTab";
import { SettingsTab } from "@/components/nexus/tabs/SettingsTab";
import { PlaceholderTab } from "@/components/nexus/tabs/PlaceholderTab";
import { AiChatTab } from "@/components/nexus/tabs/AiChatTab";

export const Route = createFileRoute("/nexus")({
  head: () => ({
    meta: [
      { title: "NEXUS · Command Center — Butler AI" },
      { name: "description", content: "Full Nexus cyberpunk command center: dashboards, AI chat, KB graph, files, terminal, and settings." },
    ],
  }),
  component: NexusPage,
});

type TabId =
  | "connection" | "dashboard" | "scripts" | "terminal" | "files" | "aichat"
  | "builder" | "kb" | "flows" | "network" | "settings";

const TABS: { id: TabId; label: string; Icon: LucideIcon }[] = [
  { id: "connection", label: "CONN",   Icon: Plug },
  { id: "dashboard",  label: "DASH",   Icon: LayoutGrid },
  { id: "scripts",    label: "SCRIPT", Icon: BookOpen },
  { id: "terminal",   label: "TERM",   Icon: TerminalSquare },
  { id: "files",      label: "FILES",  Icon: Folder },
  { id: "aichat",     label: "AI",     Icon: Bot },
  { id: "builder",    label: "BUILD",  Icon: Sparkles },
  { id: "kb",         label: "KB",     Icon: Brain },
  { id: "flows",      label: "FLOWS",  Icon: Workflow },
  { id: "network",    label: "NET",    Icon: Antenna },
  { id: "settings",   label: "CFG",    Icon: Settings },
];

function NexusPage() {
  const [tab, setTab] = useState<TabId>("dashboard");

  const view = (() => {
    switch (tab) {
      case "connection": return <ConnectionTab />;
      case "dashboard":  return <DashboardTab />;
      case "kb":         return <KbTab />;
      case "files":
      case "terminal":   return <FilesTab />;
      case "settings":   return <SettingsTab />;
      case "aichat":     return <AiChatTab />;
      case "scripts":    return <PlaceholderTab title="SCRIPTS" desc="Library of executable Python automations. Pair an agent to populate." />;
      case "builder":    return <PlaceholderTab title="WIDGET BUILDER" desc="Drag, snap and deploy custom telemetry widgets to your home screen." />;
      case "flows":      return <PlaceholderTab title="FLOWS" desc="Node-graph automations linking triggers, scripts and AI actions." />;
      case "network":    return <PlaceholderTab title="NETWORK" desc="LAN topology, port maps, and live packet telemetry." />;
    }
  })();

  return (
    <AppShell>
      <div className="mb-2 -mx-1 overflow-x-auto no-scrollbar">
        <div className="flex gap-1 px-1 pb-1 min-w-min">
          {TABS.map(({ id, label, Icon }) => {
            const active = id === tab;
            return (
              <button key={id} onClick={() => setTab(id)}
                className={`shrink-0 flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-lg min-w-[52px] transition pressable ${
                  active ? "bg-primary/10 border border-primary/40" : "border border-transparent"
                }`}
                style={active ? { boxShadow: "0 0 12px hsl(187 100% 50% / .35)" } : undefined}
              >
                <Icon className={`w-[18px] h-[18px] ${active ? "text-primary" : "text-muted-foreground"}`}
                      style={active ? { filter: "drop-shadow(0 0 6px hsl(187 100% 50% / .8))" } : undefined}
                      strokeWidth={1.8} />
                <span className={`font-mono text-[0.5rem] font-bold tracking-wider ${active ? "text-primary" : "text-muted-foreground"}`}>{label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {tab === "connection" && (
        <div className="fixed inset-0 abyss-bg -z-10" aria-hidden />
      )}

      {view}
    </AppShell>
  );
}
