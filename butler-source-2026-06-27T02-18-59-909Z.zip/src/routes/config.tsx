import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Settings as SettingsIcon, ShieldCheck, Trash2, Server, Bell, Moon, Database } from "lucide-react";
import { AppShell, PageHeader, SectionTitle } from "@/components/AppShell";
import { toast } from "sonner";

export const Route = createFileRoute("/config")({
  head: () => ({
    meta: [
      { title: "Butler AI — Config" },
      { name: "description", content: "Tune Butler. Notifications, theme, data, and pairing controls." },
    ],
  }),
  component: ConfigPage,
});

function ConfigPage() {
  const [notif, setNotif] = useState(true);
  const [haptics, setHaptics] = useState(true);
  const [sound, setSound] = useState(true);
  const [paired, setPaired] = useState<string | null>(null);

  useEffect(() => {
    try {
      const p = JSON.parse(localStorage.getItem("butler_paired_session_v1") || "null");
      if (p?.ip) setPaired(`${p.ip}:${p.port}`);
    } catch { /* noop */ }
  }, []);

  const clearAll = () => {
    localStorage.clear();
    toast.success("Local data cleared", { description: "Pairing + onboarding state reset." });
    setPaired(null);
  };

  return (
    <AppShell active="cfg">
      <PageHeader title="CONFIG" sub="DEVICE PREFERENCES" color="cyan" />

      <section className="panel-cyber space-y-2 p-3 glow-cyan">
        <SectionTitle icon={<Server className="h-4 w-4" />} color="cyan" label="PAIRING" />
        <Row label="Paired host" value={paired || "— none —"} />
        <Link
          to="/home"
          className="block rounded-md border border-cyan/50 bg-cyan/10 px-3 py-2 text-center font-mono text-[11px] font-extrabold tracking-widest text-cyan hover:bg-cyan/20"
        >
          MANAGE ON HOME
        </Link>
      </section>

      <section className="panel-cyber space-y-2 p-3 glow-magenta">
        <SectionTitle icon={<Bell className="h-4 w-4" />} color="magenta" label="FEEDBACK" />
        <Toggle label="Notifications" icon={<Bell className="h-3.5 w-3.5" />} on={notif} onChange={setNotif} />
        <Toggle label="Haptics" icon={<SettingsIcon className="h-3.5 w-3.5" />} on={haptics} onChange={setHaptics} />
        <Toggle label="Sound effects" icon={<Moon className="h-3.5 w-3.5" />} on={sound} onChange={setSound} />
      </section>

      <section className="panel-cyber space-y-2 p-3 glow-green">
        <SectionTitle icon={<ShieldCheck className="h-4 w-4" />} color="green" label="PRIVACY" />
        <Row label="Telemetry" value="OFF · always" />
        <Row label="Cloud sync" value="DISABLED" />
        <Row label="Encryption" value="HMAC-SHA256" />
      </section>

      <section className="panel-cyber space-y-2 p-3 glow-orange">
        <SectionTitle icon={<Database className="h-4 w-4" />} color="orange" label="DATA" />
        <button
          onClick={clearAll}
          className="flex w-full items-center justify-center gap-2 rounded-md border border-red-500/50 bg-red-500/10 px-3 py-2 font-mono text-[11px] font-extrabold tracking-widest text-red-400 hover:bg-red-500/20"
        >
          <Trash2 className="h-3.5 w-3.5" /> CLEAR ALL LOCAL DATA
        </button>
      </section>

      <section className="panel-cyber space-y-2 p-3">
        <SectionTitle icon={<SettingsIcon className="h-4 w-4" />} color="cyan" label="LEGAL" />
        <div className="grid grid-cols-2 gap-2">
          <Link to="/legal/privacy" className="rounded-md border border-foreground/15 px-3 py-2 text-center font-mono text-[10px] tracking-widest text-foreground/80 hover:bg-foreground/5">PRIVACY</Link>
          <Link to="/legal/terms" className="rounded-md border border-foreground/15 px-3 py-2 text-center font-mono text-[10px] tracking-widest text-foreground/80 hover:bg-foreground/5">TERMS</Link>
          <Link to="/legal/safety" className="rounded-md border border-foreground/15 px-3 py-2 text-center font-mono text-[10px] tracking-widest text-foreground/80 hover:bg-foreground/5">SAFETY</Link>
          <Link to="/legal/delete" className="rounded-md border border-foreground/15 px-3 py-2 text-center font-mono text-[10px] tracking-widest text-foreground/80 hover:bg-foreground/5">DELETE DATA</Link>
        </div>
      </section>
    </AppShell>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-foreground/10 bg-background/40 px-2 py-1.5">
      <span className="font-mono text-[10px] tracking-widest text-foreground/70">{label}</span>
      <span className="font-mono text-[10px] font-extrabold tracking-widest text-foreground">{value}</span>
    </div>
  );
}

function Toggle({ label, icon, on, onChange }: { label: string; icon: React.ReactNode; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className="flex w-full items-center justify-between rounded-md border border-foreground/10 bg-background/40 px-2 py-1.5"
    >
      <span className="flex items-center gap-2 font-mono text-[11px] tracking-widest text-foreground/80">{icon} {label}</span>
      <span className={`h-4 w-8 rounded-full p-0.5 transition ${on ? "bg-cyan/40" : "bg-foreground/15"}`}>
        <span className={`block h-3 w-3 rounded-full bg-cyan transition ${on ? "translate-x-4" : ""}`} />
      </span>
    </button>
  );
}
