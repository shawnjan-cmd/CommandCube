import { createFileRoute } from "@tanstack/react-router";
import { LegalShell, LegalSection } from "@/components/LegalShell";

export const Route = createFileRoute("/legal/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Butler AI" },
      { name: "description", content: "Zero data collection. No cloud servers. LAN-only operation. Open-source server." },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <LegalShell
      title="Privacy Policy"
      accent="cyan"
      emoji="🔒"
      headline="Butler AI Automation · Android App · Effective April 1, 2026"
      badges={[
        { label: "ZERO DATA COLLECTION", tone: "green" },
        { label: "NO CLOUD SERVERS",     tone: "green" },
        { label: "LAN ONLY",             tone: "cyan"  },
        { label: "NO ACCOUNTS",          tone: "cyan"  },
        { label: "CAMERA: QR SCAN ONLY", tone: "orange"},
        { label: "OPEN SOURCE SERVER",   tone: "cyan"  },
      ]}
    >
      <LegalSection title="01 · SUMMARY" tone="green">
        <p>Butler AI is a self-hosted remote PC controller. The Android app talks to a Python server running on <em>your own</em> PC over your local Wi-Fi.</p>
        <p>We collect <strong>zero personal data</strong>. There are no servers we run, no telemetry, no analytics, no ads, no accounts, and no cloud relay of any kind.</p>
      </LegalSection>

      <LegalSection title="02 · WHAT IS STORED LOCALLY" tone="cyan">
        <ul className="list-disc space-y-1 pl-5">
          <li><strong>Device UUID</strong> — a random identifier generated on first launch, used only to remember your paired PC. Never leaves the device.</li>
          <li><strong>Pairing secret</strong> — HMAC-SHA256 shared key set during setup. Stored in Android Keystore.</li>
          <li><strong>Server IP / LAN address</strong> — so we can reconnect to your PC.</li>
          <li><strong>UI preferences</strong> — theme, language, layout.</li>
        </ul>
      </LegalSection>

      <LegalSection title="03 · WHAT WE NEVER COLLECT" tone="orange">
        <ul className="list-disc space-y-1 pl-5">
          <li>Names, emails, phone numbers, addresses, payment info.</li>
          <li>Contacts, calendar, SMS, call logs, browser history.</li>
          <li>Location (precise or coarse).</li>
          <li>Script source, script outputs, file names, or any PC content.</li>
          <li>Photos, videos, microphone audio, or biometric data.</li>
          <li>Crash reports or analytics events.</li>
        </ul>
      </LegalSection>

      <LegalSection title="04 · CAMERA" tone="orange">
        <p>The camera is used <strong>only</strong> to scan a one-time pairing QR code shown on your PC. The frame buffer is never recorded, never written to disk, and never transmitted. You can pair manually by typing the IP instead.</p>
      </LegalSection>

      <LegalSection title="05 · NETWORK" tone="cyan">
        <p>The app communicates exclusively with your own PC over your local Wi-Fi (e.g. <code>192.168.x.x</code>). It does not contact any other host. Every request is signed with HMAC-SHA256 and rejected on tamper or replay.</p>
      </LegalSection>

      <LegalSection title="06 · YOUR RIGHTS" tone="green">
        <p>You can wipe everything at any time via <strong>Settings → DELETE ALL MY DATA</strong>. There is no cloud backup to request, export, or delete — there is no cloud.</p>
      </LegalSection>

      <LegalSection title="07 · CONTACT" tone="cyan">
        <p>Source: <a className="text-cyan underline" href="https://github.com/shawnjan-cmd/CommandCube" target="_blank" rel="noreferrer">github.com/shawnjan-cmd/CommandCube</a></p>
      </LegalSection>
    </LegalShell>
  );
}
