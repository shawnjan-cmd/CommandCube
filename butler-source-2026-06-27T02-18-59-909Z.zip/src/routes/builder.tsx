import { createFileRoute } from "@tanstack/react-router";
import { Wrench, Zap, ArrowRight, Play, Plus, Bell, Clock, Cpu, HardDrive, FileText, Send, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";

export const Route = createFileRoute("/builder")({
  head: () => ({ meta: [{ title: "Script Builder — Butler AI" }] }),
  component: BuilderPage,
});

type Kind = "TRIGGER" | "ACTION" | "OUTPUT";
type Node = { id: string; kind: Kind; label: string; icon: React.ReactNode; color: string };

const PALETTE: Node[] = [
  { id: "notify",      kind: "TRIGGER", label: "NOTIFY",       icon: <Bell className="h-3.5 w-3.5" />,       color: "var(--cyan)"    },
  { id: "schedule",    kind: "TRIGGER", label: "SCHEDULE",     icon: <Clock className="h-3.5 w-3.5" />,      color: "var(--cyan)"    },
  { id: "cpu_thresh",  kind: "TRIGGER", label: "CPU > 80%",    icon: <Cpu className="h-3.5 w-3.5" />,        color: "var(--cyan)"    },
  { id: "disk_full",   kind: "TRIGGER", label: "DISK FULL",    icon: <HardDrive className="h-3.5 w-3.5" />,  color: "var(--cyan)"    },
  { id: "clean_temp",  kind: "ACTION",  label: "CLEAN TEMP",   icon: <Zap className="h-3.5 w-3.5" />,        color: "var(--green)"   },
  { id: "kill_proc",   kind: "ACTION",  label: "KILL PROCESS", icon: <X className="h-3.5 w-3.5" />,          color: "var(--green)"   },
  { id: "backup",      kind: "ACTION",  label: "BACKUP",       icon: <HardDrive className="h-3.5 w-3.5" />,  color: "var(--green)"   },
  { id: "scan_sec",    kind: "ACTION",  label: "SEC SCAN",     icon: <Zap className="h-3.5 w-3.5" />,        color: "var(--green)"   },
  { id: "log_console", kind: "OUTPUT",  label: "LOG",          icon: <FileText className="h-3.5 w-3.5" />,   color: "var(--magenta)" },
  { id: "save_file",   kind: "OUTPUT",  label: "SAVE FILE",    icon: <FileText className="h-3.5 w-3.5" />,   color: "var(--magenta)" },
  { id: "send_push",   kind: "OUTPUT",  label: "PUSH",         icon: <Send className="h-3.5 w-3.5" />,       color: "var(--magenta)" },
];

const PIPELINE: Node[] = [
  PALETTE[2], // CPU > 80%
  PALETTE[4], // CLEAN TEMP
  PALETTE[8], // LOG
];

function NodeChip({ n }: { n: Node }) {
  return (
    <button
      className="panel-cyber lift relative flex w-full flex-col items-start gap-1 px-2.5 py-2 text-left"
      style={{ ["--c" as any]: n.color }}
    >
      <span className="flex items-center gap-1.5" style={{ color: n.color }}>
        {n.icon}
        <span className="font-display text-[9px] font-extrabold tracking-[0.2em]">{n.label}</span>
      </span>
      <span className="font-mono text-[8px] tracking-widest text-foreground/40">{n.kind}</span>
    </button>
  );
}

function BuilderPage() {
  const counts = {
    TRIGGER: PALETTE.filter(p => p.kind === "TRIGGER").length,
    ACTION:  PALETTE.filter(p => p.kind === "ACTION").length,
    OUTPUT:  PALETTE.filter(p => p.kind === "OUTPUT").length,
  };

  return (
    <AppShell active="builder">
      <PageTitle kicker="VISUAL PIPELINE" title="SCRIPT BUILDER" sub="TRIGGERS · ACTIONS · OUTPUTS" color="violet" />

      <div className="mt-3 grid grid-cols-4 gap-1.5">
        <Stat label="TRIGGERS" value={counts.TRIGGER} color="var(--cyan)" />
        <Stat label="ACTIONS"  value={counts.ACTION}  color="var(--green)" />
        <Stat label="OUTPUTS"  value={counts.OUTPUT}  color="var(--magenta)" />
        <Stat label="PIPELINE" value={PIPELINE.length} color="var(--orange)" />
      </div>

      <div className="mt-3">
        <ThemedCard color="violet" title="PIPELINE · CURRENT" icon={<Wrench className="h-3.5 w-3.5" />} action={
          <button className="font-display text-[9px] font-extrabold tracking-[0.2em] text-[color:var(--magenta)]">
            <Play className="inline h-3 w-3" /> RUN
          </button>
        }>
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {PIPELINE.map((n, i) => (
              <div key={i} className="flex shrink-0 items-center gap-1.5">
                <div className="min-w-[88px]"><NodeChip n={n} /></div>
                {i < PIPELINE.length - 1 && <ArrowRight className="h-3.5 w-3.5 shrink-0 text-foreground/40" />}
              </div>
            ))}
            <button className="panel-cyber lift ml-1 grid h-[52px] w-[52px] shrink-0 place-items-center"
              style={{ ["--c" as any]: "var(--cyan)" }} aria-label="Add node">
              <Plus className="h-4 w-4 text-cyan" />
            </button>
          </div>
        </ThemedCard>
      </div>

      {(["TRIGGER", "ACTION", "OUTPUT"] as const).map((k) => (
        <div key={k} className="mt-2.5">
          <ThemedCard
            color={k === "TRIGGER" ? "cyan" : k === "ACTION" ? "green" : "violet"}
            title={`${k} NODES`}
            icon={<Zap className="h-3.5 w-3.5" />}
            action={<span className="font-mono text-[9px] tracking-widest text-foreground/45">{PALETTE.filter(p => p.kind === k).length}</span>}
          >
            <div className="grid grid-cols-3 gap-1.5">
              {PALETTE.filter(p => p.kind === k).map(n => <NodeChip key={n.id} n={n} />)}
            </div>
          </ThemedCard>
        </div>
      ))}

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS · NODE PIPELINE · v2.0
      </div>
    </AppShell>
  );
}

function Stat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="panel-cyber px-2 py-2 text-center" style={{ ["--c" as any]: color }}>
      <div className="font-display text-[18px] font-black leading-none" style={{ color }}>{value}</div>
      <div className="mt-0.5 font-mono text-[8px] tracking-widest text-foreground/55">{label}</div>
    </div>
  );
}
