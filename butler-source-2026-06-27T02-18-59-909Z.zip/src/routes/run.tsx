import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Play, Search, Star, ChevronRight, Code2, Folder, Globe,
  Cpu, Database, Calendar, Mail, FileText, Activity, Wrench, X,
  Loader2, CheckCircle2, AlertTriangle, ShieldCheck, Copy, Check,
  Shield, Lock, Eye, Zap, Trash2, Archive, MonitorSmartphone, MousePointer,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ThemedCard, PageTitle } from "@/components/ThemedCard";
import { toast } from "sonner";
import {
  SCRIPTS, CATEGORIES, search, categoryOf, getCategoriesPresent,
  type LibScript, type UICardColor,
} from "@/data/library";
import { useFavorites, useRunHistory } from "@/lib/useFavorites";
import { runScript } from "@/lib/scriptExecutor";
import { serverLink } from "@/lib/serverLink";
import { useServerLink } from "@/hooks/useServerLink";

export const Route = createFileRoute("/run")({
  head: () => ({
    meta: [
      { title: "Script Library — Butler AI" },
      { name: "description", content: `${SCRIPTS.length}+ local Python automations — categorized, signed, one-tap.` },
    ],
  }),
  component: ScriptsPage,
});

const CAT_ICONS: Record<string, React.ReactNode> = {
  Files:       <Folder      className="h-3.5 w-3.5" />,
  System:      <Cpu         className="h-3.5 w-3.5" />,
  Web:         <Globe       className="h-3.5 w-3.5" />,
  GUI:         <MousePointer className="h-3.5 w-3.5" />,
  Email:       <Mail        className="h-3.5 w-3.5" />,
  Data:        <Database    className="h-3.5 w-3.5" />,
  Scheduling:  <Calendar    className="h-3.5 w-3.5" />,
  Setup:       <Wrench      className="h-3.5 w-3.5" />,
  Network:     <Activity    className="h-3.5 w-3.5" />,
  Text:        <FileText    className="h-3.5 w-3.5" />,
  Monitoring:  <MonitorSmartphone className="h-3.5 w-3.5" />,
  Security:    <Shield      className="h-3.5 w-3.5" />,
  Privacy:     <Lock        className="h-3.5 w-3.5" />,
  Performance: <Zap         className="h-3.5 w-3.5" />,
  Cleaning:    <Trash2      className="h-3.5 w-3.5" />,
  Backup:      <Archive     className="h-3.5 w-3.5" />,
};

const DIFF_COLOR: Record<LibScript["difficulty"], string> = {
  BEGINNER:     "var(--green)",
  INTERMEDIATE: "var(--orange)",
  ADVANCED:     "var(--red)",
};

type Filter = "ALL" | "FAV" | string;

function ScriptsPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<Filter>("ALL");
  const [open, setOpen] = useState<LibScript | null>(null);
  const [running, setRunning] = useState<string | null>(null);
  const [results, setResults] = useState<Record<string, "ok" | "err">>({});
  const { isFav, toggle, count: favCount } = useFavorites();
  const { history, push } = useRunHistory();

  const present = useMemo(() => getCategoriesPresent(), []);

  const filtered = useMemo(() => {
    const base = q.trim() ? search(q) : SCRIPTS;
    return base.filter((s) => {
      if (cat === "ALL") return true;
      if (cat === "FAV") return isFav(s.id);
      return s.category === cat;
    });
  }, [q, cat, isFav]);

  const stats = useMemo(() => {
    const okN = history.filter((h) => h.ok).length;
    const rate = history.length ? Math.round((okN / history.length) * 100) : 100;
    return { total: SCRIPTS.length, runs: history.length, favs: favCount, success: rate };
  }, [history, favCount]);

  const link = useServerLink();
  const run = async (s: LibScript) => {
    if (running) return;
    setRunning(s.id);
    const t0 = performance.now();
    const connected = link.status === "connected";
    if (!connected) {
      toast(`▶ ${s.title}`, { description: "PC offline — running local simulation" });
      await new Promise((r) => setTimeout(r, 600 + Math.random() * 500));
      const ok = Math.random() > 0.07;
      const ms = Math.round(performance.now() - t0);
      setResults((r) => ({ ...r, [s.id]: ok ? "ok" : "err" }));
      push({ id: s.id, name: s.title, ok, ms, ts: Date.now() });
      setRunning(null);
      ok ? toast.success(`✓ ${s.title} (sim)`, { description: `${ms}ms · connect PC for real run` })
         : toast.error(`✗ ${s.title} failed`);
      return;
    }
    toast(`▶ ${s.title}`, { description: `Dispatching to ${serverLink.getState().ip}` });
    const r = await runScript({ id: s.id, name: s.title, category: s.category, script: s.script, language: "python" });
    const ms = r.ms ?? Math.round(performance.now() - t0);
    setResults((rr) => ({ ...rr, [s.id]: r.success ? "ok" : "err" }));
    push({ id: s.id, name: s.title, ok: r.success, ms, ts: Date.now() });
    setRunning(null);
    r.success
      ? toast.success(`✓ ${s.title}`, { description: `${ms}ms · exit ${r.exitCode ?? 0}` })
      : toast.error(`✗ ${s.title}`, { description: r.error ?? "execution failed" });
  };

  return (
    <AppShell active="scripts">
      <PageTitle
        kicker="LOCAL · HMAC-SIGNED"
        title="SCRIPT LIBRARY"
        sub={`${SCRIPTS.length} READY · ${present.length} CATEGORIES · 100% OFFLINE`}
        color="violet"
      />

      {/* Stats strip */}
      <div className="mt-3 grid grid-cols-4 gap-1.5">
        <Stat color="var(--green)"   value={`${stats.success}%`}      label="SUCCESS" />
        <Stat color="var(--cyan)"    value={String(stats.total)}      label="SCRIPTS" />
        <Stat color="var(--magenta)" value={String(stats.runs)}       label="RUNS"    />
        <Stat color="var(--orange)"  value={String(stats.favs)}       label="STARRED" />
      </div>

      {/* Search */}
      <div className="mt-3">
        <ThemedCard color="cyan" title="SEARCH" icon={<Search className="h-3.5 w-3.5" />}
          action={<span className="font-mono text-[9px] tracking-widest text-foreground/45">{filtered.length} HITS</span>}>
          <div className="flex items-center gap-2 rounded-md border border-[color:var(--border)] bg-[var(--ink)] px-2 py-1.5">
            <Search className="h-3.5 w-3.5 text-foreground/40" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="search 100+ python scripts…"
              className="min-w-0 flex-1 bg-transparent font-mono text-[11px] text-foreground placeholder:text-foreground/30 focus:outline-none"
            />
            {q && (
              <button onClick={() => setQ("")} className="text-foreground/40 hover:text-foreground/80">
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </ThemedCard>
      </div>

      {/* Category chips */}
      <div className="-mx-1 mt-2.5 flex gap-1.5 overflow-x-auto px-1 pb-1"
           style={{ scrollbarWidth: "none" }}>
        <CatChip active={cat === "ALL"}  onClick={() => setCat("ALL")}  color="cyan"
                 icon={<Code2 className="h-3.5 w-3.5" />} label="ALL" />
        <CatChip active={cat === "FAV"}  onClick={() => setCat("FAV")}  color="amber"
                 icon={<Star className="h-3.5 w-3.5" />}  label={`★ ${favCount}`} />
        {present.map((c) => (
          <CatChip key={c.id}
                   active={cat === c.id} onClick={() => setCat(c.id)}
                   color={c.color}
                   icon={CAT_ICONS[c.id] ?? <Code2 className="h-3.5 w-3.5" />}
                   label={c.label} />
        ))}
      </div>

      {/* Script list */}
      <div className="mt-2 grid grid-cols-1 gap-2">
        {filtered.length === 0 && (
          <div className="panel-cyber p-4 text-center font-mono text-[11px] text-foreground/55">
            no scripts match — try a different filter
          </div>
        )}
        {filtered.slice(0, 60).map((s) => {
          const isRunning = running === s.id;
          const result = results[s.id];
          const starred = isFav(s.id);
          const meta = categoryOf(s);
          return (
            <ThemedCard key={s.id} color={meta.color}
              title={meta.label}
              icon={CAT_ICONS[s.category] ?? <ShieldCheck className="h-3.5 w-3.5" />}
              action={
                <div className="flex items-center gap-1.5">
                  <span className="rounded px-1.5 py-0.5 font-mono text-[9px] tracking-widest border"
                        style={{ color: DIFF_COLOR[s.difficulty],
                                 borderColor: `color-mix(in oklab, ${DIFF_COLOR[s.difficulty]} 50%, transparent)` }}>
                    {s.difficulty.slice(0, 3)}
                  </span>
                  {s.admin && (
                    <span className="rounded px-1.5 py-0.5 font-mono text-[9px] tracking-widest text-[color:var(--red)] border border-[color:var(--red)]/50">
                      ADMIN
                    </span>
                  )}
                  <button onClick={() => toggle(s.id)}
                          className={`grid h-6 w-6 place-items-center rounded border ${starred ? "border-[color:var(--orange)]/60 bg-[color:var(--orange)]/10 text-[color:var(--orange)]" : "border-[color:var(--border)] text-foreground/45"}`}
                          aria-label="Star">
                    <Star className="h-3 w-3" fill={starred ? "currentColor" : "none"} />
                  </button>
                </div>
              }>
              <div className="flex items-start gap-2">
                <div className="min-w-0 flex-1">
                  <div className="font-display text-[12.5px] font-extrabold leading-tight tracking-[0.02em] text-foreground/95">{s.title}</div>
                  <div className="mt-0.5 font-mono text-[10.5px] leading-snug text-foreground/60 line-clamp-2">{s.description}</div>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5 font-mono text-[8.5px] tracking-widest text-foreground/45">
                    <span>{s.time}</span>
                    {s.requirements.length > 0 && (
                      <span className="text-[color:var(--orange)]">PIP {s.requirements.length}</span>
                    )}
                    {s.tags.slice(0, 2).map((t) => (
                      <span key={t} className="rounded-sm bg-[color:var(--surface-2)] px-1 py-[1px] text-foreground/55">{t}</span>
                    ))}
                    {result === "ok"  && <span className="flex items-center gap-1 text-[color:var(--green)]"><CheckCircle2 className="h-3 w-3" /> OK</span>}
                    {result === "err" && <span className="flex items-center gap-1 text-[color:var(--red)]"><AlertTriangle className="h-3 w-3" /> ERR</span>}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1.5">
                  <button onClick={() => run(s)} disabled={!!running}
                    className="grid h-10 w-10 place-items-center rounded-md border text-[color:var(--magenta)] disabled:opacity-50"
                    style={{
                      borderColor: "color-mix(in oklab, var(--magenta) 60%, transparent)",
                      background: "color-mix(in oklab, var(--magenta) 14%, var(--ink))",
                      boxShadow: "0 0 14px -3px var(--magenta)",
                    }}
                    aria-label="Run">
                    {isRunning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                  </button>
                  <button onClick={() => setOpen(s)}
                    className="font-display text-[9px] font-extrabold tracking-[0.2em] text-cyan hover:underline">
                    CODE <ChevronRight className="inline h-3 w-3" />
                  </button>
                </div>
              </div>
            </ThemedCard>
          );
        })}
        {filtered.length > 60 && (
          <div className="panel-cyber p-2 text-center font-mono text-[9px] tracking-widest text-foreground/45">
            showing 60 of {filtered.length} — refine your search
          </div>
        )}
      </div>

      {open && <CodeModal s={open} onClose={() => setOpen(null)} onRun={() => { void run(open); setOpen(null); }} />}

      <div className="pt-2 text-center font-mono text-[9px] tracking-[0.32em] text-foreground/40">
        NEXUS SCRIPT LIB · {filtered.length}/{SCRIPTS.length}
      </div>
    </AppShell>
  );
}

function Stat({ value, label, color }: { value: string; label: string; color: string }) {
  return (
    <div className="panel-cyber px-2 py-2 text-center" style={{ ["--c" as any]: color }}>
      <div className="font-display text-[15px] font-black leading-none" style={{ color }}>{value}</div>
      <div className="mt-0.5 font-mono text-[8px] tracking-widest text-foreground/55">{label}</div>
    </div>
  );
}

function CatChip({ active, onClick, icon, label, color }: {
  active: boolean; onClick: () => void; icon: React.ReactNode; label: string; color: UICardColor;
}) {
  const cvar = color === "violet" ? "var(--magenta)" : color === "amber" ? "var(--orange)" : `var(--${color})`;
  return (
    <button onClick={onClick}
      data-active={active ? "true" : "false"}
      className="hex-tab shrink-0 flex-row gap-1.5 px-3"
      style={{ ["--c" as any]: cvar }}>
      {icon}
      <span className="font-display text-[9px] font-extrabold tracking-[0.2em]">{label}</span>
    </button>
  );
}

function CodeModal({ s, onClose, onRun }: { s: LibScript; onClose: () => void; onRun: () => void }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(s.script); setCopied(true); setTimeout(() => setCopied(false), 1400); } catch {}
  };
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/80" onClick={onClose}>
      <div className="panel-cyber w-full max-w-md p-3 m-2"
           onClick={(e) => e.stopPropagation()}
           style={{ ["--c" as any]: "var(--magenta)" }}>
        <div className="mb-2 flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <div className="font-mono text-[9px] tracking-widest text-[color:var(--magenta)]">{s.category} · {s.id}</div>
            <div className="font-display text-[13px] font-extrabold tracking-[0.06em] text-foreground">{s.title}</div>
            <div className="mt-0.5 font-mono text-[10px] text-foreground/60">{s.description}</div>
          </div>
          <button onClick={onClose} className="text-foreground/50 hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>
        {s.requirements.length > 0 && (
          <div className="mb-2 rounded border border-[color:var(--orange)]/40 bg-[color:var(--orange)]/5 p-1.5">
            <div className="font-display text-[8.5px] font-extrabold tracking-widest text-[color:var(--orange)]">PIP REQUIREMENTS</div>
            <div className="mt-0.5 font-mono text-[10px] text-foreground/80">pip install {s.requirements.join(" ")}</div>
          </div>
        )}
        <div className="relative">
          <button onClick={copy}
            className="absolute right-1.5 top-1.5 z-10 flex items-center gap-1 rounded border border-[color:var(--border)] bg-[var(--ink)]/90 px-1.5 py-0.5 font-display text-[8.5px] font-extrabold tracking-widest text-foreground/70 hover:text-cyan">
            {copied ? <><Check className="h-2.5 w-2.5 text-[color:var(--green)]" /> COPIED</>
                    : <><Copy className="h-2.5 w-2.5" /> COPY</>}
          </button>
          <pre className="max-h-[42vh] overflow-auto rounded border border-[color:var(--border)] bg-[var(--ink)] p-2 pr-16 font-mono text-[10.5px] leading-relaxed text-cyan whitespace-pre">
{s.script}
          </pre>
        </div>
        {s.notes && <div className="mt-1.5 font-mono text-[9.5px] text-foreground/55">{s.notes}</div>}
        <button onClick={onRun}
          className="mt-2 flex w-full items-center justify-center gap-2 rounded-md border border-[color:var(--magenta)]/60 bg-[color:var(--magenta)]/10 px-3 py-2 font-display text-[11px] font-extrabold tracking-[0.22em] text-[color:var(--magenta)]"
          style={{ boxShadow: "0 0 18px -4px var(--magenta)" }}>
          <Play className="h-3.5 w-3.5" /> RUN ON PC
        </button>
      </div>
    </div>
  );
}
