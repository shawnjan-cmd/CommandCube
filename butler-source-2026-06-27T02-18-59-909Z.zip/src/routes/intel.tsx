import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/intel")({
  beforeLoad: () => {
    throw redirect({ to: "/knowledge", search: { tab: "intel" } as any });
  },
  component: () => null,
});
