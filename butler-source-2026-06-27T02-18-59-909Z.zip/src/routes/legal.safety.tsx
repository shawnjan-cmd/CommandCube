import { createFileRoute } from "@tanstack/react-router";
import { LegalShell, LegalSection } from "@/components/LegalShell";

export const Route = createFileRoute("/legal/safety")({
  head: () => ({
    meta: [
      { title: "Data Safety — Butler AI" },
      { name: "description", content: "What is collected, what is shared, what is encrypted. The honest one-page truth." },
    ],
  }),
  component: SafetyPage,
});

function SafetyPage() {
  return (
    <LegalShell
      title="Data Safety"
      accent="green"
      emoji="🛡️"
      headline="The honest one-page truth · audit-friendly"
      badges={[
        { label: "DATA COLLECTED · NONE", tone: "green"  },
        { label: "DATA SHARED · NONE",    tone: "green"  },
        { label: "ENCRYPTED IN TRANSIT",  tone: "cyan"   },
        { label: "DELETE IN 3 TAPS",      tone: "orange" },
      ]}
    >
      <LegalSection title="DATA TYPES COLLECTED" tone="green">
        <p className="font-bold text-green">None.</p>
        <p>Butler AI does not collect any of the data categories defined in Google Play's Data Safety form: personal info, financial info, health/fitness, messages, photos/videos, audio, files/docs, calendar, contacts, app activity, web history, device IDs, or installed apps.</p>
      </LegalSection>

      <LegalSection title="DATA SHARED WITH THIRD PARTIES" tone="green">
        <p className="font-bold text-green">None.</p>
        <p>No analytics SDKs. No advertising SDKs. No crash reporters. No social SDKs. No third-party servers are contacted, ever.</p>
      </LegalSection>

      <LegalSection title="ENCRYPTION" tone="cyan">
        <ul className="list-disc space-y-1 pl-5">
          <li><strong>In transit:</strong> every command is HMAC-SHA256 signed with your pairing secret.</li>
          <li><strong>At rest:</strong> pairing secret stored in Android Keystore (hardware-backed where available).</li>
          <li><strong>Replay protection:</strong> timestamp window rejects re-played requests.</li>
        </ul>
      </LegalSection>

      <LegalSection title="DATA DELETION" tone="orange">
        <p>Three taps in <strong>Settings → DELETE ALL MY DATA</strong> wipes the device UUID, pairing secret, preferences, and KB cache. Server data lives on your PC and is removed by the PC uninstaller.</p>
      </LegalSection>

      <LegalSection title="OPEN-SOURCE SERVER" tone="cyan">
        <p>The PC server is open source so anyone can audit what runs on their machine: <a className="text-cyan underline" href="https://github.com/shawnjan-cmd/CommandCube" target="_blank" rel="noreferrer">github.com/shawnjan-cmd/CommandCube</a></p>
      </LegalSection>
    </LegalShell>
  );
}
