/**
 * Script library — public surface for app routes.
 * Wraps the verbatim port from CommandCube/Butler-AI and exposes
 * a flat, typed catalogue + category metadata for the cyberpunk UI.
 */
import { PYTHON_AUTOMATION_SCRIPTS } from "./pythonAutomationKnowledge";
import type { AutomationScript } from "./scriptTypes";

export type Difficulty = "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
export type UICardColor = "cyan" | "violet" | "green" | "amber" | "red";

export type LibScript = AutomationScript & {
  difficulty: Difficulty;
  time: string;
  admin: boolean;
};

export type CategoryMeta = {
  id: string;          // matches AutomationScript.category
  label: string;       // pill label (short)
  title: string;       // full title
  subtitle: string;
  color: UICardColor;  // mapped to our themed-card palette
  hex: string;         // raw color for accents
};

export const CATEGORIES: CategoryMeta[] = [
  { id: "Files",       label: "FILES",      title: "File & Folder",        subtitle: "Organize · backup · rename",        color: "amber",  hex: "#FF6A1F" },
  { id: "System",      label: "SYSTEM",     title: "System Tools",         subtitle: "CPU · RAM · processes",             color: "cyan",   hex: "#00D4FF" },
  { id: "Web",         label: "WEB",        title: "Web & Scraping",       subtitle: "Scrape · download · automate",      color: "green",  hex: "#00FF88" },
  { id: "GUI",         label: "GUI",        title: "GUI Automation",       subtitle: "Mouse · keyboard · windows",        color: "amber",  hex: "#FFC400" },
  { id: "Email",       label: "EMAIL",      title: "Email & Notify",       subtitle: "SMTP · Slack · Discord",            color: "violet", hex: "#FF6FD8" },
  { id: "Data",        label: "DATA",       title: "Data Processing",      subtitle: "CSV · Excel · PDF · SQLite",        color: "amber",  hex: "#FFC400" },
  { id: "Scheduling",  label: "SCHED",      title: "Scheduling",           subtitle: "Cron · timers · automation",        color: "cyan",   hex: "#00D4FF" },
  { id: "Setup",       label: "SETUP",      title: "Setup & DevOps",       subtitle: "Docker · git · CI/CD",              color: "amber",  hex: "#FF6A1F" },
  { id: "Network",     label: "NET",        title: "Network & Monitoring", subtitle: "Scan · ping · ports · bandwidth",   color: "green",  hex: "#00FF88" },
  { id: "Text",        label: "TEXT",       title: "Text & Docs",          subtitle: "PDF · Word · regex · Markdown",     color: "cyan",   hex: "#A8C8D8" },
  { id: "Monitoring",  label: "MON",        title: "Monitoring & Alerts",  subtitle: "Watch · alert · log · GPU · disk",  color: "red",    hex: "#FF3C5A" },
  { id: "Security",    label: "SEC",        title: "Security & Threat",    subtitle: "Scan · harden · SSL · passwords",   color: "red",    hex: "#FF4444" },
  { id: "Privacy",     label: "PRIV",       title: "Privacy & Protection", subtitle: "Block · shred · WiFi · DNS · VPN",  color: "amber",  hex: "#FFC400" },
  { id: "Performance", label: "PERF",       title: "Performance & Speed",  subtitle: "Profile · benchmark · TCP · CPU",   color: "green",  hex: "#00FFB3" },
  { id: "Cleaning",    label: "CLEAN",      title: "System Cleaning",      subtitle: "Temp · Docker · git · pip · logs",  color: "cyan",   hex: "#4DFFEA" },
  { id: "Backup",      label: "BACKUP",     title: "Backup & Recovery",    subtitle: "Verify · sync · cloud · database",  color: "amber",  hex: "#FFA040" },
];

const META_BY_ID: Record<string, CategoryMeta> = Object.fromEntries(
  CATEGORIES.map((c) => [c.id, c]),
);

function inferDifficulty(req: string[], len: number): Difficulty {
  if (req.length >= 3 || len > 1200) return "ADVANCED";
  if (req.length >= 1 || len > 600)  return "INTERMEDIATE";
  return "BEGINNER";
}
function inferTime(len: number): string {
  if (len > 1200) return "5-10 min";
  if (len > 600)  return "2-5 min";
  return "< 2 min";
}
function inferAdmin(code: string): boolean {
  return /winreg|admin|ctypes\.windll|HKEY_LOCAL_MACHINE|sudo|iptables/i.test(code);
}

/** Full library — every script with computed UI metadata. */
export const SCRIPTS: LibScript[] = PYTHON_AUTOMATION_SCRIPTS.map((s) => ({
  ...s,
  difficulty: inferDifficulty(s.requirements ?? [], (s.script ?? "").length),
  time:       inferTime((s.script ?? "").length),
  admin:      inferAdmin(s.script ?? ""),
}));

/** Returns the category meta for a script (falls back to System). */
export function categoryOf(s: AutomationScript): CategoryMeta {
  return META_BY_ID[s.category] ?? META_BY_ID["System"];
}

export function getCategoriesPresent(): CategoryMeta[] {
  const seen = new Set<string>(SCRIPTS.map((s) => s.category));
  return CATEGORIES.filter((c) => seen.has(c.id));
}

/** Lightweight relevance ranking — title/tag matches first. */
export function search(query: string): LibScript[] {
  const q = query.trim().toLowerCase();
  if (!q) return SCRIPTS;
  const words = q.split(/\s+/).filter((w) => w.length > 1);
  return SCRIPTS
    .map((s) => {
      let score = 0;
      const hay = `${s.title} ${s.description} ${s.category} ${s.tags.join(" ")}`.toLowerCase();
      for (const w of words) {
        if (s.tags.some((t) => t.toLowerCase().includes(w))) score += 10;
        if (s.title.toLowerCase().includes(w))               score += 8;
        if (s.category.toLowerCase().includes(w))            score += 6;
        if (hay.includes(w))                                 score += 1;
      }
      return { s, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((x) => x.s);
}

export const SCRIPT_COUNT = SCRIPTS.length;
