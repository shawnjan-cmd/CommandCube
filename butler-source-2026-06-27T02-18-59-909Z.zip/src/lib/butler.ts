// Butler PC server client — talks to butler_server.py over LAN.
// Full port from prior project; preserves all endpoints and helpers.

export type ButlerConfig = {
  baseUrl: string;
  token: string;
  deviceId: string;
  host: string;
  appSig: string;
  pairingCode: string;
  pairedAt: number;
  paired: boolean;
};

const CFG_KEY = "butler.cfg.v2";

function emptyCfg(): ButlerConfig {
  return {
    baseUrl: "", token: "", deviceId: "", host: "",
    appSig: "", pairingCode: "", pairedAt: 0, paired: false,
  };
}

function genDeviceId(): string {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return "web-" + Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}

export function getConfig(): ButlerConfig {
  if (typeof window === "undefined") return emptyCfg();
  try {
    const raw = localStorage.getItem(CFG_KEY) || localStorage.getItem("butler.cfg.v1");
    if (raw) {
      const c = { ...emptyCfg(), ...JSON.parse(raw) } as ButlerConfig;
      if (!c.deviceId) c.deviceId = genDeviceId();
      return c;
    }
  } catch {}
  const c = emptyCfg();
  c.deviceId = genDeviceId();
  return c;
}

export function setConfig(patch: Partial<ButlerConfig>): ButlerConfig {
  const next = { ...getConfig(), ...patch };
  try { localStorage.setItem(CFG_KEY, JSON.stringify(next)); } catch {}
  if (typeof window !== "undefined") window.dispatchEvent(new Event("butler:cfg"));
  return next;
}

export function clearConfig() {
  try {
    localStorage.removeItem(CFG_KEY);
    localStorage.removeItem("butler.cfg.v1");
  } catch {}
  if (typeof window !== "undefined") window.dispatchEvent(new Event("butler:cfg"));
}

function normalizeBase(url: string): string {
  let u = url.trim();
  if (!u) return "";
  if (!/^https?:\/\//i.test(u)) u = "http://" + u;
  return u.replace(/\/+$/, "");
}

export async function request<T = any>(
  path: string,
  init: RequestInit = {},
  opts: { auth?: boolean; timeoutMs?: number; baseUrl?: string } = {},
): Promise<T> {
  const cfg = getConfig();
  const base = opts.baseUrl || cfg.baseUrl;
  if (!base) throw new Error("Butler server not configured");
  const headers = new Headers(init.headers || {});
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  if (opts.auth !== false && cfg.token) {
    headers.set("Authorization", `Bearer ${cfg.token}`);
    headers.set("X-Session-Token", cfg.token);
  }
  headers.set("X-Device-Id", cfg.deviceId);
  if (cfg.appSig) headers.set("X-Butler-App-Sig", cfg.appSig);
  headers.set("X-App-Version", "web-1.0");

  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), opts.timeoutMs ?? 15000);
  try {
    const res = await fetch(base + path, { ...init, headers, signal: ctrl.signal });
    const text = await res.text();
    let data: any = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = { raw: text }; }
    if (!res.ok) {
      const err: any = new Error(data?.error || `HTTP ${res.status}`);
      err.status = res.status; err.body = data; throw err;
    }
    return data as T;
  } finally {
    clearTimeout(tid);
  }
}

export type QrPayload = {
  ip?: string; host?: string; port?: number; scheme?: string;
  url?: string; baseUrl?: string; pairingCode?: string;
  appSig?: string; version?: string; tls?: any; allIPs?: string[];
};

export function parseQrPayload(text: string): QrPayload {
  const t = (text || "").trim();
  if (!t) throw new Error("Empty QR payload");
  const cleaned = t.replace(/^butler:\/\//i, "").trim();
  let obj: any;
  try { obj = JSON.parse(cleaned); }
  catch {
    const parts = cleaned.split("|");
    if (parts.length >= 2 && parts[0].includes(":")) {
      const [ip, port] = parts[0].split(":");
      obj = { ip, port: Number(port), pairingCode: parts[1], appSig: parts[2] || "" };
    } else throw new Error("QR payload is not JSON");
  }
  if (!obj || typeof obj !== "object") throw new Error("Invalid QR payload");
  return obj as QrPayload;
}

export function qrToBaseUrl(p: QrPayload): string {
  if (p.url) return normalizeBase(p.url);
  if (p.baseUrl) return normalizeBase(p.baseUrl);
  const scheme = p.scheme || (p.tls ? "https" : "http");
  const host = p.ip || p.host || "";
  const port = p.port || 8766;
  if (!host) throw new Error("QR payload missing ip/host");
  return normalizeBase(`${scheme}://${host}:${port}`);
}

export async function pair(baseUrl: string, pairingCode = "", appSig = "") {
  const url = normalizeBase(baseUrl);
  setConfig({ baseUrl: url, appSig: appSig || getConfig().appSig });
  const cfg = getConfig();
  const res = await request<{ status: string; sessionToken: string; serverVersion?: string }>(
    "/pair",
    { method: "POST", body: JSON.stringify({ deviceId: cfg.deviceId, pairingCode: pairingCode || "" }) },
    { auth: false, timeoutMs: 12000 },
  );
  if (!res.sessionToken) throw new Error("Pairing failed: server returned no session token");
  setConfig({
    baseUrl: url, token: res.sessionToken, paired: true,
    host: hostOf(url), pairedAt: Date.now(), pairingCode,
  });
  return res;
}

export async function pairFromQr(payloadText: string) {
  const p = parseQrPayload(payloadText);
  const url = qrToBaseUrl(p);
  const code = (p.pairingCode || "").toUpperCase();
  const sig = p.appSig || "";
  if (!sig) throw new Error("QR missing appSig — reprint the QR from the PC console");
  return pair(url, code, sig);
}

export async function reconnect() {
  const cfg = getConfig();
  if (!cfg.baseUrl) throw new Error("No server URL");
  const res = await request<{ sessionToken?: string }>(
    "/reconnect",
    { method: "POST", body: JSON.stringify({ deviceId: cfg.deviceId, token: cfg.token }) },
    { auth: false, timeoutMs: 6000 },
  );
  if (res?.sessionToken) setConfig({ token: res.sessionToken, paired: true });
  return res;
}

export async function pairStatus(baseUrl?: string) {
  return request<{ paired: boolean; pairingCode?: string; serverVersion?: string }>(
    "/api/pair/status", { method: "POST", body: "{}" }, { auth: false, timeoutMs: 4000, baseUrl },
  );
}

export async function resetPair(pairingCode = "") {
  return request<{ ok: boolean }>(
    "/api/reset_pair",
    { method: "POST", body: JSON.stringify({ pairingCode }) },
    { auth: false, timeoutMs: 8000 },
  );
}

function hostOf(u: string): string {
  try { return new URL(u).host; } catch { return u; }
}

export type HealthInfo = { status: string; version?: string; uptime?: number; ai?: boolean; model?: string };
export const health = () => request<HealthInfo>("/api/health", {}, { auth: false, timeoutMs: 4000 });

export type SysInfo = {
  cpu?: number; ram?: number; disk?: number;
  cpuPercent?: number; ramPercent?: number; diskPercent?: number;
  hostname?: string; platform?: string; uptime?: number;
  [k: string]: any;
};
export const sysinfo = () => request<SysInfo>("/api/sysinfo");
export const statusFull = () => request<any>("/api/status/full");
export const processes = () => request<any>("/api/processes");
export const diskSpace = () => request<any>("/api/disk_space");
export const telemetry = () => request<any>("/api/telemetry", { method: "POST", body: "{}" });
export const haptic = (style = "light") =>
  fetch(`${getConfig().baseUrl}/api/haptic?style=${style}`).catch(() => {});

export const ollamaStatus = () => request<any>("/api/ollama/status", { method: "POST", body: "{}" });
export const ollamaRecommend = () => request<any>("/api/ollama/recommend");
export const ollamaModels = () => request<any>("/api/models");
export const ollamaPullStatus = () => request<any>("/api/ollama/pull_status");
export const ollamaPull = (model: string) =>
  request<any>("/api/ollama/pull", { method: "POST", body: JSON.stringify({ model }) }, { timeoutMs: 8000 });

export const kbStats = () => request<{ articles: number; sigma?: any }>("/api/kb/stats");
export const kbList = (limit = 50) => request<any>(`/api/kb/list?limit=${limit}`);
export const kbSearch = (q: string, limit = 8) =>
  request<{ results: any[]; total: number; query: string }>(
    "/api/kb/search", { method: "POST", body: JSON.stringify({ q, limit }) }, { timeoutMs: 8000 },
  );
export const kbEnrich = (query: string, keywords: string[] = [], maxResults = 5) =>
  request<{ enrichments: any[] }>(
    "/api/kb/enrich",
    { method: "POST", body: JSON.stringify({ query, keywords, maxResults }) },
    { timeoutMs: 10000 },
  );
export const kbFeed = (items: any) =>
  request<any>("/api/kb/feed", { method: "POST", body: JSON.stringify(items) }, { timeoutMs: 20000 });
export const kbExpand = (topic: string) =>
  request<any>("/api/kb/expand", { method: "POST", body: JSON.stringify({ topic }) }, { timeoutMs: 30000 });

export const learnStatus = () => request<any>("/api/learn/status", { method: "POST", body: "{}" });
export const crawlerPause = () => request<any>("/api/crawler/pause", { method: "POST", body: "{}" });
export const crawlerResume = () => request<any>("/api/crawler/resume", { method: "POST", body: "{}" });

export const requirementsList = () => request<any>("/api/requirements");
export const requirementsInstall = () =>
  request<any>("/api/requirements/install", { method: "POST", body: "{}" }, { timeoutMs: 300_000 });
export const pipInstall = (packages: string[]) =>
  request<any>("/api/pip/install", { method: "POST", body: JSON.stringify({ packages }) }, { timeoutMs: 300_000 });

export type ChatMsg = { role: "user" | "assistant"; content: string };

export async function chat(
  message: string,
  conversation: ChatMsg[] = [],
  opts: { systemPrompt?: string; metricsSnapshot?: string; model?: string } = {},
) {
  return request<{
    response?: string; reply?: string; message?: string;
    degraded?: boolean; model?: string; intent?: string;
  }>(
    "/api/butler/chat",
    {
      method: "POST",
      body: JSON.stringify({
        message,
        conversation,
        systemPrompt: opts.systemPrompt || "",
        metricsSnapshot: opts.metricsSnapshot || "",
        model: opts.model || "",
      }),
    },
    { timeoutMs: 180_000 },
  );
}

export async function chatClear() {
  return request<any>("/api/butler/clear", { method: "POST", body: "{}" }, { timeoutMs: 6000 });
}

export async function executeStream(
  script: string,
  language: "python" | "powershell" | "bash" | "sh" | "cmd" = "python",
  onChunk?: (text: string) => void,
): Promise<{ ok: boolean; output: string }> {
  const cfg = getConfig();
  if (!cfg.baseUrl) throw new Error("Not paired");
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${cfg.token}`,
    "X-Session-Token": cfg.token,
    "X-Device-Id": cfg.deviceId,
  };
  if (cfg.appSig) headers["X-Butler-App-Sig"] = cfg.appSig;
  const res = await fetch(cfg.baseUrl + "/api/execute/stream", {
    method: "POST", headers, body: JSON.stringify({ script, language }),
  });
  if (!res.ok || !res.body) {
    const t = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}${t ? ": " + t.slice(0, 200) : ""}`);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "", full = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = dec.decode(value, { stream: true });
    full += chunk; buf += chunk;
    let idx;
    while ((idx = buf.indexOf("\n\n")) !== -1) {
      const evt = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      const dataLine = evt.split("\n").find((l) => l.startsWith("data:"));
      if (dataLine && onChunk) onChunk(dataLine.slice(5).trim());
    }
  }
  return { ok: true, output: full };
}

export type SetupStep = {
  id: string; label: string;
  status: "pending" | "running" | "ok" | "skip" | "error";
  detail?: string; percent?: number;
};

export async function runAutoSetup(onUpdate: (steps: SetupStep[]) => void) {
  const steps: SetupStep[] = [
    { id: "deps", label: "Install Python dependencies", status: "pending" },
    { id: "recommend", label: "Recommend best Ollama model", status: "pending" },
    { id: "pull", label: "Download model", status: "pending" },
    { id: "verify", label: "Verify AI engine", status: "pending" },
  ];
  const update = () => onUpdate(steps.map(s => ({ ...s })));
  update();

  steps[0].status = "running"; update();
  try {
    const r = await requirementsInstall();
    steps[0].status = "ok";
    steps[0].detail = r?.installed ? `${r.installed} pkgs` : "ok";
  } catch (e: any) {
    steps[0].status = "skip";
    steps[0].detail = `skipped (${String(e?.message || e).slice(0, 60)})`;
  }
  update();

  steps[1].status = "running"; update();
  let pickModel = "";
  try {
    const rec: any = await ollamaRecommend();
    pickModel = extractRecommendedModel(rec);
    if (!pickModel) {
      try {
        const m: any = await ollamaModels();
        const list = (m?.models || m?.list || m || []) as any[];
        const first = list?.[0];
        pickModel = (first?.name || first?.model || (typeof first === "string" ? first : "")) as string;
      } catch {}
    }
    if (!pickModel) pickModel = "llama3.2:1b";
    steps[1].status = "ok";
    steps[1].detail = pickModel;
  } catch (e: any) {
    pickModel = "llama3.2:1b";
    steps[1].status = "ok";
    steps[1].detail = `${pickModel} (default — ${String(e?.message || e).slice(0, 40)})`;
  }
  update();

  if (!pickModel) {
    steps[2].status = "skip"; steps[2].detail = "no recommendation";
    steps[3].status = "skip"; update(); return steps;
  }
  steps[2].status = "running"; update();
  try { await ollamaPull(pickModel); } catch (e: any) {
    steps[2].status = "error"; steps[2].detail = String(e?.message || e);
    update(); return steps;
  }
  for (let i = 0; i < 600; i++) {
    await new Promise(r => setTimeout(r, 2500));
    try {
      const p = await ollamaPullStatus();
      const pct = Number(p?.percent ?? p?.progress ?? 0);
      steps[2].percent = Math.max(0, Math.min(100, Math.round(pct)));
      steps[2].detail = `${pickModel} · ${steps[2].percent}%`;
      update();
      if (!p?.active && (steps[2].percent >= 100 || p?.status === "done" || p?.completed)) {
        steps[2].status = "ok"; steps[2].percent = 100; break;
      }
    } catch {}
  }
  if (steps[2].status === "running") steps[2].status = "ok";
  update();

  steps[3].status = "running"; update();
  try {
    const s = await ollamaStatus();
    if (s?.ok || s?.activeModel || s?.model) {
      steps[3].status = "ok";
      steps[3].detail = s.activeModel || s.model || "ready";
    } else {
      steps[3].status = "error";
      steps[3].detail = "engine not ready";
    }
  } catch (e: any) {
    steps[3].status = "error"; steps[3].detail = String(e?.message || e);
  }
  update();
  return steps;
}

function extractRecommendedModel(rec: any): string {
  if (!rec) return "";
  if (typeof rec === "string") return rec;
  const direct = rec.recommended || rec.model || rec.best || rec.pick || rec.name;
  if (typeof direct === "string" && direct.trim()) return direct.trim();
  const arr = rec.picks || rec.models || rec.candidates || rec.results;
  if (Array.isArray(arr) && arr.length) {
    const first = arr[0];
    if (typeof first === "string") return first;
    if (first?.name) return String(first.name);
    if (first?.model) return String(first.model);
  }
  const tiers = rec.tiers || rec.tier;
  if (tiers && typeof tiers === "object") {
    return String(tiers.small || tiers.tiny || tiers.medium || tiers.large || "").trim();
  }
  return "";
}

export function useButlerConfigSubscribe(cb: () => void) {
  if (typeof window === "undefined") return () => {};
  window.addEventListener("butler:cfg", cb);
  return () => window.removeEventListener("butler:cfg", cb);
}

// ─────────────────────────────────────────────────────────────────────────────
// EXTENDED ENDPOINT SURFACE — full port of butler_server.py API (v20.1)
// Wired but lazy: every call returns {ok:false,error} when server is offline.
// ─────────────────────────────────────────────────────────────────────────────

// AI / Ollama (chat + model selection)
export const aiChat = (messages: any[], opts: any = {}) =>
  request<any>("/api/ai/chat", { method: "POST", body: JSON.stringify({ messages, ...opts }) }, { timeoutMs: 60000 });
export const aiMessage = (text: string) =>
  request<any>("/api/ai/message", { method: "POST", body: JSON.stringify({ text }) }, { timeoutMs: 60000 });
export const aiClear = () => request<any>("/api/ai/clear", { method: "POST", body: "{}" });
export const aiModels = () => request<any>("/api/ai/models");
export const aiSetModel = (model: string) =>
  request<any>("/api/ai/set_model", { method: "POST", body: JSON.stringify({ model }) });
export const ollamaChat = (messages: any[], model?: string) =>
  request<any>("/api/ollama/chat", { method: "POST", body: JSON.stringify({ messages, model }) }, { timeoutMs: 60000 });
export const ollamaSetModel = (model: string) =>
  request<any>("/api/ollama/set_model", { method: "POST", body: JSON.stringify({ model }) });
export const butlerAbort = () => request<any>("/api/butler/abort", { method: "POST", body: "{}" });

// Execute / Run
export const execute = (script: string, args: string[] = []) =>
  request<any>("/api/execute", { method: "POST", body: JSON.stringify({ script, args }) }, { timeoutMs: 0 });
export const executeSettings = () => request<any>("/api/execute/settings");
export const runScript = (id: string, params?: any) =>
  request<any>("/api/run", { method: "POST", body: JSON.stringify({ id, params }) }, { timeoutMs: 0 });

// PC Scripts CRUD
export const pcScriptsList = () => request<any>("/api/pc_scripts/list");
export const pcScriptsGet = (id: string) => request<any>(`/api/pc_scripts/get?id=${encodeURIComponent(id)}`);
export const pcScriptsSave = (script: any) =>
  request<any>("/api/pc_scripts/save", { method: "POST", body: JSON.stringify(script) });
export const pcScriptsDelete = (id: string) =>
  request<any>("/api/pc_scripts/delete", { method: "POST", body: JSON.stringify({ id }) });
export const pcScriptsRun = (id: string, params?: any) =>
  request<any>("/api/pc_scripts/run", { method: "POST", body: JSON.stringify({ id, params }) }, { timeoutMs: 0 });
export const pcScriptsImport = (payload: any) =>
  request<any>("/api/pc_scripts/import", { method: "POST", body: JSON.stringify(payload) }, { timeoutMs: 20000 });
export const pcScriptsExport = () => request<any>("/api/pc_scripts/export");
export const pcScriptsSearch = (q: string) =>
  request<any>("/api/pc_scripts/search", { method: "POST", body: JSON.stringify({ q }) });

// Filesystem
export const fsDrives = () => request<any>("/api/fs/drives");
export const fsCrawl = (path: string, depth = 2) =>
  request<any>("/api/fs/crawl", { method: "POST", body: JSON.stringify({ path, depth }) }, { timeoutMs: 30000 });
export const fsRead = (path: string) =>
  request<any>("/api/fs/read", { method: "POST", body: JSON.stringify({ path }) }, { timeoutMs: 15000 });
export const filesList = () => request<any>("/api/files");
export const downloadFile = (path: string) =>
  request<any>("/api/download", { method: "POST", body: JSON.stringify({ path }) }, { timeoutMs: 0 });
export const receiveFile = (form: FormData) =>
  fetch(`${getConfig().baseUrl}/api/receive_file`, { method: "POST", body: form, headers: { "X-Token": getConfig().token } }).then(r => r.json());

// Clipboard / Input / Power
export const clipboardGet = () => request<{ text: string }>("/api/clipboard");
export const clipboardSet = (text: string) =>
  request<any>("/api/clipboard", { method: "POST", body: JSON.stringify({ text }) });
export const keyboardType = (text: string) =>
  request<any>("/api/keyboard/type", { method: "POST", body: JSON.stringify({ text }) });
export const power = (action: "shutdown" | "restart" | "sleep" | "lock") =>
  request<any>("/api/power", { method: "POST", body: JSON.stringify({ action }) });
export const killProcess = (pid: number) =>
  request<any>("/api/kill_process", { method: "POST", body: JSON.stringify({ pid }) });
export const killInterference = () => request<any>("/api/kill_interference", { method: "POST", body: "{}" });

// Nexus Brain (legacy AI tuner)
export const nexusBrainStatus = () => request<any>("/api/nexus_brain/status");
export const nexusBrainMetrics = () => request<any>("/api/nexus_brain/metrics");
export const nexusBrainInsights = () => request<any>("/api/nexus_brain/insights");
export const nexusBrainAnomalies = () => request<any>("/api/nexus_brain/anomalies");
export const nexusBrainTuning = () => request<any>("/api/nexus_brain/tuning");
export const nexusBrainResetTuning = () => request<any>("/api/nexus_brain/reset_tuning", { method: "POST", body: "{}" });

// Security — Proximity + Digital Twin (anti-tamper)
export const proximityStatus = () => request<any>("/api/security/proximity/status");
export const proximityEnable = () => request<any>("/api/security/proximity/enable", { method: "POST", body: "{}" });
export const proximityDisable = () => request<any>("/api/security/proximity/disable", { method: "POST", body: "{}" });
export const proximityHeartbeat = () => request<any>("/api/security/proximity/heartbeat", { method: "POST", body: "{}" });
export const twinStatus = () => request<any>("/api/security/twin/status");
export const twinEnable = () => request<any>("/api/security/twin/enable", { method: "POST", body: "{}" });
export const twinDisable = () => request<any>("/api/security/twin/disable", { method: "POST", body: "{}" });
export const twinScan = () => request<any>("/api/security/twin/scan", { method: "POST", body: "{}" }, { timeoutMs: 30000 });
export const twinBaselineTake = () => request<any>("/api/security/twin/baseline/take", { method: "POST", body: "{}" }, { timeoutMs: 60000 });
export const twinBaselineClear = () => request<any>("/api/security/twin/baseline/clear", { method: "POST", body: "{}" });
export const twinAlerts = () => request<any>("/api/security/twin/alerts");

// Undo / Rollback (file-level safety net)
export const undoList = () => request<any>("/api/undo/list");
export const undoRollback = (id: string) =>
  request<any>("/api/undo/rollback", { method: "POST", body: JSON.stringify({ id }) }, { timeoutMs: 20000 });

// Debug / Diagnostics
export const debugConnection = () => request<any>("/api/debug/connection");
export const debugAi = () => request<any>("/api/debug/ai");
export const debugKb = () => request<any>("/api/debug/kb");
export const debugSearch = (q: string) =>
  request<any>("/api/debug/search", { method: "POST", body: JSON.stringify({ q }) });
export const debugGuard = () => request<any>("/api/debug/guard");
export const serverLog = (lines = 200) => request<any>(`/api/server_log?lines=${lines}`);
export const sessions = () => request<any>("/api/sessions");
export const metrics = () => request<any>("/api/metrics");
export const performanceStats = () => request<any>("/api/performance");
export const version = () => request<any>("/api/version");
export const ping = () => request<any>("/api/ping");

// Crawler / KB extras
export const crawl = (url: string) =>
  request<any>("/api/crawl", { method: "POST", body: JSON.stringify({ url }) }, { timeoutMs: 30000 });
export const crawlBatch = (urls: string[]) =>
  request<any>("/api/crawl/batch", { method: "POST", body: JSON.stringify({ urls }) }, { timeoutMs: 60000 });
export const kbContribute = (entry: any) =>
  request<any>("/api/kb/contribute", { method: "POST", body: JSON.stringify(entry) });
export const kbExport = () => request<any>("/api/kb/export");
export const kbImport = (data: any) =>
  request<any>("/api/kb/import", { method: "POST", body: JSON.stringify(data) }, { timeoutMs: 30000 });
export const kbGrowth = () => request<any>("/api/kb/growth");
export const kbLog = () => request<any>("/api/kb/log");

// PC Check (system audit)
export const pcCheckScan = () => request<any>("/api/pc-check/scan", { method: "POST", body: "{}" }, { timeoutMs: 60000 });
export const pcCheckAction = (action: string, target?: string) =>
  request<any>("/api/pc-check/action", { method: "POST", body: JSON.stringify({ action, target }) }, { timeoutMs: 30000 });

// Pairing extras
export const pairQr = () => request<any>("/api/pair/qr");
export const handshake = () => request<any>("/api/handshake", { method: "POST", body: "{}" });
export const authRotate = () => request<any>("/api/auth/rotate", { method: "POST", body: "{}" });
