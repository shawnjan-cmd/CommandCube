/**
 * Connection Diagnostics — persistent connect/disconnect/ping log (web port).
 * Ported from BUTLER-AI/services/connectionDiagnostics.ts
 */
import { storage } from './storage';

export type DiagEventKind = 'connect' | 'disconnect' | 'ping' | 'fail' | 'reconnect' | 'scan';

export interface DiagEvent {
  id: string;
  kind: DiagEventKind;
  at: string;
  host?: string;
  port?: number;
  latencyMs?: number;
  message?: string;
}

const KEY = 'nexus_conn_diag_v1';
const MAX = 200;

async function load(): Promise<DiagEvent[]> {
  const raw = await storage.getItem(KEY);
  try { return raw ? (JSON.parse(raw) as DiagEvent[]) : []; } catch { return []; }
}
async function save(ev: DiagEvent[]): Promise<void> { await storage.setItem(KEY, JSON.stringify(ev.slice(0, MAX))); }

export const connectionDiagnostics = {
  async record(kind: DiagEventKind, data: Omit<Partial<DiagEvent>, 'id' | 'kind' | 'at'> = {}) {
    const list = await load();
    const ev: DiagEvent = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
      kind, at: new Date().toISOString(), ...data,
    };
    await save([ev, ...list]);
    return ev;
  },
  async getAll() { return load(); },
  async clear() { await storage.removeItem(KEY); },
  async exportText() {
    const list = await load();
    return list.map((e) => `[${e.at}] ${e.kind.toUpperCase()} ${e.host ?? ''}${e.port ? ':' + e.port : ''} ${e.latencyMs != null ? e.latencyMs + 'ms' : ''} ${e.message ?? ''}`.trim()).join('\n');
  },
};
