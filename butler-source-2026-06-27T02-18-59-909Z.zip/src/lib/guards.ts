/**
 * Input guards & route guards.
 * - zod schemas for every server-bound payload
 * - sanitizers for clipboard/keyboard input (server can execute these)
 * - `requireServerLink()` — throws redirect if PC server isn't paired
 */
import { z } from "zod";
import { redirect } from "@tanstack/react-router";
import { getConfig } from "./butler";

// ─── Schemas ────────────────────────────────────────────────────────────────
export const ChatMessageSchema = z.object({
  id: z.string().min(1).max(64),
  role: z.enum(["user", "assistant", "system"]),
  parts: z.array(z.any()).max(64),
});
export const ChatBodySchema = z.object({
  messages: z.array(ChatMessageSchema).min(1).max(50),
  kbContext: z.string().max(20_000).optional(),
});

export const ScriptIdSchema = z.string().min(1).max(120).regex(/^[a-zA-Z0-9_\-./]+$/, "invalid id");
export const FsPathSchema = z.string().min(1).max(1024).refine(
  (p) => !p.includes("\0"),
  "path contains null byte",
);
export const UrlSchema = z.string().url().max(2048);

export const ClipboardSchema = z.object({ text: z.string().max(100_000) });
export const KeyboardSchema = z.object({ text: z.string().max(10_000) });
export const PowerSchema = z.object({
  action: z.enum(["shutdown", "restart", "sleep", "lock"]),
});

// ─── Sanitizers ─────────────────────────────────────────────────────────────
/** Strip control chars except \n\r\t. Used before sending to server APIs. */
export function sanitizeText(s: string, max = 10_000): string {
  return String(s ?? "")
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "")
    .slice(0, max);
}

/** Safe parse helper — returns {ok, data, error} instead of throwing. */
export function safeParse<T>(schema: z.ZodType<T>, value: unknown):
  | { ok: true; data: T }
  | { ok: false; error: string } {
  const r = schema.safeParse(value);
  if (r.success) return { ok: true, data: r.data };
  const first = r.error.issues[0];
  return { ok: false, error: `${first?.path?.join(".") || "input"}: ${first?.message || "invalid"}` };
}

// ─── Route guards ───────────────────────────────────────────────────────────
/**
 * Throws redirect to /settings if the PC server isn't paired.
 * Use in `beforeLoad` for routes that depend on butler_server.
 */
export function requireServerLink() {
  if (typeof window === "undefined") return; // skip during SSR/prerender
  const cfg = getConfig();
  if (!cfg.paired || !cfg.baseUrl) {
    throw redirect({ to: "/settings", search: { reason: "needs-pair" } as any });
  }
}

/** Soft check — returns boolean, never throws. */
export function isServerLinked(): boolean {
  if (typeof window === "undefined") return false;
  const c = getConfig();
  return Boolean(c.paired && c.baseUrl);
}
