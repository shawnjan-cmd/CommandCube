/**
 * Pro License — free-forever stub (web port).
 * Ported from BUTLER-AI/services/proLicense.ts (all features unlocked).
 */
export type ProFeature = 'butler_chat' | 'knowledge_base' | 'scheduling' | 'custom_scripts' | 'file_share';

export interface ProLicenseState {
  isPro: boolean;
  purchaseId: string | null;
  purchasedAt: number | null;
  source: 'iap' | 'restore' | 'debug' | 'free' | null;
}

const STATE: ProLicenseState = {
  isPro: true,
  purchaseId: 'free_forever',
  purchasedAt: 0,
  source: 'free',
};

export const proLicense = {
  productId: 'com.butlerai.pc.automation.pro',
  priceLabel: 'Free',
  get isPro() { return true; },
  get state() { return STATE; },
  async load() { return STATE; },
  async purchase() { return { success: true as const }; },
  async restore() { return { success: true as const }; },
  canAccess(_f: ProFeature) { return true; },
  onChange(_cb: (s: ProLicenseState) => void) { return () => {}; },
};
