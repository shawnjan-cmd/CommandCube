/**
 * Tiny SSR-safe localStorage wrapper (AsyncStorage-shaped API).
 * All ported services from past projects use this.
 */
const safe = (): Storage | null => (typeof window !== 'undefined' ? window.localStorage : null);

export const storage = {
  async getItem(k: string): Promise<string | null> {
    try { return safe()?.getItem(k) ?? null; } catch { return null; }
  },
  async setItem(k: string, v: string): Promise<void> {
    try { safe()?.setItem(k, v); } catch {}
  },
  async removeItem(k: string): Promise<void> {
    try { safe()?.removeItem(k); } catch {}
  },
  async multiRemove(keys: string[]): Promise<void> {
    try { keys.forEach((k) => safe()?.removeItem(k)); } catch {}
  },
};
