import { useEffect, useMemo, useState } from "react";

const KEY = "butler-favorites-v1";

function read(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try { return new Set(JSON.parse(window.localStorage.getItem(KEY) ?? "[]")); }
  catch { return new Set(); }
}
function write(s: Set<string>) {
  try { window.localStorage.setItem(KEY, JSON.stringify([...s])); } catch {}
}

/** localStorage-backed favorites — synced across hooks via a tiny event bus. */
export function useFavorites() {
  const [fav, setFav] = useState<Set<string>>(() => read());
  useEffect(() => {
    const onStorage = () => setFav(read());
    window.addEventListener("storage", onStorage);
    window.addEventListener("butler-fav-change", onStorage);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("butler-fav-change", onStorage);
    };
  }, []);
  const toggle = (id: string) => {
    setFav((cur) => {
      const next = new Set(cur);
      next.has(id) ? next.delete(id) : next.add(id);
      write(next);
      window.dispatchEvent(new Event("butler-fav-change"));
      return next;
    });
  };
  const isFav = (id: string) => fav.has(id);
  return useMemo(() => ({ fav, isFav, toggle, count: fav.size }), [fav]);
}

const RUNS_KEY = "butler-run-history-v1";
export type RunEntry = { id: string; ts: number; ok: boolean; ms: number; name: string };
export function useRunHistory() {
  const [history, setHistory] = useState<RunEntry[]>(() => {
    if (typeof window === "undefined") return [];
    try { return JSON.parse(window.localStorage.getItem(RUNS_KEY) ?? "[]"); }
    catch { return []; }
  });
  const push = (entry: RunEntry) => {
    setHistory((cur) => {
      const next = [entry, ...cur].slice(0, 50);
      try { window.localStorage.setItem(RUNS_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  };
  const clear = () => {
    setHistory([]);
    try { window.localStorage.removeItem(RUNS_KEY); } catch {}
  };
  return { history, push, clear };
}
