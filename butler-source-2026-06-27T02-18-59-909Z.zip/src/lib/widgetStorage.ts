/**
 * Widget Storage v2 (web port).
 * Ported from BUTLER-AI/services/widgetStorage.ts
 */
import { storage } from './storage';

const KEY = '@butler_pinned_widgets_v2';

export type WidgetPlacement = 'floating' | 'inline-top' | 'inline-middle' | 'inline-bottom';

export interface PinnedWidget {
  id: string;
  pageId: string;
  label: string;
  code: string;
  placement: WidgetPlacement;
  x: number;
  y: number;
  height?: number;
  createdAt: string;
}

async function loadAll(): Promise<PinnedWidget[]> {
  const raw = await storage.getItem(KEY);
  try { return raw ? (JSON.parse(raw) as PinnedWidget[]) : []; } catch { return []; }
}
async function saveAll(w: PinnedWidget[]): Promise<void> { await storage.setItem(KEY, JSON.stringify(w)); }

export const widgetStorage = {
  async getForPage(pageId: string) {
    return (await loadAll()).filter((w) => w.pageId === pageId);
  },
  async getForPageByPlacement(pageId: string, placement: WidgetPlacement) {
    return (await loadAll()).filter((w) => w.pageId === pageId && w.placement === placement);
  },
  async pin(widget: Omit<PinnedWidget, 'id' | 'createdAt'>): Promise<PinnedWidget> {
    const all = await loadAll();
    const next: PinnedWidget = {
      ...widget,
      id: `widget_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString(),
    };
    await saveAll([...all, next]);
    return next;
  },
  async updatePosition(id: string, x: number, y: number) {
    await saveAll((await loadAll()).map((w) => (w.id === id ? { ...w, x, y } : w)));
  },
  async updateCode(id: string, code: string, label?: string) {
    await saveAll((await loadAll()).map((w) => (w.id === id ? { ...w, code, ...(label ? { label } : {}) } : w)));
  },
  async updateHeight(id: string, height: number) {
    await saveAll((await loadAll()).map((w) =>
      w.id === id ? { ...w, height: height > 0 ? Math.max(60, Math.round(height)) : undefined } : w,
    ));
  },
  async updatePlacement(id: string, placement: WidgetPlacement) {
    await saveAll((await loadAll()).map((w) => (w.id === id ? { ...w, placement } : w)));
  },
  async remove(id: string) {
    await saveAll((await loadAll()).filter((w) => w.id !== id));
  },
  async getAll() { return loadAll(); },
  async clearAll() { await storage.removeItem(KEY); },
};
