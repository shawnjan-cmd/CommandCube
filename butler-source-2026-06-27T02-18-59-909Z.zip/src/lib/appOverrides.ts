/**
 * Unified App Override Engine
 * -----------------------------------------------------------------------------
 * Accepts a single uploaded "master" payload — JSON or Markdown — and applies
 * every editable layer of the app at runtime:
 *
 *   - theme      → CSS variables, fonts, radius, raw CSS  (themeOverrides.ts)
 *   - text       → label/string overrides (getText)        (themeOverrides.ts)
 *   - files      → source-code snapshots (re-exportable, available on window)
 *   - data       → arbitrary JSON blobs keyed by name (library, config, etc.)
 *
 * Supports:
 *   - Filename-agnostic upload (.json, .md, .txt — detected by content)
 *   - Markdown bundle parsing  (``` path=<file> blocks → files map)
 *   - One-step UNDO (snapshots previous state on every apply)
 *   - Auto soft-reload so the UI reflects edits immediately
 */

import {
  applyTheme,
  persist as persistTheme,
  loadStored as loadStoredTheme,
  snapshotCurrentTheme,
  clearTheme,
  isThemeFile,
  type ButlerThemeFile,
  THEME_KEY,
  THEME_TEXT_KEY,
} from "./themeOverrides";

export const FILES_KEY = "butler.override.files.v1";
export const DATA_KEY  = "butler.override.data.v1";
export const UNDO_KEY  = "butler.override.undo.v1";
export const LAST_APPLIED_KEY = "butler.override.last.v1";

export type MasterPayload = {
  _type?: string;
  version?: string;
  name?: string;
  theme?: ButlerThemeFile;
  text?: Record<string, string>;
  files?: Record<string, string>;            // path → source
  data?: Record<string, unknown>;            // arbitrary JSON blobs
  // Top-level shortcuts (also accepted at root for convenience):
  colors?: Record<string, string>;
  fonts?: ButlerThemeFile["fonts"];
  radius?: ButlerThemeFile["radius"];
  vars?: Record<string, string>;
  css?: string;
};

export type ApplyResult = {
  ok: boolean;
  error?: string;
  appliedTheme: number;
  appliedText: number;
  appliedFiles: number;
  appliedData: number;
  fileList: string[];
  source: "json" | "markdown";
  snapshotForUndo: boolean;
};

/* --------------------------------- utils -------------------------------- */

function safeRead<T>(key: string): T | null {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : null; }
  catch { return null; }
}
function safeWrite(key: string, val: unknown) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

/* --------------------------- markdown bundle ---------------------------- */

/**
 * Parse a Butler Master `.md` bundle. Extracts every fenced code block whose
 * info string contains `path=<file>` and returns { files: { path: content } }.
 * Tolerates the ``` `lang path=foo` ``` shape used by the exporter.
 */
export function parseMarkdownBundle(md: string): MasterPayload {
  const files: Record<string, string> = {};
  // Matches ```<anything> path=<path>\n<body>\n```
  const re = /```[^\n`]*?path=([^\s`]+)\s*\n([\s\S]*?)\n```/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(md)) !== null) {
    const path = m[1].trim().replace(/^\/+/, "");
    if (!path) continue;
    files[path] = m[2];
  }
  return { _type: "butler_master_file", files };
}

/* ------------------------------ detection ------------------------------- */

export type ParsedUpload = { payload: MasterPayload; source: "json" | "markdown" };

export function parseUpload(raw: string): ParsedUpload {
  const trimmed = raw.trimStart();
  if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
    const j = JSON.parse(raw);
    // Tolerate a few shapes:
    if (j && typeof j === "object") {
      if (j.source_export && !j.files) {
        // Butler legacy export → flatten to files map.
        const files: Record<string, string> = {};
        for (const [k, v] of Object.entries(j.source_export as Record<string, any>)) {
          if (k === "_meta") continue;
          if (typeof v === "string") files[k] = v;
          else if (v && typeof v === "object" && typeof v.content === "string") files[k] = v.content;
        }
        return { payload: { ...j, files }, source: "json" };
      }
      return { payload: j as MasterPayload, source: "json" };
    }
    throw new Error("JSON did not decode to an object");
  }
  // Markdown / text fallback — pull fenced blocks.
  const parsed = parseMarkdownBundle(raw);
  if (!Object.keys(parsed.files ?? {}).length) {
    throw new Error("No `path=<file>` code blocks found in markdown");
  }
  return { payload: parsed, source: "markdown" };
}

/* ------------------------------ snapshots ------------------------------- */

type Snapshot = {
  ts: number;
  theme: string | null;       // raw stored theme JSON
  themeText: string | null;
  files: string | null;
  data: string | null;
  lastApplied: string | null;
};

function takeSnapshot(): Snapshot {
  return {
    ts: Date.now(),
    theme:       localStorage.getItem(THEME_KEY),
    themeText:   localStorage.getItem(THEME_TEXT_KEY),
    files:       localStorage.getItem(FILES_KEY),
    data:        localStorage.getItem(DATA_KEY),
    lastApplied: localStorage.getItem(LAST_APPLIED_KEY),
  };
}
function restoreSnapshot(s: Snapshot) {
  const setOrClear = (k: string, v: string | null) => {
    if (v == null) localStorage.removeItem(k);
    else localStorage.setItem(k, v);
  };
  setOrClear(THEME_KEY, s.theme);
  setOrClear(THEME_TEXT_KEY, s.themeText);
  setOrClear(FILES_KEY, s.files);
  setOrClear(DATA_KEY, s.data);
  setOrClear(LAST_APPLIED_KEY, s.lastApplied);
}

export function hasUndo(): boolean {
  return !!safeRead<Snapshot>(UNDO_KEY);
}
export function undoLast(): { ok: boolean; error?: string } {
  const snap = safeRead<Snapshot>(UNDO_KEY);
  if (!snap) return { ok: false, error: "Nothing to undo" };
  try {
    restoreSnapshot(snap);
    localStorage.removeItem(UNDO_KEY);
    return { ok: true };
  } catch (e: any) { return { ok: false, error: e?.message ?? "Undo failed" }; }
}

/* --------------------------------- apply -------------------------------- */

export function getFiles(): Record<string, string> {
  return safeRead<Record<string, string>>(FILES_KEY) ?? {};
}
export function getData(): Record<string, unknown> {
  return safeRead<Record<string, unknown>>(DATA_KEY) ?? {};
}

export function applyMaster(payload: MasterPayload, source: "json" | "markdown"): ApplyResult {
  if (typeof window === "undefined") {
    return { ok: false, error: "Browser only", appliedTheme: 0, appliedText: 0,
             appliedFiles: 0, appliedData: 0, fileList: [], source, snapshotForUndo: false };
  }

  // 1) Snapshot current state for undo BEFORE we change anything.
  const snap = takeSnapshot();
  safeWrite(UNDO_KEY, snap);

  // 2) Theme — accept nested `.theme` OR top-level shortcuts.
  const themeBlock: ButlerThemeFile | null = payload.theme
    ? payload.theme
    : (payload.colors || payload.fonts || payload.radius || payload.vars || payload.css)
      ? { _type: "butler_theme_file", colors: payload.colors, fonts: payload.fonts,
          radius: payload.radius, vars: payload.vars, css: payload.css }
      : null;

  let appliedTheme = 0;
  if (themeBlock && isThemeFile(themeBlock)) {
    applyTheme(themeBlock);
    persistTheme(themeBlock);
    appliedTheme =
      Object.keys(themeBlock.colors ?? {}).length +
      Object.keys(themeBlock.vars ?? {}).length +
      Object.keys(themeBlock.radius ?? {}).length +
      Object.keys(themeBlock.fonts ?? {}).length;
  }

  // 3) Text labels
  let appliedText = 0;
  if (payload.text && typeof payload.text === "object") {
    const merged = { ...(safeRead<Record<string, string>>(THEME_TEXT_KEY) ?? {}), ...payload.text };
    safeWrite(THEME_TEXT_KEY, merged);
    (window as any).__BUTLER_TEXT__ = merged;
    appliedText = Object.keys(payload.text).length;
  }

  // 4) Files — store and expose on window for any component that reads overrides.
  const files = payload.files ?? {};
  const fileList = Object.keys(files);
  if (fileList.length) {
    const merged = { ...getFiles(), ...files };
    safeWrite(FILES_KEY, merged);
    (window as any).__BUTLER_FILE_OVERRIDES__ = merged;
  }

  // 5) Arbitrary data blobs
  let appliedData = 0;
  if (payload.data && typeof payload.data === "object") {
    const merged = { ...getData(), ...payload.data };
    safeWrite(DATA_KEY, merged);
    (window as any).__BUTLER_DATA_OVERRIDES__ = merged;
    appliedData = Object.keys(payload.data).length;
  }

  // 6) Record what we applied (for the UI summary + diagnostics)
  const summary = {
    ts: Date.now(),
    source,
    appliedTheme, appliedText, appliedFiles: fileList.length, appliedData,
    fileList: fileList.slice(0, 64),
  };
  safeWrite(LAST_APPLIED_KEY, summary);

  window.dispatchEvent(new CustomEvent("butler:master-applied", { detail: summary }));
  window.dispatchEvent(new CustomEvent("butler:theme-changed", { detail: themeBlock }));

  return {
    ok: true,
    appliedTheme, appliedText,
    appliedFiles: fileList.length,
    appliedData,
    fileList,
    source,
    snapshotForUndo: true,
  };
}

/** One-shot helper: parse + apply + optionally reload. */
export function importMasterFromText(raw: string, opts?: { autoReload?: boolean }): ApplyResult {
  const { payload, source } = parseUpload(raw);
  const r = applyMaster(payload, source);
  if (r.ok && opts?.autoReload) {
    // Give toast a tick to render before reload.
    setTimeout(() => { try { window.location.reload(); } catch {} }, 350);
  }
  return r;
}

/* ----------------------------- boot / rehydrate -------------------------- */

export function bootAppOverrides(): void {
  if (typeof window === "undefined") return;
  const files = getFiles();
  if (Object.keys(files).length) (window as any).__BUTLER_FILE_OVERRIDES__ = files;
  const data = getData();
  if (Object.keys(data).length) (window as any).__BUTLER_DATA_OVERRIDES__ = data;
}

/* ----------------------------- master template -------------------------- */

/** Produce a JSON skeleton listing every editable surface a user can change. */
export function masterTemplate(): MasterPayload {
  const theme = loadStoredTheme();
  return {
    _type: "butler_master_file",
    version: "2.0",
    name: "Butler Master Override",
    theme: theme ?? {
      _type: "butler_theme_file",
      colors: { cyan: "#00ffd1", magenta: "#ff3df7", background: "#04060c" },
      fonts:  { display: "Orbitron, sans-serif", sans: "Inter, sans-serif", mono: "JetBrains Mono, monospace" },
      radius: { md: "6px", lg: "10px" },
    },
    text: {
      "app.title":   "Butler AI",
      "app.tagline": "Local-only PC butler",
      "nav.core":    "CORE",
      "nav.ops":     "OPS",
    },
    files: {
      // "src/routes/home.tsx": "<paste full file source here to override at runtime>",
    },
    data: {
      // "library.extra": [{ id: "ex1", title: "My script", body: "..." }],
    },
  };
}

export { clearTheme };

/* -------------------- export current master (live snapshot) ------------- */

/**
 * Capture EVERYTHING currently editable through the override pipeline:
 * - the live applied theme (CSS vars / fonts / radius / raw CSS)
 * - every text/label override
 * - every file override snapshot
 * - every data blob
 *
 * The returned object is round-trip safe: re-uploading it via UPLOAD MASTER
 * reproduces the exact same runtime state.
 */
export function exportCurrentMaster(): MasterPayload {
  const theme = loadStoredTheme() ?? snapshotCurrentTheme();
  const text  = safeRead<Record<string, string>>(THEME_TEXT_KEY) ?? {};
  const files = getFiles();
  const data  = getData();
  return {
    _type: "butler_master_file",
    version: "2.0",
    name: `Butler Master Export ${new Date().toISOString()}`,
    theme,
    text,
    files,
    data,
  };
}

/* ----------------------- AI upgrade prompt (clipboard) ------------------ */

/**
 * A long, defensive prompt to paste alongside the exported master file when
 * asking another AI (Claude / GPT / Gemini) to upgrade the app offline.
 * Tells the AI exactly what it may and may not do, what the file is, what
 * shape to return, and what mistakes destroy the app.
 */
export const AI_UPGRADE_PROMPT = `# BUTLER AI — OFFLINE UPGRADE PROMPT (read fully before editing)

You are being given a single JSON file exported from a running React + TanStack
Start app called "Butler AI". The file is a **master override bundle**. The
running app loads it at startup and applies every field live without rebuilding.
Your job: improve the app by editing this file and returning a NEW JSON file in
the SAME shape. The user will upload your output back into the app and it will
auto-apply + soft-reload.

## What the file contains
Top-level keys (all optional except _type):
- "_type":   must stay "butler_master_file"
- "version": bump if you make breaking changes, else keep
- "name":    human label
- "theme":   { _type:"butler_theme_file", colors, fonts, radius, vars, css }
- "text":    { "key.path": "Label string", ... }   // UI label overrides
- "files":   { "src/routes/home.tsx": "<full file source>", ... }
- "data":    { "library.extra": [...], ... }       // arbitrary JSON blobs

## What you ARE allowed to do
- Edit / add / remove THEME colors, fonts, radius, vars, css.
- Edit / add / remove TEXT label overrides.
- Add or replace entries in FILES with full, valid source for that path.
- Add or replace entries in DATA.
- Add new keys under "data" for new features.
- Improve visual design, spacing, typography, micro-interactions, copy.
- Refactor a file's internals as long as its default export and props stay compatible.

## What you MUST NOT do (these break the app)
1. DO NOT delete keys you did not author just because you "didn't need them".
   Preserve every existing theme color, text key, file entry, and data blob
   unless the user explicitly asked you to remove it. Unknown keys are used
   by other parts of the app you cannot see.
2. DO NOT change "_type" values. "butler_master_file" and "butler_theme_file"
   are how the loader detects the payload.
3. DO NOT return Markdown, prose, code fences, or commentary OUTSIDE the JSON.
   The user uploads the raw file — extra text will fail to parse. Return ONLY
   a single JSON object. No \`\`\`json fences. No leading "Here is...".
4. DO NOT rename routes, components, or default exports inside "files". Routes
   are file-path based; renaming the file or its export breaks navigation.
5. DO NOT introduce new npm imports inside "files" entries. The runtime cannot
   install packages from an override. Only use imports that already exist in
   the file you are replacing.
6. DO NOT use Node-only APIs (fs, child_process, path) in client files. The
   app runs in the browser; server logic lives on Cloudflare Workers and is
   NOT editable through this file.
7. DO NOT touch authentication, secrets, API keys, or environment variables.
   They are not in this file and cannot be set from it.
8. DO NOT remove the "_type" or rename "theme" / "text" / "files" / "data".
9. DO NOT inline gigantic base64 assets. Keep the file under ~2 MB.
10. DO NOT replace a file with a stub or "TODO" — partial files crash the route.

## What CANNOT be edited via this file (do not try)
- Server functions, API routes, database schema, environment secrets.
- Installed npm dependencies / package.json / lockfile.
- Vite config, TanStack route tree generation, build pipeline.
- Anything under src/routes/api/*  (server-only).
- The override engine itself (src/lib/appOverrides.ts, themeOverrides.ts).
- Native Android wrapper / Capacitor / Expo config.

If the user asks for one of the above, return JSON with an unchanged payload
and add a "data._notes" string explaining the limitation. Do not silently
no-op.

## Theme block — exact shape
"theme": {
  "_type": "butler_theme_file",
  "colors": {
    "background": "#04060c",
    "foreground": "#e6f7ff",
    "cyan":       "#00ffd1",
    "magenta":    "#ff3df7",
    "border":     "#0b1726"
    // ... keep every existing color key
  },
  "fonts":  { "display": "Orbitron, sans-serif", "sans": "Inter, sans-serif", "mono": "JetBrains Mono, monospace" },
  "radius": { "md": "6px", "lg": "10px" },
  "vars":   { "shadow-cyan": "0 0 18px rgba(0,255,209,.35)" },
  "css":    "/* optional raw CSS appended after vars */"
}

Color values must be valid CSS (#hex, rgb(), hsl(), or a CSS keyword). Do not
use Tailwind class names here.

## File overrides — exact shape
Each value MUST be the COMPLETE source of the file at that path, valid
TypeScript/TSX, parseable by Vite + SWC, with ALL imports the file uses and
a matching default export (for routes) or named export (for components).

"files": {
  "src/components/Foo.tsx": "import { useState } from 'react';\\nexport function Foo(){ ... }\\n"
}

Checklist before returning a file entry:
- [ ] Every JSX tag is balanced.
- [ ] Every "import ... from '...'" path already exists in the project.
- [ ] Default export name and props signature unchanged (for routes/pages).
- [ ] No "...rest of file omitted" placeholders.
- [ ] No TypeScript syntax errors. Prefer plain types over exotic generics.
- [ ] Uses existing CSS variables (var(--cyan), var(--ink)) instead of hardcoded colors.

## Text overrides — exact shape
Flat string-to-string map. Keys are dotted names already in the codebase:
"text": { "app.title": "Butler AI", "nav.core": "CORE", "nav.ops": "OPS" }
Adding new keys is fine but they only render where getText("the.key") is called.

## Data overrides — exact shape
Arbitrary JSON keyed by name. Used by components that opt in via
__BUTLER_DATA_OVERRIDES__. Safe to extend.

## Output contract (read twice)
Return a SINGLE JSON object, nothing else. Start with "{" and end with "}".
Preserve unknown fields verbatim. If you are unsure, copy the original value
through unchanged rather than dropping it. When in doubt: small, surgical
diffs beat sweeping rewrites.

## Failure modes to actively avoid
- "It loaded but the page is blank"  → you broke a JSX balance or removed a default export.
- "Upload failed: JSON did not decode" → you wrapped output in \`\`\`json fences.
- "Theme reverted"                   → you removed required color keys.
- "Route 404 after upload"           → you renamed a file path or its export.
- "Hydration mismatch"               → you used Date.now()/Math.random() at module scope in a route.

## Final reminder
The user will simply drop your JSON into the UPLOAD MASTER button. There is no
review step. If your output is malformed, the app rolls back via UNDO and your
work is discarded. Be conservative, complete, and correct. Return ONLY the JSON.
`;

