/**
 * Theme Override Engine
 * -----------------------------------------------------------------------------
 * Loads a "butler_theme_file" JSON and applies it live to the running app by
 * injecting a <style id="butler-theme-overrides"> block that sets CSS variables
 * on :root, plus optional text/label overrides exposed on window.__BUTLER_TEXT__.
 *
 * - Persists to localStorage so refresh keeps the theme.
 * - Re-hydrates on app boot.
 * - Safe to call repeatedly; replaces the previous override block.
 */

export const THEME_KEY = "butler.theme.override.v1";
export const THEME_TEXT_KEY = "butler.theme.text.v1";
const STYLE_ID = "butler-theme-overrides";

export type ButlerThemeFile = {
  _type?: "butler_theme_file";
  version?: string;
  name?: string;
  /** CSS variable overrides — keys map to :root vars (without leading --). */
  colors?: Record<string, string>;
  /** font-family overrides for --font-display / --font-sans / --font-mono */
  fonts?: { display?: string; sans?: string; mono?: string };
  /** Border radius overrides (sm/md/lg/xl/2xl) */
  radius?: Partial<Record<"sm" | "md" | "lg" | "xl" | "2xl", string>>;
  /** Arbitrary --var: value pairs (advanced) */
  vars?: Record<string, string>;
  /** Text/label overrides accessible via getText(key) */
  text?: Record<string, string>;
  /** Optional raw CSS appended after generated vars */
  css?: string;
};

/* ------------------------------- defaults ------------------------------- */

const COLOR_KEYS = [
  "background", "foreground", "surface", "surface-2", "border", "muted",
  "muted-foreground", "cyan", "cyan-dim", "green", "green-dim", "magenta",
  "magenta-dim", "orange", "orange-dim", "red", "yellow",
  "ink", "ink-2", "ink-3", "ink-deep",
] as const;

/** Read currently-applied :root values so we can produce a template. */
export function snapshotCurrentTheme(): ButlerThemeFile {
  if (typeof window === "undefined") return { _type: "butler_theme_file", colors: {} };
  const cs = getComputedStyle(document.documentElement);
  const colors: Record<string, string> = {};
  for (const k of COLOR_KEYS) {
    const v = cs.getPropertyValue(`--${k}`).trim();
    if (v) colors[k] = v;
  }
  return {
    _type: "butler_theme_file",
    version: "1.0",
    name: "Butler Theme Snapshot",
    colors,
    fonts: {
      display: cs.getPropertyValue("--font-display").trim() || undefined,
      sans:    cs.getPropertyValue("--font-sans").trim() || undefined,
      mono:    cs.getPropertyValue("--font-mono").trim() || undefined,
    },
    radius: {
      sm:  cs.getPropertyValue("--radius-sm").trim() || undefined,
      md:  cs.getPropertyValue("--radius-md").trim() || undefined,
      lg:  cs.getPropertyValue("--radius-lg").trim() || undefined,
      xl:  cs.getPropertyValue("--radius-xl").trim() || undefined,
      "2xl": cs.getPropertyValue("--radius-2xl").trim() || undefined,
    },
    text: loadText() ?? {},
  };
}

/* ------------------------------- validate ------------------------------- */

export function isThemeFile(j: unknown): j is ButlerThemeFile {
  if (!j || typeof j !== "object") return false;
  const o = j as Record<string, unknown>;
  if (o._type === "butler_theme_file") return true;
  // Heuristic: accept any object with a colors/fonts/vars/text block.
  return Boolean(o.colors || o.fonts || o.vars || o.text || o.radius || o.css);
}

/* --------------------------------- apply -------------------------------- */

function buildCss(theme: ButlerThemeFile): string {
  const lines: string[] = [];
  lines.push(":root {");
  if (theme.colors) {
    for (const [k, v] of Object.entries(theme.colors)) {
      if (typeof v === "string" && v.trim()) lines.push(`  --${k}: ${v};`);
    }
  }
  if (theme.fonts) {
    if (theme.fonts.display) lines.push(`  --font-display: ${theme.fonts.display};`);
    if (theme.fonts.sans)    lines.push(`  --font-sans: ${theme.fonts.sans};`);
    if (theme.fonts.mono)    lines.push(`  --font-mono: ${theme.fonts.mono};`);
  }
  if (theme.radius) {
    for (const [k, v] of Object.entries(theme.radius)) {
      if (v) lines.push(`  --radius-${k}: ${v};`);
    }
  }
  if (theme.vars) {
    for (const [k, v] of Object.entries(theme.vars)) {
      const key = k.startsWith("--") ? k : `--${k}`;
      if (typeof v === "string" && v.trim()) lines.push(`  ${key}: ${v};`);
    }
  }
  lines.push("}");
  if (theme.css && typeof theme.css === "string") lines.push(theme.css);
  return lines.join("\n");
}

export function applyTheme(theme: ButlerThemeFile): void {
  if (typeof document === "undefined") return;
  let el = document.getElementById(STYLE_ID) as HTMLStyleElement | null;
  if (!el) {
    el = document.createElement("style");
    el.id = STYLE_ID;
    document.head.appendChild(el);
  }
  el.textContent = buildCss(theme);
  if (theme.text) {
    (window as any).__BUTLER_TEXT__ = { ...(loadText() ?? {}), ...theme.text };
    try { localStorage.setItem(THEME_TEXT_KEY, JSON.stringify((window as any).__BUTLER_TEXT__)); } catch {}
  }
  // Notify any listeners (TopBar, headers etc.) to re-render text labels.
  window.dispatchEvent(new CustomEvent("butler:theme-changed", { detail: theme }));
}

export function persist(theme: ButlerThemeFile): void {
  try { localStorage.setItem(THEME_KEY, JSON.stringify(theme)); } catch {}
}

export function clearTheme(): void {
  try { localStorage.removeItem(THEME_KEY); } catch {}
  try { localStorage.removeItem(THEME_TEXT_KEY); } catch {}
  const el = document.getElementById(STYLE_ID);
  if (el) el.remove();
  (window as any).__BUTLER_TEXT__ = {};
  window.dispatchEvent(new CustomEvent("butler:theme-changed", { detail: null }));
}

export function loadStored(): ButlerThemeFile | null {
  try {
    const raw = localStorage.getItem(THEME_KEY);
    if (!raw) return null;
    const j = JSON.parse(raw);
    return isThemeFile(j) ? j : null;
  } catch { return null; }
}

export function loadText(): Record<string, string> | null {
  try {
    const raw = localStorage.getItem(THEME_TEXT_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch { return null; }
}

/** Read a labeled text override; returns fallback if not present. */
export function getText(key: string, fallback: string): string {
  if (typeof window === "undefined") return fallback;
  const map = (window as any).__BUTLER_TEXT__ || loadText() || {};
  return typeof map[key] === "string" ? map[key] : fallback;
}

/** Apply persisted theme on boot. Call once from RootComponent. */
export function bootThemeOverrides(): void {
  if (typeof document === "undefined") return;
  const stored = loadStored();
  const text = loadText();
  if (text) (window as any).__BUTLER_TEXT__ = text;
  if (stored) applyTheme(stored);
}

/** Top-level entry: import a theme file, persist, apply, return summary. */
export function importTheme(json: unknown): {
  ok: boolean;
  applied: number;
  error?: string;
  theme?: ButlerThemeFile;
} {
  if (!isThemeFile(json)) return { ok: false, applied: 0, error: "Not a butler_theme_file" };
  const t = json as ButlerThemeFile;
  applyTheme(t);
  persist(t);
  const applied =
    Object.keys(t.colors ?? {}).length +
    Object.keys(t.vars ?? {}).length +
    Object.keys(t.radius ?? {}).length +
    Object.keys(t.fonts ?? {}).length +
    Object.keys(t.text ?? {}).length;
  return { ok: true, applied, theme: t };
}

/** Download a JSON file in-browser. */
export function downloadJson(name: string, data: unknown): void {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Built-in template a user can download, edit, and re-upload. */
export function templateTheme(): ButlerThemeFile {
  const snap = snapshotCurrentTheme();
  return {
    _type: "butler_theme_file",
    version: "1.0",
    name: "Butler Theme Template",
    colors: snap.colors,
    fonts:  snap.fonts,
    radius: snap.radius,
    vars: {
      "border-strong": "color-mix(in oklab, var(--cyan) 36%, transparent)",
    },
    text: {
      "app.title":  "Butler AI",
      "app.tagline": "Local-only PC butler",
    },
    css: "/* Optional raw CSS appended after the generated :root block.\n   Example: body { background-image: radial-gradient(circle at 50% 0%, var(--cyan)22, transparent 60%); } */",
  };
}
