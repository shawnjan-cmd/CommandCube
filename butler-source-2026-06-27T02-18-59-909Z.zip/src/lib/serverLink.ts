/**
 * 🔌 SERVER LINK — web port of CommandCube serverConnection + heartbeat + persistence.
 *
 * Singleton that:
 *  • remembers last-known IP/port in localStorage
 *  • probes common Butler/Ollama ports across known hosts
 *  • keeps a heartbeat to track live latency
 *  • exposes pub/sub for React hooks and UI badges
 *
 * Works entirely client-side. Never throws — all errors are swallowed and reflected
 * as a disconnected status. Safe to call from SSR (operations no-op without window).
 */

import { networkMonitor } from "./networkMonitor";
import { connectionDiagnostics } from "./connectionDiagnostics";



const KEYS = {
  IP: "butler.link.ip",
  PORT: "butler.link.port",
  TOKEN: "butler.link.token",
  KNOWN: "butler.link.known.v1",
  LAST_OK: "butler.link.last_ok",
} as const;

const COMMON_PORTS = [
  8765, 8766, 8000, 8080, 5000, 3000, 3001, 4000,
  11434, // ollama
  8888, 9000, 9090, 7860,
] as const;

const PROBE_PATHS = ["/api/status", "/status", "/health", "/api/health", "/"];
const DEFAULT_HOSTS = ["127.0.0.1", "localhost"];
const TIMEOUT_MS = 1800;
const HEARTBEAT_MS = 15_000;

export type LinkStatus =
  | "idle"
  | "discovering"
  | "connecting"
  | "connected"
  | "disconnected";

export interface LinkState {
  status: LinkStatus;
  ip: string;
  port: string;
  latencyMs: number | null;
  lastOkAt: number | null;
  error?: string;
}

const SSR = typeof window === "undefined";

function lsGet(k: string) {
  if (SSR) return null;
  try { return window.localStorage.getItem(k); } catch { return null; }
}
function lsSet(k: string, v: string) {
  if (SSR) return;
  try { window.localStorage.setItem(k, v); } catch {}
}
function lsDel(k: string) {
  if (SSR) return;
  try { window.localStorage.removeItem(k); } catch {}
}

async function pingOnce(ip: string, port: string, signal?: AbortSignal): Promise<number | null> {
  if (SSR) return null;
  const base = `http://${ip}:${port}`;
  for (const path of PROBE_PATHS) {
    const t0 = performance.now();
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
      signal?.addEventListener("abort", () => ctrl.abort(), { once: true });
      const res = await fetch(base + path, {
        method: "GET",
        mode: "cors",
        signal: ctrl.signal,
        headers: { Accept: "application/json,text/plain,*/*" },
      });
      clearTimeout(t);
      if (res.ok || res.status === 401 || res.status === 204) {
        return Math.round(performance.now() - t0);
      }
    } catch {
      /* try next path */
    }
  }
  return null;
}

class ServerLink {
  private state: LinkState = {
    status: "idle",
    ip: lsGet(KEYS.IP) ?? "",
    port: lsGet(KEYS.PORT) ?? "",
    latencyMs: null,
    lastOkAt: Number(lsGet(KEYS.LAST_OK)) || null,
  };
  private listeners = new Set<(s: LinkState) => void>();
  private timer: ReturnType<typeof setInterval> | null = null;
  private discovering = false;

  getState(): LinkState {
    return this.state;
  }

  subscribe(fn: (s: LinkState) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit(patch: Partial<LinkState>) {
    this.state = { ...this.state, ...patch };
    for (const fn of this.listeners) fn(this.state);
  }

  knownGood(): Array<{ ip: string; port: string }> {
    try {
      const raw = lsGet(KEYS.KNOWN);
      if (!raw) return [];
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr.filter((x) => x?.ip && x?.port) : [];
    } catch { return []; }
  }

  private rememberGood(ip: string, port: string) {
    const list = this.knownGood().filter((x) => !(x.ip === ip && x.port === port));
    list.unshift({ ip, port });
    lsSet(KEYS.KNOWN, JSON.stringify(list.slice(0, 8)));
  }

  /** Manually set host/port and verify. */
  async connect(ip: string, port: string | number): Promise<boolean> {
    if (SSR) return false;
    const portStr = String(port).trim();
    const ipStr = ip.trim();
    if (!ipStr || !portStr) return false;
    this.emit({ status: "connecting", ip: ipStr, port: portStr, error: undefined });
    const latency = await pingOnce(ipStr, portStr);
    if (latency != null) {
      lsSet(KEYS.IP, ipStr);
      lsSet(KEYS.PORT, portStr);
      const now = Date.now();
      lsSet(KEYS.LAST_OK, String(now));
      this.rememberGood(ipStr, portStr);
      this.emit({ status: "connected", latencyMs: latency, lastOkAt: now });
      void networkMonitor.log("CONNECT_OK", { ip: ipStr, port: portStr, ms: latency });
      void connectionDiagnostics.record("connect", { host: ipStr, port: Number(portStr), latencyMs: latency });
      this.startHeartbeat();
      return true;
    }
    this.emit({ status: "disconnected", latencyMs: null, error: "no response" });
    void networkMonitor.log("CONNECT_FAIL", { ip: ipStr, port: portStr });
    void connectionDiagnostics.record("fail", { host: ipStr, port: Number(portStr), message: "no response" });
    return false;
  }

  disconnect() {
    this.stopHeartbeat();
    lsDel(KEYS.TOKEN);
    this.emit({ status: "disconnected", latencyMs: null });
    void networkMonitor.log("DISCONNECT", { ip: this.state.ip, port: this.state.port });
    void connectionDiagnostics.record("disconnect", { host: this.state.ip, port: Number(this.state.port) || undefined });
  }

  /** Probe last-known + known-good + common defaults until something answers. */
  async autoDiscover(extraHosts: string[] = []): Promise<boolean> {
    if (SSR || this.discovering) return false;
    this.discovering = true;
    this.emit({ status: "discovering" });
    try {
      const targets: Array<{ ip: string; port: string }> = [];
      const seen = new Set<string>();
      const add = (ip?: string, port?: string) => {
        if (!ip || !port) return;
        const k = `${ip}:${port}`;
        if (seen.has(k)) return;
        seen.add(k);
        targets.push({ ip, port });
      };
      add(this.state.ip, this.state.port);
      for (const k of this.knownGood()) add(k.ip, k.port);
      const hosts = [...new Set([...extraHosts, ...DEFAULT_HOSTS])];
      for (const h of hosts) for (const p of COMMON_PORTS) add(h, String(p));

      for (const { ip, port } of targets) {
        const latency = await pingOnce(ip, port);
        if (latency != null) {
          lsSet(KEYS.IP, ip);
          lsSet(KEYS.PORT, port);
          const now = Date.now();
          lsSet(KEYS.LAST_OK, String(now));
          this.rememberGood(ip, port);
          this.emit({ status: "connected", ip, port, latencyMs: latency, lastOkAt: now });
          this.startHeartbeat();
          return true;
        }
      }
      this.emit({ status: "disconnected", latencyMs: null, error: "no host answered" });
      return false;
    } finally {
      this.discovering = false;
    }
  }

  startHeartbeat() {
    if (SSR || this.timer) return;
    this.timer = setInterval(() => void this.tick(), HEARTBEAT_MS);
  }

  stopHeartbeat() {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
  }

  private async tick() {
    if (!this.state.ip || !this.state.port) return;
    const latency = await pingOnce(this.state.ip, this.state.port);
    if (latency != null) {
      const now = Date.now();
      lsSet(KEYS.LAST_OK, String(now));
      this.emit({ status: "connected", latencyMs: latency, lastOkAt: now });
    } else if (this.state.status === "connected") {
      this.emit({ status: "disconnected", latencyMs: null, error: "heartbeat lost" });
    }
  }
}

export const serverLink = new ServerLink();

/** Best-effort bootstrap call — fire-and-forget on first client load. */
export function bootServerLink() {
  if (SSR) return;
  const ip = lsGet(KEYS.IP);
  const port = lsGet(KEYS.PORT);
  if (ip && port) void serverLink.connect(ip, port);
}
