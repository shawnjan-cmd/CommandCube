/**
 * Network Monitor — circular event log + stats (web port).
 * Ported from BUTLER-AI/services/networkMonitor.ts (slimmed for web).
 */
import { storage } from './storage';

const LOG_KEY = '@netmon_log_v1';
const STATS_KEY = '@netmon_stats_v1';
const MAX_LOG_SIZE = 200;

export type NetEventType =
  | 'CONNECT_OK' | 'CONNECT_FAIL' | 'PING_OK' | 'PING_FAIL'
  | 'SCAN_START' | 'SCAN_FOUND' | 'SCAN_EMPTY'
  | 'RECONNECT_OK' | 'RECONNECT_FAIL' | 'DISCONNECT'
  | 'PORT_DISCOVERED' | 'IP_CHANGED' | 'TIMEOUT'
  | 'ENGINE_START' | 'ENGINE_STOP';

export interface NetLogEntry {
  id: number;
  ts: number;
  type: NetEventType;
  ip?: string;
  port?: string;
  ms?: number;
  error?: string;
  success: boolean;
}

export interface NetStats {
  totalAttempts: number;
  totalSuccesses: number;
  totalFailures: number;
  avgLatencyMs: number;
  lastSuccessTs: number;
  lastFailureTs: number;
  portHistory: Record<string, { ok: number; fail: number }>;
  ipHistory: Record<string, { ok: number; fail: number; lastSeen: number }>;
  failStreak: number;
  successStreak: number;
}

const DEFAULT_STATS: NetStats = {
  totalAttempts: 0, totalSuccesses: 0, totalFailures: 0,
  avgLatencyMs: 0, lastSuccessTs: 0, lastFailureTs: 0,
  portHistory: {}, ipHistory: {}, failStreak: 0, successStreak: 0,
};

let memLog: NetLogEntry[] = [];
let memStats: NetStats = { ...DEFAULT_STATS };
let nextId = 1;
let loaded = false;

async function ensureLoaded() {
  if (loaded) return;
  loaded = true;
  const [rawL, rawS] = await Promise.all([storage.getItem(LOG_KEY), storage.getItem(STATS_KEY)]);
  try { if (rawL) memLog = JSON.parse(rawL); } catch {}
  try { if (rawS) memStats = { ...DEFAULT_STATS, ...JSON.parse(rawS) }; } catch {}
  nextId = (memLog[0]?.id ?? 0) + 1;
}

function flush() {
  storage.setItem(LOG_KEY, JSON.stringify(memLog.slice(0, MAX_LOG_SIZE)));
  storage.setItem(STATS_KEY, JSON.stringify(memStats));
}

export const networkMonitor = {
  async log(type: NetEventType, data: { ip?: string; port?: string; ms?: number; error?: string } = {}) {
    await ensureLoaded();
    const success = type.endsWith('_OK') || type === 'SCAN_FOUND' || type === 'PORT_DISCOVERED';
    const entry: NetLogEntry = { id: nextId++, ts: Date.now(), type, success, ...data };
    memLog = [entry, ...memLog].slice(0, MAX_LOG_SIZE);

    if (type === 'CONNECT_OK' || type === 'PING_OK' || type === 'RECONNECT_OK') {
      memStats.totalAttempts++; memStats.totalSuccesses++;
      memStats.successStreak++; memStats.failStreak = 0;
      memStats.lastSuccessTs = entry.ts;
      if (data.ms != null) {
        const n = memStats.totalSuccesses;
        memStats.avgLatencyMs = Math.round(((memStats.avgLatencyMs * (n - 1)) + data.ms) / n);
      }
    } else if (type === 'CONNECT_FAIL' || type === 'PING_FAIL' || type === 'RECONNECT_FAIL' || type === 'TIMEOUT') {
      memStats.totalAttempts++; memStats.totalFailures++;
      memStats.failStreak++; memStats.successStreak = 0;
      memStats.lastFailureTs = entry.ts;
    }

    if (data.port) {
      const p = (memStats.portHistory[data.port] ??= { ok: 0, fail: 0 });
      success ? p.ok++ : p.fail++;
    }
    if (data.ip) {
      const ip = (memStats.ipHistory[data.ip] ??= { ok: 0, fail: 0, lastSeen: 0 });
      success ? ip.ok++ : ip.fail++;
      ip.lastSeen = entry.ts;
    }
    flush();
    return entry;
  },
  async getLog() { await ensureLoaded(); return memLog.slice(); },
  async getStats() { await ensureLoaded(); return { ...memStats }; },
  async clear() {
    memLog = []; memStats = { ...DEFAULT_STATS };
    await Promise.all([storage.removeItem(LOG_KEY), storage.removeItem(STATS_KEY)]);
  },
};
