// Butler Master ingestion / persistence / runtime apply
// Ported from Butler AI Home. Web-safe (browser localStorage only).

export const BUTLER_MASTER_KEY = "commandcube.butlerMaster.v1";

export type ButlerMasterFile = {
  _master_export?: boolean;
  _type?: string;
  _meta?: Record<string, unknown>;
  source_export?: Record<string, { type?: string; content?: string } | unknown>;
  _guard_hash?: string;
  _guard_ts?: string;
  _lovable_enhanced?: Record<string, unknown>;
  _index?: { files?: string[] };
};

export type ImportResult = {
  ok: boolean;
  fileCount: number;
  applied: string[];
  errors: string[];
};

function safe<T>(fn: () => T, fallback: T): T {
  try { return fn(); } catch { return fallback; }
}

export function validate(master: unknown): master is ButlerMasterFile {
  if (!master || typeof master !== "object") return false;
  const m = master as ButlerMasterFile;
  return !!(m._master_export || m._type === "butler_master_file" || m.source_export);
}

export function loadStored(): ButlerMasterFile | null {
  if (typeof window === "undefined") return null;
  return safe(() => {
    const raw = window.localStorage.getItem(BUTLER_MASTER_KEY);
    return raw ? (JSON.parse(raw) as ButlerMasterFile) : null;
  }, null);
}

export function persist(master: ButlerMasterFile) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(BUTLER_MASTER_KEY, JSON.stringify(master));
}

export function clearStored() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(BUTLER_MASTER_KEY);
}

export function listFiles(master: ButlerMasterFile): string[] {
  const se = master.source_export ?? {};
  return Object.keys(se).filter((k) => k !== "_meta");
}

export function getFileSource(master: ButlerMasterFile, path: string): string | null {
  const entry = (master.source_export as Record<string, { content?: string }> | undefined)?.[path];
  return entry && typeof entry.content === "string" ? entry.content : null;
}

function extractArray(src: string, name: string): string | null {
  const re = new RegExp(`${name}\\s*=\\s*(\\[[\\s\\S]*?\\n\\])`);
  const m = src.match(re);
  return m ? m[1] : null;
}

export function applyToRuntime(master: ButlerMasterFile): string[] {
  const applied: string[] = [];
  if (typeof window === "undefined") return applied;
  const w = window as unknown as Record<string, unknown>;

  const hdr = getFileSource(master, "constants/HeaderConstants.ts");
  if (hdr) { w.__BUTLER_HEADERS_SRC = hdr; applied.push("constants/HeaderConstants.ts"); }

  const home = getFileSource(master, "app/(tabs)/nexushome.tsx");
  if (home) {
    const qs = extractArray(home, "QUICK_SCRIPTS");
    if (qs) { w.__BUTLER_QUICK_SCRIPTS_SRC = qs; applied.push("QUICK_SCRIPTS"); }
  }

  const kn = getFileSource(master, "constants/butlerKnowledge.ts");
  if (kn) { w.__BUTLER_PERSONA_SRC = kn; applied.push("constants/butlerKnowledge.ts"); }

  w.__BUTLER_MASTER = master;
  window.dispatchEvent(new CustomEvent("butler-master-applied", { detail: { applied } }));
  return applied;
}

export function importMaster(json: unknown): ImportResult {
  const errors: string[] = [];
  if (!validate(json)) {
    return { ok: false, fileCount: 0, applied: [], errors: ["Invalid butler_master file"] };
  }
  const master = json as ButlerMasterFile;
  persist(master);
  const applied = applyToRuntime(master);
  return { ok: true, fileCount: listFiles(master).length, applied, errors };
}

export function rehydrate() {
  const m = loadStored();
  if (m) applyToRuntime(m);
}
