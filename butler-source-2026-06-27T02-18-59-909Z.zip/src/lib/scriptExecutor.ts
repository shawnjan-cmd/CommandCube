/**
 * SCRIPT EXECUTOR — web port of CommandCube scriptExecutor.
 * Sends scripts to the connected PC server via serverLink, with:
 *  • SSE streaming (/api/execute/stream) with graceful fallback
 *  • auto pip install on "No module named X" (one retry)
 *  • signed-payload guard via Bearer token from localStorage
 *  • ETag-cached library fetch
 */

import { serverLink } from "./serverLink";
import { storage } from "./storage";
import { executionHistory } from "./executionHistory";

const TOKEN_KEY = "butler.link.token";
const ETAG_KEY = "@scripts_etag_v1";
const DATA_KEY = "@scripts_data_v1";

export interface ExecResult {
  success: boolean;
  output: string;
  exitCode?: number;
  ms?: number;
  error?: string;
}

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  try { return window.localStorage.getItem(TOKEN_KEY); } catch { return null; }
}

function endpoint(path: string): string | null {
  const { ip, port, status } = serverLink.getState();
  if (!ip || !port || status === "disconnected") return null;
  return `http://${ip}:${port}${path}`;
}

export async function execute(
  script: string,
  language: string = "python",
  opts: { timeout?: number; onOutput?: (chunk: string) => void; _retry?: boolean } = {},
): Promise<ExecResult> {
  const { timeout = 90_000, onOutput } = opts;
  const url = endpoint("/api/execute");
  if (!url) {
    return { success: false, output: "", error: "Not connected to PC server. Open Settings → SCAN." };
  }
  const t0 = performance.now();
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  const tok = getToken();
  if (tok) headers["Authorization"] = `Bearer ${tok}`;

  try {
    const ctrl = new AbortController();
    const id = setTimeout(() => ctrl.abort(), timeout);
    const res = await fetch(url, {
      method: "POST", headers,
      body: JSON.stringify({ script, language }),
      signal: ctrl.signal,
    });
    clearTimeout(id);

    if (!res.ok) {
      const txt = await res.text().catch(() => `HTTP ${res.status}`);
      return { success: false, output: "", error: `Server error ${res.status}: ${txt}`, ms: Math.round(performance.now() - t0) };
    }

    const data: any = await res.json().catch(() => ({}));
    const output: string = data.output ?? data.result ?? data.stdout ?? "";
    const exitCode: number = data.exitCode ?? data.exit_code ?? 0;
    const serverError: string = data.error ?? data.stderr ?? "";

    // Auto-install missing pip packages (one retry)
    const combined = [output, serverError].filter(Boolean).join("\n");
    const missing = combined.match(/No module named '([^']+)'/);
    if (missing && !opts._retry) {
      const pkg = missing[1].split(".")[0];
      onOutput?.(`📦 Auto-installing ${pkg}...\n`);
      try {
        await fetch(endpoint("/api/pip/install")!, {
          method: "POST", headers,
          body: JSON.stringify({ package: pkg }),
        });
        return execute(script, language, { ...opts, _retry: true });
      } catch {}
    }

    const ms = Math.round(performance.now() - t0);
    const finalOutput = [output, serverError].filter(Boolean).join("\n");
    onOutput?.(finalOutput);

    if (data.status === "error" || exitCode !== 0) {
      return { success: false, output: finalOutput, exitCode, ms, error: serverError || `Exit code ${exitCode}` };
    }
    return { success: true, output: finalOutput, exitCode: 0, ms };
  } catch (err: any) {
    const ms = Math.round(performance.now() - t0);
    const msg = err?.name === "AbortError"
      ? `Timeout after ${Math.round(timeout / 1000)}s`
      : err?.message ?? "Unknown error";
    return { success: false, output: "", error: msg, ms };
  }
}

/** SSE streaming execution. Falls back to execute() transparently. */
export async function executeStream(
  script: string,
  opts: { onChunk: (line: string) => void; signal?: AbortSignal },
): Promise<{ exitCode: number; ms: number }> {
  const t0 = performance.now();
  const url = endpoint("/api/execute/stream");
  if (!url) {
    const r = await execute(script);
    if (r.output) opts.onChunk(r.output);
    if (r.error) opts.onChunk(`ERROR: ${r.error}\n`);
    return { exitCode: r.exitCode ?? (r.success ? 0 : 1), ms: r.ms ?? 0 };
  }
  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), 90_000);
  opts.signal?.addEventListener("abort", () => ctrl.abort(), { once: true });
  const tok = getToken();
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
      body: JSON.stringify({ script, language: "python" }),
      signal: ctrl.signal,
    });
    if (!res.ok || !res.body) {
      const r = await execute(script);
      if (r.output) opts.onChunk(r.output);
      return { exitCode: r.exitCode ?? (r.success ? 0 : 1), ms: r.ms ?? 0 };
    }
    const reader = (res.body as any).getReader();
    const decoder = new TextDecoder();
    let buf = ""; let exitCode = 0;
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      let idx: number;
      while ((idx = buf.indexOf("\n\n")) !== -1) {
        const event = buf.slice(0, idx); buf = buf.slice(idx + 2);
        const line = event.split("\n").find((l) => l.startsWith("data: "));
        if (!line) continue;
        try {
          const j = JSON.parse(line.slice(6));
          if (j.chunk) opts.onChunk(j.chunk);
          if (j.done) exitCode = j.exitCode ?? 0;
          if (j.error && !j.done) opts.onChunk(`ERROR: ${j.error}\n`);
        } catch {}
      }
    }
    return { exitCode, ms: Math.round(performance.now() - t0) };
  } catch (e: any) {
    if (e?.name === "AbortError") throw e;
    const r = await execute(script);
    if (r.output) opts.onChunk(r.output);
    return { exitCode: r.exitCode ?? 1, ms: Math.round(performance.now() - t0) };
  } finally {
    clearTimeout(tid);
  }
}

/** ETag-cached library fetch from PC server. */
export async function fetchLibraryWithETag(): Promise<any | null> {
  const url = endpoint("/api/scripts/library");
  if (!url) return null;
  const tok = getToken();
  try {
    const savedEtag = await storage.getItem(ETAG_KEY);
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (tok) headers["Authorization"] = `Bearer ${tok}`;
    if (savedEtag) headers["If-None-Match"] = savedEtag;
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 8_000);
    const res = await fetch(url, { headers, signal: ctrl.signal });
    if (res.status === 304) {
      const cached = await storage.getItem(DATA_KEY);
      return cached ? JSON.parse(cached) : null;
    }
    if (!res.ok) return null;
    const etag = res.headers.get("ETag");
    const j = await res.json();
    if (etag) await storage.setItem(ETAG_KEY, etag);
    await storage.setItem(DATA_KEY, JSON.stringify(j));
    return j;
  } catch { return null; }
}

/** High-level wrapper used by the /run page — records history + diagnostics. */
export async function runScript(meta: {
  id: string; name: string; category: string; script: string; language?: string;
}, onOutput?: (chunk: string) => void): Promise<ExecResult> {
  const r = await execute(meta.script, meta.language ?? "python", { onOutput });
  await executionHistory.addEntry({
    scriptId: meta.id,
    scriptName: meta.name,
    category: meta.category,
    success: r.success,
    ms: r.ms ?? 0,
    timestamp: new Date().toISOString(),
    error: r.error,
  });
  return r;
}

export const scriptExecutor = { execute, executeStream, fetchLibraryWithETag, runScript };
