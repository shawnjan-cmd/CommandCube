/**
 * Execution History — stores last 50 executed scripts (web port).
 * Ported from BUTLER-AI/services/executionHistory.ts
 */
import { storage } from './storage';

const KEY = 'boter_exec_history_v1';
const MAX = 50;

export interface HistoryEntry {
  id: string;
  scriptId: string;
  scriptName: string;
  category: string;
  success: boolean;
  ms: number;
  timestamp: string;
  error?: string;
}

async function loadHistory(): Promise<HistoryEntry[]> {
  const raw = await storage.getItem(KEY);
  try { return raw ? (JSON.parse(raw) as HistoryEntry[]) : []; } catch { return []; }
}

async function addEntry(entry: Omit<HistoryEntry, 'id'>): Promise<HistoryEntry[]> {
  const history = await loadHistory();
  const next: HistoryEntry = { ...entry, id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6) };
  const updated = [next, ...history].slice(0, MAX);
  await storage.setItem(KEY, JSON.stringify(updated));
  return updated;
}

async function clearHistory(): Promise<void> { await storage.removeItem(KEY); }

export const executionHistory = { loadHistory, addEntry, clearHistory, getAll: loadHistory };
