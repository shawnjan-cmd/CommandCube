// Shared execution log persisted to localStorage.
export type LogLevel = "info" | "success" | "warn" | "error";

export interface ExecRecord {
  id: string;
  ts: number;
  level: LogLevel;
  source: string;
  title: string;
  detail?: string;
}

const KEY = "butler.execlog.v1";
const MAX = 200;

export function loadLog(): ExecRecord[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return seed();
}

export function appendLog(rec: Omit<ExecRecord, "id" | "ts">): ExecRecord {
  const entry: ExecRecord = { id: crypto.randomUUID(), ts: Date.now(), ...rec };
  const next = [entry, ...loadLog()].slice(0, MAX);
  try { localStorage.setItem(KEY, JSON.stringify(next)); } catch {}
  try { window.dispatchEvent(new CustomEvent("butler:log", { detail: entry })); } catch {}
  return entry;
}

export function clearLog() {
  try { localStorage.removeItem(KEY); } catch {}
  try { window.dispatchEvent(new CustomEvent("butler:log")); } catch {}
}

function seed(): ExecRecord[] {
  const now = Date.now();
  return [
    { id: "s1", ts: now - 60_000,  level: "success", source: "scripts",   title: "Bridge handshake OK" },
    { id: "s2", ts: now - 240_000, level: "info",    source: "butler",    title: "Knowledge base indexed", detail: "130 scripts" },
    { id: "s3", ts: now - 600_000, level: "warn",    source: "fileshare", title: "Idle relay slow", detail: "latency 38ms" },
  ];
}
