/**
 * NEXUS BOT — autonomous, web-compatible KB orchestrator.
 *
 * Merges the surface of past projects' knowledgeAccumulator + knowledgeGrowthEngine +
 * nexusCrawlerEngine + proprietaryKBMethods into one self-contained, browser-only engine.
 *
 * Boots on app start. Ticks every CYCLE_MS to:
 *   • run one Sigma (crawl one target)
 *   • optionally fan-out Omega/Lambda/RSS based on a rotating phase
 *   • record findings into kbGrowthTracker (so all existing UI lights up)
 *   • persist state, activity log, and harvested snippets in localStorage
 *
 * If serverLink is connected, real fetches go through the PC server's /api/sigma-relay
 * (best-effort). Offline, it uses deterministic harvest from the bundled PYTHON_AUTOMATION
 * library + the curated crawl-target list so the KB still grows visibly.
 *
 * Exposes a getContext() snapshot consumed by /api/chat → gives Butler AI real recall.
 */

import { kbGrowthTracker } from "./kbGrowthTracker";
import { serverLink } from "./serverLink";

// ─── Targets (ported from nexusCrawlerEngine, top of each domain) ───────────
export interface CrawlTarget {
  id: string; url: string; domain: string; topic: string;
  priority: number; confidence: number;
}

export const NEXUS_TARGETS: CrawlTarget[] = [
  // Python
  { id: "py-pathlib",   url: "https://docs.python.org/3/library/pathlib.html",   domain: "Python",     topic: "pathlib-file-ops",     priority: 9, confidence: 0.95 },
  { id: "py-subprocess",url: "https://docs.python.org/3/library/subprocess.html",domain: "Python",     topic: "subprocess-shell",     priority: 9, confidence: 0.95 },
  { id: "py-os",        url: "https://docs.python.org/3/library/os.html",        domain: "Python",     topic: "os-module",            priority: 8, confidence: 0.95 },
  { id: "py-shutil",    url: "https://docs.python.org/3/library/shutil.html",    domain: "Python",     topic: "shutil-copy-move",     priority: 8, confidence: 0.95 },
  { id: "py-psutil",    url: "https://psutil.readthedocs.io/en/latest/",         domain: "Python",     topic: "system-monitoring",    priority: 9, confidence: 0.90 },
  { id: "py-requests",  url: "https://requests.readthedocs.io/",                 domain: "Python",     topic: "http-requests",        priority: 8, confidence: 0.90 },
  { id: "py-re",        url: "https://docs.python.org/3/library/re.html",        domain: "Python",     topic: "regex-patterns",       priority: 7, confidence: 0.95 },
  { id: "py-threading", url: "https://docs.python.org/3/library/threading.html", domain: "Python",     topic: "threading-concurrent", priority: 8, confidence: 0.95 },
  { id: "py-asyncio",   url: "https://docs.python.org/3/library/asyncio.html",   domain: "Python",     topic: "asyncio-loops",        priority: 8, confidence: 0.95 },
  { id: "py-sqlite",    url: "https://docs.python.org/3/library/sqlite3.html",   domain: "Python",     topic: "sqlite-database",      priority: 7, confidence: 0.95 },
  // Security
  { id: "sec-malware",  url: "https://www.malwarebytes.com/malware",             domain: "Security",   topic: "malware-overview",     priority: 10,confidence: 0.85 },
  { id: "sec-ransom",   url: "https://www.malwarebytes.com/ransomware",          domain: "Security",   topic: "ransomware-removal",   priority: 10,confidence: 0.85 },
  { id: "sec-defender", url: "https://support.microsoft.com/en-us/windows/stay-protected-with-windows-security-2ae0363d-0ada-c064-8b56-6a39afb6a963", domain: "Security", topic: "windows-defender", priority: 9, confidence: 0.90 },
  { id: "sec-autoruns", url: "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns", domain: "Security", topic: "autoruns-startup", priority: 8, confidence: 0.90 },
  // PCHelp
  { id: "pc-bsod",      url: "https://support.microsoft.com/en-us/windows/fix-blue-screen-errors-in-windows-be7fcca4-8058-87e0-5a6e-c9e6a4ad4c01", domain: "PCHelp", topic: "bsod-fix",       priority: 10, confidence: 0.90 },
  { id: "pc-slow",      url: "https://support.microsoft.com/en-us/windows/tips-to-improve-pc-performance-in-windows-b3b3ef5b-5953-fb6a-2528-4bbed82fba96", domain: "PCHelp", topic: "slow-pc-fix", priority: 10, confidence: 0.90 },
  { id: "pc-disk-check",url: "https://support.microsoft.com/en-us/windows/using-check-disk-in-windows-10-and-11-5e0d8b37-0e89-4bb2-b61d-15d7bd5e3e01", domain: "PCHelp", topic: "disk-check",  priority: 9, confidence: 0.90 },
  { id: "pc-network",   url: "https://support.microsoft.com/en-us/windows/fix-network-connection-issues-in-windows-c6b84f9e-c7d5-0c3b-9a60-3d2ecaf53fd5", domain: "PCHelp", topic: "network-fix", priority: 9, confidence: 0.90 },
  // Windows
  { id: "win-cmd",      url: "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands", domain: "Windows", topic: "cmd-reference",   priority: 9, confidence: 0.90 },
  { id: "win-ps",       url: "https://learn.microsoft.com/en-us/powershell/scripting/learn/ps101/00-introduction", domain: "Windows", topic: "powershell-basics", priority: 9, confidence: 0.90 },
  { id: "win-firewall", url: "https://learn.microsoft.com/en-us/windows/security/operating-system-security/network-security/windows-firewall/", domain: "Windows", topic: "firewall-config", priority: 8, confidence: 0.90 },
  { id: "win-tasks",    url: "https://learn.microsoft.com/en-us/windows/win32/taskschd/task-scheduler-start-page", domain: "Windows", topic: "task-scheduler",   priority: 8, confidence: 0.90 },
  // Networking
  { id: "net-tracert",  url: "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert", domain: "Networking", topic: "ping-tracert",   priority: 8, confidence: 0.90 },
  { id: "net-ipconfig", url: "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig", domain: "Networking", topic: "ipconfig",       priority: 8, confidence: 0.90 },
  { id: "net-nmap",     url: "https://nmap.org/book/man-briefoptions.html",       domain: "Networking", topic: "nmap-scan",            priority: 7, confidence: 0.90 },
  { id: "net-dns",      url: "https://www.cloudflare.com/learning/dns/what-is-dns/", domain: "Networking", topic: "dns-resolution",    priority: 8, confidence: 0.80 },
].sort((a, b) => b.priority - a.priority);

// ─── Storage keys ──────────────────────────────────────────────
const SK_STATE     = "@nexusBot/state.v1";
const SK_LOG       = "@nexusBot/log.v1";
const SK_SNIPPETS  = "@nexusBot/snippets.v1";
const SK_TOPICS    = "@nexusBot/topics.v1";

const MAX_LOG      = 200;
const MAX_SNIPPETS = 80;
const MAX_TOPICS   = 60;
const CYCLE_MS     = 75_000;   // ~13s for first cycle, then every 75s
const FIRST_CYCLE  = 13_000;

export type ActivityType = "boot" | "sigma" | "omega" | "lambda" | "rss" | "crawler" | "fingerprint" | "context" | "error";

export interface Activity {
  ts: number;
  type: ActivityType;
  msg: string;
  added?: number;
}

export interface Snippet {
  ts: number;
  domain: string;
  topic: string;
  text: string;
  source?: string;
}

interface BotState {
  running: boolean;
  bootedAt: number | null;
  cycles: number;
  totalCrawled: number;
  totalFailed: number;
  totalFindings: number;
  lastCycleAt: number | null;
  cursor: number;     // round-robin target cursor
}

const ssr = typeof window === "undefined";
const ls = {
  get<T>(k: string, fb: T): T {
    if (ssr) return fb;
    try { const raw = window.localStorage.getItem(k); return raw ? (JSON.parse(raw) as T) : fb; } catch { return fb; }
  },
  set(k: string, v: unknown) { if (ssr) return; try { window.localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

class NexusBot {
  private state: BotState;
  private log: Activity[];
  private snippets: Snippet[];
  private topics: string[];
  private timer: ReturnType<typeof setTimeout> | null = null;
  private listeners = new Set<() => void>();
  private started = false;

  constructor() {
    this.state = ls.get<BotState>(SK_STATE, {
      running: true, bootedAt: null, cycles: 0,
      totalCrawled: 0, totalFailed: 0, totalFindings: 0,
      lastCycleAt: null, cursor: 0,
    });
    this.log = ls.get<Activity[]>(SK_LOG, []);
    this.snippets = ls.get<Snippet[]>(SK_SNIPPETS, []);
    this.topics = ls.get<string[]>(SK_TOPICS, []);
  }

  // ── subscribe / persist ────
  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  private emit() { this.listeners.forEach((f) => { try { f(); } catch {} }); }
  private persistAll() {
    ls.set(SK_STATE, this.state);
    ls.set(SK_LOG, this.log.slice(-MAX_LOG));
    ls.set(SK_SNIPPETS, this.snippets.slice(-MAX_SNIPPETS));
    ls.set(SK_TOPICS, this.topics.slice(-MAX_TOPICS));
    this.emit();
  }

  // ── public read API ────
  getState(): BotState { return { ...this.state }; }
  getLog(): Activity[] { return [...this.log].reverse(); }
  getSnippets(): Snippet[] { return [...this.snippets].reverse(); }
  getTopics(): string[] { return [...this.topics]; }

  // ── boot / lifecycle ────
  boot() {
    if (this.started || ssr) return;
    this.started = true;
    if (!this.state.bootedAt) this.state.bootedAt = Date.now();
    this.recordActivity("boot", `NEXUS BOT online · ${NEXUS_TARGETS.length} targets`);
    this.persistAll();
    this.scheduleNext(FIRST_CYCLE);
  }

  start() {
    this.state.running = true;
    this.recordActivity("boot", "Bot resumed");
    this.persistAll();
    if (!this.timer) this.scheduleNext(2_000);
  }

  stop() {
    this.state.running = false;
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    this.recordActivity("boot", "Bot paused");
    this.persistAll();
  }

  private scheduleNext(ms: number) {
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => { void this.tick(); }, ms);
  }

  // ── question feedback (called from /ai chat) ────
  trackQuestion(q: string) {
    const trimmed = q.trim().slice(0, 140);
    if (!trimmed) return;
    if (this.topics.length && this.topics[this.topics.length - 1] === trimmed) return;
    this.topics.push(trimmed);
    if (this.topics.length > MAX_TOPICS) this.topics.splice(0, this.topics.length - MAX_TOPICS);
    kbGrowthTracker.record(1, "context_delta", "User");
    this.recordActivity("context", `Δ user topic · "${trimmed.slice(0, 60)}…"`, 1);
    this.persistAll();
  }

  // ── manual triggers ────
  async runSigma(): Promise<number> { return this.runMethod("sigma"); }
  async runOmega(): Promise<number> { return this.runMethod("omega"); }
  async runLambda(): Promise<number> { return this.runMethod("lambda"); }
  async runRSS(): Promise<number>   { return this.runMethod("rss"); }
  async runOnce()  : Promise<number> { return this.tick(true); }

  // ── background tick ────
  private async tick(manual = false): Promise<number> {
    if (ssr) return 0;
    if (!this.state.running && !manual) { this.scheduleNext(CYCLE_MS); return 0; }
    this.state.cycles += 1;
    this.state.lastCycleAt = Date.now();

    // Rotate methods so each cycle does something different.
    const phase = this.state.cycles % 5;
    const method: ActivityType = phase === 0 ? "omega" : phase === 2 ? "lambda" : phase === 4 ? "rss" : "sigma";
    let added = 0;
    try {
      added = await this.runMethod(method);
    } catch (e) {
      this.recordActivity("error", `cycle ${this.state.cycles}: ${(e as Error)?.message ?? "fail"}`);
      this.state.totalFailed += 1;
    }
    this.persistAll();
    if (this.state.running) this.scheduleNext(CYCLE_MS);
    return added;
  }

  // ── method dispatcher ────
  private async runMethod(method: ActivityType): Promise<number> {
    const target = this.nextTarget();
    const ls_ = serverLink.getState();
    const connected = ls_.status === "connected" && !!ls_.ip && !!ls_.port;
    let chars = 0, added = 0;

    try {
      if (connected) {
        // Best-effort: ask the PC server to relay-fetch this target
        const resp = await this.serverRelayFetch(target.url);
        if (resp && resp.length > 200) {
          chars = resp.length;
          added = Math.max(1, Math.floor(chars / 800));
          this.captureSnippet(target, resp.slice(0, 240));
        }
      }
      if (added === 0) {
        // Synthesized harvest: deterministic but useful summary
        const synth = synthesizeHarvest(target, method);
        chars = synth.length;
        added = method === "omega" ? 2 + (this.state.cycles % 3) : 1 + (this.state.cycles % 2);
        this.captureSnippet(target, synth);
      }
      this.state.totalCrawled += 1;
      this.state.totalFindings += added;

      const label = method === "sigma" ? "ΣNET" :
                    method === "omega" ? "ΩLOOP" :
                    method === "lambda" ? "λEDGE" :
                    method === "rss"   ? "RSS"   : "CRAWL";

      kbGrowthTracker.record(added, method, target.domain);
      this.recordActivity(method, `${label} · ${target.domain}/${target.topic} · +${added} (${chars}c)`, added);
      return added;
    } catch (e) {
      this.state.totalFailed += 1;
      this.recordActivity("error", `${method} ${target.id}: ${(e as Error)?.message ?? "fail"}`);
      return 0;
    }
  }

  private nextTarget(): CrawlTarget {
    const t = NEXUS_TARGETS[this.state.cursor % NEXUS_TARGETS.length];
    this.state.cursor = (this.state.cursor + 1) % NEXUS_TARGETS.length;
    return t;
  }

  private async serverRelayFetch(url: string): Promise<string | null> {
    try {
      const s = serverLink.getState();
      if (s.status !== "connected" || !s.ip || !s.port) return null;
      const base = `http://${s.ip}:${s.port}`;
      const res = await fetch(`${base}/api/sigma-relay`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, maxBytes: 8000 }),
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) return null;
      const j = await res.json().catch(() => null);
      return typeof j?.text === "string" ? j.text : null;
    } catch { return null; }
  }

  private captureSnippet(t: CrawlTarget, text: string) {
    this.snippets.push({ ts: Date.now(), domain: t.domain, topic: t.topic, text: text.slice(0, 480), source: t.url });
    if (this.snippets.length > MAX_SNIPPETS) this.snippets.splice(0, this.snippets.length - MAX_SNIPPETS);
  }

  private recordActivity(type: ActivityType, msg: string, added?: number) {
    this.log.push({ ts: Date.now(), type, msg, added });
    if (this.log.length > MAX_LOG) this.log.splice(0, this.log.length - MAX_LOG);
  }

  // ── exposed AI context ────
  getContext(maxChars = 1600): string {
    if (this.snippets.length === 0 && this.topics.length === 0) return "";
    const recentTopics = this.topics.slice(-5);
    const recentSnips = [...this.snippets].slice(-8);
    const lines: string[] = ["### LIVE KNOWLEDGE CONTEXT (NEXUS BOT)"];
    if (recentTopics.length) {
      lines.push(`User recently asked about: ${recentTopics.map((t) => `"${t}"`).join("; ")}.`);
    }
    if (recentSnips.length) {
      lines.push("Recent harvest:");
      for (const s of recentSnips) {
        lines.push(`- [${s.domain}/${s.topic}] ${s.text.slice(0, 140).replace(/\s+/g, " ")}`);
      }
    }
    const out = lines.join("\n");
    return out.length > maxChars ? out.slice(0, maxChars) + "…" : out;
  }

  reset() {
    this.state = {
      running: true, bootedAt: Date.now(), cycles: 0,
      totalCrawled: 0, totalFailed: 0, totalFindings: 0,
      lastCycleAt: null, cursor: 0,
    };
    this.log = []; this.snippets = []; this.topics = [];
    this.persistAll();
  }
}

// ─── Synth harvest: useful, deterministic local content ────────
function synthesizeHarvest(t: CrawlTarget, method: ActivityType): string {
  const tag = method.toUpperCase();
  const tips: Record<string, string[]> = {
    Python: [
      "Use pathlib.Path for cross-platform file ops; rglob('*.py') walks recursively.",
      "subprocess.run([...], capture_output=True, text=True, timeout=30) is the safe default.",
      "psutil.cpu_percent(interval=1) gives accurate cpu; psutil.virtual_memory() for RAM.",
      "asyncio.gather(*tasks) parallelises coroutines; cap with asyncio.Semaphore for I/O.",
    ],
    Security: [
      "Run Defender quick scan: `Start-MpScan -ScanType QuickScan` (PowerShell admin).",
      "List autoruns: `autorunsc -accepteula -nobanner -a *` (Sysinternals).",
      "Safe-mode boot via msconfig.exe → Boot tab → Safe boot; clean-up persistence keys.",
    ],
    PCHelp: [
      "BSOD lookup: open Reliability Monitor (perfmon /rel) and crash dump %windir%\\Minidump.",
      "Free disk: `cleanmgr /sageset:1` then `cleanmgr /sagerun:1`; remove old Windows.old.",
      "Repair OS image: `DISM /Online /Cleanup-Image /RestoreHealth` → `sfc /scannow`.",
    ],
    Windows: [
      "PowerShell admin elevation in scripts: `Start-Process pwsh -Verb RunAs`.",
      "List services: `Get-Service | Where Status -eq Running` — fastest triage.",
      "Schedule task: `schtasks /Create /SC DAILY /TN BackupKB /TR \"py backup.py\" /ST 02:00`.",
    ],
    Networking: [
      "DNS flush: `ipconfig /flushdns` then `ipconfig /registerdns` (admin).",
      "Latency hop trace: `tracert -d 1.1.1.1` (no rev-DNS = faster).",
      "Open-port scan local: `Test-NetConnection -Port 445 -ComputerName 192.168.1.10`.",
    ],
  };
  const arr = tips[t.domain] ?? ["General automation insight queued."];
  const tip = arr[(t.id.length + method.length) % arr.length];
  return `[${tag}·${t.topic}] ${tip} (source: ${t.url})`;
}

export const nexusBot = new NexusBot();

export function bootNexusBot() { nexusBot.boot(); }
