/**
 * User Scripts — local CRUD (web port).
 * Ported from BUTLER-AI/services/userScripts.ts (Supabase stripped).
 */
import { storage } from './storage';

export interface UserScript {
  id: string;
  user_id: string;
  name: string;
  description: string;
  category: string;
  script_content: string;
  language: string;
  image_url: string | null;
  created_at: string;
  updated_at: string;
  execution_count: number;
}

export interface CreateScriptData {
  name: string; description: string; category: string;
  script_content: string; language?: string;
}
export type UpdateScriptData = Partial<CreateScriptData>;

const KEY = '@butler_user_scripts_v1';

async function loadAll(): Promise<UserScript[]> {
  const raw = await storage.getItem(KEY);
  try { return raw ? (JSON.parse(raw) as UserScript[]) : []; } catch { return []; }
}
async function saveAll(s: UserScript[]): Promise<void> { await storage.setItem(KEY, JSON.stringify(s)); }

export async function createUserScript(data: CreateScriptData) {
  const scripts = await loadAll();
  const s: UserScript = {
    id: `local_${Date.now()}`, user_id: 'local',
    name: data.name, description: data.description, category: data.category,
    script_content: data.script_content, language: data.language || 'python',
    image_url: null, created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(), execution_count: 0,
  };
  await saveAll([s, ...scripts]);
  return { data: s, error: null };
}

export async function getUserScripts() {
  return { data: await loadAll(), error: null as string | null };
}

export async function updateUserScript(id: string, updates: UpdateScriptData) {
  const scripts = await loadAll();
  const i = scripts.findIndex((s) => s.id === id);
  if (i === -1) return { data: null, error: 'Script not found' };
  scripts[i] = { ...scripts[i], ...updates, updated_at: new Date().toISOString() };
  await saveAll(scripts);
  return { data: scripts[i], error: null };
}

export async function deleteUserScript(id: string) {
  const scripts = await loadAll();
  await saveAll(scripts.filter((s) => s.id !== id));
  return { error: null };
}

export async function incrementExecutionCount(id: string): Promise<void> {
  const scripts = await loadAll();
  const i = scripts.findIndex((s) => s.id === id);
  if (i !== -1) { scripts[i].execution_count = (scripts[i].execution_count || 0) + 1; await saveAll(scripts); }
}

export const SCRIPT_CATEGORIES = [
  'System', 'Network', 'Security', 'Gaming', 'Media',
  'Files', 'Power', 'Browser', 'Developer', 'Other',
];
