/**
 * KB GROWTH TRACKER — web port of services/kbGrowthTracker.ts
 * Stores timestamped findings events in localStorage. Bounded to MAX_EVENTS.
 *
 * Methods (named event types) mirror the proprietary collection methods:
 *   seed · sigma · omega · rss · context_delta · manual · lambda ·
 *   fingerprint_harvest · crawler · ncx · script_exec · butler_chat
 */

const STORAGE_KEY = "@kb_growth_timeline_v2";
const MAX_EVENTS = 10000;
const CHUNK_MINS = 15;

export interface GrowthEvent {
  ts: number;
  count: number;
  method: string;
  domain?: string;
}

export interface ChartBucket {
  ts: number;
  total: number;
  delta: number;
  label: string;
}

interface Persisted {
  events: GrowthEvent[];
  totalFindings: number;
}

function safeLoad(): Persisted {
  if (typeof window === "undefined") return { events: [], totalFindings: 0 };
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { events: [], totalFindings: 0 };
    const p = JSON.parse(raw);
    return {
      events: Array.isArray(p.events) ? p.events : [],
      totalFindings: typeof p.totalFindings === "number" ? p.totalFindings : 0,
    };
  } catch {
    return { events: [], totalFindings: 0 };
  }
}

function safeSave(p: Persisted) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(p));
  } catch {}
}

function formatLabel(ts: number, hours: number): string {
  const d = new Date(ts);
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  if (hours <= 6) return `${hh}:${mm}`;
  if (hours <= 24) return `${hh}h`;
  return `${d.getDate()}/${d.getMonth() + 1}`;
}

class KBGrowthTracker {
  private events: GrowthEvent[];
  private totalFindings: number;
  private listeners = new Set<() => void>();

  constructor() {
    const p = safeLoad();
    this.events = p.events;
    this.totalFindings = p.totalFindings || p.events.reduce((s, e) => s + e.count, 0);
  }

  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  private emit() { this.listeners.forEach((f) => f()); }

  record(count: number, method: string, domain?: string): void {
    if (count <= 0) return;
    this.events.push({ ts: Date.now(), count, method, domain });
    this.totalFindings += count;
    if (this.events.length > MAX_EVENTS) {
      this.events = this.events.slice(-MAX_EVENTS);
    }
    safeSave({ events: this.events, totalFindings: this.totalFindings });
    this.emit();
  }

  getChartData(hours = 24, bucketMinutes = CHUNK_MINS): ChartBucket[] {
    const now = Date.now();
    const start = now - hours * 60 * 60 * 1000;
    const bucketMs = bucketMinutes * 60 * 1000;
    const numBuckets = Math.max(1, Math.ceil((hours * 60) / bucketMinutes));
    const buckets: ChartBucket[] = Array.from({ length: numBuckets }, (_, i) => {
      const bucketStart = start + i * bucketMs;
      return { ts: bucketStart, total: 0, delta: 0, label: formatLabel(bucketStart, hours) };
    });
    let baseline = 0;
    for (const ev of this.events) if (ev.ts < start) baseline += ev.count;
    for (const ev of this.events) {
      if (ev.ts < start || ev.ts > now) continue;
      const idx = Math.min(numBuckets - 1, Math.floor((ev.ts - start) / bucketMs));
      buckets[idx].delta += ev.count;
    }
    let running = baseline;
    for (const b of buckets) { running += b.delta; b.total = running; }
    return buckets;
  }

  getTotalCount(): number { return this.totalFindings; }
  getEventCount(): number { return this.events.length; }
  getRecentEvents(n = 50): GrowthEvent[] { return this.events.slice(-n).reverse(); }

  getMethodBreakdown(): Record<string, number> {
    const out: Record<string, number> = {};
    for (const ev of this.events) out[ev.method] = (out[ev.method] || 0) + ev.count;
    return out;
  }

  getDomainBreakdown(): Record<string, number> {
    const out: Record<string, number> = {};
    for (const ev of this.events) {
      const k = ev.domain || "uncategorized";
      out[k] = (out[k] || 0) + ev.count;
    }
    return out;
  }

  getStreakDays(): number {
    if (this.events.length === 0) return 0;
    const days = new Set<string>();
    for (const ev of this.events) {
      const d = new Date(ev.ts);
      days.add(`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`);
    }
    let streak = 0;
    const cur = new Date();
    for (;;) {
      const key = `${cur.getFullYear()}-${cur.getMonth()}-${cur.getDate()}`;
      if (days.has(key)) { streak++; cur.setDate(cur.getDate() - 1); } else break;
    }
    return streak;
  }

  clear(): void {
    this.events = [];
    this.totalFindings = 0;
    safeSave({ events: [], totalFindings: 0 });
    this.emit();
  }

  export(): string {
    return JSON.stringify(
      { events: this.events, totalFindings: this.totalFindings, exportedAt: new Date().toISOString() },
      null,
      2,
    );
  }
}

export const kbGrowthTracker = new KBGrowthTracker();

/** Method metadata for UI labels & colors */
export const METHOD_META: Record<string, { label: string; color: string; desc: string }> = {
  seed:                { label: "SEED",         color: "var(--cyan)",    desc: "Initial domain seeding (priority queue)" },
  sigma:               { label: "Σ SIGMA",      color: "var(--green)",   desc: "SIGMA-NET federated crawl" },
  omega:               { label: "Ω OMEGA",      color: "var(--magenta)", desc: "ΩLOOP autonomous expansion cycle" },
  rss:                 { label: "RSS",          color: "var(--orange)",  desc: "RSS / Atom feed delta" },
  context_delta:       { label: "Δ CONTEXT",    color: "var(--cyan)",    desc: "User chat context delta filler" },
  manual:              { label: "MANUAL",       color: "var(--green)",   desc: "Manual entry via Knowledge tab" },
  lambda:              { label: "λ LAMBDA",     color: "var(--magenta)", desc: "Lambda edge function harvest" },
  fingerprint_harvest: { label: "FINGERPRINT",  color: "var(--orange)",  desc: "Dedup fingerprint harvest" },
  crawler:             { label: "CRAWLER",      color: "var(--cyan)",    desc: "Nexus crawler engine" },
  ncx:                 { label: "NCX",          color: "var(--magenta)", desc: "NCX crawler integration" },
  script_exec:         { label: "SCRIPT RUN",   color: "var(--green)",   desc: "Recorded script execution" },
  butler_chat:         { label: "BUTLER CHAT",  color: "var(--orange)",  desc: "Butler AI question tracked" },
  legacy_seed:         { label: "LEGACY SEED",  color: "var(--cyan)",    desc: "Migrated legacy KB seed" },
};
