import { useEffect, useRef, useState } from "react";
import { getConfig, health, sysinfo } from "@/lib/butler";

export type Telemetry = {
  paired: boolean;
  online: boolean;
  cpu: number | null;
  ram: number | null;
  disk: number | null;
  temp: number | null;
  uptime: number | null;
  hostname: string;
  platform: string;
  model: string;
  history: number[];
  lastTs: number;
  error?: string;
};

const EMPTY: Telemetry = {
  paired: false, online: false,
  cpu: null, ram: null, disk: null, temp: null, uptime: null,
  hostname: "", platform: "", model: "",
  history: [], lastTs: 0,
};

export function useTelemetry(intervalMs = 3000): Telemetry {
  const [state, setState] = useState<Telemetry>(EMPTY);
  const histRef = useRef<number[]>([]);

  useEffect(() => {
    let alive = true;
    let timer: any;

    const tick = async () => {
      const cfg = getConfig();
      if (!cfg.paired || !cfg.baseUrl) {
        if (alive) setState((s) => ({ ...s, paired: false, online: false }));
        return;
      }
      try {
        const [h, s] = await Promise.all([
          health().catch(() => null),
          sysinfo().catch(() => null),
        ]);
        if (!alive) return;
        const cpu = (s?.cpuPercent ?? s?.cpu ?? null) as number | null;
        const ram = (s?.ramPercent ?? s?.ram ?? null) as number | null;
        const disk = (s?.diskPercent ?? s?.disk ?? null) as number | null;
        if (typeof cpu === "number") {
          histRef.current = [...histRef.current, cpu].slice(-32);
        }
        setState({
          paired: true,
          online: !!h,
          cpu, ram, disk,
          temp: (s?.temp ?? s?.cpuTemp ?? null) as number | null,
          uptime: (s?.uptime ?? h?.uptime ?? null) as number | null,
          hostname: s?.hostname ?? "",
          platform: s?.platform ?? "",
          model: h?.model ?? "",
          history: histRef.current,
          lastTs: Date.now(),
        });
      } catch (e: any) {
        if (alive) setState((s) => ({ ...s, paired: true, online: false, error: e?.message }));
      }
    };

    tick();
    timer = setInterval(tick, intervalMs);
    const onCfg = () => { histRef.current = []; tick(); };
    window.addEventListener("butler:cfg", onCfg);
    return () => { alive = false; clearInterval(timer); window.removeEventListener("butler:cfg", onCfg); };
  }, [intervalMs]);

  return state;
}

export function fmtUptime(secs: number | null): string {
  if (!secs || secs <= 0) return "—";
  const d = Math.floor(secs / 86400);
  const h = Math.floor((secs % 86400) / 3600);
  const m = Math.floor((secs % 3600) / 60);
  if (d) return `${d}d ${h}h`;
  if (h) return `${h}h ${m}m`;
  return `${m}m`;
}

export function fmtPct(v: number | null, fallback = "—"): string {
  return typeof v === "number" ? `${Math.round(v)}%` : fallback;
}
