# Butler AI — Play Store Submission Guide

This project is now Play-Store-ready as a **Trusted Web Activity (TWA)**. The Play Store binary is built by GitHub Actions from your published Lovable URL.

## What's already done

- `public/manifest.webmanifest` — PWA manifest (required for TWA).
- `public/icon-512.png` — 512×512 app icon.
- `public/robots.txt` + `public/sitemap.xml` — SEO basics.
- `public/.well-known/assetlinks.json` — Digital Asset Links (needs your package + SHA256).
- `twa-manifest.json` — Bubblewrap config.
- `.github/workflows/build-aab.yml` — CI that produces a **signed `.aab`** you upload to Play Console.
- Real legal pages live at `/legal/privacy`, `/legal/terms`, `/legal/safety`, `/legal/delete`.
- Root metadata, OG tags, theme colors set to real Butler AI values (no "Lovable App" defaults).

## One-time setup (15 minutes)

### 1. Publish the web app
Click **Publish** in Lovable. Note your URL (e.g. `butler-ai.lovable.app`) or connect a custom domain. The TWA opens this URL inside a Chrome shell — it MUST be HTTPS and publicly reachable.

### 2. Pick a Play Store package ID
Reverse-DNS, lowercase, unchangeable after first upload. Example: `com.shawnjan.butlerai`.

### 3. Generate a signing keystore (local machine, once)
```bash
keytool -genkeypair -v -keystore android.keystore -alias android \
  -keyalg RSA -keysize 2048 -validity 10000
# remember the passwords you choose
base64 -w0 android.keystore > keystore.b64.txt
```

### 4. Add three GitHub Actions secrets
In your repo → Settings → Secrets and variables → Actions:
- `ANDROID_KEYSTORE_BASE64` — contents of `keystore.b64.txt`
- `ANDROID_KEYSTORE_PASSWORD` — store password from step 3
- `ANDROID_KEY_PASSWORD` — key password from step 3

### 5. Fill in the three `REPLACE_WITH_…` placeholders
- `twa-manifest.json` → `packageId`, `host`, and all `REPLACE_WITH_YOUR_PUBLISHED_DOMAIN` strings.
- `public/.well-known/assetlinks.json` → `package_name` (the SHA256 comes from step 7).

### 6. Build the AAB
Push a tag, or run the workflow manually:
```bash
git tag v1.0.0 && git push --tags
```
GitHub Actions produces `app-release-bundle.aab`. Download it from the Actions artifacts.

### 7. Upload to Play Console
- Create app → upload the `.aab` to Internal Testing first.
- After upload, Play Console → Setup → App Integrity gives you the **SHA-256 cert fingerprint**.
- Paste it into `public/.well-known/assetlinks.json` and republish the web app. Without this, the TWA will show a Chrome address bar (which Play Store rejects for production).

### 8. Fill out the Play Console listing
- **Privacy Policy URL**: `https://YOUR-DOMAIN/legal/privacy`
- **Data Safety form**: Butler AI collects no data → check "No data collected". Reference `/legal/safety`.
- **Account deletion URL**: `https://YOUR-DOMAIN/legal/delete`
- **Content rating**: complete the IARC questionnaire (this app is utility, no UGC).
- **Target audience**: 18+ (matches existing legal copy).
- **App category**: Productivity.

## Anything region-locked? No.

- No hardcoded IPs in shipping code (LAN discovery probes the user's *own* network at runtime).
- No owner-specific emails baked into UI — contact addresses come from the JSON override system, so each deployer can set their own.
- The PC server companion (`butler_server_*.py`) is optional and runs on the user's own machine; the mobile app works standalone.

## Updating the app

Web changes go live the instant you click Publish — no Play Store re-submission needed. Only re-upload an AAB when you bump the version code in `twa-manifest.json` (e.g. native permissions change).
