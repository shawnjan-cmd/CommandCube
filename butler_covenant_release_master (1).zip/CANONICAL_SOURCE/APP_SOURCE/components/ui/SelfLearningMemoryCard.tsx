import React, { useCallback, useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { loadScriptEvidenceProfile } from '@/services/scriptEvidencePipeline';
import type { LearningProfile } from '@/services/memoryLearningEngine';

const C = { panel: '#0C1220', cyan: '#38D9E8', green: '#2FE38A', amber: '#FFB43D', text: '#E5F5FF', dim: '#7C91A5', line: '#1D3950' };

export default function SelfLearningMemoryCard() {
  const [profile, setProfile] = useState<LearningProfile | null>(null);
  const refresh = useCallback(() => { loadScriptEvidenceProfile().then(setProfile).catch(() => setProfile(null)); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  return <View style={s.card}>
    <View style={s.header}><MaterialCommunityIcons name="brain" size={23} color={C.cyan} /><View style={s.flex}><Text style={s.title}>ADMISSION MEMORY</Text><Text style={s.sub}>Self-learning policy profile · local and encrypted</Text></View><Pressable onPress={refresh} style={s.refresh}><MaterialCommunityIcons name="refresh" size={18} color={C.cyan} /></Pressable></View>
    <Text style={s.body}>Butler learns from real TrustLab outcomes and user-approved memory admissions. It stores aggregate counters, not raw candidate text, secrets, or unverified instructions.</Text>
    <View style={s.grid}><Metric label="SEEN" value={profile?.candidatesSeen ?? '—'} /><Metric label="ADMITTED" value={profile?.admitted ?? '—'} color={C.green} /><Metric label="REJECTED" value={profile?.rejected ?? '—'} color={C.amber} /><Metric label="VERIFIED" value={profile?.verifiedCandidates ?? '—'} color={C.cyan} /></View>
    <Text style={s.evidence}>LEARNING STATUS · {profile ? 'REAL LOCAL PROFILE' : 'NOT LOADED'} · NO SYNTHETIC METRICS</Text>
  </View>;
}

function Metric({ label, value, color = C.text }: { label: string; value: number | string; color?: string }) { return <View style={s.metric}><Text style={[s.value, { color }]}>{value}</Text><Text style={s.label}>{label}</Text></View>; }

const s = StyleSheet.create({ card: { backgroundColor: C.panel, borderWidth: 1, borderColor: C.cyan + '60', padding: 15, gap: 10 }, header: { flexDirection: 'row', alignItems: 'center', gap: 10 }, flex: { flex: 1 }, title: { color: C.cyan, fontWeight: '900', letterSpacing: 1.5, fontSize: 13 }, sub: { color: C.dim, fontSize: 10, marginTop: 2 }, refresh: { borderWidth: 1, borderColor: C.cyan + '60', padding: 7 }, body: { color: C.dim, fontSize: 12, lineHeight: 18 }, grid: { flexDirection: 'row', gap: 8 }, metric: { flex: 1, backgroundColor: '#07131A', borderWidth: 1, borderColor: C.line, alignItems: 'center', paddingVertical: 9 }, value: { fontSize: 18, fontWeight: '900', fontFamily: 'monospace' }, label: { color: C.dim, fontSize: 8, letterSpacing: 1, marginTop: 3 }, evidence: { color: C.green, fontFamily: 'monospace', fontSize: 9, letterSpacing: .4 } });
