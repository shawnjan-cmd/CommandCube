import { memo, useCallback, useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSkin } from '@/hooks/useSkin';
import { memoryLearningEngine, type LearningProfile } from '@/services/memoryLearningEngine';

export type ButlerProcessRibbonProps = {
  isConnected: boolean;
  learningActive: boolean;
  queuePending: number;
  workersRunning: number;
  onOpenLogs: () => void;
  onOpenMemory: () => void;
};

export default memo(function ButlerProcessRibbon({ isConnected, learningActive, queuePending, workersRunning, onOpenLogs, onOpenMemory }: ButlerProcessRibbonProps) {
  const skin = useSkin();
  const [profile, setProfile] = useState<LearningProfile | null>(null);
  const load = useCallback(() => { memoryLearningEngine.getProfile().then(setProfile).catch(() => setProfile(null)); }, []);
  useEffect(() => { load(); }, [load]);
  const localState = profile ? `${profile.candidatesSeen} OBSERVED · ${profile.verifiedCandidates} VERIFIED` : 'LOCAL PROFILE UNAVAILABLE';
  const serverState = isConnected ? (learningActive ? `${workersRunning} WORKERS · ${queuePending} QUEUED` : 'PAIRED · IDLE') : 'OFFLINE · ON-DEMAND LOGS';
  return <View style={[s.root, { borderColor: `${skin.accent}55`, backgroundColor: `${skin.panel}F2` }]}>
    <View style={[s.node, { borderColor: `${skin.accent2}99`, backgroundColor: `${skin.accent2}12` }]}><MaterialCommunityIcons name="brain" size={17} color={skin.accent2} /></View>
    <Pressable onPress={onOpenMemory} accessibilityRole="button" accessibilityLabel="Open local self-learning evidence" style={s.cell}><Text style={[s.label, { color: skin.accent2 }]}>LOCAL LEARNING</Text><Text style={[s.value, { color: skin.text }]} numberOfLines={1}>{localState}</Text></Pressable>
    <View style={[s.divider, { backgroundColor: `${skin.border}99` }]} />
    <Pressable onPress={onOpenLogs} accessibilityRole="button" accessibilityLabel="Open server logs" style={s.cell}><Text style={[s.label, { color: isConnected ? skin.ok : skin.warn }]}>SERVER LOG</Text><Text style={[s.value, { color: skin.text }]} numberOfLines={1}>{serverState}</Text></Pressable>
    <Pressable onPress={load} accessibilityRole="button" accessibilityLabel="Refresh process status" style={[s.refresh, { borderColor: `${skin.accent}66` }]}><MaterialCommunityIcons name="refresh" size={15} color={skin.accent} /></Pressable>
  </View>;
});

const s = StyleSheet.create({ root: { minHeight: 48, borderWidth: 1, borderRadius: 12, paddingHorizontal: 8, paddingVertical: 7, flexDirection: 'row', alignItems: 'center', gap: 8 }, node: { width: 32, height: 32, borderWidth: 1, borderRadius: 9, alignItems: 'center', justifyContent: 'center' }, cell: { flex: 1, minWidth: 0, gap: 2 }, divider: { width: 1, height: 26 }, label: { fontFamily: 'monospace', fontSize: 7, fontWeight: '900', letterSpacing: 0.8 }, value: { fontFamily: 'monospace', fontSize: 7.5 }, refresh: { width: 30, height: 30, borderWidth: 1, borderRadius: 8, alignItems: 'center', justifyContent: 'center' } });
