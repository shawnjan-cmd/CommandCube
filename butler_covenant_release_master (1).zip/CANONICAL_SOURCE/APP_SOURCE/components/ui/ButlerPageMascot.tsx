import { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useSkin } from '@/hooks/useSkin';
import { pageRecipe } from '@/services/stylePageRecipes';
import type { ButlerPageId } from '@/services/pageLayoutCustomization';
import ButlerMascotMotion from '@/components/ui/ButlerMascotMotion';

export default memo(function ButlerPageMascot({ pageId, compact = false }: { pageId: ButlerPageId; compact?: boolean }) {
  const skin = useSkin();
  const recipe = pageRecipe(skin.packId, pageId);
  const size = compact ? 42 : 58;
  return <View accessible accessibilityLabel={`${recipe.eyebrow} themed Butler mascot`} style={[s.root, { borderColor: `${skin.accent}35`, backgroundColor: `${skin.panel}B8` }]}>
    <ButlerMascotMotion size={size} pose={recipe.mascotPose} prop={recipe.mascotProp} paused={false} />
    {!compact && <View style={s.copy}><Text style={[s.eyebrow, { color: skin.accent }]}>{recipe.eyebrow}</Text><Text style={[s.title, { color: skin.text }]}>{recipe.title}</Text><Text style={[s.sub, { color: skin.mid }]}>{recipe.subtitle}</Text></View>}
  </View>;
});
const s = StyleSheet.create({ root: { minHeight: 70, borderWidth: 1, borderRadius: 14, paddingHorizontal: 8, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 8 }, copy: { flex: 1, minWidth: 0, gap: 2 }, eyebrow: { fontFamily: 'monospace', fontSize: 7, fontWeight: '900', letterSpacing: 1 }, title: { fontFamily: 'monospace', fontSize: 10, fontWeight: '900', letterSpacing: 0.4 }, sub: { fontFamily: 'monospace', fontSize: 7, lineHeight: 10 } });
