import { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSkin } from '@/hooks/useSkin';
import { IMMUTABLE_SAFETY_RULES } from '@/services/immutableSafetyPolicy';

const ICONS = ['lock-check-outline', 'database-check-outline', 'shield-alert-outline'] as const;

export default memo(function ImmutableRulesCard() {
  const skin = useSkin();
  return <View style={[s.root, { borderColor: `${skin.accent3}55`, backgroundColor: `${skin.panel}F0` }]}>
    <View style={s.heading}><MaterialCommunityIcons name="lock-outline" size={17} color={skin.accent3} /><View style={s.headingCopy}><Text style={[s.kicker, { color: skin.accent3 }]}>CARVED-IN-STONE POLICY</Text><Text style={[s.sub, { color: skin.mid }]}>Shown from the enforced client policy · not a user setting</Text></View><MaterialCommunityIcons name="lock-outline" size={16} color={skin.ok} /></View>
    {IMMUTABLE_SAFETY_RULES.map((rule, index) => <View key={rule.id} style={[s.rule, { borderTopColor: `${skin.border}99` }]}><View style={[s.icon, { borderColor: `${skin.accent3}66`, backgroundColor: `${skin.accent3}10` }]}><MaterialCommunityIcons name={ICONS[index]} size={16} color={skin.accent3} /></View><View style={s.copy}><Text style={[s.title, { color: skin.text }]}>{index + 1}. {rule.title}</Text><Text style={[s.text, { color: skin.dim }]}>{rule.text}</Text></View></View>)}
  </View>;
});

const s = StyleSheet.create({ root: { borderWidth: 1, borderRadius: 13, padding: 11, gap: 7 }, heading: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingBottom: 2 }, headingCopy: { flex: 1 }, kicker: { fontFamily: 'monospace', fontSize: 8, fontWeight: '900', letterSpacing: 1.1 }, sub: { fontFamily: 'monospace', fontSize: 7, marginTop: 2 }, rule: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, paddingTop: 8, borderTopWidth: 1 }, icon: { width: 29, height: 29, borderWidth: 1, borderRadius: 8, alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1, gap: 3 }, title: { fontFamily: 'monospace', fontSize: 8, fontWeight: '900', letterSpacing: 0.3 }, text: { fontFamily: 'monospace', fontSize: 7.5, lineHeight: 11 } });
