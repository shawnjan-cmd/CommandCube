import React from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const C = { panel: '#0C1220', cyan: '#38D9E8', violet: '#B14DFF', amber: '#FFB43D', text: '#E5F5FF', dim: '#7C91A5', line: '#1D3950' };
const OPTIONS = [
  ['Cryptomator', 'Client-side encryption before a user-managed cloud backup.', 'https://cryptomator.org/'],
  ['VeraCrypt', 'Encrypted desktop volume for a manual offline or removable-drive backup.', 'https://veracrypt.io/'],
  ['age', 'Advanced passphrase or public-key file encryption from the paired PC.', 'https://github.com/FiloSottile/age'],
] as const;

export default function ExternalEncryptionGuide() {
  return <View style={s.card}><View style={s.header}><MaterialCommunityIcons name="key-chain" size={22} color={C.violet} /><View style={s.flex}><Text style={s.title}>OPTIONAL SECOND LOCK</Text><Text style={s.sub}>Manual user-controlled backup layer</Text></View></View><Text style={s.body}>Butler never uploads vault files or stores third-party keys. If you export an already encrypted vault envelope, you may place that export inside a separately managed encrypted container.</Text>{OPTIONS.map(([name, desc, url]) => <Pressable key={name} onPress={() => Linking.openURL(url).catch(() => {})} style={s.row}><View style={s.icon}><MaterialCommunityIcons name="shield-key-outline" size={18} color={C.cyan} /></View><View style={s.flex}><Text style={s.name}>{name}</Text><Text style={s.body}>{desc}</Text></View><MaterialCommunityIcons name="open-in-new" size={17} color={C.cyan} /></Pressable>)}<Text style={s.warning}>A second lock does not protect an unlocked or fully compromised device. Protect recovery keys separately.</Text></View>;
}
const s = StyleSheet.create({ card: { backgroundColor: C.panel, borderWidth: 1, borderColor: C.violet + '70', padding: 15, gap: 10 }, header: { flexDirection: 'row', alignItems: 'center', gap: 10 }, flex: { flex: 1 }, title: { color: C.violet, fontWeight: '900', letterSpacing: 1.4, fontSize: 13 }, sub: { color: C.dim, fontSize: 10, marginTop: 2 }, body: { color: C.dim, fontSize: 12, lineHeight: 17 }, row: { flexDirection: 'row', alignItems: 'center', gap: 10, borderTopWidth: 1, borderTopColor: C.line, paddingTop: 10 }, icon: { width: 32, height: 32, borderWidth: 1, borderColor: C.cyan + '70', alignItems: 'center', justifyContent: 'center' }, name: { color: C.cyan, fontWeight: '900', fontSize: 12, letterSpacing: 1 }, warning: { color: C.amber, fontSize: 10, lineHeight: 15 } });
