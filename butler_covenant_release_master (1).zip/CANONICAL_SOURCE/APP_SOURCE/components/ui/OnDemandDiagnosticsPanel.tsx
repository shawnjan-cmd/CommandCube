import React, { useRef, useState } from 'react';
import { Alert, Animated, PanResponder, Pressable, StyleSheet, Text, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { loadServerActivity, type ActivityEntry } from '@/services/trustTransparencyClient';

const C = { bg: '#07101A', panel: '#0C1220', cyan: '#38D9E8', green: '#2FE38A', amber: '#FFB43D', red: '#FF4D5E', text: '#E5F5FF', dim: '#7C91A5', line: '#1D3950' };

export default function OnDemandDiagnosticsPanel() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [entries, setEntries] = useState<ActivityEntry[]>([]);
  const [localCrash, setLocalCrash] = useState('No local crash record loaded.');
  const position = useRef(new Animated.ValueXY({ x: 0, y: 0 })).current;
  const panResponder = useRef(PanResponder.create({ onStartShouldSetPanResponder: () => true, onPanResponderMove: Animated.event([null, { dx: position.x, dy: position.y }], { useNativeDriver: false }), onPanResponderRelease: () => position.extractOffset() })).current;

  const openPanel = async () => {
    setOpen(true); setBusy(true);
    try {
      const [server, crash, boot] = await Promise.all([
        loadServerActivity(120).catch(() => ({ entries: [] as ActivityEntry[] })),
        AsyncStorage.getItem('@butler_last_crash_v2'),
        AsyncStorage.getItem('@butler_boot_errors_v1'),
      ]);
      setEntries(server.entries);
      setLocalCrash(crash ? `LAST CRASH\n${crash}` : boot ? `BOOT ERRORS\n${boot}` : 'No local crash record found.');
    } finally { setBusy(false); }
  };

  if (!open) return <Pressable onPress={openPanel} style={s.launcher}><MaterialCommunityIcons name="bug-check-outline" size={18} color={C.cyan} /><Text style={s.launcherText}>OPEN DIAGNOSTICS</Text></Pressable>;
  return <Animated.View style={[s.panel, { transform: position.getTranslateTransform() }]} {...panResponder.panHandlers}>
    <View style={s.header}><MaterialCommunityIcons name="drag-variant" size={20} color={C.cyan} /><View style={s.flex}><Text style={s.title}>ON-DEMAND DIAGNOSTICS</Text><Text style={s.sub}>No polling · loaded by explicit action</Text></View><Pressable onPress={() => setOpen(false)}><MaterialCommunityIcons name="close" size={20} color={C.dim} /></Pressable></View>
    <View style={s.row}><Pressable onPress={openPanel} style={s.button}><MaterialCommunityIcons name="refresh" size={16} color={C.cyan} /><Text style={s.buttonText}>{busy ? 'LOADING' : 'REFRESH'}</Text></Pressable><Pressable onPress={() => Alert.alert('DIAGNOSTIC SCOPE', 'Butler combines the paired server activity log with local crash records. It redacts nothing further in this view, so do not share screenshots containing private text.')} style={s.button}><MaterialCommunityIcons name="information-outline" size={16} color={C.amber} /><Text style={s.buttonText}>SCOPE</Text></Pressable></View>
    <Text style={s.section}>SERVER ACTIVITY · {entries.length} LOADED</Text>{entries.slice(-14).reverse().map(item => <Text key={`${item.id}-${item.ts}`} style={[s.log, { color: item.tag === 'err' ? C.red : item.tag === 'warn' || item.tag === 'guard' ? C.amber : C.text }]}>[{item.tag}] {item.msg}</Text>)}
    <Text style={s.section}>LOCAL CRASH EVIDENCE</Text><Text selectable style={s.crash}>{localCrash.slice(0, 5000)}</Text>
  </Animated.View>;
}

const s = StyleSheet.create({ launcher: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, borderWidth: 1, borderColor: C.cyan + '70', backgroundColor: C.bg, paddingVertical: 11 }, launcherText: { color: C.cyan, fontWeight: '900', letterSpacing: 1, fontSize: 11 }, panel: { position: 'relative', backgroundColor: C.panel, borderWidth: 1.5, borderColor: C.cyan + '80', padding: 13, gap: 8, maxHeight: 520 }, header: { flexDirection: 'row', alignItems: 'center', gap: 8 }, flex: { flex: 1 }, title: { color: C.cyan, fontWeight: '900', letterSpacing: 1.2, fontSize: 12 }, sub: { color: C.dim, fontSize: 10, marginTop: 2 }, row: { flexDirection: 'row', gap: 8 }, button: { flexDirection: 'row', alignItems: 'center', gap: 5, borderWidth: 1, borderColor: C.line, paddingHorizontal: 10, paddingVertical: 7 }, buttonText: { color: C.text, fontWeight: '900', fontSize: 10, letterSpacing: 1 }, section: { color: C.green, fontFamily: 'monospace', fontSize: 9, letterSpacing: 1, marginTop: 3 }, log: { fontFamily: 'monospace', fontSize: 10, lineHeight: 15 }, crash: { color: C.dim, fontFamily: 'monospace', fontSize: 9, lineHeight: 13, maxHeight: 100 } });
