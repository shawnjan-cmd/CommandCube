import React, { memo } from 'react';
import { StyleSheet, View } from 'react-native';
import ButlerBuildModePanel from '@/components/ui/ButlerBuildModePanel';
import ButlerPageRecipeBadge from '@/components/ui/ButlerPageRecipeBadge';
import ButlerPageMascot from '@/components/ui/ButlerPageMascot';
import { ButlerPageId } from '@/services/pageLayoutCustomization';

export const ButlerPageStudioHost = memo(function ButlerPageStudioHost({ pageId }: { pageId: ButlerPageId }) {
  return <View style={styles.host} accessibilityLabel={`${pageId} page customization studio`}><ButlerPageMascot pageId={pageId} compact /><ButlerPageRecipeBadge pageId={pageId} /><ButlerBuildModePanel pageId={pageId} /></View>;
});

const styles = StyleSheet.create({ host: { width: '100%', zIndex: 5 } });

export default ButlerPageStudioHost;
