import { memo, useEffect, useRef } from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSkin } from '@/hooks/useSkin';

export type ButlerMascotPose = 'welcome' | 'analyst' | 'sentinel' | 'scribe' | 'operator' | 'navigator' | 'builder' | 'guardian';
export type ButlerMascotProp = 'bowtie' | 'graph' | 'shield' | 'document' | 'server' | 'compass' | 'backpack' | 'lock';

const POSE_ICON: Record<ButlerMascotPose, keyof typeof MaterialCommunityIcons.glyphMap> = {
  welcome: 'robot-happy-outline', analyst: 'robot-industrial', sentinel: 'robot-outline', scribe: 'robot-excited-outline', operator: 'robot', navigator: 'robot-confused-outline', builder: 'robot-excited', guardian: 'robot-dead-outline',
};
const PROP_ICON: Record<ButlerMascotProp, keyof typeof MaterialCommunityIcons.glyphMap> = {
  bowtie: 'bow-tie', graph: 'chart-timeline-variant', shield: 'shield-star-outline', document: 'file-document-outline', server: 'server-network', compass: 'compass-outline', backpack: 'bag-personal-outline', lock: 'lock-check-outline',
};

export const ButlerMascotMotion = memo(function ButlerMascotMotion({ size = 72, paused = false, pose = 'welcome', prop = 'bowtie' }: { size?: number; paused?: boolean; pose?: ButlerMascotPose; prop?: ButlerMascotProp }) {
  const skin = useSkin();
  const sway = useRef(new Animated.Value(0)).current;
  const breathe = useRef(new Animated.Value(0.9)).current;
  const orbit = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (paused) { sway.stopAnimation(); breathe.stopAnimation(); orbit.stopAnimation(); sway.setValue(0); breathe.setValue(0.92); orbit.setValue(0); return; }
    const movement = Animated.loop(Animated.sequence([
      Animated.parallel([Animated.timing(sway, { toValue: 1, duration: 3600, useNativeDriver: true }), Animated.timing(breathe, { toValue: 1, duration: 1800, useNativeDriver: true }), Animated.timing(orbit, { toValue: 1, duration: 5200, useNativeDriver: true })]),
      Animated.parallel([Animated.timing(sway, { toValue: -1, duration: 3600, useNativeDriver: true }), Animated.timing(breathe, { toValue: 0.9, duration: 1800, useNativeDriver: true })]),
      Animated.timing(sway, { toValue: 0, duration: 1800, useNativeDriver: true }),
    ])); movement.start(); return () => movement.stop();
  }, [breathe, orbit, paused, sway]);
  const rotate = sway.interpolate({ inputRange: [-1, 0, 1], outputRange: ['-4deg', '0deg', '4deg'] });
  const translateY = sway.interpolate({ inputRange: [-1, 0, 1], outputRange: [2, 0, -3] });
  const orbitRotate = orbit.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const accent = skin.accent;
  return <Animated.View accessible accessibilityRole="image" accessibilityLabel={`Butler mascot ${pose}`} style={[s.wrap, { width: size * 1.18, height: size * 1.18, opacity: breathe, transform: [{ perspective: 600 }, { rotateY: rotate }, { translateY }] }]}>
    <Animated.View style={[s.ring, { width: size * 1.08, height: size * 1.08, borderRadius: size, borderColor: `${skin.accent2}45`, transform: [{ rotate: orbitRotate }] }]} />
    <View style={[s.halo, { width: size, height: size, borderRadius: size / 2, borderColor: `${accent}75`, backgroundColor: `${accent}13`, shadowColor: accent }]}>
      <View style={[s.core, { width: size * 0.76, height: size * 0.76, borderRadius: size, borderColor: `${skin.accent3}70`, backgroundColor: `${skin.panel2}E8` }]}>
        <MaterialCommunityIcons name={POSE_ICON[pose]} size={size * 0.39} color={accent} />
        <View style={[s.prop, { right: size * 0.09, bottom: size * 0.1, borderColor: `${skin.accent3}80`, backgroundColor: `${skin.accent3}22` }]}><MaterialCommunityIcons name={PROP_ICON[prop]} size={size * 0.16} color={skin.accent3} /></View>
      </View>
    </View>
  </Animated.View>;
});
const s = StyleSheet.create({ wrap: { alignItems: 'center', justifyContent: 'center' }, ring: { position: 'absolute', borderWidth: 1, borderStyle: 'dashed' }, halo: { alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, shadowOpacity: 0.45, shadowRadius: 12, elevation: 4 }, core: { alignItems: 'center', justifyContent: 'center', borderWidth: 1.2 }, prop: { position: 'absolute', width: 22, height: 22, borderWidth: 1, borderRadius: 7, alignItems: 'center', justifyContent: 'center' } });
export default ButlerMascotMotion;
