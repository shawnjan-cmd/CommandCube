import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { proposeCovenant, type IntentReceiptCovenant } from '@/services/intentReceiptCovenant';

const C = { panel: '#0C1220', panel2: '#101827', cyan: '#38D9E8', green: '#2FE38A', amber: '#FFB43D', violet: '#B14DFF', red: '#FF4D5E', text: '#E5F5FF', dim: '#7C91A5', line: '#1D3950' };

type PromiseRow = { icon: keyof typeof MaterialCommunityIcons.glyphMap; title: string; copy: string; color: string };
const PROMISES: PromiseRow[] = [
  { icon: 'text-search', title: 'FIRST · BUTLER SHOWS THE PLAN', copy: 'You say what you want. Butler turns it into a plain plan instead of guessing what you meant.', color: C.cyan },
  { icon: 'lock-check-outline', title: 'NEXT · BUTLER SHOWS THE LIMITS', copy: 'You can see what the plan may touch. If the plan changes, Butler stops and asks again.', color: C.amber },
  { icon: 'file-document-outline', title: 'LAST · BUTLER LEAVES PROOF', copy: 'After an approved action, Butler records what happened and what it actually used.', color: C.green },
];

function shortDigest(value: string): string {
  return value.length > 28 ? `${value.slice(0, 14)}…${value.slice(-10)}` : value;
}

export default function CovenantPreviewCard() {
  const [intent, setIntent] = useState('');
  const [covenant, setCovenant] = useState<IntentReceiptCovenant | null>(null);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('Nothing is waiting for approval.');
  const canBuild = intent.trim().length > 0 && !busy;
  const plainLimit = useMemo(() => covenant ? 'Only the review-preview permission is present. No PC action is attached.' : 'No permission has been created yet.', [covenant]);

  const buildPreview = async () => {
    const value = intent.trim();
    if (!value) { setMessage('Tell Butler what you want first. Nothing was created.'); setCovenant(null); return; }
    setBusy(true);
    try {
      const next = await proposeCovenant({
        actorId: 'native-user-intent',
        intent: value,
        proposal: { mode: 'planning-preview', normalizedIntent: value },
        capabilities: ['proposal.review_only'],
        scope: ['native-planning-preview'],
        risk: 'read_only',
        ttlMs: 120_000,
      });
      setCovenant(next);
      setMessage('Preview created. Nothing was sent to the PC and nothing was run.');
      setOpen(true);
    } catch (error: any) {
      setCovenant(null);
      setMessage(String(error?.message || 'Butler could not make the preview. It stopped safely.'));
    } finally { setBusy(false); }
  };

  return (
    <View style={s.card}>
      <View style={s.heroRow}>
        <View style={s.seal}><MaterialCommunityIcons name="shield-star-outline" size={28} color={C.cyan} /></View>
        <View style={s.flex}><Text style={s.kicker}>BUTLER ORIGINAL · PLAIN-LANGUAGE SAFETY</Text><Text style={s.title}>THE BUTLER PROMISE</Text><Text style={s.body}>Before Butler touches your PC, it must tell you what it plans to do, what it is allowed to touch, and what proof it will leave.</Text></View>
      </View>

      <View style={s.promiseStack}>{PROMISES.map(row => <View key={row.title} style={[s.promise, { borderLeftColor: row.color }]}><MaterialCommunityIcons name={row.icon} size={22} color={row.color} /><View style={s.flex}><Text style={[s.promiseTitle, { color: row.color }]}>{row.title}</Text><Text style={s.body}>{row.copy}</Text></View></View>)}</View>

      <View style={s.divider} />
      <Text style={s.sectionTitle}>TRY THE IDEA WITH YOUR OWN WORDS</Text>
      <Text style={s.instruction}>Write a real request below. This creates a local planning preview only. It does not approve, connect, download, or run anything.</Text>
      <TextInput value={intent} onChangeText={setIntent} placeholder="Example: organize the files I choose into a folder" placeholderTextColor={C.dim} multiline numberOfLines={3} style={s.input} accessibilityLabel="Describe a real Butler request" />
      <Pressable disabled={!canBuild} onPress={buildPreview} style={[s.button, !canBuild && s.disabled]} accessibilityRole="button"><MaterialCommunityIcons name="arrow-right-circle-outline" size={20} color={C.text} /><Text style={s.buttonText}>{busy ? 'MAKING YOUR PREVIEW…' : 'SHOW ME WHAT BUTLER WOULD CHECK'}</Text></Pressable>
      <Text style={[s.message, { color: covenant ? C.green : C.amber }]}>{message}</Text>

      {covenant && <View style={s.receipt}>
        <View style={s.receiptHeader}><MaterialCommunityIcons name="check-decagram-outline" size={22} color={C.green} /><View style={s.flex}><Text style={s.receiptTitle}>YOUR REQUEST HAS A SAFETY LABEL</Text><Text style={s.body}>This label lets Butler notice if the plan changes later.</Text></View><Pressable onPress={() => setOpen(!open)} accessibilityRole="button"><MaterialCommunityIcons name={open ? 'chevron-up' : 'chevron-down'} size={24} color={C.green} /></Pressable></View>
        <View style={s.labelRow}><Text style={s.label}>WHAT BUTLER HEARD</Text><Text style={s.value} numberOfLines={3}>{covenant.intent}</Text></View>
        <View style={s.labelRow}><Text style={s.label}>ALLOWED RIGHT NOW</Text><Text style={s.value}>Review the plan on this phone</Text></View>
        <View style={s.labelRow}><Text style={s.label}>NOT ALLOWED RIGHT NOW</Text><Text style={[s.value, { color: C.amber }]}>No PC action · no download · no approval</Text></View>
        {open && <View style={s.details}><Text style={s.mono}>CHECK ID · {shortDigest(covenant.covenantDigest)}</Text><Text style={s.mono}>EXPIRES · {new Date(covenant.expiresAtMs).toLocaleTimeString()}</Text><Text style={s.mono}>SCOPE · Review preview only</Text><Text style={s.mono}>STATUS · Waiting for a separate review</Text><Text style={s.note}>{plainLimit} If a future PC proposal, file scope, script, or model is different, Butler rejects the mismatch instead of silently adapting.</Text></View>}
      </View>}
    </View>
  );
}

const s = StyleSheet.create({
  card: { backgroundColor: C.panel, borderWidth: 1, borderColor: C.cyan + '70', padding: 16, gap: 13 },
  heroRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 11 },
  seal: { width: 52, height: 52, borderRadius: 17, borderWidth: 1, borderColor: C.cyan + '90', backgroundColor: C.cyan + '13', alignItems: 'center', justifyContent: 'center' },
  flex: { flex: 1 }, kicker: { color: C.cyan, fontFamily: 'monospace', fontSize: 8, fontWeight: '900', letterSpacing: 1.1 },
  title: { color: C.text, fontSize: 20, fontWeight: '900', letterSpacing: 1.8, marginTop: 3 },
  body: { color: C.dim, fontSize: 12, lineHeight: 18, marginTop: 4 },
  promiseStack: { gap: 8 }, promise: { flexDirection: 'row', gap: 10, padding: 11, borderLeftWidth: 3, backgroundColor: C.panel2 }, promiseTitle: { fontSize: 10, fontWeight: '900', letterSpacing: 0.8 },
  divider: { height: 1, backgroundColor: C.line }, sectionTitle: { color: C.violet, fontSize: 11, fontWeight: '900', letterSpacing: 1.4 }, instruction: { color: C.text, fontSize: 12, lineHeight: 18 },
  input: { minHeight: 78, color: C.text, borderWidth: 1, borderColor: C.line, backgroundColor: '#080E18', padding: 12, textAlignVertical: 'top', fontSize: 13 },
  button: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7, borderWidth: 1, borderColor: C.cyan + '80', backgroundColor: C.cyan + '18', paddingVertical: 13 }, buttonText: { color: C.text, fontWeight: '900', letterSpacing: 0.8, fontSize: 10 }, disabled: { opacity: 0.35 }, message: { fontSize: 11, lineHeight: 16, fontWeight: '800' },
  receipt: { borderWidth: 1, borderColor: C.green + '75', backgroundColor: '#06150F', padding: 13, gap: 10 }, receiptHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 }, receiptTitle: { color: C.green, fontSize: 11, fontWeight: '900', letterSpacing: 0.9 }, labelRow: { gap: 3, borderTopWidth: 1, borderTopColor: C.green + '25', paddingTop: 8 }, label: { color: C.dim, fontFamily: 'monospace', fontSize: 8, fontWeight: '900', letterSpacing: 1 }, value: { color: C.text, fontSize: 12, lineHeight: 17 }, details: { borderTopWidth: 1, borderTopColor: C.green + '30', paddingTop: 9, gap: 5 }, mono: { color: C.green, fontFamily: 'monospace', fontSize: 9 }, note: { color: C.amber, fontSize: 10, lineHeight: 15, marginTop: 4 },
});
