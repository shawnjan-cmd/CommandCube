import React, { useEffect, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { configureRemoteSetup, loadRemoteSetup, openRemoteSetupLink, REMOTE_METHODS, type RemoteMethodId } from '@/services/remoteSetupGuide';

const C = { panel: '#0C1220', panel2: '#101827', cyan: '#38D9E8', green: '#2FE38A', amber: '#FFB43D', red: '#FF4D5E', text: '#E5F5FF', dim: '#7C91A5', line: '#1D3950' };

export default function RemoteAccessSetupCard() {
  const [method, setMethod] = useState<RemoteMethodId>('private_vpn');
  const [endpoint, setEndpoint] = useState('');
  const [fingerprint, setFingerprint] = useState('');
  const [optedIn, setOptedIn] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('SETUP REQUIRED');
  const selected = REMOTE_METHODS.find(item => item.id === method) ?? REMOTE_METHODS[0];

  useEffect(() => { loadRemoteSetup().then(record => { setEndpoint(record.endpoint ?? ''); setFingerprint(record.serverFingerprint ?? ''); setOptedIn(record.userOptIn); setStatus(record.state === 'ready' ? 'READY · AUTHENTICATED TEST REQUIRED' : 'SETUP REQUIRED'); }).catch(() => setStatus('UNAVAILABLE · FAILED CLOSED')); }, []);

  const save = async () => {
    setBusy(true);
    try {
      const { result } = await configureRemoteSetup(endpoint, fingerprint, optedIn);
      setStatus(result.ok ? 'READY · PINNED IDENTITY SAVED' : `FAILED CLOSED · ${result.reason}`);
      if (result.ok) Alert.alert('REMOTE SETUP SAVED', 'The endpoint and fingerprint are encrypted locally. Butler will not create a relay, open router ports, install software, or store credentials. Run the authenticated connection test from the normal pairing flow.');
      else Alert.alert('REMOTE SETUP BLOCKED', result.reason);
    } finally { setBusy(false); }
  };

  return <View style={s.card}>
    <View style={s.header}><MaterialCommunityIcons name="earth" size={25} color={C.cyan} /><View style={{ flex: 1 }}><Text style={s.title}>NON-LAN CONNECTION SETUP</Text><Text style={s.sub}>Guided, user-owned remote access. No hidden relay and no new Android permissions.</Text></View></View>
    <View style={s.warning}><MaterialCommunityIcons name="alert-outline" size={18} color={C.amber} /><Text style={s.warningText}>Butler cannot safely create third-party accounts, install VPN software, expose router ports, or accept embedded credentials. It opens setup pages only after you tap.</Text></View>
    <Text style={s.label}>CHOOSE YOUR USER-MANAGED METHOD</Text>
    {REMOTE_METHODS.map(item => <Pressable key={item.id} onPress={() => setMethod(item.id)} style={[s.method, method === item.id && s.methodSelected]}><MaterialCommunityIcons name={method === item.id ? 'radiobox-marked' : 'radiobox-blank'} size={19} color={method === item.id ? C.green : C.dim} /><View style={{ flex: 1 }}><Text style={s.methodTitle}>{item.title}</Text><Text style={s.methodText}>{item.summary}</Text></View></Pressable>)}
    <Text style={s.label}>GUIDED STEPS · {selected.title}</Text>
    {selected.steps.map((step, index) => <View key={step} style={s.step}><Text style={s.stepNumber}>{index + 1}</Text><Text style={s.stepText}>{step}</Text></View>)}
    <Pressable onPress={async () => { const ok = await openRemoteSetupLink(selected.setupUrl); if (!ok) Alert.alert('LINK UNAVAILABLE', 'Open the provider or documentation site manually.'); }} style={s.link}><MaterialCommunityIcons name="open-in-new" size={17} color={C.cyan} /><Text style={s.linkText}>OPEN SETUP GUIDE</Text></Pressable>
    <Text style={s.label}>PIN THE PC IDENTITY</Text>
    <TextInput value={endpoint} onChangeText={setEndpoint} placeholder="https://your-private-endpoint" placeholderTextColor={C.dim} autoCapitalize="none" keyboardType="url" style={s.input} accessibilityLabel="Remote HTTPS endpoint" />
    <TextInput value={fingerprint} onChangeText={setFingerprint} placeholder="sha256: fingerprint from PC console" placeholderTextColor={C.dim} autoCapitalize="none" style={s.input} accessibilityLabel="Remote server fingerprint" />
    <Pressable onPress={() => setOptedIn(value => !value)} style={s.consent}><MaterialCommunityIcons name={optedIn ? 'checkbox-marked' : 'checkbox-blank-outline'} size={22} color={optedIn ? C.green : C.dim} /><Text style={s.consentText}>I reviewed the endpoint, own or authorize the remote network, and understand remote transport changes the trust boundary.</Text></Pressable>
    <Pressable disabled={busy} onPress={save} style={[s.save, busy && { opacity: 0.55 }]}><MaterialCommunityIcons name="content-save-check-outline" size={19} color={C.text} /><Text style={s.saveText}>{busy ? 'SAVING…' : 'SAVE PINNED SETUP'}</Text></Pressable>
    <Text style={[s.status, status.startsWith('FAILED') ? { color: C.red } : { color: C.green }]}>{status}</Text>
  </View>;
}

const s = StyleSheet.create({
  card: { backgroundColor: C.panel, borderWidth: 1, borderColor: C.cyan + '70', padding: 15, gap: 11 },
  header: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 }, title: { color: C.cyan, fontSize: 13, fontWeight: '900', letterSpacing: 1.4 }, sub: { color: C.dim, fontSize: 11, lineHeight: 16, marginTop: 3 }, warning: { flexDirection: 'row', gap: 8, backgroundColor: '#241B08', borderWidth: 1, borderColor: C.amber + '60', padding: 10 }, warningText: { flex: 1, color: C.amber, fontSize: 11, lineHeight: 16 }, label: { color: C.dim, fontSize: 10, fontWeight: '900', letterSpacing: 1.6, marginTop: 3 }, method: { flexDirection: 'row', gap: 9, padding: 10, borderWidth: 1, borderColor: C.line, backgroundColor: C.panel2 }, methodSelected: { borderColor: C.green + '90', backgroundColor: C.green + '12' }, methodTitle: { color: C.text, fontWeight: '900', fontSize: 11, letterSpacing: 0.7 }, methodText: { color: C.dim, fontSize: 11, lineHeight: 16, marginTop: 3 }, step: { flexDirection: 'row', gap: 9, alignItems: 'flex-start' }, stepNumber: { width: 22, height: 22, textAlign: 'center', paddingTop: 3, borderWidth: 1, borderColor: C.cyan + '70', color: C.cyan, fontWeight: '900', fontSize: 11 }, stepText: { flex: 1, color: C.text, fontSize: 11, lineHeight: 16 }, link: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderColor: C.cyan + '70', paddingHorizontal: 11, paddingVertical: 9 }, linkText: { color: C.cyan, fontWeight: '900', fontSize: 10, letterSpacing: 1 }, input: { color: C.text, borderWidth: 1, borderColor: C.line, backgroundColor: '#070B12', paddingHorizontal: 11, paddingVertical: 10, fontSize: 12 }, consent: { flexDirection: 'row', gap: 8, alignItems: 'flex-start' }, consentText: { flex: 1, color: C.text, fontSize: 11, lineHeight: 16 }, save: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7, backgroundColor: C.green + '25', borderWidth: 1, borderColor: C.green + '90', paddingVertical: 12 }, saveText: { color: C.text, fontWeight: '900', letterSpacing: 1 }, status: { fontFamily: 'monospace', fontSize: 10, letterSpacing: 0.6 },
});
