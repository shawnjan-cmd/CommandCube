import { Linking } from 'react-native';
import { encryptedStorage } from '@/services/encryptedStorage';
import { configureRemote, initialRemoteSession, type RemoteSessionRecord, type RemoteTransitionResult } from '@/services/remoteConnectionPolicy';

const KEY = '@butler_remote_setup_v1';

export type RemoteMethodId = 'private_vpn' | 'private_https' | 'ssh_reverse_tunnel';
export type RemoteMethod = {
  id: RemoteMethodId;
  title: string;
  summary: string;
  steps: readonly string[];
  setupUrl: string;
  requiresUserAccount: boolean;
  requiresServerCertificate: boolean;
};

export const REMOTE_METHODS: readonly RemoteMethod[] = Object.freeze([
  {
    id: 'private_vpn',
    title: 'PRIVATE OVERLAY VPN',
    summary: 'Preferred worldwide path: both devices join a private network you control, then Butler uses the PC private address.',
    steps: ['Install the same reputable private-VPN client on the PC and Android device.', 'Sign in yourself and approve both devices in that provider account.', 'Start Butler on the PC, copy its private VPN address, and verify the server certificate or fingerprint.', 'Enter the HTTPS endpoint and pinned fingerprint here, then run a visible connection test.'],
    setupUrl: 'https://tailscale.com/download',
    requiresUserAccount: true,
    requiresServerCertificate: true,
  },
  {
    id: 'private_https',
    title: 'USER-MANAGED HTTPS',
    summary: 'Use a trusted private DNS name or private reverse proxy that you operate. Butler does not create or host the relay.',
    steps: ['Configure the PC server behind your own HTTPS endpoint.', 'Restrict the endpoint to your identity/VPN and firewall policy.', 'Obtain the server fingerprint from the PC console through a trusted channel.', 'Enter the endpoint and fingerprint here, then test the authenticated session.'],
    setupUrl: 'https://developer.mozilla.org/en-US/docs/Web/HTTP/Overview',
    requiresUserAccount: false,
    requiresServerCertificate: true,
  },
  {
    id: 'ssh_reverse_tunnel',
    title: 'SSH REVERSE TUNNEL',
    summary: 'Advanced option for users who already operate a hardened SSH host. No credentials are generated or stored by Butler.',
    steps: ['Create and secure your own SSH host and key policy.', 'Create the reverse tunnel outside Butler using your reviewed server configuration.', 'Bind the forwarded Butler port to the intended private interface only.', 'Enter the resulting HTTPS endpoint and pinned fingerprint here.'],
    setupUrl: 'https://www.ssh.com/academy/ssh/tunneling',
    requiresUserAccount: true,
    requiresServerCertificate: true,
  },
]);

export async function loadRemoteSetup(): Promise<RemoteSessionRecord> {
  const raw = await encryptedStorage.getItem(KEY).catch(() => null);
  if (!raw) return initialRemoteSession();
  try {
    const parsed = JSON.parse(raw) as Partial<RemoteSessionRecord>;
    return { ...initialRemoteSession(), ...parsed };
  } catch {
    return initialRemoteSession();
  }
}

export async function saveRemoteSetup(record: RemoteSessionRecord): Promise<void> {
  await encryptedStorage.setItem(KEY, JSON.stringify(record));
}

export function validateRemoteEndpoint(endpoint: string): string | null {
  const value = endpoint.trim();
  if (!value) return 'Enter the endpoint supplied by your own setup.';
  if (!value.startsWith('https://')) return 'Non-LAN setup requires HTTPS. Plain HTTP is not accepted for remote mode.';
  try {
    const parsed = new URL(value);
    if (!parsed.hostname || parsed.username || parsed.password) return 'Endpoint must not contain embedded credentials.';
    return null;
  } catch {
    return 'Enter a valid HTTPS endpoint.';
  }
}

export async function configureRemoteSetup(endpoint: string, fingerprint: string, optedIn: boolean): Promise<{ result: RemoteTransitionResult; record: RemoteSessionRecord }> {
  const current = await loadRemoteSetup();
  const endpointError = validateRemoteEndpoint(endpoint);
  if (endpointError) return { result: { ok: false, state: 'setup_required', reason: endpointError }, record: current };
  if (!/^sha256:[A-Za-z0-9+/=_:-]{8,}$/.test(fingerprint.trim())) {
    return { result: { ok: false, state: 'setup_required', reason: 'A sha256 server fingerprint from the PC is required.' }, record: current };
  }
  const result = configureRemote(current, endpoint.trim(), fingerprint.trim(), optedIn);
  if (!result.ok) return { result, record: current };
  const record: RemoteSessionRecord = { ...current, endpoint: endpoint.trim(), serverFingerprint: fingerprint.trim(), userOptIn: true, state: 'ready' };
  await saveRemoteSetup(record);
  return { result, record };
}

export async function openRemoteSetupLink(url: string): Promise<boolean> {
  try {
    if (!(await Linking.canOpenURL(url))) return false;
    await Linking.openURL(url);
    return true;
  } catch {
    return false;
  }
}
