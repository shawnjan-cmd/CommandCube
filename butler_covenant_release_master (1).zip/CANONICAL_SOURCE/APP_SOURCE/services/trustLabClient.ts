import { connectionHub } from './connectionHub';
import { recordScriptEvidence } from './scriptEvidencePipeline';

export type TrustFinding = {
  rule_id: string;
  severity: 'block' | 'review';
  message: string;
  line: number | null;
  evidence: string;
};

export type TrustReport = {
  script_id: string;
  sha256: string;
  status: 'verified' | 'review' | 'blocked';
  syntax_ok?: boolean;
  source_bytes?: number;
  stages?: Array<Record<string, unknown>>;
  capabilities?: string[];
  scanner_version?: string;
  verified: boolean;
  origin: string;
  findings: TrustFinding[];
  immutable_rules: string[];
};

export async function scanScriptTrust(scriptId: string, source: string, origin = 'bundled-library'): Promise<TrustReport> {
  const response = await connectionHub.fetch('/api/trust/scan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ scriptId, source, origin, allowNetwork: false }),
    timeoutMs: 10000,
  });
  const payload: any = await response.json().catch(() => ({}));
  if (!response.ok || !payload?.report) throw new Error(payload?.code || payload?.error || `Trust Lab HTTP ${response.status}`);
  const report = { ...payload.report, immutable_rules: Array.isArray(payload.immutableRules) ? payload.immutableRules : [] } as TrustReport;
  await recordScriptEvidence(source, report);
  return report;
}
