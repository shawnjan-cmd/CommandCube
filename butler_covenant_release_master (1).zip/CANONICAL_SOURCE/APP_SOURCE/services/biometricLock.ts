/**
 * Butler AI — PC Challenge Lock
 *
 * Compatibility filename retained for older imports. This service deliberately
 * contains no biometric, camera, microphone, secret-phrase, or background
 * listener behavior. Vault/app unlock uses either a visible one-time challenge
 * displayed by the paired PC or a locally configured password/PIN fallback.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { connectionHub } from './connectionHub';
import { serverConnection } from './serverConnection';

const LOCK_ENABLED_KEY = '@butler_pc_challenge_lock_enabled_v2';
const LOCK_TIMEOUT_KEY = '@butler_pc_challenge_lock_timeout_v2';
const LOCK_STATE_KEY = '@butler_pc_challenge_lock_state_v2';
const PIN_HASH_KEY = '@butler_pc_challenge_pin_hash_v2';

export type BiometricType = 'NONE';
export type LockStatus = 'locked' | 'unlocked' | 'unavailable' | 'disabled' | 'challenge_required';
export interface BiometricLockState {
  status: LockStatus;
  biometricType: BiometricType;
  isAvailable: boolean;
  isEnabled: boolean;
  timeoutSec: number;
  lastUnlockedAt: number;
  failedAttempts: number;
  pinSet: boolean;
  challengePending: boolean;
  challengeHint: string;
}

type Listener = (state: BiometricLockState) => void;

class PcChallengeLockService {
  private static _instance: PcChallengeLockService;
  static getInstance() { if (!this._instance) this._instance = new PcChallengeLockService(); return this._instance; }
  private _state: BiometricLockState = { status: 'disabled', biometricType: 'NONE', isAvailable: false, isEnabled: false, timeoutSec: 60, lastUnlockedAt: 0, failedAttempts: 0, pinSet: false, challengePending: false, challengeHint: '' };
  private _listeners = new Set<Listener>();
  private _backgroundTime = 0;
  private _initialized = false;

  subscribe(fn: Listener): () => void { this._listeners.add(fn); fn({ ...this._state }); return () => this._listeners.delete(fn); }
  private _emit() { this._listeners.forEach(fn => { try { fn({ ...this._state }); } catch {} }); }
  getState(): BiometricLockState { return { ...this._state }; }

  async init(): Promise<void> {
    if (this._initialized) return;
    this._initialized = true;
    try {
      const values = await AsyncStorage.multiGet([LOCK_ENABLED_KEY, LOCK_TIMEOUT_KEY, PIN_HASH_KEY, LOCK_STATE_KEY]);
      this._state.isEnabled = values[0][1] === '1';
      this._state.timeoutSec = Math.max(15, Math.min(3600, parseInt(values[1][1] ?? '60', 10) || 60));
      this._state.pinSet = !!values[2][1];
      this._state.status = !this._state.isEnabled ? 'disabled' : values[3][1] === 'locked' ? 'locked' : 'unlocked';
      if (this._state.status === 'unlocked') this._state.lastUnlockedAt = Date.now();
    } catch { this._state.status = 'unavailable'; }
    this._emit();
  }

  onBackground(): void { this._backgroundTime = Date.now(); if (this._state.isEnabled) void AsyncStorage.setItem(LOCK_STATE_KEY, 'locked'); }
  onForeground(): void { if (!this._state.isEnabled) return; if (Date.now() - this._backgroundTime >= this._state.timeoutSec * 1000) { this._state.status = 'locked'; this._state.challengePending = false; this._emit(); } }

  async requestPcChallenge(): Promise<{ success: boolean; prompt?: string; error?: string }> {
    if (!this._state.isEnabled) return { success: false, error: 'PC challenge lock is disabled.' };
    if (!connectionHub.getState().isConnected) { this._state.status = 'challenge_required'; this._emit(); return { success: false, error: 'Pair the PC server before requesting a vault challenge.' }; }
    try {
      const response = await connectionHub.fetch('/api/vault/challenge', { method: 'POST', body: JSON.stringify({ purpose: 'vault_unlock', deviceId: serverConnection.getDeviceId() }) });
      const payload = await response.json();
      if (!response.ok || !payload?.challengeId || !payload?.prompt) throw new Error(payload?.error || 'PC challenge unavailable');
      this._state.challengePending = true; this._state.status = 'challenge_required'; this._state.challengeHint = String(payload.prompt); this._emit();
      return { success: true, prompt: String(payload.prompt) };
    } catch (error: any) { this._state.status = 'challenge_required'; this._emit(); return { success: false, error: error?.message || 'PC challenge unavailable' }; }
  }

  async verifyPcChallenge(answer: string): Promise<{ success: boolean; error?: string }> {
    const value = answer.trim();
    if (!value) return { success: false, error: 'Enter the response shown by the PC.' };
    try {
      const response = await connectionHub.fetch('/api/vault/challenge/verify', { method: 'POST', body: JSON.stringify({ answer: value, deviceId: serverConnection.getDeviceId() }) });
      const payload = await response.json();
      if (!response.ok || payload?.verified !== true) { this._state.failedAttempts += 1; this._emit(); return { success: false, error: payload?.error || 'PC challenge rejected' }; }
      await this._markUnlocked();
      return { success: true };
    } catch (error: any) { return { success: false, error: error?.message || 'PC challenge unavailable' }; }
  }

  async unlockWithBiometric(): Promise<{ success: boolean; error?: string }> { return { success: false, error: 'Fingerprint and biometric unlock are disabled. Use the visible PC challenge or local password.' }; }
  async unlockWithPIN(pin: string): Promise<{ success: boolean; error?: string }> {
    const stored = await AsyncStorage.getItem(PIN_HASH_KEY);
    if (!stored) return { success: false, error: 'No local password is configured.' };
    if (await hashPIN(pin) !== stored) { this._state.failedAttempts += 1; this._emit(); return { success: false, error: 'Incorrect local password.' }; }
    await this._markUnlocked(); return { success: true };
  }
  async setPIN(pin: string): Promise<void> { if (pin.trim().length < 6) throw new Error('LOCAL_PASSWORD_TOO_SHORT'); await AsyncStorage.setItem(PIN_HASH_KEY, await hashPIN(pin)); this._state.pinSet = true; this._emit(); }
  async clearPIN(): Promise<void> { await AsyncStorage.removeItem(PIN_HASH_KEY).catch(() => {}); this._state.pinSet = false; this._emit(); }
  async setEnabled(enabled: boolean): Promise<void> { this._state.isEnabled = enabled; this._state.status = enabled ? 'locked' : 'disabled'; await AsyncStorage.multiSet([[LOCK_ENABLED_KEY, enabled ? '1' : '0'], [LOCK_STATE_KEY, enabled ? 'locked' : 'unlocked']]); this._emit(); }
  async setTimeout(sec: number): Promise<void> { this._state.timeoutSec = Math.max(15, Math.min(3600, Math.round(sec))); await AsyncStorage.setItem(LOCK_TIMEOUT_KEY, String(this._state.timeoutSec)); this._emit(); }
  async forceLock(): Promise<void> { if (!this._state.isEnabled) return; this._state.status = 'locked'; this._state.challengePending = false; await AsyncStorage.setItem(LOCK_STATE_KEY, 'locked'); this._emit(); }

  private async _markUnlocked(): Promise<void> { this._state.status = 'unlocked'; this._state.challengePending = false; this._state.challengeHint = ''; this._state.lastUnlockedAt = Date.now(); this._state.failedAttempts = 0; await AsyncStorage.setItem(LOCK_STATE_KEY, 'unlocked'); this._emit(); }
}

async function hashPIN(pin: string): Promise<string> {
  const Crypto = require('expo-crypto');
  return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, `butler_local_password_v2:${pin}`);
}

export const biometricLock = PcChallengeLockService.getInstance();
export const pcChallengeLock = biometricLock;
