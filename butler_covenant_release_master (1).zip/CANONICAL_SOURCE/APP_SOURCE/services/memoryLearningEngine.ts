import { encryptedStorage } from './encryptedStorage';
import { admitMemory, type MemoryAdmissionInput, type MemoryAdmissionResult } from './memoryAdmission';
import { assertImmutablePolicyIntact } from './immutableSafetyPolicy';

const KEY = '@butler_memory_learning_v1';
const MAX_SOURCES = 32;

export type LearningProfile = {
  version: 1;
  candidatesSeen: number;
  admitted: number;
  rejected: number;
  verifiedCandidates: number;
  sourceCounts: Record<string, number>;
  rejectionCounts: Record<string, number>;
  lastObservationAt: number | null;
};

const emptyProfile = (): LearningProfile => ({ version: 1, candidatesSeen: 0, admitted: 0, rejected: 0, verifiedCandidates: 0, sourceCounts: {}, rejectionCounts: {}, lastObservationAt: null });

class MemoryLearningEngine {
  private profile: LearningProfile = emptyProfile();
  private loaded = false;

  async load(): Promise<void> {
    if (this.loaded) return;
    assertImmutablePolicyIntact();
    const raw = await encryptedStorage.getItem(KEY);
    if (raw) {
      try { this.profile = { ...emptyProfile(), ...JSON.parse(raw), version: 1 }; } catch { this.profile = emptyProfile(); }
    }
    this.loaded = true;
  }

  async observe(input: MemoryAdmissionInput, evidenceStatus: 'verified' | 'review' | 'blocked' | 'user-approved' = 'review'): Promise<MemoryAdmissionResult> {
    await this.load();
    assertImmutablePolicyIntact();
    const result = admitMemory(input);
    this.profile.candidatesSeen += 1;
    this.profile.lastObservationAt = Date.now();
    const source = String(input.source || 'unknown').slice(0, 80);
    this.profile.sourceCounts[source] = (this.profile.sourceCounts[source] || 0) + 1;
    if (Object.keys(this.profile.sourceCounts).length > MAX_SOURCES) {
      const oldest = Object.keys(this.profile.sourceCounts)[0]; if (oldest) delete this.profile.sourceCounts[oldest];
    }
    if (result.admitted && (evidenceStatus === 'verified' || evidenceStatus === 'user-approved')) {
      this.profile.admitted += 1;
      if (evidenceStatus === 'verified') this.profile.verifiedCandidates += 1;
    } else {
      this.profile.rejected += 1;
      this.profile.rejectionCounts[result.reason] = (this.profile.rejectionCounts[result.reason] || 0) + 1;
    }
    await encryptedStorage.setItem(KEY, JSON.stringify(this.profile));
    return result;
  }

  async getProfile(): Promise<LearningProfile> {
    await this.load();
    return JSON.parse(JSON.stringify(this.profile));
  }

  async reset(): Promise<void> {
    await encryptedStorage.removeItem(KEY);
    this.profile = emptyProfile();
    this.loaded = true;
  }
}

export const memoryLearningEngine = new MemoryLearningEngine();
