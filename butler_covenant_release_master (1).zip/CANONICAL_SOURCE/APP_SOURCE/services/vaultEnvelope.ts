import * as Crypto from 'expo-crypto';
import { gcm } from '@noble/ciphers/aes.js';
import { hexToBytes } from '@noble/ciphers/utils.js';
import { encryptedStorage } from './encryptedStorage';

const PREFIX = 'BUTLER-VAULT2';
const encoder = new TextEncoder();
const decoder = new TextDecoder();

function b64(bytes: Uint8Array): string { let binary = ''; for (const byte of bytes) binary += String.fromCharCode(byte); return btoa(binary); }
function unb64(value: string): Uint8Array { const binary = atob(value); const out = new Uint8Array(binary.length); for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i); return out; }
function hex(bytes: Uint8Array): string { return Array.from(bytes).map(v => v.toString(16).padStart(2, '0')).join(''); }

export async function sealVaultPayload(base64Content: string): Promise<string> {
  const dataKey = await Crypto.getRandomBytesAsync(32);
  const nonce = await Crypto.getRandomBytesAsync(12);
  const cipher = gcm(dataKey, nonce).encrypt(encoder.encode(base64Content));
  const digest = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, base64Content);
  const wrappedKey = await encryptedStorage.encryptBlobText(hex(dataKey));
  return [PREFIX, b64(nonce), b64(cipher), digest, b64(encoder.encode(wrappedKey))].join('|');
}

export async function openVaultPayload(envelope: string): Promise<string> {
  const [prefix, nonceText, cipherText, expectedDigest, wrappedText] = envelope.split('|');
  if (prefix !== PREFIX || !nonceText || !cipherText || !expectedDigest || !wrappedText) throw new Error('VAULT_ENVELOPE_INVALID');
  const wrappedKey = decoder.decode(unb64(wrappedText));
  const keyHex = await encryptedStorage.decryptBlobText(wrappedKey);
  const plain = gcm(hexToBytes(keyHex), unb64(nonceText)).decrypt(unb64(cipherText));
  const content = decoder.decode(plain);
  const actualDigest = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, content);
  if (actualDigest !== expectedDigest) throw new Error('VAULT_INTEGRITY_FAILED');
  return content;
}

export const VAULT_ENVELOPE_SPEC = Object.freeze({
  version: 2,
  layers: ['random per-file AES-256-GCM data key', 'authenticated encrypted key wrap in Butler storage', 'SHA-256 content integrity check'],
  warning: 'Layering improves compartmentalization but cannot protect a fully compromised or unlocked device.',
});
