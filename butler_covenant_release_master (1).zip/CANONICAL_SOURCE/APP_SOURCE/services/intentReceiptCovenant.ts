import * as Crypto from 'expo-crypto';

export type CovenantRisk = 'read_only' | 'private_read' | 'external_read' | 'side_effect' | 'remote_side_effect';
export type CovenantStatus = 'proposed' | 'approved' | 'executing' | 'closed' | 'expired' | 'drifted';

export type IntentReceiptCovenant = {
  version: '1.0-intent-receipt-covenant';
  covenantId: string;
  actorId: string;
  intent: string;
  proposal: Record<string, unknown>;
  capabilities: string[];
  scope: string[];
  scriptDigest: string;
  modelDigest: string;
  risk: CovenantRisk;
  createdAtMs: number;
  expiresAtMs: number;
  covenantDigest: string;
  status: CovenantStatus;
};

export type CovenantApproval = {
  approvalId: string;
  covenantId: string;
  actorId: string;
  covenantDigest: string;
  expiresAtMs: number;
  nonce: string;
};

export type CovenantReceipt = {
  receiptId: string;
  covenantId: string;
  covenantDigest: string;
  actorId: string;
  outcome: 'succeeded' | 'failed' | 'cancelled' | 'rejected';
  actualCapabilities: string[];
  actualScope: string[];
  resultDigest: string;
  createdAtMs: number;
  receiptDigest: string;
};

export function covenantCanonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(covenantCanonical).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value as Record<string, unknown>).sort().map(key => `${JSON.stringify(key)}:${covenantCanonical((value as Record<string, unknown>)[key])}`).join(',')}}`;
  }
  return JSON.stringify(value);
}

async function digest(value: unknown): Promise<string> {
  return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, covenantCanonical(value));
}

function boundedSet(values: string[] | undefined, label: string): string[] {
  const result = [...new Set((values ?? []).map(value => value.trim()).filter(Boolean))].sort();
  if (!result.length || result.length > 32 || result.some(value => value.length > 240)) throw new Error(`${label} outside covenant bounds`);
  return result;
}

export async function proposeCovenant(input: {
  actorId: string;
  intent: string;
  proposal: Record<string, unknown>;
  capabilities: string[];
  scope: string[];
  scriptDigest?: string;
  modelDigest?: string;
  risk?: CovenantRisk;
  ttlMs?: number;
  nowMs?: number;
}): Promise<IntentReceiptCovenant> {
  const now = input.nowMs ?? Date.now();
  const ttl = Math.min(Math.max(input.ttlMs ?? 120_000, 5_000), 300_000);
  if (!input.actorId || !input.intent.trim()) throw new Error('actor and intent required');
  const body = {
    version: '1.0-intent-receipt-covenant' as const,
    covenantId: Crypto.randomUUID(),
    actorId: input.actorId,
    intent: input.intent.trim().slice(0, 2000),
    proposal: input.proposal,
    capabilities: boundedSet(input.capabilities, 'capabilities'),
    scope: boundedSet(input.scope, 'scope'),
    scriptDigest: input.scriptDigest ?? '',
    modelDigest: input.modelDigest ?? '',
    risk: input.risk ?? 'read_only' as CovenantRisk,
    createdAtMs: now,
    expiresAtMs: now + ttl,
  };
  return { ...body, covenantDigest: await digest(body), status: 'proposed' };
}

export function isCovenantCurrent(covenant: IntentReceiptCovenant, nowMs = Date.now()): boolean {
  return (covenant.status === 'proposed' || covenant.status === 'approved' || covenant.status === 'executing')
    && covenant.createdAtMs <= nowMs
    && covenant.expiresAtMs > nowMs;
}

export async function verifyCovenantDrift(covenant: IntentReceiptCovenant, current: { proposal: Record<string, unknown>; capabilities: string[]; scope: string[]; scriptDigest?: string; modelDigest?: string }): Promise<{ ok: boolean; reason: string; expectedDigest: string }> {
  const body = {
    version: covenant.version,
    covenantId: covenant.covenantId,
    actorId: covenant.actorId,
    intent: covenant.intent,
    proposal: current.proposal,
    capabilities: boundedSet(current.capabilities, 'capabilities'),
    scope: boundedSet(current.scope, 'scope'),
    scriptDigest: current.scriptDigest ?? '',
    modelDigest: current.modelDigest ?? '',
    risk: covenant.risk,
    createdAtMs: covenant.createdAtMs,
    expiresAtMs: covenant.expiresAtMs,
  };
  const expectedDigest = await digest(body);
  return expectedDigest === covenant.covenantDigest
    ? { ok: true, reason: 'covenant_fields_unchanged', expectedDigest }
    : { ok: false, reason: 'proposal_capability_scope_or_digest_drift', expectedDigest };
}

export async function createCovenantReceipt(input: { covenant: IntentReceiptCovenant; actorId: string; outcome: CovenantReceipt['outcome']; result: unknown; actualCapabilities: string[]; actualScope: string[] }): Promise<CovenantReceipt> {
  if (input.actorId !== input.covenant.actorId) throw new Error('receipt actor mismatch');
  const actualCapabilities = boundedSet(input.actualCapabilities, 'actual capabilities');
  const actualScope = boundedSet(input.actualScope, 'actual scope');
  if (actualCapabilities.join('\0') !== input.covenant.capabilities.join('\0') || actualScope.join('\0') !== input.covenant.scope.join('\0')) throw new Error('receipt exceeds covenant bounds');
  const body = { receiptId: Crypto.randomUUID(), covenantId: input.covenant.covenantId, covenantDigest: input.covenant.covenantDigest, actorId: input.actorId, outcome: input.outcome, actualCapabilities, actualScope, resultDigest: await digest(input.result), createdAtMs: Date.now() };
  return { ...body, receiptDigest: await digest(body) };
}
