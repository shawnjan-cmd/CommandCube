import { memoryLearningEngine, type LearningProfile } from './memoryLearningEngine';
import type { TrustReport } from './trustLabClient';

/** Single public seam for script evidence + learning. Raw script text is never persisted here. */
export async function recordScriptEvidence(source: string, report: TrustReport): Promise<void> {
  await memoryLearningEngine.observe({
    text: source,
    source: 'trustlab-script',
    confidence: report.status === 'verified' ? 1 : 0.5,
    sensitivity: 'public',
    userApproved: report.status === 'verified',
    provenanceId: report.sha256,
    durable: report.status === 'verified',
  }, report.status).catch(() => {});
}

export async function loadScriptEvidenceProfile(): Promise<LearningProfile> {
  return memoryLearningEngine.getProfile();
}

export const SCRIPT_EVIDENCE_PIPELINE_SPEC = Object.freeze({
  name: 'TRUSTLAB-EVIDENCE-MEMORY',
  stages: ['static scan', 'immutable policy decision', 'aggregate learning observation'],
  rawSourcePersistence: false,
});
