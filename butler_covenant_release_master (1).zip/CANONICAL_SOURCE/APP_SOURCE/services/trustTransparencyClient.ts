import { connectionHub } from '@/services/connectionHub';
import { BUNDLE_MANIFEST, computeSourceHash } from '@/constants/appSourceBundle';

export type ActivityEntry = { id: number; tag: string; msg: string; ts: number };
export type ServerAuditReport = { script_id: string; sha256: string; status: string; syntax_ok: boolean; findings: unknown[]; stages?: unknown[]; capabilities?: string[]; scanner_version?: string };

async function json<T>(path: string, timeoutMs = 12_000): Promise<T> {
  const response = await connectionHub.fetch(path, { timeoutMs });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body?.error || `REQUEST_FAILED_${response.status}`);
  return body as T;
}

export async function loadServerActivity(limit = 80): Promise<{ entries: ActivityEntry[]; count: number; total: number; guards?: Record<string, unknown> }> {
  return json(`/api/server_log?limit=${Math.min(500, Math.max(1, limit))}`);
}

export async function loadImmutableRules(): Promise<{ rules: Array<{ id: string; title: string; text: string }>; serverTime: number }> {
  return json('/api/trust/rules');
}

export async function auditPairedServer(): Promise<{ scope: string; reports: ServerAuditReport[]; serverTime: number }> {
  return json('/api/trust/server-audit', 30_000);
}

export function describeAppBuildScope() {
  return {
    sourceHash: computeSourceHash(),
    manifestCount: BUNDLE_MANIFEST.length,
    manifest: BUNDLE_MANIFEST.map(item => ({ path: item.path, category: item.category, lines: item.lines })),
    limitation: 'This verifies the bundled source registry and hash; it is not an independent third-party security audit.',
  };
}
