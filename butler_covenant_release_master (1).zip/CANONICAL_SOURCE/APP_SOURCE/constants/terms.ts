export { termsText } from './legalDocuments';
