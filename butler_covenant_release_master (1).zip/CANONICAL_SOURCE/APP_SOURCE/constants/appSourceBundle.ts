/**
 * APP SOURCE BUNDLE v6.0
 * ─────────────────────────────────────────────────────────────────────────────
 * • Full embedded sources registered via registerTabSource()
 * • buildExportJson() → safe JSON object (JSON.stringify handles all escaping)
 * • buildAllFilesExport() → clipboard-friendly text dump
 * • DETAILED_AI_PROMPT exported for embedding in every export output
 *
 * BUG FIXES v6.0:
 *  - Removed all references to expo-clipboard, expo-document-picker, expo-sharing
 *    (these caused black screen on APK install — replaced with RN Clipboard + Share)
 *  - Updated BUNDLE_MANIFEST line counts to current file sizes
 *  - Updated AI prompt to reflect v6 stack and banned package list
 *  - Added metro.config.js hermesParser stub redirect to manifest
 *
 * GUARDS:
 *  - No template-literal backtick embedding of large sources (module size limit)
 *  - Proxy-based BUNDLE_SOURCES for legacy compat (settings.tsx dot-access)
 *  - All source strings registered via registerTabSource() at runtime
 */

export interface BundleFile {
  path: string;
  description: string;
  category: 'tab' | 'component' | 'service' | 'constant' | 'layout';
  lines: number;
}

// ─── Manifest ─────────────────────────────────────────────────────────────────
export const BUNDLE_MANIFEST: BundleFile[] = [
  { path: "app.json", description: "Canonical source: app.json", category: "constant", lines: 66 },
  { path: "app/_layout.tsx", description: "Canonical source: app/_layout.tsx", category: "layout", lines: 254 },
  { path: "app/(tabs)/_layout.tsx", description: "Canonical source: app/(tabs)/_layout.tsx", category: "layout", lines: 319 },
  { path: "app/(tabs)/builder.tsx", description: "Canonical source: app/(tabs)/builder.tsx", category: "tab", lines: 265 },
  { path: "app/(tabs)/butler.tsx", description: "Canonical source: app/(tabs)/butler.tsx", category: "tab", lines: 657 },
  { path: "app/(tabs)/connect.tsx", description: "Canonical source: app/(tabs)/connect.tsx", category: "tab", lines: 360 },
  { path: "app/(tabs)/cosmetic.tsx", description: "Canonical source: app/(tabs)/cosmetic.tsx", category: "tab", lines: 314 },
  { path: "app/(tabs)/fileshare.tsx", description: "Canonical source: app/(tabs)/fileshare.tsx", category: "tab", lines: 335 },
  { path: "app/(tabs)/home.tsx", description: "Canonical source: app/(tabs)/home.tsx", category: "tab", lines: 1023 },
  { path: "app/(tabs)/index.tsx", description: "Canonical source: app/(tabs)/index.tsx", category: "tab", lines: 18 },
  { path: "app/(tabs)/knowledge.tsx", description: "Canonical source: app/(tabs)/knowledge.tsx", category: "tab", lines: 1091 },
  { path: "app/(tabs)/logs.tsx", description: "Canonical source: app/(tabs)/logs.tsx", category: "tab", lines: 290 },
  { path: "app/(tabs)/monitor.tsx", description: "Canonical source: app/(tabs)/monitor.tsx", category: "tab", lines: 107 },
  { path: "app/(tabs)/onboarding.tsx", description: "Canonical source: app/(tabs)/onboarding.tsx", category: "tab", lines: 2328 },
  { path: "app/(tabs)/scripts.tsx", description: "Canonical source: app/(tabs)/scripts.tsx", category: "tab", lines: 709 },
  { path: "app/(tabs)/serverSetup.tsx", description: "Canonical source: app/(tabs)/serverSetup.tsx", category: "tab", lines: 146 },
  { path: "app/(tabs)/settings.tsx", description: "Canonical source: app/(tabs)/settings.tsx", category: "tab", lines: 597 },
  { path: "app/(tabs)/tools.tsx", description: "Canonical source: app/(tabs)/tools.tsx", category: "tab", lines: 85 },
  { path: "app/+not-found.tsx", description: "Canonical source: app/+not-found.tsx", category: "layout", lines: 25 },
  { path: "app/category/[id].tsx", description: "Canonical source: app/category/[id].tsx", category: "layout", lines: 652 },
  { path: "app/crash-report.tsx", description: "Canonical source: app/crash-report.tsx", category: "layout", lines: 653 },
  { path: "app/data-safety.tsx", description: "Canonical source: app/data-safety.tsx", category: "layout", lines: 7 },
  { path: "app/legal.tsx", description: "Canonical source: app/legal.tsx", category: "layout", lines: 31 },
  { path: "app/privacy-policy.tsx", description: "Canonical source: app/privacy-policy.tsx", category: "layout", lines: 7 },
  { path: "app/security-trust.tsx", description: "Canonical source: app/security-trust.tsx", category: "layout", lines: 317 },
  { path: "app/terms.tsx", description: "Canonical source: app/terms.tsx", category: "layout", lines: 7 },
  { path: "components/LegalDocView.tsx", description: "Canonical source: components/LegalDocView.tsx", category: "component", lines: 47 },
  { path: "components/ui/AnimatedWire.tsx", description: "Canonical source: components/ui/AnimatedWire.tsx", category: "component", lines: 350 },
  { path: "components/ui/ButlerAtmosphere.tsx", description: "Canonical source: components/ui/ButlerAtmosphere.tsx", category: "component", lines: 40 },
  { path: "components/ui/ButlerAutoScaleText.tsx", description: "Canonical source: components/ui/ButlerAutoScaleText.tsx", category: "component", lines: 46 },
  { path: "components/ui/ButlerBackpackInventory.tsx", description: "Canonical source: components/ui/ButlerBackpackInventory.tsx", category: "component", lines: 42 },
  { path: "components/ui/ButlerBackpackShowcase.tsx", description: "Canonical source: components/ui/ButlerBackpackShowcase.tsx", category: "component", lines: 39 },
  { path: "components/ui/ButlerBackpackThankYou.tsx", description: "Canonical source: components/ui/ButlerBackpackThankYou.tsx", category: "component", lines: 24 },
  { path: "components/ui/ButlerBuildModeGuide.tsx", description: "Canonical source: components/ui/ButlerBuildModeGuide.tsx", category: "component", lines: 20 },
  { path: "components/ui/ButlerBuildModePanel.tsx", description: "Canonical source: components/ui/ButlerBuildModePanel.tsx", category: "component", lines: 172 },
  { path: "components/ui/ButlerCanvasControls.tsx", description: "Canonical source: components/ui/ButlerCanvasControls.tsx", category: "component", lines: 44 },
  { path: "components/ui/ButlerCanvasPreview.tsx", description: "Canonical source: components/ui/ButlerCanvasPreview.tsx", category: "component", lines: 21 },
  { path: "components/ui/ButlerDragonFlavorMoment.tsx", description: "Canonical source: components/ui/ButlerDragonFlavorMoment.tsx", category: "component", lines: 25 },
  { path: "components/ui/ButlerFX.tsx", description: "Canonical source: components/ui/ButlerFX.tsx", category: "component", lines: 578 },
  { path: "components/ui/ButlerGraphVariantRenderer.tsx", description: "Canonical source: components/ui/ButlerGraphVariantRenderer.tsx", category: "component", lines: 31 },
  { path: "components/ui/ButlerLoadingScreen.tsx", description: "Canonical source: components/ui/ButlerLoadingScreen.tsx", category: "component", lines: 74 },
  { path: "components/ui/ButlerMascotMotion.tsx", description: "Canonical source: components/ui/ButlerMascotMotion.tsx", category: "component", lines: 62 },
  { path: "components/ui/ButlerPageMascot.tsx", description: "Canonical source: components/ui/ButlerPageMascot.tsx", category: "component", lines: 22 },
  { path: "components/ui/ButlerMediaBlockEditor.tsx", description: "Canonical source: components/ui/ButlerMediaBlockEditor.tsx", category: "component", lines: 51 },
  { path: "components/ui/ButlerMicrocopy.tsx", description: "Canonical source: components/ui/ButlerMicrocopy.tsx", category: "component", lines: 20 },
  { path: "components/ui/ButlerPackageSpotlight.tsx", description: "Canonical source: components/ui/ButlerPackageSpotlight.tsx", category: "component", lines: 37 },
  { path: "components/ui/ButlerPageRecipeBadge.tsx", description: "Canonical source: components/ui/ButlerPageRecipeBadge.tsx", category: "component", lines: 22 },
  { path: "components/ui/ButlerPageStudioHost.tsx", description: "Canonical source: components/ui/ButlerPageStudioHost.tsx", category: "component", lines: 14 },
  { path: "components/ui/ButlerPageTokenControls.tsx", description: "Canonical source: components/ui/ButlerPageTokenControls.tsx", category: "component", lines: 28 },
  { path: "components/ui/ButlerProcessRibbon.tsx", description: "Canonical source: components/ui/ButlerProcessRibbon.tsx", category: "component", lines: 33 },
  { path: "components/ui/ButlerResponsiveFrame.tsx", description: "Canonical source: components/ui/ButlerResponsiveFrame.tsx", category: "component", lines: 17 },
  { path: "components/ui/ButlerShortcutBlockEditor.tsx", description: "Canonical source: components/ui/ButlerShortcutBlockEditor.tsx", category: "component", lines: 26 },
  { path: "components/ui/ButlerSignalIcon.tsx", description: "Canonical source: components/ui/ButlerSignalIcon.tsx", category: "component", lines: 48 },
  { path: "components/ui/ButlerStyleRecipePreview.tsx", description: "Canonical source: components/ui/ButlerStyleRecipePreview.tsx", category: "component", lines: 38 },
  { path: "components/ui/ButlerSurface.tsx", description: "Canonical source: components/ui/ButlerSurface.tsx", category: "component", lines: 82 },
  { path: "components/ui/ButlerTabIcons.tsx", description: "Canonical source: components/ui/ButlerTabIcons.tsx", category: "component", lines: 372 },
  { path: "components/ui/ButlerWordmark.tsx", description: "Canonical source: components/ui/ButlerWordmark.tsx", category: "component", lines: 37 },
  { path: "components/ui/CyberPanel.tsx", description: "Canonical source: components/ui/CyberPanel.tsx", category: "component", lines: 112 },
  { path: "components/ui/CovenantPreviewCard.tsx", description: "Canonical source: components/ui/CovenantPreviewCard.tsx", category: "component", lines: 90 },
  { path: "components/ui/ExternalEncryptionGuide.tsx", description: "Canonical source: components/ui/ExternalEncryptionGuide.tsx", category: "component", lines: 16 },
  { path: "components/ui/FuturisticTabBar.tsx", description: "Canonical source: components/ui/FuturisticTabBar.tsx", category: "component", lines: 366 },
  { path: "components/ui/GitHubUpdateBanner.tsx", description: "Canonical source: components/ui/GitHubUpdateBanner.tsx", category: "component", lines: 105 },
  { path: "components/ui/Guard.tsx", description: "Canonical source: components/ui/Guard.tsx", category: "component", lines: 107 },
  { path: "components/ui/ImmutableRulesCard.tsx", description: "Canonical source: components/ui/ImmutableRulesCard.tsx", category: "component", lines: 18 },
  { path: "components/ui/MicroCopy.tsx", description: "Canonical source: components/ui/MicroCopy.tsx", category: "component", lines: 58 },
  { path: "components/ui/OnboardingHeroStep.tsx", description: "Canonical source: components/ui/OnboardingHeroStep.tsx", category: "component", lines: 556 },
  { path: "components/ui/OnDemandDiagnosticsPanel.tsx", description: "Canonical source: components/ui/OnDemandDiagnosticsPanel.tsx", category: "component", lines: 40 },
  { path: "components/ui/OpportunityReviewCard.tsx", description: "Canonical source: components/ui/OpportunityReviewCard.tsx", category: "component", lines: 67 },
  { path: "components/ui/QuickButlerBar.tsx", description: "Canonical source: components/ui/QuickButlerBar.tsx", category: "component", lines: 492 },
  { path: "components/ui/ResearchCrawlerCard.tsx", description: "Canonical source: components/ui/ResearchCrawlerCard.tsx", category: "component", lines: 68 },
  { path: "components/ui/RemoteAccessSetupCard.tsx", description: "Canonical source: components/ui/RemoteAccessSetupCard.tsx", category: "component", lines: 49 },
  { path: "components/ui/SecurityShowcase.tsx", description: "Canonical source: components/ui/SecurityShowcase.tsx", category: "component", lines: 326 },
  { path: "components/ui/SelfLearningMemoryCard.tsx", description: "Canonical source: components/ui/SelfLearningMemoryCard.tsx", category: "component", lines: 24 },
  { path: "components/ui/ServerConsolePanel.tsx", description: "Canonical source: components/ui/ServerConsolePanel.tsx", category: "component", lines: 146 },
  { path: "components/ui/SkinHeaderFX.tsx", description: "Canonical source: components/ui/SkinHeaderFX.tsx", category: "component", lines: 125 },
  { path: "components/ui/TabErrorBoundary.tsx", description: "Canonical source: components/ui/TabErrorBoundary.tsx", category: "component", lines: 229 },
  { path: "constants/appSourceBundle.ts", description: "Canonical source: constants/appSourceBundle.ts", category: "constant", lines: 577 },
  { path: "constants/butlerDesign.ts", description: "Canonical source: constants/butlerDesign.ts", category: "constant", lines: 53 },
  { path: "constants/dataSafety.ts", description: "Canonical source: constants/dataSafety.ts", category: "constant", lines: 2 },
  { path: "constants/fxRotation.ts", description: "Canonical source: constants/fxRotation.ts", category: "constant", lines: 61 },
  { path: "constants/legalDocuments.ts", description: "Canonical source: constants/legalDocuments.ts", category: "constant", lines: 122 },
  { path: "constants/onboardingKeys.ts", description: "Canonical source: constants/onboardingKeys.ts", category: "constant", lines: 62 },
  { path: "constants/privacyPolicy.ts", description: "Canonical source: constants/privacyPolicy.ts", category: "constant", lines: 2 },
  { path: "constants/terms.ts", description: "Canonical source: constants/terms.ts", category: "constant", lines: 2 },
  { path: "constants/theme.ts", description: "Canonical source: constants/theme.ts", category: "constant", lines: 20 },
  { path: "constants/tokens.ts", description: "Canonical source: constants/tokens.ts", category: "constant", lines: 43 },
  { path: "contexts/CosmeticContext.tsx", description: "Canonical source: contexts/CosmeticContext.tsx", category: "constant", lines: 586 },
  { path: "contexts/LanguageContext.tsx", description: "Canonical source: contexts/LanguageContext.tsx", category: "constant", lines: 630 },
  { path: "contexts/PurchaseContext.tsx", description: "Canonical source: contexts/PurchaseContext.tsx", category: "constant", lines: 117 },
  { path: "contexts/TabBarContext.tsx", description: "Canonical source: contexts/TabBarContext.tsx", category: "constant", lines: 210 },
  { path: "docs/privacy-policy.html", description: "Canonical source: docs/privacy-policy.html", category: "layout", lines: 14 },
  { path: "hooks/useResponsiveLayout.ts", description: "Canonical source: hooks/useResponsiveLayout.ts", category: "service", lines: 50 },
  { path: "hooks/useSkin.ts", description: "Canonical source: hooks/useSkin.ts", category: "service", lines: 94 },
  { path: "metro.config.js", description: "Canonical source: metro.config.js", category: "constant", lines: 9 },
  { path: "services/aiLogger.ts", description: "Canonical source: services/aiLogger.ts", category: "service", lines: 280 },
  { path: "services/androidSafetyGuide.ts", description: "Canonical source: services/androidSafetyGuide.ts", category: "service", lines: 27 },
  { path: "services/autoConnectEngine.ts", description: "Canonical source: services/autoConnectEngine.ts", category: "service", lines: 501 },
  { path: "services/autoErrorLogger.ts", description: "Canonical source: services/autoErrorLogger.ts", category: "service", lines: 140 },
  { path: "services/automationEngine.ts", description: "Canonical source: services/automationEngine.ts", category: "service", lines: 212 },
  { path: "services/automationWatchdog.ts", description: "Canonical source: services/automationWatchdog.ts", category: "service", lines: 327 },
  { path: "services/biometricLock.ts", description: "Canonical source: services/biometricLock.ts", category: "service", lines: 110 },
  { path: "services/bootErrorLog.ts", description: "Canonical source: services/bootErrorLog.ts", category: "service", lines: 214 },
  { path: "services/bootGuard.tsx", description: "Canonical source: services/bootGuard.tsx", category: "service", lines: 250 },
  { path: "services/butlerAsk.ts", description: "Canonical source: services/butlerAsk.ts", category: "service", lines: 213 },
  { path: "services/butlerLanguage.ts", description: "Canonical source: services/butlerLanguage.ts", category: "service", lines: 58 },
  { path: "services/butlerScripts.ts", description: "Canonical source: services/butlerScripts.ts", category: "service", lines: 226 },
  { path: "services/capabilityIntentEnvelope.ts", description: "Canonical source: services/capabilityIntentEnvelope.ts", category: "service", lines: 72 },
  { path: "services/intentReceiptCovenant.ts", description: "Canonical source: services/intentReceiptCovenant.ts", category: "service", lines: 129 },
  { path: "services/connectionHub.ts", description: "Canonical source: services/connectionHub.ts", category: "service", lines: 576 },
  { path: "services/connectionPersistence.ts", description: "Canonical source: services/connectionPersistence.ts", category: "service", lines: 273 },
  { path: "services/cosmeticInventoryNames.ts", description: "Canonical source: services/cosmeticInventoryNames.ts", category: "service", lines: 11 },
  { path: "services/cosmeticProducts.ts", description: "Canonical source: services/cosmeticProducts.ts", category: "service", lines: 12 },
  { path: "services/cosmeticVariantRegistry.ts", description: "Canonical source: services/cosmeticVariantRegistry.ts", category: "service", lines: 127 },
  { path: "services/creatorBatchFactory.ts", description: "Canonical source: services/creatorBatchFactory.ts", category: "service", lines: 20 },
  { path: "services/creatorPresetBundles.ts", description: "Canonical source: services/creatorPresetBundles.ts", category: "service", lines: 20 },
  { path: "services/creatorVisualManufacturing.ts", description: "Canonical source: services/creatorVisualManufacturing.ts", category: "service", lines: 31 },
  { path: "services/designCatalogSync.ts", description: "Canonical source: services/designCatalogSync.ts", category: "service", lines: 47 },
  { path: "services/deviceIdentifier.ts", description: "Canonical source: services/deviceIdentifier.ts", category: "service", lines: 165 },
  { path: "services/encryptedStorage.ts", description: "Canonical source: services/encryptedStorage.ts", category: "service", lines: 344 },
  { path: "services/errorAutoFix.ts", description: "Canonical source: services/errorAutoFix.ts", category: "service", lines: 185 },
  { path: "services/errorPatternDetector.ts", description: "Canonical source: services/errorPatternDetector.ts", category: "service", lines: 387 },
  { path: "services/executionCounter.ts", description: "Canonical source: services/executionCounter.ts", category: "service", lines: 45 },
  { path: "services/executionHistory.ts", description: "Canonical source: services/executionHistory.ts", category: "service", lines: 48 },
  { path: "services/flowLedger.ts", description: "Canonical source: services/flowLedger.ts", category: "service", lines: 60 },
  { path: "services/frameBudgetMonitor.ts", description: "Canonical source: services/frameBudgetMonitor.ts", category: "service", lines: 132 },
  { path: "services/haptics.ts", description: "Canonical source: services/haptics.ts", category: "service", lines: 150 },
  { path: "services/heartbeatEngine.ts", description: "Canonical source: services/heartbeatEngine.ts", category: "service", lines: 208 },
  { path: "services/immutableSafetyPolicy.ts", description: "Canonical source: services/immutableSafetyPolicy.ts", category: "service", lines: 42 },
  { path: "services/jsonGuard.ts", description: "Canonical source: services/jsonGuard.ts", category: "service", lines: 369 },
  { path: "services/kbGrowthTracker.ts", description: "Canonical source: services/kbGrowthTracker.ts", category: "service", lines: 199 },
  { path: "services/knowledgeAccumulator.ts", description: "Canonical source: services/knowledgeAccumulator.ts", category: "service", lines: 653 },
  { path: "services/lanScanner.ts", description: "Canonical source: services/lanScanner.ts", category: "service", lines: 413 },
  { path: "services/layoutCustomization.ts", description: "Canonical source: services/layoutCustomization.ts", category: "service", lines: 237 },
  { path: "services/localVault.ts", description: "Canonical source: services/localVault.ts", category: "service", lines: 75 },
  { path: "services/memoryAdmission.ts", description: "Canonical source: services/memoryAdmission.ts", category: "service", lines: 62 },
  { path: "services/memoryIntegrityMonitor.ts", description: "Canonical source: services/memoryIntegrityMonitor.ts", category: "service", lines: 28 },
  { path: "services/memoryLearningEngine.ts", description: "Canonical source: services/memoryLearningEngine.ts", category: "service", lines: 70 },
  { path: "services/networkMonitor.ts", description: "Canonical source: services/networkMonitor.ts", category: "service", lines: 395 },
  { path: "services/neuralTripwire.ts", description: "Canonical source: services/neuralTripwire.ts", category: "service", lines: 285 },
  { path: "services/nexusCopyright.ts", description: "Canonical source: services/nexusCopyright.ts", category: "service", lines: 10 },
  { path: "services/onboardingState.ts", description: "Canonical source: services/onboardingState.ts", category: "service", lines: 133 },
  { path: "services/opportunityEngine.ts", description: "Canonical source: services/opportunityEngine.ts", category: "service", lines: 93 },
  { path: "services/otaUpdates.ts", description: "Canonical source: services/otaUpdates.ts", category: "service", lines: 249 },
  { path: "services/pageLayoutCustomization.ts", description: "Canonical source: services/pageLayoutCustomization.ts", category: "service", lines: 69 },
  { path: "services/pcClipboard.ts", description: "Canonical source: services/pcClipboard.ts", category: "service", lines: 94 },
  { path: "services/performanceGovernor.ts", description: "Canonical source: services/performanceGovernor.ts", category: "service", lines: 209 },
  { path: "services/personalMemory.ts", description: "Canonical source: services/personalMemory.ts", category: "service", lines: 197 },
  { path: "services/powerhouseImport.ts", description: "Canonical source: services/powerhouseImport.ts", category: "service", lines: 536 },
  { path: "services/privateDataPolicy.ts", description: "Canonical source: services/privateDataPolicy.ts", category: "service", lines: 83 },
  { path: "services/proofCarryingStatus.test.ts", description: "Canonical source: services/proofCarryingStatus.test.ts", category: "service", lines: 16 },
  { path: "services/proofCarryingStatus.ts", description: "Canonical source: services/proofCarryingStatus.ts", category: "service", lines: 36 },
  { path: "services/pythonAutomationKnowledge.ts", description: "Canonical source: services/pythonAutomationKnowledge.ts", category: "service", lines: 2269 },
  { path: "services/pythonDeveloperProtocol.test.ts", description: "Canonical source: services/pythonDeveloperProtocol.test.ts", category: "service", lines: 13 },
  { path: "services/pythonDeveloperProtocol.ts", description: "Canonical source: services/pythonDeveloperProtocol.ts", category: "service", lines: 44 },
  { path: "services/qrParser.ts", description: "Canonical source: services/qrParser.ts", category: "service", lines: 82 },
  { path: "services/remoteAccessTiers.ts", description: "Canonical source: services/remoteAccessTiers.ts", category: "service", lines: 394 },
  { path: "services/remoteConnectionPolicy.test.ts", description: "Canonical source: services/remoteConnectionPolicy.test.ts", category: "service", lines: 22 },
  { path: "services/remoteConnectionPolicy.ts", description: "Canonical source: services/remoteConnectionPolicy.ts", category: "service", lines: 54 },
  { path: "services/remoteSetupGuide.ts", description: "Canonical source: services/remoteSetupGuide.ts", category: "service", lines: 98 },
  { path: "services/runtimeErrorMonitor.ts", description: "Canonical source: services/runtimeErrorMonitor.ts", category: "service", lines: 908 },
  { path: "services/safeClipboard.ts", description: "Canonical source: services/safeClipboard.ts", category: "service", lines: 16 },
  { path: "services/scriptConcierge.test.ts", description: "Canonical source: services/scriptConcierge.test.ts", category: "service", lines: 22 },
  { path: "services/scriptConcierge.ts", description: "Canonical source: services/scriptConcierge.ts", category: "service", lines: 140 },
  { path: "services/scriptEvidencePipeline.ts", description: "Canonical source: services/scriptEvidencePipeline.ts", category: "service", lines: 26 },
  { path: "services/scriptExecutor.ts", description: "Canonical source: services/scriptExecutor.ts", category: "service", lines: 415 },
  { path: "services/scriptLibraryData.ts", description: "Canonical source: services/scriptLibraryData.ts", category: "service", lines: 210 },
  { path: "services/scriptLibraryExtensions.ts", description: "Canonical source: services/scriptLibraryExtensions.ts", category: "service", lines: 3154 },
  { path: "services/scriptLibraryPCCheck.ts", description: "Canonical source: services/scriptLibraryPCCheck.ts", category: "service", lines: 459 },
  { path: "services/scriptTypes.ts", description: "Canonical source: services/scriptTypes.ts", category: "service", lines: 15 },
  { path: "services/selfHealingSupervisor.test.ts", description: "Canonical source: services/selfHealingSupervisor.test.ts", category: "service", lines: 12 },
  { path: "services/selfHealingSupervisor.ts", description: "Canonical source: services/selfHealingSupervisor.ts", category: "service", lines: 149 },
  { path: "services/sentinel.ts", description: "Canonical source: services/sentinel.ts", category: "service", lines: 333 },
  { path: "services/serverConnection.ts", description: "Canonical source: services/serverConnection.ts", category: "service", lines: 755 },
  { path: "services/serverCrawler.ts", description: "Canonical source: services/serverCrawler.ts", category: "service", lines: 349 },
  { path: "services/serverFeatures.ts", description: "Canonical source: services/serverFeatures.ts", category: "service", lines: 91 },
  { path: "services/serverMetrics.ts", description: "Canonical source: services/serverMetrics.ts", category: "service", lines: 151 },
  { path: "services/smokeBeacon.ts", description: "Canonical source: services/smokeBeacon.ts", category: "service", lines: 121 },
  { path: "services/styleChatRecipes.ts", description: "Canonical source: services/styleChatRecipes.ts", category: "service", lines: 29 },
  { path: "services/stylePageRecipes.ts", description: "Canonical source: services/stylePageRecipes.ts", category: "service", lines: 49 },
  { path: "services/timerBus.ts", description: "Canonical source: services/timerBus.ts", category: "service", lines: 122 },
  { path: "services/transitionLibrary.ts", description: "Canonical source: services/transitionLibrary.ts", category: "service", lines: 29 },
  { path: "services/trustLabClient.ts", description: "Canonical source: services/trustLabClient.ts", category: "service", lines: 40 },
  { path: "services/trustTransparencyClient.ts", description: "Canonical source: services/trustTransparencyClient.ts", category: "service", lines: 34 },
  { path: "services/uiConfig.ts", description: "Canonical source: services/uiConfig.ts", category: "service", lines: 300 },
  { path: "services/vaultEnvelope.ts", description: "Canonical source: services/vaultEnvelope.ts", category: "service", lines: 40 },
  { path: "services/voiceLane.ts", description: "Canonical source: services/voiceLane.ts", category: "service", lines: 59 },
  { path: "services/voicePrivacy.ts", description: "Canonical source: services/voicePrivacy.ts", category: "service", lines: 37 },
];

// ─── Lightweight djb2 string hash ─────────────────────────────────────────────
function _djb2(str: string): string {
  let h = 5381;
  for (let i = 0; i < str.length; i++) {
    h = ((h << 5) + h) ^ str.charCodeAt(i);
    h = h | 0;
  }
  return Math.abs(h).toString(36);
}

/**
 * Compute a lightweight hash of ALL currently registered sources.
 * Sorted by path so key ordering does not affect the hash.
 */
export function computeSourceHash(): string {
  const sources = getBundleSources();
  const combined = Object.keys(sources)
    .sort()
    .map(k => k + '::' + _djb2(sources[k]))
    .join('|');
  return _djb2(combined + String(BUNDLE_MANIFEST.length));
}

// ─── Color palette reference ──────────────────────────────────────────────────
export const APP_PALETTE = {
  bg:      '#070A10',
  surface: '#111621',
  card:    '#0B0F17',
  border:  '#4A9EFF',
  NCX_BG:      '#0B0F17',
  NCX_SURFACE: '#0B0F17',
  NCX_BORDER:  '#4A9EFF',
  NCX_LIGHT:   'rgba(255,255,255,0.04)',
  teal:    '#2FE38A',
  cyan:    '#38D9E8',
  green:   '#2FE38A',
  purple:  '#A468FF',
  amber:   '#FFB43D',
  red:     '#FF4D5E',
  sigma:   '#A468FF',
  blue:    '#4A9EFF',
  yellow:  '#FFC94A',
  pink:    '#FF5FA8',
  text:    '#38D9E8',
  textBrt: '#4A9EFF',
};

// ─── DETAILED AI BUILDER PROMPT ───────────────────────────────────────────────
export const DETAILED_AI_PROMPT = `
# BUTLER AI — MASTER CODING PROMPT (V12 — UPDATED JUNE 2026)
# Stack: React Native 0.79.3 / Expo SDK 53 / Expo Router v5 / TypeScript / Hermes

## CRITICAL BANNED PACKAGES (cause black screen on APK install — NEVER use)
The following packages were REMOVED in v9 due to incompatible native auto-linking:
  • expo-clipboard         — use: safeSetClipboard/safeGetClipboard from services/safeClipboard.ts
  • expo-document-picker  — use: lazy require('expo-document-picker') inside function
  • expo-sharing          — use: import { Share } from 'react-native'
  • expo-linear-gradient  — use: react-native-svg LinearGradient
  • expo-image (in most components) — use only where already whitelisted
  • expo-av / expo-speech — use only expo-av for AUDIO (never for video)
  • expo-video (direct native module) — excluded from Android auto-linking

## PROTECTED SERVICES (never modify internals)
  services/serverConnection.ts — getIP(), getPort(), getToken(), connect()
  services/autoConnectEngine.ts — onEvent(), start(), stop()
  services/widgetStorage.ts — getForPage(), pin(), remove()
  services/haptics.ts — haptic feedback API
  services/knowledgeAccumulator.ts — KB compression
  services/butlerBridge.ts — bridge protocol
  services/lanScanner.ts — LAN auto-scan
  services/connectionPersistence.ts — connection state

## PROTECTED ASYNCSTORAGE KEYS (never rename)
  commandcube_server_ip / commandcube_server_port / commandcube_session_token
  @butler_pinned_widgets_v2 — widget storage
  @butler_onboarding_done_v2 — NEVER rename this key
  @clipboard_history_v1 — clipboard history
  @butler_export_hash_v1 — export change detection

## APP IDENTITY
  App: Butler AI: PC Automation | Package: com.butlerai.pc.automation
  Version: v9.x | Expo SDK: 53 | RN: 0.79.3 | Min Android: API 26 | Target: API 35
  AI Backend: Ollama local (qwen2.5-coder:7b) — ZERO cloud
  PC Bridge: butler_server.py v7.0 (Python, runs on user's PC, LAN only)
  Auth: HMAC-SHA256 token | Authorization: Bearer <token> header

## REACT NATIVE HARD RULES
  • Never use transformOrigin — use transform: [{ rotate: '45deg' }]
  • Never use inline gap on Views — use marginRight/marginBottom
  • Never use CSS units (px/em/rem/vw/vh) — RN uses unitless numbers
  • Never import react-native-web or browser APIs (window/document/localStorage)
  • Named exports only for screens — never default exports
  • Never use useLayoutEffect — SSR warning + Hermes timing bug
  • Never nest ScrollViews without nestedScrollEnabled
  • Never put VirtualizedLists inside ScrollView
  • FlatList keyExtractor must return string: keyExtractor={(item) => String(item.id)}
  • Every interval/timeout in useEffect MUST be cleared in cleanup return
  • All animations: useNativeDriver:true for transform/opacity; false for layout

## NCX CARD PATTERN (use for ALL cards)
  backgroundColor: '#0B0F17', borderWidth:1, borderColor:'#4A9EFF',
  borderLeftWidth:2, borderLeftColor:'<accent>',
  borderTopWidth:1, borderTopColor:'rgba(255,255,255,0.04)',
  borderRadius:12, elevation:3

## DESIGN PALETTE
  bg:#070A10  surface:#111621  card:#0B0F17
  NCX_BG:#0B0F17  NCX_BORDER:#4A9EFF
  teal:#2FE38A  cyan:#38D9E8  green:#2FE38A  purple:#A468FF
  sigma:#A468FF  blue:#4A9EFF  amber:#FFB43D  red:#FF4D5E
  yellow:#FFC94A  pink:#FF5FA8  text:#38D9E8  textBrt:#4A9EFF

## CLIPBOARD SAFE PATTERN (no expo-clipboard)
  import { safeSetClipboard, safeGetClipboard } from '@/services/safeClipboard';
  await safeSetClipboard(text);
  const text = await safeGetClipboard();

## SHARE SAFE PATTERN (no expo-sharing)
  import { Share } from 'react-native';
  await Share.share({ title: 'filename.txt', message: content });

## DOCUMENT PICKER SAFE PATTERN (use lazy require inside function only)
  const result = await require('expo-document-picker').getDocumentAsync({ ... });

## API FETCH PATTERN (always AbortController)
  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), 10000);
  const res = await fetch(url, { signal: ctrl.signal }).finally(() => clearTimeout(tid));

## NAVIGATION
  Use router.push('/(tabs)/knowledge') — group prefix required
  Tab switching: (global as any).__butlerSwitchTab?.('butler')
  QR modal: (global as any).__butlerHomeOpenQR?.()

## RETURN FORMAT
  Always return COMPLETE file content. Never partial diffs.
  Preserve ALL existing imports.
  Do not explain how to paste — just return code.

## RESTORE ORDER
  1. constants/HeaderConstants.ts   2. constants/theme.ts
  3. services/widgetStorage.ts      4. services/serverConnection.ts
  5. stubs/hermes-parser-plugin.js  6. metro.config.js
  7. app/(tabs)/_layout.tsx         8. app/_layout.tsx
  9. Each tab page                  10. components/ files
`;

// ─── Source file registry ─────────────────────────────────────────────────────
const _sourceFns: Record<string, () => string> = {};

// ─── Built-in constant sources ────────────────────────────────────────────────

function getHeaderConstantsSrc(): string {
  return [
    '/**',
    ' * BUTLER AI — ZERO-CREDIT HEADER CONSTANTS v2',
    ' * Edit text labels, subtitles, button labels, and accent colors here.',
    ' * All values consumed by CompactPageHeader / ButlerPageHeader components.',
    ' */',
    '',
    "export interface TabHeaderEntry {",
    "  title: string;",
    "  subtitle: string;",
    "  actionLabel: string;",
    "  actionIcon: string;",
    "  accentColor: string;",
    "}",
    '',
    "export const TAB_HEADER_ENTRIES: Record<string, TabHeaderEntry> = {",
    "  home: { title:'BUTLER HOME',      subtitle:'PC Automation · Command Center',       actionLabel:'QR SCAN',  actionIcon:'qr-code-scanner', accentColor:'#38D9E8' },",
    "  butler:    { title:'BUTLER AI',       subtitle:'Local Ollama · Private · Zero Cloud',  actionLabel:'CLEAR',    actionIcon:'delete-sweep',    accentColor:'#A468FF' },",
    "  scripts:   { title:'SCRIPTS',         subtitle:'Python Automation · Library',           actionLabel:'HISTORY',  actionIcon:'history',         accentColor:'#38D9E8' },",
    "  knowledge: { title:'KNOWLEDGE BASE',  subtitle:'SIGMA-NET · Live Crawler · KB Graph',  actionLabel:'SYNC',     actionIcon:'sync',            accentColor:'#FFB43D' },",
    "  fileshare: { title:'NET OPS',         subtitle:'LAN Scanner · Port Audit · Ping',      actionLabel:'REFRESH',  actionIcon:'refresh',         accentColor:'#38D9E8' },",
    "  logs:      { title:'PC INTEL',        subtitle:'Health · Cleaning · Automation',       actionLabel:'REFRESH',  actionIcon:'refresh',         accentColor:'#2FE38A' },",
    "  cosmetic:  { title:'SKINS',           subtitle:'Themes · Cosmetics · Customization',   actionLabel:'BROWSE',   actionIcon:'palette',         accentColor:'#FF5FA8' },",
    "  settings:  { title:'SYSTEM CONFIG',   subtitle:'App Settings · Preferences · Export',  actionLabel:'EXPORT',   actionIcon:'download',        accentColor:'#FF7A1F' },",
    "  terminal:  { title:'LIVE TERMINAL',   subtitle:'butler@terminal:~$',                    actionLabel:'CLEAR',    actionIcon:'delete-sweep',    accentColor:'#2FE38A' },",
    "  builder:   { title:'BUILDER',         subtitle:'Visual Node Pipeline · Drag & Build',  actionLabel:'CLEAR',    actionIcon:'delete-sweep',    accentColor:'#A468FF' },",
    "};",
    '',
    "export const CONN_COLORS = {",
    "  connected:    '#2FE38A',",
    "  disconnected: '#FF4D5E',",
    "};",
    '',
    "export const SPLASH_CONFIG = {",
    "  titleLine1:  'BUTLER',",
    "  titleLine2:  'AI',",
    "  tagline:     'PC AUTOMATION · COMMAND CENTER',",
    "  bootText:    'INITIALIZING SYSTEMS...',",
    "  versionBadge:'v9.x · ANDROID · LOCAL AI',",
    "  accentColor: '#38D9E8',",
    "};",
  ].join('\n');
}

function getWidgetStorageSrc(): string {
  return [
    "/**",
    " * Widget Storage Service v2 — AsyncStorage CRUD for pinned widgets",
    " * Safe: no banned packages.",
    " */",
    "import AsyncStorage from '@react-native-async-storage/async-storage';",
    '',
    "const STORAGE_KEY = '@butler_pinned_widgets_v2';",
    '',
    "export type WidgetPlacement = 'floating' | 'inline-top' | 'inline-middle' | 'inline-bottom';",
    '',
    "export interface PinnedWidget {",
    "  id: string;",
    "  pageId: string;",
    "  label: string;",
    "  code: string;",
    "  placement: WidgetPlacement;",
    "  x: number;",
    "  y: number;",
    "  height?: number;",
    "  createdAt: string;",
    "}",
    '',
    "async function loadAll(): Promise<PinnedWidget[]> {",
    "  try {",
    "    const raw = await AsyncStorage.getItem(STORAGE_KEY);",
    "    if (raw) return JSON.parse(raw) as PinnedWidget[];",
    "    return [];",
    "  } catch { return []; }",
    "}",
    '',
    "async function saveAll(widgets: PinnedWidget[]): Promise<void> {",
    "  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(widgets));",
    "}",
    '',
    "export const widgetStorage = {",
    "  async getForPage(pageId: string): Promise<PinnedWidget[]> {",
    "    const all = await loadAll();",
    "    return all.filter(w => w.pageId === pageId);",
    "  },",
    "  async pin(widget: Omit<PinnedWidget, 'id' | 'createdAt'>): Promise<PinnedWidget> {",
    "    const all = await loadAll();",
    "    const nw: PinnedWidget = { ...widget, id: 'widget_' + Date.now(), createdAt: new Date().toISOString() };",
    "    await saveAll([...all, nw]);",
    "    return nw;",
    "  },",
    "  async updateCode(id: string, code: string, label?: string): Promise<void> {",
    "    const all = await loadAll();",
    "    await saveAll(all.map(w => w.id === id ? { ...w, code, ...(label ? { label } : {}) } : w));",
    "  },",
    "  async updateHeight(id: string, height: number): Promise<void> {",
    "    const all = await loadAll();",
    "    await saveAll(all.map(w => w.id === id",
    "      ? { ...w, height: height > 0 ? Math.max(60, Math.round(height)) : undefined }",
    "      : w));",
    "  },",
    "  async remove(id: string): Promise<void> {",
    "    const all = await loadAll();",
    "    await saveAll(all.filter(w => w.id !== id));",
    "  },",
    "  async getAll(): Promise<PinnedWidget[]> { return loadAll(); },",
    "  async clearAll(): Promise<void> { await AsyncStorage.removeItem(STORAGE_KEY); },",
    "};",
  ].join('\n');
}

function getHermesPluginSrc(): string {
  return [
    "/**",
    " * stubs/hermes-parser-plugin.js",
    " * Replacement for babel-plugin-syntax-hermes-parser.",
    " * Only adds flow + flowComments parser plugins — no parserOverride.",
    " * Redirect wired in metro.config.js and both node_modules copies.",
    " */",
    "'use strict';",
    "module.exports = function hermesParserPlugin(api) {",
    "  if (!api || !api.assertVersion) return {};",
    "  try { api.assertVersion(7); } catch (_) {}",
    "  return {",
    "    name: 'syntax-hermes-parser-stub',",
    "    manipulateOptions: function(opts, parserOpts) {",
    "      if (!parserOpts) return;",
    "      if (!Array.isArray(parserOpts.plugins)) parserOpts.plugins = [];",
    "      var plugins = parserOpts.plugins;",
    "      if (!plugins.includes('flow')) plugins.push('flow');",
    "      if (!plugins.includes('flowComments')) plugins.push('flowComments');",
    "    },",
    "  };",
    "};",
  ].join('\n');
}

// Register built-in sources
_sourceFns['constants/HeaderConstants.ts'] = getHeaderConstantsSrc;
_sourceFns['services/widgetStorage.ts']    = getWidgetStorageSrc;
_sourceFns['stubs/hermes-parser-plugin.js'] = getHermesPluginSrc;

// ─── Public API ───────────────────────────────────────────────────────────────

/** Register a tab/component source at runtime (called from tabSourcesBundle.ts) */
export function registerTabSource(path: string, source: string): void {
  _sourceFns[path] = () => source;
}

/** Get all registered sources as a plain object (safe for JSON.stringify) */
export function getBundleSources(): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [path, fn] of Object.entries(_sourceFns)) {
    try { out[path] = fn(); } catch (e) { out[path] = '[source load error: ' + String(e) + ']'; }
  }
  return out;
}

/** Legacy compat: BUNDLE_SOURCES[path] dot/bracket access */
export const BUNDLE_SOURCES: Record<string, string> = new Proxy(
  {} as Record<string, string>,
  {
    get(_t, prop: string) {
      const fn = _sourceFns[prop];
      if (fn) { try { return fn(); } catch { return '[error]'; } }
      return undefined;
    },
    has(_t, prop: string) { return prop in _sourceFns; },
    ownKeys() { return Object.keys(_sourceFns); },
    getOwnPropertyDescriptor(_t, prop: string) {
      if (prop in _sourceFns) {
        let v: string;
        try { v = _sourceFns[prop](); } catch { v = '[error]'; }
        return { configurable: true, enumerable: true, writable: false, value: v };
      }
      return undefined;
    },
  }
);

// ─── Build JSON export ────────────────────────────────────────────────────────
/**
 * Returns a plain JS object safe for JSON.stringify.
 * GUARD: All content stored as JS strings — JSON.stringify handles
 *        backslashes, quotes, newlines, and all special chars automatically.
 */
export function buildExportJson(): Record<string, unknown> {
  const sources = getBundleSources();

  const obj: Record<string, unknown> = {
    _meta: {
      exportedAt:     new Date().toISOString(),
      appName:        'Butler AI — PC Automation',
      version:        'v9.x',
      packageId:      'com.butlerai.pc.automation',
      totalFiles:     BUNDLE_MANIFEST.length,
      embeddedFiles:  Object.keys(sources).length,
      stack:          'React Native 0.79.3 / Expo SDK 53 / Expo Router v5 / TypeScript / Hermes',
      targetPlatform: 'Android API 35 (min API 26 / Android 8.0)',
      aiEngine:       'Ollama local (qwen2.5-coder:7b) — no cloud',
      builtIn:        'OnSpace.ai App Builder',
      palette:        APP_PALETTE,
      aiBuilderGuide: DETAILED_AI_PROMPT,
      bannedPackages: [
        'expo-clipboard — REMOVED: black screen on APK install; use RN Clipboard',
        'expo-document-picker — REMOVED: black screen on APK install; use lazy require inside function',
        'expo-sharing — REMOVED: black screen on APK install; use RN Share',
        'expo-linear-gradient — REMOVED: black screen on APK install; use react-native-svg LinearGradient',
        'expo-av — REMOVED for audio/video combo; use expo-av for audio only',
        'expo-video native module — excluded from Android auto-linking in react-native.config.js',
        'react-native-reanimated top-level import at module level — causes install() crash before native ready',
        'AbortSignal.timeout() — ES2022, not in Hermes; use AbortController + setTimeout instead',
      ],
      criticalFixes: [
        'constants/animations.ts: removed react-native-reanimated Proxy at module level (caused install() crash)',
        'All expo-clipboard static imports → replaced with RN Clipboard API',
        'All expo-document-picker static imports → replaced with lazy require() inside functions',
        'All expo-sharing static imports → replaced with RN Share',
        'All AbortSignal.timeout() → replaced with AbortController + setTimeout',
        'home.tsx: removed await import("expo-camera") dynamic import → uses QRCameraScanner component',
        'stubs/hermes-parser-plugin.js: removed parserOverride (caused metro-source-map invariant crash)',
        'metro.config.js: intercepts both babel-plugin-syntax-hermes-parser copies → stubs file',
        'app/(tabs)/_layout.tsx: removed isDone from useEffect dependency array (caused infinite bootstrap loop)',
      ],
      restorePrompt: [
        'You are an AI assistant inside OnSpace.ai (https://onspace.ai).',
        'Stack: React Native + Expo SDK 53 + TypeScript + Expo Router v5 + Hermes.',
        'This export is from Butler AI: PC Automation (com.butlerai.pc.automation) v9.x.',
        'READ THE bannedPackages AND criticalFixes IN _meta BEFORE MAKING ANY CHANGES.',
        'Always return COMPLETE file content — OnSpace.ai replaces entire files.',
        'Never return partial diffs. Preserve all imports.',
        'Protected: serverConnection, autoConnectEngine, widgetStorage, all services/ network code.',
        'To restore: use content from type:"source" files. For type:"manifest", use metadata + guide.',
      ].join(' '),
    },
  };

  // Embedded source files (full content)
  for (const [filePath, source] of Object.entries(sources)) {
    obj[filePath] = {
      type:    'source',
      content: source,
      lines:   source.split('\n').length,
      chars:   source.length,
    };
  }

  // Manifest-only entries
  for (const f of BUNDLE_MANIFEST) {
    if (!obj[f.path]) {
      obj[f.path] = {
        type:        'manifest',
        description: f.description,
        category:    f.category,
        lines:       f.lines,
        restoreHint: 'Ask OnSpace.ai to regenerate this file based on the aiBuilderGuide in _meta and the bannedPackages/criticalFixes lists.',
      };
    }
  }

  return obj;
}

// ─── Build clipboard text export ─────────────────────────────────────────────
export function buildAllFilesExport(): string {
  const sources = getBundleSources();
  const now = new Date().toLocaleString();
  const lines: string[] = [
    '// ╔══════════════════════════════════════════════════════════════════════════╗',
    '// ║  BUTLER AI — FULL APP SOURCE EXPORT v6.0 (BUG-FIXED)                  ║',
    `// ║  Generated: ${now.padEnd(57)}║`,
    '// ║  Stack: React Native · Expo Router v5 · TypeScript · Expo SDK 53       ║',
    '// ║  IMPORTANT: expo-clipboard/document-picker/sharing REMOVED             ║',
    '// ╚══════════════════════════════════════════════════════════════════════════╝',
    '',
    `// App: Butler AI: PC Automation — com.butlerai.pc.automation — v9.x`,
    `// Total files in project: ${BUNDLE_MANIFEST.length}`,
    `// Files with embedded source: ${Object.keys(sources).length}`,
    '',
    '// ═══ BANNED PACKAGES (black screen on APK install — NEVER re-add) ═══════',
    '// expo-clipboard       → use: import { Clipboard } from "react-native"',
    '// expo-document-picker → use: lazy require() inside function only',
    '// expo-sharing         → use: import { Share } from "react-native"',
    '// expo-linear-gradient → use: react-native-svg LinearGradient',
    '',
    '// ═══ CRITICAL FIXES APPLIED ══════════════════════════════════════════════',
    '// • constants/animations.ts: removed react-native-reanimated Proxy (install() crash)',
    '// • All static expo-clipboard/document-picker/sharing → RN equivalents',
    '// • All AbortSignal.timeout() → AbortController + setTimeout (Hermes safe)',
    '// • home.tsx: removed dynamic await import("expo-camera")',
    '// • stubs/hermes-parser-plugin.js: removed parserOverride',
    '// • app/(tabs)/_layout.tsx: removed isDone from useEffect deps (infinite loop)',
    '',
  ];

  lines.push('// ─── FILE MANIFEST ─────────────────────────────────────────────────────────');
  for (let i = 0; i < BUNDLE_MANIFEST.length; i++) {
    const f = BUNDLE_MANIFEST[i];
    const hasSrc = Boolean(sources[f.path]);
    lines.push(
      `// ${String(i + 1).padStart(2, '0')}. [${hasSrc ? '●SRC' : '○   '}] [${f.category.toUpperCase().padEnd(9)}] ${f.path.padEnd(45)} ~${f.lines}L`
    );
  }
  lines.push('// Legend: ● = full source embedded   ○ = manifest only');
  lines.push('');

  for (const promptLine of DETAILED_AI_PROMPT.split('\n')) {
    lines.push('// ' + promptLine);
  }

  lines.push('');
  for (const [path, source] of Object.entries(sources)) {
    lines.push(`// ${'═'.repeat(72)}`);
    lines.push(`// EMBEDDED SOURCE: ${path}`);
    lines.push(`// Lines: ${source.split('\n').length} · Chars: ${source.length}`);
    lines.push(`// ${'─'.repeat(72)}`);
    lines.push('');
    for (const srcLine of source.split('\n')) {
      lines.push('// ' + srcLine);
    }
    lines.push('');
  }

  lines.push('// ─── END OF BUTLER AI EXPORT v6.0 ──────────────────────────────────────────');
  lines.push(`// Exported: ${now}`);
  return lines.join('\n');
}
