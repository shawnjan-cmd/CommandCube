export { privacyPolicyText } from './legalDocuments';
