export const LEGAL_LAST_UPDATED = '2026-08-14';
export const LEGAL_CONTACT = 'andrejsladkovic1992@gmail.com';

export const privacyPolicyText = `BUTLER AI — PRIVACY POLICY
Last updated: ${LEGAL_LAST_UPDATED}

This policy describes the local-first Butler AI Android application, its user-operated Python server, and optional local Ollama connection. It is a product disclosure, not a promise that every user deployment or third-party integration has identical behavior. Review the actual release build, server configuration, and applicable law before publication.

1. WHO OPERATES THE DATA PATH
Butler is designed to run on the user's Android device and, when paired, the user's own PC. The developer does not operate a Butler cloud database, advertising network, data broker, or default cloud AI service for the local-only build.

2. WHAT THE APP MAY PROCESS
Depending on the features the user explicitly enables, Butler may process chat text, pairing identifiers, session credentials, selected scripts, TrustLab scan reports, local crash evidence, server activity returned by the paired PC, layout preferences, cosmetic entitlements, and files or images that the user explicitly selects for the local encrypted Vault. QR camera frames are used for pairing and are not intended to be retained. Optional voice features require a visible user action and the applicable platform permission.

3. WHERE DATA GOES
Chat text and selected context may be sent to the user's paired PC for local Ollama or server processing. TrustLab submissions may be sent to the paired PC for static analysis. User-selected vault files remain in the app-private local storage path by default. The app does not intentionally send private data to a developer-operated cloud, advertising service, analytics broker, or unknown destination. A remote transport, crawler, external integration, or third-party service configured by the user can create additional recipients and must be reviewed separately.

4. ENCRYPTION AND MEMORY
Sensitive app records use authenticated encryption and a versioned BUTLER Language envelope. The BUTLER Language is a tamper-evident format layer and is not security by obscurity. The security boundary is authenticated encryption and protected key handling. The local Vault uses a compartmentalized per-file envelope with a random data key, an encrypted key wrap, a fresh nonce, and an integrity digest. No application can guarantee protection from a rooted, unlocked, fully compromised, or physically controlled device.

5. TRUST LAB AND LEARNING
TrustLab performs defensive static analysis and fail-closed policy checks. It does not execute submitted scripts during scanning. The self-learning profile stores aggregate admission outcomes and provenance digests, not raw candidate script text. A green or verified state is shown only after a real report is received; otherwise the UI must show UNSCANNED, UNAVAILABLE, REVIEW, or BLOCKED.

6. DIAGNOSTICS
Crash evidence and paired-server logs are loaded on demand when the user opens the diagnostics surface. Butler does not require a continuously running developer telemetry loop. Local diagnostics are not automatically uploaded to the developer.

7. PERMISSIONS
The build may use internet access for communication with the user's paired PC and camera access for explicit QR pairing. File access is user-selected through the Android picker for the local Vault. Microphone access, if shipped, must be visible, user-started, cancellable, and declared according to the final Android and Play configuration. Butler does not implement covert recording, secret phrase listeners, silent SMS, hidden police calls, or silent remote wiping.

8. RETENTION AND DELETION
Retention depends on the local app and paired-server configuration. Users can clear app-local chat, memory, pairing data, settings, vault entries, and local diagnostics where the corresponding controls are provided. Data already retained on the paired PC, a backup, or a user-configured remote endpoint must be deleted through that system separately. Uninstalling an app is not a promise that every PC or backup copy disappears.

9. CONTACT
Privacy questions, correction requests, and publication updates: ${LEGAL_CONTACT}.
`;

export const termsText = `BUTLER AI — TERMS OF SERVICE
Last updated: ${LEGAL_LAST_UPDATED}

1. ACCEPTANCE
By installing or using Butler AI, you agree to use it lawfully, respect other people and systems, and review the permissions and server configuration before connecting sensitive data.

2. USER-CONTROLLED SYSTEM
Butler is a tool for a user-operated Android client and optional user-operated PC server. The user is responsible for the operating system, accounts, firewall, Ollama installation, network exposure, remote transport, backups, scripts, and third-party services they configure.

3. SAFE EXECUTION
Scripts and automation are not automatically safe because they are written in Python or displayed in a library. TrustLab is a defensive static scanner, not a guarantee. Users must review evidence, origins, capabilities, downloads, and requested side effects before execution. Untrusted code must fail closed.

4. PROHIBITED USE
Do not use Butler to steal credentials, deploy malware, bypass access controls, evade law enforcement, conduct harassment, perform unauthorized surveillance, or cause harm. Butler's immutable safety boundaries are intended to block unsafe side effects, but no software can make a compromised device or user-controlled server universally safe.

5. REAL-DATA DISCLOSURE
Operational components must use real local or paired-server evidence or clearly show an unavailable state. Showcase, fake, seeded, placeholder, or fabricated operational metrics must not be presented as live results.

6. USER CONTENT
The user retains responsibility for scripts, prompts, files, images, chat content, and other material they enter or select. Do not place secrets into an untrusted server, third-party integration, or public repository.

7. AVAILABILITY AND CHANGES
Features can vary by Android version, manufacturer, server version, model availability, network configuration, and applicable platform policy. Legal text and safety controls may be updated to reflect actual releases.

8. NO GUARANTEE
Butler is provided without a promise of uninterrupted operation, perfect malware detection, guaranteed emergency response, or recovery from a compromised device. Emergency assistance must use the user's local emergency services and visible system actions.

9. CONTACT
Questions about these terms: ${LEGAL_CONTACT}.
`;

export const dataSafetyText = `BUTLER AI — DATA SAFETY DISCLOSURE
Last updated: ${LEGAL_LAST_UPDATED}

Use the final release manifest and actual Play Console declarations as the source of truth. This document is a preparation guide and must be reconciled with the exact binary before submission.

DATA THAT MAY BE PROCESSED
• Other in-app messages: chat text may be sent to the user's paired PC and local Ollama when Butler AI is used.
• Device or other IDs: pairing identifiers may be stored locally and sent to the user's paired PC for authentication.
• Files and documents: images or documents may be selected by the user for the local encrypted Vault.
• App information and performance: local crash evidence and diagnostics may be stored for user inspection; they are not sent to developer telemetry by default.
• Audio: only if the optional voice lane is included in the final build, after visible user action and permission.
• Camera: used for explicit QR pairing; camera frames are not intended to be retained.

SHARING AND DESTINATIONS
The local-only build does not intentionally share Butler content with developer-operated advertising, analytics, data-broker, or cloud-AI services. User-configured remote transports, crawlers, and third-party integrations can change the destination and must be disclosed separately.

SECURITY
Sensitive local records use authenticated encryption. The Vault uses a layered per-file envelope and integrity digest. The paired PC connection uses the project's pairing and transport controls. These measures do not guarantee protection from a rooted, unlocked, compromised, or physically controlled device.

DELETION
The app provides user controls for applicable local chat, memory, pairing, settings, Vault entries, and diagnostic records. Paired-PC and backup data require separate deletion through those systems.

PLAY CONSOLE CHECK
Do not select “no data collected” merely because there is no developer cloud. Data sent to a user's own paired PC can still be relevant to the platform's disclosure questions. Verify collection, sharing, encryption, optionality, retention, account deletion, microphone, camera, and file behavior against the final manifest and runtime.
`;

export const deletionText = `BUTLER AI — DATA DELETION AND RESET
Last updated: ${LEGAL_LAST_UPDATED}

Use the in-app reset controls whenever available. Before resetting, disconnect the paired PC and export only what you intentionally want to keep.

APP-LOCAL RESET
1. Clear chat history from the Butler AI screen.
2. Clear memory and knowledge records from Settings where provided.
3. Delete Vault entries individually or use the Vault reset control when provided.
4. Clear local diagnostics and pairing credentials where provided.
5. Uninstalling Butler removes app-private Android storage according to Android behavior, but it does not erase PC, backup, or remote copies.

PAIRED-PC RESET
Use the server's own controls to remove scripts, receipts, logs, chat context, memory, and server keys. Review backup folders and operating-system recycle bins separately.

REMOTE OR THIRD-PARTY RESET
A user-configured remote endpoint, external encryption tool, cloud backup, or third-party integration has its own deletion process. Butler does not silently control those systems and cannot promise that deleting an app-local record deletes every copy.

HELP
For a deletion question or correction request, contact ${LEGAL_CONTACT}. Do not email passwords, private keys, recovery phrases, or unencrypted Vault files.
`;

export const legalDocuments = Object.freeze({
  privacy: privacyPolicyText,
  terms: termsText,
  safety: dataSafetyText,
  delete: deletionText,
});
