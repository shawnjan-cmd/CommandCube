export { dataSafetyText } from './legalDocuments';
