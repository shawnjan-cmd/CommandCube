import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const skip = new Set(['node_modules', '.expo', '.git', '.android-build-check', 'scripts']);
const roots = ['app', 'components', 'services', 'constants', 'contexts', 'hooks'];
const files = [];
function walk(dir) { for (const entry of fs.readdirSync(dir, { withFileTypes: true })) { if (skip.has(entry.name)) continue; const full = path.join(dir, entry.name); if (entry.isDirectory()) walk(full); else if (/\.(ts|tsx|js|jsx|mjs|cjs)$/.test(entry.name)) files.push(path.relative(root, full).replaceAll(path.sep, '/')); } }
for (const dir of roots) if (fs.existsSync(path.join(root, dir))) walk(path.join(root, dir));
const bundle = fs.readFileSync(path.join(root, 'constants/appSourceBundle.ts'), 'utf8');
const registered = new Set([...bundle.matchAll(/path:\s*'([^']+)'/g)].map(m => m[1]));
const missing = files.filter(f => !registered.has(f)).sort();
const stale = [...registered].filter(f => !fs.existsSync(path.join(root, f))).sort();
console.log(JSON.stringify({ actualSourceCount: files.length, registeredCount: registered.size, missing, stale }, null, 2));
process.exitCode = stale.length ? 1 : 0;
