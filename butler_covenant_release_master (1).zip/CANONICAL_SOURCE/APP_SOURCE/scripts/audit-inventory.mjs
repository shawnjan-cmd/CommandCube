import fs from 'node:fs';
const source = fs.readFileSync('services/cosmeticVariantRegistry.ts', 'utf8');
const ids = [...source.matchAll(/item\(`([^`]+)`/g)].map(m => m[1]);
const sections = [...source.matchAll(/'([a-z-]+)'/g)].map(m => m[1]);
const duplicateIds = ids.filter((id, i) => ids.indexOf(id) !== i);
const required = ['security-tools', 'trust-evidence', 'diagnostics', 'vault'];
const missingSections = required.filter(section => !source.includes(`'${section}'`));
console.log(JSON.stringify({ itemTemplates: ids.length, duplicateIds, missingSections, newSectionCounts: Object.fromEntries(required.map(section => [section, (source.match(new RegExp(`'${section}'`, 'g')) || []).length])) }, null, 2));
if (duplicateIds.length || missingSections.length) process.exitCode = 1;
