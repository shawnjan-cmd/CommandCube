import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const manifestPath = path.join(root, 'constants/appSourceBundle.ts');
const skip = new Set(['node_modules', '.expo', '.git', '.android-build-check', 'scripts']);
const roots = ['app', 'components', 'services', 'constants', 'contexts', 'hooks'];
const sourceExt = /\.(ts|tsx|js|jsx|mjs|cjs)$/;
const lines = p => fs.readFileSync(path.join(root, p), 'utf8').split(/\r?\n/).length;
const files = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (skip.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (sourceExt.test(entry.name)) files.push(path.relative(root, full).replaceAll(path.sep, '/'));
  }
}
for (const dir of roots) if (fs.existsSync(path.join(root, dir))) walk(path.join(root, dir));

const original = fs.readFileSync(manifestPath, 'utf8');
const existing = [...original.matchAll(/\{ path:\s*'([^']+)'[^\n]*category:\s*'(tab|component|service|constant|layout)'[^\n]*\}/g)]
  .map(m => ({ path: m[1], category: m[2] }))
  .filter(item => fs.existsSync(path.join(root, item.path)));
const all = new Map(existing.map(item => [item.path, item]));
function categoryFor(p) {
  if (p.startsWith('app/(tabs)/')) return 'tab';
  if (p.startsWith('app/')) return 'layout';
  if (p.startsWith('components/')) return 'component';
  if (p.startsWith('services/')) return 'service';
  if (p.startsWith('contexts/')) return 'constant';
  if (p.startsWith('hooks/')) return 'service';
  return 'constant';
}
for (const p of files) if (!all.has(p)) all.set(p, { path: p, category: categoryFor(p) });
const entries = [...all.values()].sort((a, b) => a.path.localeCompare(b.path));
const block = `export const BUNDLE_MANIFEST: BundleFile[] = [\n${entries.map(item => `  { path: ${JSON.stringify(item.path)}, description: ${JSON.stringify(`Canonical source: ${item.path}`)}, category: ${JSON.stringify(item.category)}, lines: ${lines(item.path)} },`).join('\n')}\n];`;
const start = original.indexOf('export const BUNDLE_MANIFEST: BundleFile[] = [');
const end = original.indexOf('\n];', start);
if (start < 0 || end < 0) throw new Error('MANIFEST_BLOCK_NOT_FOUND');
const updated = original.slice(0, start) + block + original.slice(end + 3);
fs.writeFileSync(manifestPath, updated);
console.log(JSON.stringify({ registered: entries.length, removedMissing: existing.length - entries.filter(item => existing.some(old => old.path === item.path)).length, added: entries.filter(item => !existing.some(old => old.path === item.path)).length }, null, 2));
