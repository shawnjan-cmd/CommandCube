#!/usr/bin/env node
/**
 * BUTLER OnSpace Native Compatibility Audit
 *
 * This audit is intentionally conservative. It verifies the source boundary
 * rather than claiming that an Android device has been physically tested.
 * It rejects browser runtimes and web-only imports in shipped app source.
 */
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const sourceRoots = ['app', 'components', 'services', 'constants', 'hooks', 'stores', 'utils'];
const extensions = new Set(['.ts', '.tsx', '.js', '.jsx', '.mjs']);
const forbiddenImportPatterns = [
  /from\s*['"]react-dom(?:\/|['"])/,
  /from\s*['"]react-native-web(?:\/|['"])/,
  /from\s*['"]react-native-webview(?:\/|['"])/,
  /require\s*\(\s*['"](?:react-dom|react-native-web|react-native-webview)(?:\/|['"])/,
  /\bwindow\.(?:document|localStorage|sessionStorage|location|addEventListener)\b/,
  /\bdocument\.(?:createElement|querySelector|body)\b/,
];

const findings = [];
let filesScanned = 0;

function walk(dir) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === '.expo' || entry.name === 'android' || entry.name === 'ios') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (extensions.has(path.extname(entry.name))) {
      filesScanned += 1;
      const lines = fs.readFileSync(full, 'utf8').split(/\r?\n/);
      lines.forEach((line, index) => {
        if (forbiddenImportPatterns.some((pattern) => pattern.test(line))) {
          findings.push({ file: path.relative(root, full), line: index + 1, text: line.trim() });
        }
      });
    }
  }
}

for (const sourceRoot of sourceRoots) walk(path.join(root, sourceRoot));

const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (packageJson.scripts?.web) {
  findings.push({ file: 'package.json', line: null, text: 'A web start script is present; OnSpace delivery is native Android/Expo only.' });
}

const report = {
  generatedAt: new Date().toISOString(),
  method: 'BUTLER_ONSPACE_NATIVE_AUDIT_V1',
  sourceRoots,
  filesScanned,
  checks: {
    nativeSourceBoundary: { pass: findings.length === 0, findings },
    packageEntry: { pass: packageJson.main === 'expo-router/entry', main: packageJson.main },
    expoDependency: { pass: typeof packageJson.dependencies?.expo === 'string', version: packageJson.dependencies?.expo ?? null },
  },
  pass: findings.length === 0 && packageJson.main === 'expo-router/entry' && typeof packageJson.dependencies?.expo === 'string',
};

console.log(JSON.stringify(report, null, 2));
if (!report.pass) process.exitCode = 1;
