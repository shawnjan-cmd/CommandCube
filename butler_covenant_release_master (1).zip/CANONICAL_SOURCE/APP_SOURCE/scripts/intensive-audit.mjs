import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const reportPath = path.join(root, '..', 'INTENSIVE_AUDIT_REPORT.json');
const sourceRoots = ['app', 'components', 'constants', 'contexts', 'hooks', 'services', 'server'];
const extensions = /\.(ts|tsx|js|jsx|mjs|cjs|py|json|md)$/;
const forbiddenNativeTerms = [/\bwindow\.[A-Za-z_$]/, /\bdocument\.(?:getElementById|createElement|body|addEventListener|execCommand)/, /\blocalStorage\.(?:getItem|setItem|removeItem|clear)/, /<html[\s>]/i, /lovable/i, /Trusted Web Activity/i];
const fakeOperationalTerms = [/mock data/i, /fake metrics/i, /showcase data/i, /placeholder metrics/i, /seeded operational/i];
const covertTerms = [/enable[^\n]{0,80}secret phrase/i, /secret[^\n]{0,80}(listener|record|location)/i, /covert[^\n]{0,80}record/i, /silent[^\n]{0,80}(sms|call)/i, /automatic[^\n]{0,80}police/i, /remote[^\n]{0,80}wipe/i, /hidden background[^\n]{0,80}(record|location|microphone)/i];
const files = [];
function walk(dir) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.expo', '.git', '.android-build-check', '__pycache__'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (extensions.test(entry.name)) files.push(full);
  }
}
for (const rootName of sourceRoots) walk(path.join(root, rootName));
const read = file => fs.readFileSync(file, 'utf8');
const matches = (patterns, include = files) => include.flatMap(file => {
  const text = read(file);
  return patterns.flatMap(pattern => { const flags = pattern.flags.includes('g') ? pattern.flags : `${pattern.flags}g`; return [...text.matchAll(new RegExp(pattern.source, flags))].map(match => ({ file: path.relative(root, file), pattern: String(pattern), line: text.slice(0, match.index ?? 0).split(/\n/).length })); });
});
const manifest = read(path.join(root, 'constants/appSourceBundle.ts'));
const relative = file => path.relative(root, file).replaceAll(path.sep, '/');
const nativeRuntimeFiles = files.filter(file => /\.(ts|tsx)$/.test(file) && !['constants/appSourceBundle.ts', 'services/jsonGuard.ts', 'services/pythonAutomationKnowledge.ts', 'services/scriptLibraryExtensions.ts'].includes(relative(file)));
const emergencyRuntimeFiles = nativeRuntimeFiles.filter(file => !['constants/legalDocuments.ts', 'services/androidSafetyGuide.ts'].includes(relative(file)));
const registered = new Set([...manifest.matchAll(/path:\s*["']([^"']+)["']/g)].map(m => m[1]));
const appFiles = files.filter(f => ['app','components','constants','contexts','hooks','services'].some(r => f.startsWith(path.join(root, r))));
const relativeApp = appFiles.map(f => path.relative(root, f).replaceAll(path.sep, '/'));
const missingManifest = relativeApp.filter(f => !registered.has(f));
const staleManifest = [...registered].filter(f => !fs.existsSync(path.join(root, f)));
const inventory = read(path.join(root, 'services/cosmeticVariantRegistry.ts'));
const ids = [...inventory.matchAll(/item\(`([^`]+)`/g)].map(m => m[1]);
const duplicateIds = ids.filter((id, i) => ids.indexOf(id) !== i);
const appConfig = JSON.parse(read(path.join(root, 'app.json')));
const declaredPermissions = new Set(appConfig?.expo?.android?.permissions ?? []);
const permissionWarnings = ['android.permission.RECORD_AUDIO','android.permission.ACCESS_FINE_LOCATION','android.permission.ACCESS_BACKGROUND_LOCATION','android.permission.READ_SMS','android.permission.SEND_SMS','android.permission.FOREGROUND_SERVICE'].filter(p => declaredPermissions.has(p));
const report = {
  generatedAt: new Date().toISOString(),
  method: 'BUTLER_EVIDENCE_CASCADE_V1',
  sourceFileCount: files.length,
  checks: {
    manifest: { pass: missingManifest.length === 0 && staleManifest.length === 0, missing: missingManifest, stale: staleManifest },
    inventory: { pass: duplicateIds.length === 0, duplicateIds },
    nativeOnly: { pass: matches(forbiddenNativeTerms, nativeRuntimeFiles).length === 0, findings: matches(forbiddenNativeTerms, nativeRuntimeFiles) },
    realDataLanguage: { pass: matches(fakeOperationalTerms).length === 0, findings: matches(fakeOperationalTerms) },
    emergencyBoundary: { pass: matches(covertTerms, emergencyRuntimeFiles).length === 0, findings: matches(covertTerms, emergencyRuntimeFiles) },
    permissionBoundary: { pass: permissionWarnings.length === 0, warnings: permissionWarnings },
    immutablePolicy: { pass: /MEMORY_NO_PLAINTEXT/.test(read(path.join(root, 'services/immutableSafetyPolicy.ts'))) && /REAL_DATA_ONLY/.test(read(path.join(root, 'services/immutableSafetyPolicy.ts'))) && /NO_UNTRUSTED_SIDE_EFFECTS/.test(read(path.join(root, 'services/immutableSafetyPolicy.ts'))) && /REAL_DATA_ONLY/.test(read(path.join(root, 'server/immutable_policy.py'))) }
  }
};
report.pass = Object.values(report.checks).every(check => check.pass);
fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (!report.pass) process.exitCode = 1;
