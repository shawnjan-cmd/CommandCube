import fs from 'node:fs';
const file = new URL('../app/(tabs)/settings.tsx', import.meta.url);
const source = fs.readFileSync(file, 'utf8');
const start = source.indexOf('// ─── VS Code-style IDE HTML builder');
const end = source.indexOf('const IDEExportPanel =', start);
if (start < 0 || end < 0) throw new Error('EMBEDDED_WEB_IDE_MARKERS_NOT_FOUND');
const replacement = `// Native-only source export surface. The previous browser IDE implementation was removed\n// because Butler is a React Native/Expo app and must not embed HTML, DOM, or browser storage.\n\n`;
fs.writeFileSync(file, source.slice(0, start) + replacement + source.slice(end));
console.log('REMOVED_EMBEDDED_WEB_IDE');
