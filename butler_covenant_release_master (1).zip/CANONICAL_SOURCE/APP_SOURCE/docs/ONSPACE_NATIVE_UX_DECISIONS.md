# Butler AI OnSpace Native UX Decisions

## Delivery contract

Butler AI is delivered as a **React Native/Expo Android application** with a local/self-hosted Python server. OnSpace.ai must receive the native project source and must not be given a web wrapper, TWA, HTML IDE, browser-storage implementation, or a claim that a browser preview is the Android product.

The three immutable rules remain authoritative:

1. **Memory is never persisted in plaintext.**
2. **Every feature uses real evidence or shows `UNSCANNED`, `UNAVAILABLE`, or `FAILED CLOSED`.**
3. **Untrusted code cannot execute or change security state.**

## Supplied Secure Enclave recommendations

| Recommendation | Decision | Reason |
|---|---|---|
| Dark tactical visual system, phosphorescent accents, mechanical press feedback | Adopt, within existing cosmetic tokens | It is native, visual, and does not alter the trust boundary. Keep contrast and small-screen sizing accessible. |
| Reanimated transitions and haptic feedback | Adopt selectively | Use existing haptic service and bounded animations. Avoid continuous loops that waste battery or obscure status. |
| Fingerprint/biometric app entry | Reject as a requirement | The product requirement is password/security-key based and must not depend on half-functional biometric behavior. Optional OS authentication may be considered later only as an explicit opt-in fallback, never as the only unlock route. |
| Skia fingerprint mesh driven by touch coordinates | Reject | It is decorative security theater and can imply biometric verification that did not occur. |
| AI typewriter effect | Adapt | It may be used only for real received text. Do not fabricate scan output, model status, or operational logs. Include a reduced-motion and instant-render path. |
| Syntax highlighting and large-script virtualization | Adopt where already supported | Use native text/list rendering and bounded chunks. Do not add a custom C++/JSI module or WebAssembly solely for decoration. TrustLab remains server-side/offline AST evidence. |
| 10–15 second “security theater” scan | Reject | Deliberate fake waiting and mock addresses violate the real-data rule. Scans show actual progress, actual findings, or an honest unavailable state. |
| Mock memory addresses such as `0x992...` | Reject | Runtime evidence must never be invented. |
| Gyroscope parallax | Defer | It is not necessary for the security workflow and would add sensor/battery complexity. Revisit only as an opt-in cosmetic effect with a low-power fallback. |
| Dynamic Island integration | Reject for Android delivery | It is iOS-specific and not part of the OnSpace Android product contract. |
| Live network mesh representing CPU/network activity | Adapt narrowly | Only render measured paired-server metrics and label unavailable data. Never infer network activity from animation. |
| CoreHaptics | Reject for Android | Use the existing Expo-native haptics abstraction for Android-compatible feedback. |

## Native performance rules

Animations must be bounded, interruptible, and disabled or reduced when the screen is inactive, the user enables reduced motion, the device reports low power, or the animation is not conveying actual state. Continuous background polling is prohibited. Diagnostics and process visualization remain on demand or driven by paired-server evidence.

The OnSpace compatibility audit is `scripts/onspace-compat-audit.mjs`. It scans shipped native source for browser runtime imports and browser globals, verifies the Expo Router entry point, and verifies that Expo is declared. It is a source-boundary audit, not a substitute for a real Android device smoke test.

## Honest security language

Butler may say that a local vault is encrypted when the code path produces an authenticated encrypted envelope and the result is validated. It must not say “military-grade,” “unhackable,” “100% safe,” “mathematically malware-free,” or “nothing can leak.” TrustLab reports are evidence of the checks that ran, not proof that arbitrary code is harmless.
