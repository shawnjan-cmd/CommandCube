import { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LegalDocView } from '@/components/LegalDocView';
import { legalDocuments, LEGAL_LAST_UPDATED } from '@/constants/legalDocuments';
import { theme } from '@/constants/theme';

type DocKey = keyof typeof legalDocuments;
const CARDS: Array<{ key: DocKey; icon: string; title: string; subtitle: string; color: string }> = [
  { key: 'privacy', icon: 'file-lock-outline', title: 'PRIVACY POLICY', subtitle: 'What Butler processes, where it goes, and what stays local.', color: '#38D9E8' },
  { key: 'terms', icon: 'shield-check-outline', title: 'TERMS OF SERVICE', subtitle: 'Rules for safe, lawful, user-controlled automation.', color: '#FFB43D' },
  { key: 'safety', icon: 'database-check-outline', title: 'DATA SAFETY', subtitle: 'Play disclosure preparation grounded in the actual build.', color: '#2FE38A' },
  { key: 'delete', icon: 'delete-alert-outline', title: 'DELETE MY DATA', subtitle: 'App-local reset steps and paired-PC deletion boundaries.', color: '#FF5364' },
];

export default function LegalHubScreen() {
  const router = useRouter();
  const [selected, setSelected] = useState<DocKey | null>(null);
  if (selected) return <LegalDocView title={CARDS.find(card => card.key === selected)?.title ?? 'Legal'} body={legalDocuments[selected]} />;
  return <View style={s.safe}>
    <View style={s.header}><Pressable onPress={() => router.back()} style={s.back} accessibilityRole="button" accessibilityLabel="Back"><MaterialCommunityIcons name="chevron-left" size={28} color={theme.text} /></Pressable><View style={s.heading}><Text style={s.kicker}>PRIVACY · LEGAL</Text><Text style={s.title}>BUTLER POLICY HUB</Text><Text style={s.sub}>Always available · updated {LEGAL_LAST_UPDATED}</Text></View><MaterialCommunityIcons name="file-lock-outline" size={30} color="#38D9E8" /></View>
    <ScrollView contentContainerStyle={s.content}>
      <View style={s.notice}><MaterialCommunityIcons name="information-outline" size={21} color="#38D9E8" /><Text style={s.noticeText}>Read these documents before pairing a PC, enabling optional voice, importing Vault files, or publishing a remote endpoint. Butler shows unavailable evidence instead of pretending a feature is active.</Text></View>
      {CARDS.map(card => <Pressable key={card.key} onPress={() => setSelected(card.key)} style={[s.card, { borderColor: `${card.color}55` }]} accessibilityRole="button" accessibilityLabel={`Open ${card.title}`}><View style={[s.icon, { borderColor: `${card.color}88`, backgroundColor: `${card.color}12` }]}><MaterialCommunityIcons name={card.icon as any} size={27} color={card.color} /></View><View style={s.cardCopy}><Text style={[s.cardTitle, { color: card.color }]}>{card.title}</Text><Text style={s.cardSub}>{card.subtitle}</Text></View><MaterialCommunityIcons name="chevron-right" size={23} color="#6E8294" /></Pressable>)}
      <Text style={s.footer}>These documents describe the current local-first design. They are not a substitute for legal advice or a final review of the exact release build and jurisdiction.</Text>
    </ScrollView>
  </View>;
}
const s = StyleSheet.create({ safe: { flex: 1, backgroundColor: '#050810' }, header: { paddingTop: 16, paddingHorizontal: 14, paddingBottom: 14, flexDirection: 'row', alignItems: 'center', gap: 9, borderBottomWidth: 1, borderBottomColor: '#173044' }, back: { width: 34, height: 38, alignItems: 'center', justifyContent: 'center' }, heading: { flex: 1 }, kicker: { color: '#38D9E8', fontFamily: 'monospace', fontSize: 10, letterSpacing: 2, fontWeight: '900' }, title: { color: '#DDF5FF', fontFamily: 'monospace', fontSize: 19, fontWeight: '900', letterSpacing: 1.5, marginTop: 3 }, sub: { color: '#7990A2', fontFamily: 'monospace', fontSize: 8, marginTop: 4 }, content: { padding: 14, gap: 10, paddingBottom: 40 }, notice: { flexDirection: 'row', gap: 9, borderWidth: 1, borderColor: '#38D9E855', backgroundColor: '#38D9E80D', borderRadius: 12, padding: 12 }, noticeText: { flex: 1, color: '#B6CDD9', fontFamily: 'monospace', fontSize: 9, lineHeight: 14 }, card: { minHeight: 86, borderWidth: 1, backgroundColor: '#0B1320', borderRadius: 13, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 12 }, icon: { width: 48, height: 48, borderWidth: 1, borderRadius: 10, alignItems: 'center', justifyContent: 'center' }, cardCopy: { flex: 1 }, cardTitle: { fontFamily: 'monospace', fontSize: 12, fontWeight: '900', letterSpacing: 1.1 }, cardSub: { color: '#8AA0AF', fontFamily: 'monospace', fontSize: 8.5, lineHeight: 13, marginTop: 5 }, footer: { color: '#617585', fontFamily: 'monospace', fontSize: 8, lineHeight: 13, textAlign: 'center', marginTop: 8 } });
